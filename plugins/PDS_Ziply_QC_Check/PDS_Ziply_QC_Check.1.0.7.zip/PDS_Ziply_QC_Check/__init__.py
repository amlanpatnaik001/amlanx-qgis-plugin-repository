# -*- coding: utf-8 -*-
"""PDS Ziply QC Check QGIS plugin.

Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.
"""

def classFactory(iface):
    from .pds_ziply_qc_check import PDSZiplyQCCheck
    return PDSZiplyQCCheck(iface)
