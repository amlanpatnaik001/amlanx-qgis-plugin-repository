# -*- coding: utf-8 -*-
"""Legacy Span-only rule helper retained for source compatibility.

Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.

The active QC plugin uses field_rulebook_checks.py, which validates all 36
rows from the current workbook. This legacy helper is not called by runtime.
"""
from __future__ import print_function

import re

COPYRIGHT = "Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere"

# Values transcribed from PDS_Ziply_QC_Field_Rules_Template.xlsx.
# Field Name and Alias Name are both used for QGIS field resolution.
SPAN_FIELD_RULES = (
    {
        "layer": "Span",
        "field_name": "install_me",
        "alias_name": "Install Method",
        "expected_value": "Dir Bore",
        "allowed_values": ("Road Crossing",),
        "severity": "WARNING",
        "check_name": "Span Install Method",
    },
    {
        "layer": "Span",
        "field_name": "size",
        "alias_name": "Size",
        "expected_value": 2,
        "allowed_values": (),
        "severity": "WARNING",
        "check_name": "Span Size",
    },
)


def _clean_text(value):
    if value is None:
        return ""
    return " ".join(str(value).strip().split())


def _normal_text(value):
    return _clean_text(value).casefold()


def _matches_expected(value, expected):
    """Compare text values case-insensitively and numeric values numerically."""
    actual_text = _clean_text(value)
    expected_text = _clean_text(expected)
    if not actual_text:
        return False
    try:
        actual_num = float(actual_text.replace(",", ""))
        expected_num = float(expected_text.replace(",", ""))
        return actual_num == expected_num
    except (TypeError, ValueError, OverflowError):
        return _normal_text(actual_text) == _normal_text(expected_text)


def _resolve_field(plugin, layer, rule):
    # The helper checks both physical field names and QGIS layer aliases.
    candidates = [rule["field_name"], rule["alias_name"]]
    return plugin._field_by_candidates(layer, candidates)


def run_span_attribute_checks(plugin, scan_layers, findings):
    """Append the two current workbook-driven Span checks to the findings list.

    Accepted values for Install Method are Dir Bore (expected) and Road
    Crossing (allowed). Span Size must equal numeric 2. Both rules are Warning
    severity, as specified by the user's spreadsheet.
    """
    checked = 0
    for layer, role, _id_field, _hub_field in scan_layers:
        if role != "span":
            continue

        resolved = {}
        for rule in SPAN_FIELD_RULES:
            resolved[id(rule)] = _resolve_field(plugin, layer, rule)
            if not resolved[id(rule)]:
                plugin._issue(
                    findings,
                    rule["severity"],
                    layer.name(),
                    "—",
                    rule["check_name"] + " field",
                    rule["field_name"],
                    "",
                    "Configured Span QC field was not found by field name or alias ({}).".format(rule["alias_name"]),
                    "Confirm that the Span layer contains the configured field or QGIS alias.",
                )

        for feature in layer.getFeatures():
            for rule in SPAN_FIELD_RULES:
                field_name = resolved.get(id(rule))
                if not field_name:
                    continue
                checked += 1
                observed = feature.attribute(field_name)
                accepted_values = (rule["expected_value"],) + tuple(rule["allowed_values"])
                if any(_matches_expected(observed, accepted) for accepted in accepted_values):
                    continue

                accepted_label = " / ".join(_clean_text(item) for item in accepted_values)
                plugin._issue(
                    findings,
                    rule["severity"],
                    layer.name(),
                    feature.id(),
                    rule["check_name"],
                    field_name,
                    observed,
                    "Observed value is not permitted. Expected {}{}; found '{}'.".format(
                        _clean_text(rule["expected_value"]),
                        " (allowed: {})".format(", ".join(_clean_text(v) for v in rule["allowed_values"])) if rule["allowed_values"] else "",
                        _clean_text(observed) or "blank",
                    ),
                    "Accepted value(s): {}. Correct the attribute or verify the source data.".format(accepted_label),
                )
    return checked
