# -*- coding: utf-8 -*-
"""PDS Ziply QC Check — QGIS plugin.

Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere
"""
from __future__ import print_function

import csv
import os
import re
from itertools import islice
from collections import defaultdict
from datetime import datetime

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QIcon
try:  # QAction moved to QtGui in Qt 6 / PyQt6.
    from qgis.PyQt.QtGui import QAction
except ImportError:  # QGIS 3 / PyQt5
    from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QComboBox,
    QGroupBox,
    QHeaderView,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)
from qgis.core import QgsProject, QgsVectorLayer

from .report_export import export_reports
from .field_rulebook_checks import run_field_rulebook_checks


SCHEMAS = [
    "LEA HILL-AUBURN",
    "COVINGTON",
    "VANCOUVER LACAMAS",
    "AUBURN",
]
DPI_BY_SCHEMA = {
    "LEA HILL-AUBURN": "KEFTP",
    "COVINGTON": "KNFTP",
    "VANCOUVER LACAMAS": "V3FTP",
    "AUBURN": "XXFTP",
}

ID_FIELDS = ["infinium_id", "infiniumid", "infinium_id_value", "infinium"]
HUB_FIELDS = ["hub_number", "hubnumber", "hub_no", "hubno", "hub_num", "hubnum", "hub"]
CATEGORY_FIELDS = ["cable_category", "cablecategory", "category", "cable_cat"]
FIBER_COUNT_FIELDS = ["fiber_count", "fibercount", "fiber_counts", "fibercounts", "count", "counts"]
SIZE_FIELDS = ["cable_size", "cablesize", "fiber_size", "fibersize", "size"]
# Any layer nested anywhere beneath one of these layer-tree groups is excluded.
EXCLUDED_GROUP_NAMES = {
    "permitting",
    "utilities",
    "qclayers",
    "hld",
    "fieldinglayers",
    "boundaries",
}
EQUIPMENT_COUNT_FIELDS = [
    "equipment_count", "equipmentcount", "terminal_count", "terminalcount",
    "count_range", "countrange", "count", "counts", "terminal_range", "terminalrange",
]
FIBER_NAMING_FIELDS = ["naming", "cable_name", "cablename", "cable_naming", "cablenaming", "fiber_cable_name", "fibercablename", "name"]
EQUIPMENT_NAMING_FIELDS = [
    "equipment_name", "equipmentname", "naming", "equipment_naming", "equipmentnaming",
    "terminal_name", "terminalname", "name", "label", "description",
]

CABLE_COUNT_RE = re.compile(
    r"^\s*(H\d+)\s*,\s*(\d+)\s*-\s*(\d+)\s*,?\s*XD\s*,?\s*(\d+)\s*-\s*(\d+)\s*$",
    re.IGNORECASE,
)
EQUIPMENT_COUNT_RE = re.compile(r"^\s*(H\d+)\s*,\s*(\d+)\s*-\s*(\d+)\s*$", re.IGNORECASE)
EQUIPMENT_NAME_RE = re.compile(r"^\s*(\S+)\s+MT-H(\d+)\s*$", re.IGNORECASE)
SERIES_FULL_RE = re.compile(r"^\s*([A-Z])(\d*)\s*$", re.IGNORECASE)
SERIES_END_RE = re.compile(r"(?:^|[\s_:/-])([A-Z])(\d*)\s*$", re.IGNORECASE)


# Resolve scoped Qt enums in PyQt6 while retaining PyQt5 compatibility.
def _qt_enum(container, group_name, member_name):
    group = getattr(container, group_name, None)
    if group is not None and hasattr(group, member_name):
        return getattr(group, member_name)
    return getattr(container, member_name)


def _exec_dialog(dialog):
    """Call the supported modal-dialog execution method in Qt 5 or Qt 6."""
    method = getattr(dialog, "exec", None)
    if not callable(method):
        method = getattr(dialog, "exec_", None)
    if not callable(method):
        raise RuntimeError("This Qt binding does not provide a dialog exec method.")
    return method()


QC_DARK_STYLESHEET = """
QDialog {
    background-color: #0B1220;
    color: #E7F2FF;
}
QLabel {
    color: #DCEBFA;
}
QGroupBox {
    color: #39D4FF;
    border: 1px solid #284A68;
    border-radius: 7px;
    margin-top: 10px;
    padding: 10px 8px 8px 8px;
    font-weight: 600;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 5px;
}
QLineEdit, QComboBox, QTableWidget {
    background-color: #111E30;
    color: #E7F2FF;
    border: 1px solid #2D4F70;
    border-radius: 5px;
    padding: 5px;
    selection-background-color: #126B9C;
    selection-color: #FFFFFF;
}
QLineEdit:focus, QComboBox:focus {
    border: 1px solid #28D4FF;
}
QComboBox QAbstractItemView {
    background-color: #111E30;
    color: #E7F2FF;
    selection-background-color: #155A83;
    selection-color: #FFFFFF;
    border: 1px solid #2D4F70;
}
QPushButton {
    background-color: #123D60;
    color: #F3FBFF;
    border: 1px solid #168BC5;
    border-radius: 6px;
    padding: 7px 14px;
    font-weight: 600;
}
QPushButton:hover {
    background-color: #15547C;
    border: 1px solid #2BD8FF;
}
QPushButton:pressed {
    background-color: #0B2D49;
}
QPushButton:disabled {
    color: #71869A;
    background-color: #172536;
    border-color: #2B3B4B;
}
QHeaderView::section {
    background-color: #152B42;
    color: #55D9FF;
    border: 1px solid #294761;
    padding: 7px 5px;
    font-weight: 600;
}
QTableWidget {
    gridline-color: #29445E;
    alternate-background-color: #142337;
}
QTableWidget::item {
    color: #E2ECF8;
    padding: 4px;
}
QTableWidget::item:selected {
    background-color: #155D86;
    color: #FFFFFF;
}
QScrollBar:vertical, QScrollBar:horizontal {
    background: #0D1928;
    border: none;
    margin: 0;
}
QScrollBar::handle:vertical, QScrollBar::handle:horizontal {
    background: #315A7B;
    border-radius: 4px;
    min-height: 24px;
    min-width: 24px;
}
QScrollBar::handle:hover {
    background: #1DAEDC;
}
"""


class PDSZiplyQCCheck:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.last_findings = []
        self.last_schema = ""
        self.last_expected_id = ""
        self.last_expected_hub = ""
        self.last_stats = {}

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.svg")
        self.action = QAction(QIcon(icon_path), "PDS Ziply QC Check", self.iface.mainWindow())
        self.action.setToolTip("Validate Ziply telecom layers for PDS QC")
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&PDS Ziply QC Check", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu("&PDS Ziply QC Check", self.action)
            self.iface.removeToolBarIcon(self.action)

    def run(self):
        # All run parameters are collected together before any QC checks begin.
        setup = QCSetupDialog(self.iface.mainWindow())
        if _exec_dialog(setup) != _qt_enum(QDialog, "DialogCode", "Accepted"):
            return

        schema = setup.schema_combo.currentText()
        expected_id = setup.infinium_input.text().strip()
        expected_hub = self._normalize_hub_input(setup.hub_input.text())
        if not expected_id or not expected_hub:
            # Defensive validation; the setup dialog also validates before closing.
            QMessageBox.warning(self.iface.mainWindow(), "PDS Ziply QC Check", "Enter both Infinium ID and Hub Number.")
            return

        self.last_schema = schema
        self.last_expected_id = expected_id
        self.last_expected_hub = expected_hub
        self.last_findings, self.last_stats = self.perform_qc(schema, expected_id, expected_hub)
        results_dialog = ResultsDialog(
            self.iface.mainWindow(), schema, expected_id, expected_hub,
            self.last_findings, self.last_stats,
        )
        _exec_dialog(results_dialog)

    @staticmethod
    def _normalize_text(value):
        if value is None:
            return ""
        text = str(value).strip()
        if text.lower() in ("none", "null"):
            return ""
        return text

    @staticmethod
    def _norm(value):
        return re.sub(r"[^a-z0-9]", "", str(value or "").lower())

    @classmethod
    def _normalize_hub_input(cls, value):
        text = cls._normalize_text(value).upper().replace(" ", "")
        if not re.match(r"^H?\d+$", text):
            return ""
        digits = text[1:] if text.startswith("H") else text
        return "H" + digits

    @classmethod
    def _normalize_hub_value(cls, value):
        text = cls._normalize_text(value).upper()
        text = re.sub(r"\s+", "", text)
        if text.startswith("H"):
            text = text[1:]
        return text if re.match(r"^\d+$", text) else ""

    @staticmethod
    def _normalize_id(value):
        return PDSZiplyQCCheck._normalize_text(value).strip().upper()

    def _field_by_candidates(self, layer, candidates, contains=()):
        fields = list(layer.fields())
        normalized_fields = []
        for index, field in enumerate(fields):
            try:
                alias = layer.attributeAlias(index) or ""
            except Exception:
                alias = ""
            normalized_fields.append((field, self._norm(field.name()), self._norm(alias)))
        norms = [self._norm(c) for c in candidates]
        # QGIS stores field aliases on the layer, not reliably on QgsField objects.
        # Prefer exact field-name or layer-alias matches before loose fallbacks.
        for candidate in norms:
            for field, name_norm, alias_norm in normalized_fields:
                if name_norm == candidate or alias_norm == candidate:
                    return field.name()
        for hint in contains:
            hint_norm = self._norm(hint)
            for field, name_norm, alias_norm in normalized_fields:
                if hint_norm and (hint_norm in name_norm or hint_norm in alias_norm):
                    return field.name()
        return None

    def _layer_role(self, layer):
        name = self._norm(layer.name())
        if "equipment" in name:
            return "equipment"
        if "structure" in name:
            return "structures"
        if "span" in name:
            return "span"
        if "fibercable" in name or ("fiber" in name and "cable" in name):
            return "fiber_cable"
        if "slackloop" in name:
            return "slackloop"
        if "spliceclosure" in name:
            return "splice_closure"
        if "laborunit" in name or "labourunit" in name:
            return "labor_units"
        return "other"

    def _resolve_naming_field(self, layer, role):
        if role == "equipment":
            candidates = EQUIPMENT_NAMING_FIELDS
        else:
            candidates = FIBER_NAMING_FIELDS
        found = self._field_by_candidates(layer, candidates)
        if found:
            return found

        # Names can vary; try semantic field-name matches next.
        fields = list(layer.fields())
        if role == "equipment":
            for field in fields:
                n = self._norm(field.name())
                if ("equipment" in n and ("name" in n or "naming" in n)) or n in ("terminal", "terminalid"):
                    return field.name()
        else:
            for field in fields:
                n = self._norm(field.name())
                if ("cable" in n and ("name" in n or "naming" in n)) or n == "naming":
                    return field.name()

        # As a last resort, infer a likely string field from example values.
        excluded = ("infinium", "hub", "category", "count", "size", "status", "type", "mount", "uuid", "id")
        sample = list(islice(layer.getFeatures(), 40))
        best_field, best_score = None, 0
        for field in fields:
            if field.typeName().lower() not in ("string", "text", "varchar", "char"):
                continue
            fname = self._norm(field.name())
            if any(term in fname for term in excluded):
                continue
            score = 0
            for feature in sample:
                value = self._normalize_text(feature.attribute(field.name()))
                if not value:
                    continue
                if role == "equipment":
                    if "MT-H" in value.upper():
                        score += 1
                elif SERIES_FULL_RE.match(value) or SERIES_END_RE.search(value):
                    score += 1
            if score > best_score:
                best_field, best_score = field.name(), score
        return best_field if best_score else None

    def _issue(self, findings, severity, layer, fid, check, field, value, result, remark=""):
        findings.append({
            "severity": severity,
            "layer": layer,
            "feature_id": str(fid),
            "check": check,
            "field": field or "—",
            "observed_value": self._normalize_text(value),
            "result": result,
            "remark": remark,
        })

    @staticmethod
    def _excluded_layer_ids():
        """Return layer IDs nested under any explicitly excluded layer-tree group."""
        excluded_ids = set()
        try:
            root = QgsProject.instance().layerTreeRoot()
            layer_nodes = root.findLayers()
        except Exception:
            return excluded_ids

        for layer_node in layer_nodes:
            parent = layer_node.parent()
            while parent is not None:
                group_name = ""
                try:
                    name_method = getattr(parent, "name", None)
                    if callable(name_method):
                        group_name = name_method()
                except Exception:
                    group_name = ""
                if PDSZiplyQCCheck._norm(group_name) in EXCLUDED_GROUP_NAMES:
                    try:
                        excluded_ids.add(layer_node.layerId())
                    except Exception:
                        pass
                    break
                try:
                    parent = parent.parent()
                except Exception:
                    parent = None
        return excluded_ids

    @staticmethod
    def _is_size_one(value):
        """Treat numeric 1, 1.0 and equivalent textual values as Size = 1."""
        text = PDSZiplyQCCheck._normalize_text(value).replace(",", "")
        if not text:
            return False
        try:
            return float(text) == 1.0
        except (TypeError, ValueError, OverflowError):
            return False

    def perform_qc(self, schema, expected_id, expected_hub):
        findings = []
        dpi = DPI_BY_SCHEMA.get(schema, "")
        expected_hub_digits = self._normalize_hub_value(expected_hub)
        project = QgsProject.instance()
        excluded_ids = self._excluded_layer_ids()

        # Inspect every valid vector layer except layers under the six excluded groups.
        project_layers = [
            layer for layer in project.mapLayers().values()
            if isinstance(layer, QgsVectorLayer)
            and layer.isValid()
            and layer.id() not in excluded_ids
        ]

        scan_layers = []
        for layer in project_layers:
            role = self._layer_role(layer)
            id_field = self._field_by_candidates(layer, ID_FIELDS, contains=("infiniumid",))
            hub_field = self._field_by_candidates(layer, HUB_FIELDS, contains=("hubnumber",))
            scan_layers.append((layer, role, id_field, hub_field))

        try:
            project_file = project.fileName()
            project_name = os.path.basename(project_file) if project_file else "Unsaved QGIS project"
        except Exception:
            project_name = "QGIS project"

        stats = {
            "schema": schema,
            "dpi": dpi,
            "project_name": project_name,
            "project_vector_layers": len(project_layers),
            "excluded_layers": len(excluded_ids),
            "scanned_layers": len(scan_layers),
            "features_scanned": 0,
            "id_values_checked": 0,
            "hub_values_checked": 0,
            "id_field_layers": sum(1 for _, _, field, _ in scan_layers if field),
            "hub_field_layers": sum(1 for _, _, _, field in scan_layers if field),
            "specialized_checks": 0,
        }

        equipment_records = []
        fiber_series_records = []

        if not scan_layers:
            self._issue(
                findings, "WARNING", "Project", "—", "Layer discovery", "—", "",
                "No eligible vector layers remained after applying the excluded group list.",
                "Load the project vector layers outside Permitting, Utilities, QC Layers, HLD, Fielding Layers, and Boundaries."
            )
            stats["errors"] = 0
            stats["warnings"] = len(findings)
            stats["passed"] = False
            stats["layer_summaries"] = []
            return findings, stats

        layer_summaries = []
        for layer, role, id_field, hub_field in scan_layers:
            layer_name = layer.name()
            layer_detail = {
                "layer": layer_name,
                "role": role,
                "features_scanned": 0,
                "id_values_checked": 0,
                "hub_values_checked": 0,
                "specialized_checks": 0,
            }

            # Missing ID/Hub fields are only called out for recognized telecom layers.
            # Other eligible layers are still inspected for either field, but unrelated
            # layers do not create noise simply because they do not carry those attributes.
            if role != "other" and not id_field:
                self._issue(findings, "WARNING", layer_name, "—", "Infinium ID field", "—", "",
                            "No Infinium ID field detected.", "Add or rename the field so it can be checked.")
            if role != "other" and not hub_field:
                self._issue(findings, "WARNING", layer_name, "—", "Hub Number field", "—", "",
                            "No Hub Number field detected.", "Add or rename a hub-number field if this layer should carry one.")

            category_field = self._field_by_candidates(layer, CATEGORY_FIELDS, contains=("category",))
            name_field = None
            count_field = None
            size_field = None
            if role == "fiber_cable":
                # Resolve the Count field by its exact known names / aliases. A
                # broad 'contains count' fallback could accidentally select
                # an unrelated attribute field.
                count_field = self._field_by_candidates(layer, FIBER_COUNT_FIELDS)
                size_field = self._field_by_candidates(layer, SIZE_FIELDS, contains=("cablesize", "size"))
                name_field = self._resolve_naming_field(layer, role)
                if not count_field:
                    self._issue(findings, "WARNING", layer_name, "—", "Fiber Cable count field", "—", "",
                                "No Fiber Cable count field detected.", "Expected a field named Count, Fiber Count, or an equivalent alias.")
                if not name_field:
                    self._issue(findings, "WARNING", layer_name, "—", "Cable series field", "—", "",
                                "No cable naming / series field detected.", "Add or identify the field containing values such as A, B, A1, A2.")
            elif role == "equipment":
                count_field = self._field_by_candidates(layer, EQUIPMENT_COUNT_FIELDS, contains=("count", "range"))
                name_field = self._resolve_naming_field(layer, role)
                if not count_field:
                    self._issue(findings, "WARNING", layer_name, "—", "Equipment count field", "—", "",
                                "No Equipment count/range field detected.", "Expected a field with values such as H6005, 24-28.")
                if not name_field:
                    self._issue(findings, "WARNING", layer_name, "—", "Equipment naming field", "—", "",
                                "No Equipment naming field detected.", "Expected naming such as KNFTP MT-H5014033.")

            for feature in layer.getFeatures():
                fid = feature.id()
                stats["features_scanned"] += 1
                layer_detail["features_scanned"] += 1

                # Global Infinium ID check: evaluate wherever the field exists.
                if id_field:
                    stats["id_values_checked"] += 1
                    layer_detail["id_values_checked"] += 1
                    observed_id = self._normalize_text(feature.attribute(id_field))
                    if not observed_id:
                        self._issue(findings, "WARNING", layer_name, fid, "Infinium ID", id_field, observed_id,
                                    "Infinium ID is blank.", "RE-VERIFY")
                    elif self._normalize_id(observed_id) != self._normalize_id(expected_id):
                        if role in ("structures", "span") and category_field:
                            category_value = self._normalize_text(feature.attribute(category_field))
                            category_norm = re.sub(r"[^A-Z0-9]", "", category_value.upper())
                            if category_norm in ("F1", "F2", "F1F2", "F1ANDF2"):
                                self._issue(findings, "WARNING", layer_name, fid, "Infinium ID / category exception",
                                            id_field, observed_id,
                                            "ID differs from the requested value; category is {}.".format(category_value),
                                            "RE-VERIFY")
                            else:
                                self._issue(findings, "ERROR", layer_name, fid, "Infinium ID", id_field, observed_id,
                                            "Infinium ID does not match the requested value; category is {}.".format(category_value or "blank"),
                                            "Check the ID and category, then correct or re-verify.")
                        elif role in ("structures", "span") and not category_field:
                            self._issue(findings, "ERROR", layer_name, fid, "Infinium ID", id_field, observed_id,
                                        "Infinium ID differs and no category/cable_category field was found for the exception check.",
                                        "RE-VERIFY the ID and add/check the category field.")
                        else:
                            self._issue(findings, "ERROR", layer_name, fid, "Infinium ID", id_field, observed_id,
                                        "Infinium ID does not match the requested value.",
                                        "Correct the ID or verify the selected schema / ID.")

                # Global Hub Number check: evaluate wherever the field exists.
                if hub_field:
                    stats["hub_values_checked"] += 1
                    layer_detail["hub_values_checked"] += 1
                    observed_hub = self._normalize_text(feature.attribute(hub_field))
                    observed_hub_digits = self._normalize_hub_value(observed_hub)
                    if not observed_hub:
                        self._issue(findings, "WARNING", layer_name, fid, "Hub Number", hub_field, observed_hub,
                                    "Hub Number is blank.", "RE-VERIFY")
                    elif observed_hub_digits != expected_hub_digits:
                        self._issue(findings, "ERROR", layer_name, fid, "Hub Number", hub_field, observed_hub,
                                    "Hub Number does not match the requested hub {}.".format(expected_hub),
                                    "Correct the hub number or verify the selected project/schema.")

                if role == "fiber_cable" and count_field:
                    stats["specialized_checks"] += 1
                    layer_detail["specialized_checks"] += 1
                    value = self._normalize_text(feature.attribute(count_field))
                    if not value:
                        size_value = self._normalize_text(feature.attribute(size_field)) if size_field else ""
                        # A blank Fiber Count is an allowed exception only when Size == 1.
                        if not self._is_size_one(size_value):
                            size_display = size_value if size_value else "unknown / unavailable"
                            self._issue(
                                findings, "WARNING", layer_name, fid, "Fiber Cable count format",
                                count_field, value,
                                "Fiber Count is blank and cable Size is {}.".format(size_display),
                                "Blank Fiber Count is allowed only when cable Size = 1; verify the Size and Count values."
                            )
                    else:
                        match = CABLE_COUNT_RE.match(value)
                        if not match:
                            self._issue(findings, "ERROR", layer_name, fid, "Fiber Cable count format", count_field, value,
                                        "Expected format like H6033, 1-10 XD, 11-48 (also accepts H3109, 13-82, XD 11-48).",
                                        "Check the H-hub prefix, commas, XD marker, and both ranges.")
                        else:
                            count_hub, live_start, live_end, dead_start, dead_end = match.groups()
                            if self._normalize_hub_value(count_hub) != expected_hub_digits:
                                self._issue(findings, "ERROR", layer_name, fid, "Fiber Cable count hub", count_field, value,
                                            "Hub embedded in count does not match {}.".format(expected_hub),
                                            "Update the embedded hub number or re-verify.")
                            if int(live_start) > int(live_end) or int(dead_start) > int(dead_end):
                                self._issue(findings, "ERROR", layer_name, fid, "Fiber Cable count ranges", count_field, value,
                                            "A range starts above its end value.", "Correct the range endpoints.")

                if role == "equipment" and count_field:
                    stats["specialized_checks"] += 1
                    layer_detail["specialized_checks"] += 1
                    value = self._normalize_text(feature.attribute(count_field))
                    if not value:
                        self._issue(findings, "WARNING", layer_name, fid, "Equipment count range", count_field, value,
                                    "Count range is blank.", "RE-VERIFY")
                    else:
                        match = EQUIPMENT_COUNT_RE.match(value)
                        if not match:
                            self._issue(findings, "WARNING", layer_name, fid, "Equipment count range", count_field, value,
                                        "Expected format like H6005, 24-28.", "RE-VERIFY the count formatting and range.")
                        else:
                            count_hub, range_start, range_end = match.groups()
                            s_num, e_num = int(range_start), int(range_end)
                            if self._normalize_hub_value(count_hub) != expected_hub_digits:
                                self._issue(findings, "WARNING", layer_name, fid, "Equipment count hub", count_field, value,
                                            "Hub embedded in count does not match {}.".format(expected_hub), "RE-VERIFY")
                            if s_num > e_num:
                                self._issue(findings, "WARNING", layer_name, fid, "Equipment count range", count_field, value,
                                            "Count range starts above its end value.", "RE-VERIFY")
                            elif self._normalize_hub_value(count_hub) == expected_hub_digits:
                                equipment_records.append((s_num, e_num, layer_name, str(fid), value, count_field))

                if role == "equipment" and name_field:
                    stats["specialized_checks"] += 1
                    layer_detail["specialized_checks"] += 1
                    name_value = self._normalize_text(feature.attribute(name_field))
                    if not name_value:
                        self._issue(findings, "WARNING", layer_name, fid, "Equipment naming", name_field, name_value,
                                    "Equipment name is blank.", "RE-VERIFY")
                    else:
                        match = EQUIPMENT_NAME_RE.match(name_value)
                        if not match:
                            self._issue(findings, "ERROR", layer_name, fid, "Equipment naming", name_field, name_value,
                                        "Expected format '{} MT-H{}NNN' with a three-digit terminal number.".format(dpi, expected_hub_digits),
                                        "Correct the DPI / MT-Hub / terminal format.")
                        else:
                            observed_dpi, digits = match.groups()
                            if observed_dpi.upper() != dpi:
                                self._issue(findings, "ERROR", layer_name, fid, "Equipment DPI code", name_field, name_value,
                                            "DPI should be {} for schema {}.".format(dpi, schema),
                                            "Correct the schema-specific DPI code.")
                            if not digits.startswith(expected_hub_digits) or len(digits) != len(expected_hub_digits) + 3:
                                self._issue(findings, "ERROR", layer_name, fid, "Equipment hub / terminal format", name_field, name_value,
                                            "MT-H portion must contain the requested hub {} followed by exactly three terminal digits.".format(expected_hub),
                                            "Correct the hub component and three-digit terminal suffix.")
                            else:
                                terminal = digits[-3:]
                                equipment_records.append((None, None, layer_name, str(fid), "TERMINAL:{}".format(terminal), name_field))

                if role == "fiber_cable" and name_field:
                    name_value = self._normalize_text(feature.attribute(name_field))
                    if name_value:
                        # Check series only for the selected hub when this layer has a hub field.
                        if not hub_field or self._normalize_hub_value(feature.attribute(hub_field)) == expected_hub_digits:
                            fiber_series_records.append((layer_name, str(fid), name_field, name_value))

            layer_summaries.append(layer_detail)

        self._check_equipment_duplicates_and_ranges(findings, equipment_records, expected_hub)
        self._check_cable_series(findings, fiber_series_records)

        # Additive strict 36-row field rulebook checks. Existing ID, Hub,
        # Fiber Cable, Equipment, cable-series, and count validation above
        # remain in place and are not replaced by this module.
        try:
            stats["field_rulebook"] = run_field_rulebook_checks(self, scan_layers, findings)
        except Exception as exc:
            self._issue(
                findings, "ERROR", "Project", "—", "Field rulebook execution", "—", "",
                "The 36-row field rulebook could not complete: {}".format(exc),
                "The QC run is incomplete and must not be treated as passed. Inspect the rulebook module and rerun QC.",
            )
            stats["field_rulebook"] = {"rule_rows": 36, "execution_error": str(exc)}

        if stats["id_values_checked"] == 0 and stats["hub_values_checked"] == 0:
            self._issue(findings, "WARNING", "Project", "—", "Global ID / Hub validation", "—", "",
                        "No Infinium ID or Hub Number fields were detected in the eligible vector layers.",
                        "Confirm the project layers or update the field names / aliases used by the QC rules.")

        stats["errors"] = sum(1 for item in findings if item["severity"] == "ERROR")
        stats["warnings"] = sum(1 for item in findings if item["severity"] == "WARNING")
        stats["passed"] = stats["errors"] == 0 and stats["warnings"] == 0
        stats["result"] = "FAILED" if stats["errors"] else ("REVIEW" if stats["warnings"] else "PASSED")
        # Attach layer-level scan coverage and findings counts for sheet-wise exports.
        for layer_detail in layer_summaries:
            layer_findings = [item for item in findings if item.get("layer") == layer_detail["layer"]]
            layer_detail["errors"] = sum(1 for item in layer_findings if item.get("severity") == "ERROR")
            layer_detail["warnings"] = sum(1 for item in layer_findings if item.get("severity") == "WARNING")
            layer_detail["info"] = sum(1 for item in layer_findings if item.get("severity") == "INFO")
            layer_detail["result"] = "FAILED" if layer_detail["errors"] else ("REVIEW" if layer_detail["warnings"] else "PASSED")
        stats["layer_summaries"] = layer_summaries
        return findings, stats

    def _check_equipment_duplicates_and_ranges(self, findings, records, expected_hub):
        # Equipment records carry either a count interval or a parsed terminal marker.
        terminals = defaultdict(list)
        ranges = defaultdict(list)
        for start, end, layer, fid, value, field in records:
            if start is None and end is None and value.startswith("TERMINAL:"):
                terminals[value.split(":", 1)[1]].append((layer, fid, field))
            elif start is not None and end is not None:
                ranges[expected_hub].append((start, end, layer, fid, value, field))

        for terminal, refs in terminals.items():
            if len(refs) > 1:
                for layer, fid, field in refs[1:]:
                    self._issue(findings, "ERROR", layer, fid, "Duplicate terminal number", field, terminal,
                                "Terminal number {} is used more than once for hub {}.".format(terminal, expected_hub),
                                "Assign a unique three-digit terminal number.")

        for hub, rows in ranges.items():
            rows.sort(key=lambda row: (row[0], row[1]))
            if len(rows) < 2:
                continue
            previous = rows[0]
            for current in rows[1:]:
                p_start, p_end, p_layer, p_fid, p_value, p_field = previous
                c_start, c_end, c_layer, c_fid, c_value, c_field = current
                if c_start > p_end + 1:
                    self._issue(findings, "WARNING", c_layer, c_fid, "Equipment count sequence gap", c_field, c_value,
                                "Missing count values {}–{} between {} and {}.".format(p_end + 1, c_start - 1, p_value, c_value),
                                "RE-VERIFY the count range continuity.")
                elif c_start <= p_end:
                    # Same exact range on two features is likely a duplicate; partial overlap may still be a QC issue.
                    self._issue(findings, "WARNING", c_layer, c_fid, "Equipment count overlap", c_field, c_value,
                                "This range overlaps the preceding range {}.".format(p_value),
                                "RE-VERIFY duplicate or overlapping count ranges.")
                if c_end > p_end:
                    previous = current

    def _check_cable_series(self, findings, records):
        if not records:
            return
        raw_seen = defaultdict(list)
        series_seen = defaultdict(list)
        pure_letter = defaultdict(list)
        numbered_groups = defaultdict(list)

        for layer, fid, field, value in records:
            normalized_raw = re.sub(r"\s+", "", value).upper()
            raw_seen[normalized_raw].append((layer, fid, field, value))
            match = SERIES_FULL_RE.match(value)
            if not match:
                match = SERIES_END_RE.search(value)
            if not match:
                continue
            letter, suffix = match.groups()
            letter = letter.upper()
            suffix = suffix or ""
            code = letter + suffix
            series_seen[code].append((layer, fid, field, value))
            if suffix:
                numbered_groups[letter].append((int(suffix), code, layer, fid, field, value))
            else:
                pure_letter[letter].append((layer, fid, field, value))

        for normalized_raw, refs in raw_seen.items():
            if normalized_raw and len(refs) > 1:
                for layer, fid, field, value in refs[1:]:
                    self._issue(findings, "ERROR", layer, fid, "Duplicate cable naming", field, value,
                                "This cable naming value is duplicated.", "Make the cable naming unique and re-verify the series.")

        for code, refs in series_seen.items():
            if len(refs) > 1:
                for layer, fid, field, value in refs[1:]:
                    self._issue(findings, "ERROR", layer, fid, "Duplicate cable series", field, value,
                                "Cable series {} is duplicated.".format(code), "Make the series value unique and re-verify.")

        letters = sorted(set(pure_letter.keys()))
        if len(letters) > 1:
            lo, hi = ord(letters[0]), ord(letters[-1])
            present = set(ord(x) for x in letters)
            for codepoint in range(lo, hi + 1):
                if codepoint not in present:
                    missing = chr(codepoint)
                    layer, fid, field, _ = records[0]
                    self._issue(findings, "WARNING", layer, "—", "Missing cable series", field, missing,
                                "Cable series {} is missing between existing single-letter series.".format(missing),
                                "RE-VERIFY the A/B/C/D… sequence.")

        for letter, rows in numbered_groups.items():
            unique_numbers = sorted(set(item[0] for item in rows))
            if len(unique_numbers) < 2:
                continue
            for missing_number in range(unique_numbers[0] + 1, unique_numbers[-1]):
                if missing_number not in unique_numbers:
                    layer, fid, field, _ = records[0]
                    missing = "{}{}".format(letter, missing_number)
                    self._issue(findings, "WARNING", layer, "—", "Missing cable series", field, missing,
                                "Cable series {} is missing between existing numbered series.".format(missing),
                                "RE-VERIFY the numbered cable sequence.")


class QCSetupDialog(QDialog):
    """Single, resizable dialog for all user-supplied QC parameters."""

    def __init__(self, parent=None):
        super(QCSetupDialog, self).__init__(parent)
        self.setWindowTitle("PDS Ziply QC Check — Setup")
        self.setMinimumSize(520, 390)
        self.resize(640, 455)
        self.setModal(True)
        self.setStyleSheet(QC_DARK_STYLESHEET)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(18, 16, 18, 14)
        outer.setSpacing(12)

        title = QLabel("PDS Ziply QC Check")
        title.setStyleSheet("font-size: 18px; font-weight: 600;")
        outer.addWidget(title)

        subtitle = QLabel(
            "Select the market and enter the expected Infinium ID and Hub Number. "
            "All values are collected here before the QC scan starts."
        )
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet("color: #9AB5CA;")
        outer.addWidget(subtitle)

        group = QGroupBox("QC setup")
        form = QFormLayout(group)
        form.setLabelAlignment(
            _qt_enum(Qt, "AlignmentFlag", "AlignLeft") |
            _qt_enum(Qt, "AlignmentFlag", "AlignVCenter")
        )
        form.setFormAlignment(_qt_enum(Qt, "AlignmentFlag", "AlignTop"))
        form.setHorizontalSpacing(16)
        form.setVerticalSpacing(12)

        self.schema_combo = QComboBox(group)
        self.schema_combo.addItems(SCHEMAS)
        self.schema_combo.setMinimumHeight(30)
        form.addRow("Schema / Market:", self.schema_combo)

        self.dpi_label = QLabel()
        self.dpi_label.setMinimumHeight(26)
        self.dpi_label.setStyleSheet("font-weight: 600;")
        form.addRow("DPI code:", self.dpi_label)

        self.infinium_input = QLineEdit(group)
        self.infinium_input.setPlaceholderText("Enter expected Infinium ID")
        self.infinium_input.setClearButtonEnabled(True)
        self.infinium_input.setMinimumHeight(30)
        form.addRow("Infinium ID:", self.infinium_input)

        self.hub_input = QLineEdit(group)
        self.hub_input.setPlaceholderText("For example, H6005 or 6005")
        self.hub_input.setClearButtonEnabled(True)
        self.hub_input.setMinimumHeight(30)
        form.addRow("Hub Number:", self.hub_input)

        outer.addWidget(group)

        coverage = QLabel(
            "Scan scope: eligible vector layers in the current QGIS project.\n"
            "Low Range and High Range fields are not used. Source features are not modified."
        )
        coverage.setWordWrap(True)
        coverage.setStyleSheet(
            "QLabel { color: #B8D0E3; background: #13263B; border: 1px solid #24435F; "
            "padding: 9px; border-radius: 5px; }"
        )
        outer.addWidget(coverage)

        outer.addStretch(1)
        footer = QLabel("Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere")
        footer.setStyleSheet("color: #7894AA; font-size: 10px;")
        outer.addWidget(footer)

        ok_button = _qt_enum(QDialogButtonBox, "StandardButton", "Ok")
        cancel_button = _qt_enum(QDialogButtonBox, "StandardButton", "Cancel")
        self.button_box = QDialogButtonBox(ok_button | cancel_button, parent=self)
        self.run_button = self.button_box.button(ok_button)
        self.run_button.setText("Run QC")
        self.run_button.setDefault(True)
        self.button_box.button(cancel_button).setText("Cancel")
        self.button_box.accepted.connect(self._validate_and_accept)
        self.button_box.rejected.connect(self.reject)
        outer.addWidget(self.button_box)

        self.schema_combo.currentTextChanged.connect(self._update_dpi)
        self._update_dpi(self.schema_combo.currentText())
        self.infinium_input.returnPressed.connect(self.hub_input.setFocus)
        self.hub_input.returnPressed.connect(self._validate_and_accept)

    def _update_dpi(self, schema):
        self.dpi_label.setText(DPI_BY_SCHEMA.get(schema, "—"))

    def _validate_and_accept(self):
        expected_id = self.infinium_input.text().strip()
        if not expected_id:
            QMessageBox.warning(self, "PDS Ziply QC Check", "Infinium ID cannot be blank.")
            self.infinium_input.setFocus()
            return

        hub_text = re.sub(r"\s+", "", self.hub_input.text().strip().upper())
        if not re.match(r"^H?\d+$", hub_text):
            QMessageBox.warning(
                self, "PDS Ziply QC Check",
                "Hub Number must contain an optional H prefix followed by digits, for example H6005 or 6005.",
            )
            self.hub_input.setFocus()
            return

        digits = hub_text[1:] if hub_text.startswith("H") else hub_text
        self.hub_input.setText("H" + digits)
        self.accept()


class ResultsDialog(QDialog):
    HEADERS = ["Severity", "Layer", "Feature ID", "QC Check", "Field", "Observed Value", "Finding", "Remark"]

    def __init__(self, parent, schema, expected_id, expected_hub, findings, stats):
        super(ResultsDialog, self).__init__(parent)
        self.schema = schema
        self.expected_id = expected_id
        self.expected_hub = expected_hub
        self.stats = stats
        self.findings = list(findings)
        self.setWindowTitle("PDS Ziply QC Check — Results")
        self.resize(1180, 650)
        self.setMinimumSize(850, 460)
        self.setStyleSheet(QC_DARK_STYLESHEET)

        layout = QVBoxLayout(self)
        heading = QLabel("<b>PDS Ziply QC Check</b> — {} | DPI: {} | Infinium ID: {} | Hub: {}".format(
            self._html(schema), self._html(stats.get("dpi", "")), self._html(expected_id), self._html(expected_hub)
        ))
        heading.setWordWrap(True)
        layout.addWidget(heading)

        rulebook_stats = stats.get("field_rulebook", {}) or {}
        self.summary = QLabel(
            "Overall result: {}. Scanned {} layer(s), {} feature(s); checked {} Infinium ID value(s) and {} Hub Number value(s). "
            "Specialized cable/equipment checks: {}. Rulebook: {} rules, {} value check(s), {} field type(s) checked ({} mismatches), {} missing field(s), {} missing layer(s), {} empty layer(s). "
            "Errors: {} | Warnings: {}".format(
                stats.get("result", "INCOMPLETE"), stats.get("scanned_layers", 0), stats.get("features_scanned", 0),
                stats.get("id_values_checked", 0), stats.get("hub_values_checked", 0),
                stats.get("specialized_checks", 0),
                rulebook_stats.get("rule_rows", 36), rulebook_stats.get("field_values_checked", 0),
                rulebook_stats.get("field_types_checked", 0), rulebook_stats.get("field_type_mismatches", 0),
                len(rulebook_stats.get("missing_fields", [])), len(rulebook_stats.get("missing_layers", [])),
                len(rulebook_stats.get("empty_layers", [])), stats.get("errors", 0), stats.get("warnings", 0),
            )
        )
        self.summary.setWordWrap(True)
        layout.addWidget(self.summary)

        self.table = QTableWidget(0, len(self.HEADERS), self)
        self.table.setHorizontalHeaderLabels(self.HEADERS)
        self.table.setSelectionBehavior(_qt_enum(QAbstractItemView, "SelectionBehavior", "SelectRows"))
        self.table.setSelectionMode(_qt_enum(QAbstractItemView, "SelectionMode", "ExtendedSelection"))
        self.table.setEditTriggers(_qt_enum(QAbstractItemView, "EditTrigger", "NoEditTriggers"))
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(_qt_enum(QHeaderView, "ResizeMode", "Interactive"))
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setSortingEnabled(False)

        rows = list(self.findings)
        if not rows:
            rows = [{
                "severity": "INFO", "layer": "Project", "feature_id": "—", "check": "QC Summary",
                "field": "—", "observed_value": "", "result": "No warnings or errors found for the checks that could be evaluated.",
                "remark": "Review the summary above for scan coverage.",
            }]
        self.table.setRowCount(len(rows))
        for row_index, finding in enumerate(rows):
            values = [
                finding.get("severity", ""), finding.get("layer", ""), finding.get("feature_id", ""),
                finding.get("check", ""), finding.get("field", ""), finding.get("observed_value", ""),
                finding.get("result", ""), finding.get("remark", ""),
            ]
            for col_index, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setToolTip(str(value))
                if col_index == 0:
                    item.setTextAlignment(_qt_enum(Qt, "AlignmentFlag", "AlignCenter"))
                severity = finding.get("severity", "").upper()
                if severity == "ERROR":
                    item.setBackground(QColor("#3D2030"))
                    item.setForeground(QColor("#FF9DB6"))
                elif severity == "WARNING":
                    item.setBackground(QColor("#40331D"))
                    item.setForeground(QColor("#FFD58A"))
                elif severity == "INFO":
                    item.setBackground(QColor("#173B34"))
                    item.setForeground(QColor("#9AF0CD"))
                self.table.setItem(row_index, col_index, item)
        self.table.resizeColumnsToContents()
        self.table.setColumnWidth(0, 90)
        self.table.setColumnWidth(1, 150)
        self.table.setColumnWidth(2, 80)
        self.table.setColumnWidth(3, 180)
        self.table.setColumnWidth(4, 140)
        self.table.setColumnWidth(5, 180)
        self.table.setColumnWidth(6, 360)
        layout.addWidget(self.table, 1)

        footer = QLabel("Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere")
        footer.setStyleSheet("color: #7894AA; font-size: 10px;")
        layout.addWidget(footer)

        buttons_layout = QHBoxLayout()
        self.export_button = QPushButton("Export Reports…")
        self.export_button.setToolTip("Export a formatted Excel workbook, an interactive HTML report, and a CSV copy.")
        self.export_button.clicked.connect(self.export_layer_reports)
        buttons_layout.addWidget(self.export_button)
        buttons_layout.addStretch(1)
        self.close_button = QPushButton("Close")
        self.close_button.clicked.connect(self.accept)
        buttons_layout.addWidget(self.close_button)
        layout.addLayout(buttons_layout)

    @staticmethod
    def _html(value):
        return (str(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace('"', "&quot;"))

    def export_layer_reports(self):
        default_name = "PDS_Ziply_QC_{}_{}.xlsx".format(
            re.sub(r"[^A-Za-z0-9]+", "_", self.schema).strip("_"),
            datetime.now().strftime("%Y%m%d_%H%M%S"),
        )
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Export PDS Ziply QC Excel and HTML reports",
            default_name,
            "Excel workbook (*.xlsx)",
        )
        if not path:
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"
        html_path = os.path.splitext(path)[0] + ".html"
        csv_path = os.path.splitext(path)[0] + ".csv"
        try:
            export_reports(
                path, html_path, self.schema, self.expected_id,
                self.expected_hub, self.findings, self.stats,
            )
            self._write_csv(csv_path)
        except Exception as exc:
            QMessageBox.critical(
                self, "Report export failed",
                "Could not create all QC report files:\n{}".format(exc),
            )
            return
        QMessageBox.information(
            self, "Report export complete",
            "QC reports exported successfully:\n\nExcel: {}\nHTML: {}\nCSV: {}\n\n"
            "The Excel workbook includes an Overview sheet and a separate worksheet for each eligible layer.".format(
                path, html_path, csv_path,
            ),
        )

    def _write_csv(self, path):
        headers = ["Schema", "Expected Infinium ID", "Expected Hub Number"] + [
            "Severity", "Layer", "Feature ID", "QC Check", "Field", "Observed Value", "Finding", "Remark"
        ]
        rows = self.findings or [{
            "severity": "INFO", "layer": "Project", "feature_id": "—", "check": "QC Summary", "field": "—",
            "observed_value": "", "result": "No warnings or errors found for the checks that could be evaluated.",
            "remark": "Review the scan summary in the results window.",
        }]
        with open(path, "w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.writer(handle)
            writer.writerow(headers)
            for finding in rows:
                writer.writerow([
                    self.schema, self.expected_id, self.expected_hub,
                    finding.get("severity", ""), finding.get("layer", ""), finding.get("feature_id", ""),
                    finding.get("check", ""), finding.get("field", ""), finding.get("observed_value", ""),
                    finding.get("result", ""), finding.get("remark", ""),
                ])

    def export_csv(self):
        default_name = "PDS_Ziply_QC_{}_{}.csv".format(
            re.sub(r"[^A-Za-z0-9]+", "_", self.schema).strip("_"),
            datetime.now().strftime("%Y%m%d_%H%M%S"),
        )
        path, _ = QFileDialog.getSaveFileName(self, "Export PDS Ziply QC results", default_name, "CSV files (*.csv)")
        if not path:
            return
        if not path.lower().endswith(".csv"):
            path += ".csv"
        try:
            self._write_csv(path)
        except Exception as exc:
            QMessageBox.critical(self, "Export failed", "Could not write CSV file:\n{}".format(exc))
            return
        QMessageBox.information(self, "Export complete", "QC results exported to:\n{}".format(path))
