# Changelog — PDS Ziply QC Check

Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.

## 1.0.7

- Added strict additive execution of all 36 configured field-rulebook rows across seven layer types.
- Added rulebook field-type validation and explicit missing-field, missing-layer, and empty-layer findings.
- Ensured rule-engine exceptions create errors and that the final QC result is calculated after legacy and rulebook checks.
- Preserved the existing legacy QC checks, setup/results workflow, report formatting, and CSV/Excel/HTML exports.
- See `README.md` for the rule coverage and evaluation behavior.
