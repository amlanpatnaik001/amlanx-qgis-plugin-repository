# -*- coding: utf-8 -*-
"""Strict additive field-level QC checks from the current 36-row rulebook.

Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.

This module is intentionally separate from pds_ziply_qc_check.py. It only
appends findings; it does not replace or modify the legacy QC engine.
"""
from __future__ import print_function

import re
from collections import defaultdict

COPYRIGHT = "Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere"

# Transcribed from the latest PDS_Ziply_QC_Field_Rules_Template workbook.
# Each entry corresponds to one workbook rule row (36 total).
RULES = {
    "equipment": [
        {"field": "location", "alias": "Location", "kind": "not_blank", "severity": "ERROR"},
        {"field": "mounttype", "alias": "Mount Type", "kind": "equals", "expected": "Handhole", "severity": "ERROR"},
        {"field": "physical_status", "alias": "Physical Status", "kind": "equals", "expected": "New Build", "severity": "ERROR"},
        {"field": "type", "alias": "Type", "kind": "equipment_type", "expected": "DBT", "allowed": ["FDH"], "severity": "WARNING"},
        {"field": "size", "alias": "Size", "kind": "equipment_size", "expected": 2, "fdh_allowed": [144, 288, 432], "severity": "WARNING"},
        {"field": "category", "alias": "Category", "kind": "equals", "expected": "F2", "severity": "ERROR"},
    ],
    "fiber_cable": [
        {"field": "placementtype", "alias": "Placement Type", "kind": "equals", "expected": "Underground", "severity": "ERROR"},
        {"field": "physical_status", "alias": "Physical Status", "kind": "equals", "expected": "New Build", "severity": "ERROR"},
    ],
    "labor_units": [
        {"field": "type", "alias": "Type", "kind": "equals", "expected": "Bore Pit", "severity": "ERROR"},
        {"field": "surface_type", "alias": "Surface Type", "kind": "equals", "expected": "Soft Surface", "severity": "ERROR"},
        {"field": "category", "alias": "Category", "kind": "equals", "expected": "F2", "severity": "ERROR"},
    ],
    "slackloop": [
        {"field": "cable_size", "alias": "Cable Size", "kind": "not_blank", "severity": "ERROR"},
        {"field": "cable_name", "alias": "Cable Name", "kind": "not_blank", "severity": "ERROR"},
        {"field": "cable_length", "alias": "Cable Length", "kind": "not_blank", "severity": "ERROR"},
        {"field": "category", "alias": "Category", "kind": "equals", "expected": "F2", "severity": "ERROR"},
        {"field": "comments", "alias": "Comments", "kind": "comments_rsv_dependency", "severity": "WARNING"},
    ],
    "span": [
        {"field": "install_me", "alias": "Install Method", "kind": "equals_allowed", "expected": "Dir Bore", "allowed": ["Road Crossing"], "severity": "WARNING"},
        {"field": "size", "alias": "Size", "kind": "equals", "expected": 2, "severity": "ERROR"},
        {"field": "physical_status", "alias": "Physical Status", "kind": "equals", "expected": "New Build", "severity": "ERROR"},
        {"field": "install_type", "alias": "Install Type", "kind": "equals", "expected": "Underground", "severity": "ERROR"},
        {"field": "category", "alias": "Category", "kind": "equals", "expected": "F2", "severity": "WARNING"},
        {"field": "row_pue", "alias": "ROW/PUE", "kind": "row_pue", "severity": "WARNING"},
        {"field": "conduit_name", "alias": "Conduit Name", "kind": "blank", "severity": "ERROR"},
        {"field": "count", "alias": "Count", "kind": "equals", "expected": 1, "severity": "ERROR"},
    ],
    "splice_closure": [
        {"field": "case_size", "alias": "Case Size", "kind": "equals", "expected": "450A", "severity": "WARNING"},
        {"field": "splice_closure_id", "alias": "Splice Closure ID", "kind": "splice_id", "severity": "WARNING"},
        {"field": "mounttype", "alias": "Mount Type", "kind": "equals", "expected": "Handhole", "severity": "ERROR"},
        {"field": "type", "alias": "Type", "kind": "equals_allowed", "expected": "Reel End", "allowed": ["MCA"], "severity": "ERROR"},
        {"field": "physical_status", "alias": "Physical Status", "kind": "equals", "expected": "New Build", "severity": "ERROR"},
        {"field": "category", "alias": "Category", "kind": "equals", "expected": "F2", "severity": "ERROR"},
    ],
    "structures": [
        {"field": "structure_name", "alias": "Structure Name", "kind": "blank", "severity": "ERROR"},
        {"field": "type", "alias": "Type", "kind": "structure_type", "expected": "Flower Pot", "allowed": ["Handhole"], "severity": "WARNING"},
        {"field": "size", "alias": "Size", "kind": "structure_size", "expected": "2x3", "allowed": ["36x60x36"], "severity": "WARNING"},
        {"field": "physical_status", "alias": "Physical Status", "kind": "equals", "expected": "New Build", "severity": "ERROR"},
        {"field": "row_pue", "alias": "ROW/PUE", "kind": "row_pue", "severity": "WARNING"},
        {"field": "category", "alias": "Category", "kind": "equals", "expected": "F2", "severity": "ERROR"},
    ],
}

# The workbook's Field Type column is part of the QC contract. All configured
# fields are String except Slackloop cable_size and cable_length (Integer).
for _role, _rules in RULES.items():
    for _rule in _rules:
        _rule["field_type"] = "Integer" if (
            _role == "slackloop" and _rule["field"] in ("cable_size", "cable_length")
        ) else "String"

EXPECTED_ROLES = tuple(RULES.keys())
EXPECTED_RULE_COUNT = 36
if sum(len(items) for items in RULES.values()) != EXPECTED_RULE_COUNT:
    raise RuntimeError("Field QC rulebook definition count does not match the 36-row master workbook.")


def _clean(value):
    if value is None:
        return ""
    text = str(value).strip()
    if text.casefold() in ("none", "null"):
        return ""
    return " ".join(text.split())


def _norm(value):
    return re.sub(r"[^a-z0-9]", "", _clean(value).casefold())


def _numeric(value):
    text = _clean(value).replace(",", "")
    if not text:
        return None
    try:
        number = float(text)
    except (TypeError, ValueError, OverflowError):
        return None
    return number if number.is_integer() else None


def _same_value(actual, expected):
    actual_num = _numeric(actual)
    expected_num = _numeric(expected)
    if actual_num is not None and expected_num is not None:
        return actual_num == expected_num
    return _norm(actual) == _norm(expected) and bool(_clean(actual))


def _resolve(plugin, layer, rule):
    return plugin._field_by_candidates(layer, [rule["field"], rule["alias"]])


def _actual_field_type(layer, field_name):
    for field in layer.fields():
        if field.name() == field_name:
            try:
                return _clean(field.typeName())
            except Exception:
                return ""
    return ""


def _field_type_matches(actual_type, expected_type):
    actual = _norm(actual_type)
    expected = _norm(expected_type)
    if expected == "string":
        return any(token in actual for token in ("string", "text", "varchar", "char", "citext"))
    if expected == "integer":
        return actual in {
            "int", "int2", "int4", "int8", "integer", "integer64", "longlong",
            "smallint", "bigint", "serial", "bigserial", "unsignedint", "unsignedlonglong",
        }
    return actual == expected


def _severity(rule):
    return rule.get("severity", "ERROR").upper()


def _issue(plugin, findings, severity, layer_name, fid, check, field, observed, message, action):
    plugin._issue(findings, severity, layer_name, fid, check, field, observed, message, action)


def _check_value(plugin, findings, layer_name, feature, field_name, rule):
    value = feature.attribute(field_name)
    cleaned = _clean(value)
    kind = rule["kind"]
    severity = _severity(rule)
    label = rule["alias"]
    check_name = "{} {}".format(plugin._layer_role_label if hasattr(plugin, "_layer_role_label") else "", label).strip()

    if kind == "not_blank":
        valid = bool(cleaned)
        expected = "must not be blank"
    elif kind == "blank":
        valid = not cleaned
        expected = "must be blank"
    elif kind in ("equals", "equals_allowed"):
        accepted = [rule["expected"]] + (rule.get("allowed", []) if kind == "equals_allowed" else [])
        valid = any(_same_value(value, item) for item in accepted)
        expected = " / ".join(_clean(item) for item in accepted)
    elif kind == "equipment_type":
        # The naming field is resolved once for this Equipment layer. The
        # layer-level dependency warning is sufficient when it is unavailable.
        naming_field = rule.get("resolved_naming_field")
        if not naming_field:
            return True
        naming = _clean(feature.attribute(naming_field))
        required = "FDH" if not naming else "DBT"
        valid = _norm(value) == _norm(required)
        expected = "{} (naming blank => FDH; naming populated => DBT)".format(required)
    elif kind == "equipment_size":
        type_field = rule.get("resolved_type_field")
        equipment_type = _clean(feature.attribute(type_field)) if type_field else ""
        accepted = rule.get("fdh_allowed", []) if _norm(equipment_type) == "fdh" else [rule["expected"]]
        valid = any(_same_value(value, item) for item in accepted)
        expected = " / ".join(_clean(item) for item in accepted)
    elif kind == "structure_type":
        size_field = rule.get("resolved_size_field")
        if not size_field:
            return True
        size_value = _clean(feature.attribute(size_field))
        required = "Handhole" if _norm(size_value) in ("2x3", "36x60x36") else "Flower Pot"
        valid = _norm(value) == _norm(required)
        expected = "{} (size 2x3 or 36x60x36 => Handhole; otherwise Flower Pot)".format(required)
    elif kind == "structure_size":
        type_field = rule.get("resolved_type_field")
        if not type_field:
            return True
        structure_type = _clean(feature.attribute(type_field))
        accepted = [] if _norm(structure_type) == "flowerpot" else [rule["expected"]] + rule.get("allowed", [])
        valid = (not cleaned) if not accepted else any(_same_value(value, item) for item in accepted)
        expected = "blank (Type = Flower Pot)" if not accepted else " / ".join(_clean(item) for item in accepted)
    elif kind == "row_pue":
        # Right of Way passes. Public Utility Easement is explicitly allowed
        # in the workbook but still must be re-verified. Any other value warns.
        if _norm(value) == _norm("Right of Way"):
            valid = True
            expected = "Right of Way"
        else:
            valid = False
            expected = "Right of Way (Public Utility Easement requires RE-VERIFY)"
    elif kind == "comments_rsv_dependency":
        rsv_field = rule.get("resolved_rsv_field")
        if not rsv_field:
            # A single layer-level dependency finding is already added by the
            # caller; don't duplicate it for every feature.
            return True
        rsv_value = _clean(feature.attribute(rsv_field))
        valid = bool(cleaned) == bool(rsv_value)
        expected = "populated when rsv_counts is populated; otherwise blank"
    elif kind == "splice_id":
        match = re.match(r"^SP(\d{2,})$", cleaned, re.IGNORECASE)
        valid = bool(match and int(match.group(1)) >= 1)
        expected = "SP01, SP02, SP03, ..."
    else:
        valid = True
        expected = "configured rule"

    if valid:
        return True

    message = "Expected {}; found '{}'".format(expected, cleaned or "blank")
    if kind == "row_pue":
        action = "RE-VERIFY the ROW/PUE classification with the source/client."
    elif kind == "comments_rsv_dependency":
        action = "Populate Comments when rsv_counts has a value; clear Comments when rsv_counts is blank."
    elif kind == "equipment_type":
        action = "Set Type to FDH when equipment naming is blank; otherwise set it to DBT."
    elif kind == "equipment_size":
        action = "Use Size 2 for DBT; for FDH use 144, 288, or 432."
    elif kind == "structure_type":
        action = "Use Handhole when Size is 2x3 or 36x60x36; otherwise use Flower Pot."
    elif kind == "structure_size":
        action = "Leave Size blank for Flower Pot; for Handhole use 2x3 or 36x60x36."
    else:
        action = "Correct the attribute to match the QC rulebook."

    _issue(plugin, findings, severity, layer_name, feature.id(), check_name, field_name,
           value, message, action)
    return False


def _add_missing_field_issue(plugin, findings, role, layer_name, rule):
    severity = _severity(rule)
    _issue(
        plugin, findings, severity, layer_name, "—",
        "{} field missing".format(rule["alias"]), rule["field"], "",
        "Required rulebook field '{}' (alias '{}') was not found; this rule was not evaluated.".format(
            rule["field"], rule["alias"]
        ),
        "Add the field or configure the matching QGIS field alias. This layer cannot be marked as passed until the rule can be checked.",
    )


def run_field_rulebook_checks(plugin, scan_layers, findings):
    """Run every rulebook rule on all detected matching layers.

    Missing configured layers/fields are emitted as findings so incomplete rule
    coverage cannot silently return a PASSED result.
    """
    counters = {
        "rule_rows": sum(len(rules) for rules in RULES.values()),
        "layers_seen": defaultdict(int),
        "features_evaluated": 0,
        "field_values_checked": 0,
        "field_types_checked": 0,
        "field_type_mismatches": 0,
        "missing_layers": [],
        "missing_fields": [],
        "empty_layers": [],
        "rule_failures": 0,
        "splice_id_duplicates": 0,
        "splice_id_gaps": 0,
    }
    seen_roles = set()
    splice_ids = defaultdict(list)

    for layer, role, _id_field, _hub_field in scan_layers:
        if role not in RULES:
            continue
        seen_roles.add(role)
        counters["layers_seen"][role] += 1
        # Work on per-layer rule copies so resolved cross-field dependencies
        # never leak between duplicate layer instances or later QC runs.
        rules = [dict(rule) for rule in RULES[role]]
        resolved = {}
        for rule in rules:
            field_name = _resolve(plugin, layer, rule)
            resolved[rule["field"]] = field_name
            if not field_name:
                _add_missing_field_issue(plugin, findings, role, layer.name(), rule)
                counters["missing_fields"].append((layer.name(), rule["field"]))
            else:
                counters["field_types_checked"] += 1
                actual_type = _actual_field_type(layer, field_name)
                expected_type = rule.get("field_type", "String")
                if not _field_type_matches(actual_type, expected_type):
                    counters["field_type_mismatches"] += 1
                    _issue(
                        plugin, findings, _severity(rule), layer.name(), "—",
                        "{} field type".format(rule["alias"]), field_name, actual_type,
                        "Field type is '{}'; the rulebook requires '{}'.".format(actual_type or "unknown", expected_type),
                        "Change the field type to {} or confirm the rulebook definition with the client.".format(expected_type),
                    )

        # Resolve cross-field dependencies once per layer.
        if role == "equipment":
            naming_field = plugin._resolve_naming_field(layer, "equipment")
            for rule in rules:
                if rule["kind"] == "equipment_type":
                    rule["resolved_naming_field"] = naming_field
                elif rule["kind"] == "equipment_size":
                    rule["resolved_type_field"] = resolved.get("type")
            if not naming_field:
                _issue(plugin, findings, "WARNING", layer.name(), "—",
                       "Equipment naming dependency", "naming", "",
                       "Equipment Type exception cannot be evaluated because the naming field is unavailable.",
                       "Confirm the equipment naming field or alias.")
        elif role == "structures":
            for rule in rules:
                if rule["kind"] == "structure_type":
                    rule["resolved_size_field"] = resolved.get("size")
                elif rule["kind"] == "structure_size":
                    rule["resolved_type_field"] = resolved.get("type")
        elif role == "slackloop":
            rsv_field = plugin._field_by_candidates(layer, ["rsv_counts", "Reserved Counts"])
            comments_rule = next((r for r in rules if r["field"] == "comments"), None)
            if comments_rule:
                comments_rule["resolved_rsv_field"] = rsv_field
            if not rsv_field:
                _issue(plugin, findings, "WARNING", layer.name(), "—",
                       "Slackloop RSV Counts dependency", "rsv_counts", "",
                       "The Comments rule cannot be evaluated because rsv_counts is missing.",
                       "Confirm the rsv_counts field or its alias.")

        layer_feature_count = 0
        try:
            for feature in layer.getFeatures():
                layer_feature_count += 1
                counters["features_evaluated"] += 1
                for rule in rules:
                    field_name = resolved.get(rule["field"])
                    if not field_name:
                        continue
                    counters["field_values_checked"] += 1
                    before = len(findings)
                    _check_value(plugin, findings, layer.name(), feature, field_name, rule)
                    if len(findings) > before:
                        counters["rule_failures"] += 1

                    if role == "splice_closure" and rule["kind"] == "splice_id":
                        value = _clean(feature.attribute(field_name))
                        match = re.match(r"^SP(\d{2,})$", value, re.IGNORECASE)
                        if match and int(match.group(1)) >= 1:
                            splice_ids[layer.name()].append((int(match.group(1)), value, feature.id(), field_name))
            if layer_feature_count == 0:
                counters["empty_layers"].append(layer.name())
                _issue(plugin, findings, "WARNING", layer.name(), "—", "Rulebook layer has no features", "—", "",
                       "The layer exists and its rule fields were inspected, but it contains no features to validate.",
                       "Confirm that this layer is intentionally empty or load the expected features before treating its QC as complete.")
        except Exception as exc:
            _issue(plugin, findings, "ERROR", layer.name(), "—", "Rulebook scan exception", "—", "",
                   "The rulebook checks for this layer did not complete: {}".format(exc),
                   "Inspect the layer/provider and rerun QC. This layer must not be treated as passed.")

    # Missing configured layer types must never be silently treated as passed.
    for role, rules in RULES.items():
        if role not in seen_roles:
            layer_label = {
                "equipment": "Equipment", "fiber_cable": "Fiber Cable", "labor_units": "Labor Units",
                "slackloop": "Slackloop", "span": "Span", "splice_closure": "Splice Closure",
                "structures": "Structures",
            }.get(role, role)
            counters["missing_layers"].append(layer_label)
            _issue(plugin, findings, "WARNING", layer_label, "—", "Rulebook layer not loaded", "—", "",
                   "The {} layer was not found among eligible scanned layers; its rulebook checks were not executed.".format(layer_label),
                   "Load the required layer outside the excluded groups or confirm that this layer is not part of the current project QC scope." )

    # Detect duplicate IDs and internal sequence gaps per Splice Closure layer.
    for layer_name, records in splice_ids.items():
        by_number = defaultdict(list)
        for number, value, fid, field_name in records:
            by_number[number].append((value, fid, field_name))
        for number, refs in by_number.items():
            if len(refs) > 1:
                for value, fid, field_name in refs[1:]:
                    counters["splice_id_duplicates"] += 1
                    _issue(plugin, findings, "WARNING", layer_name, fid, "Duplicate Splice Closure ID",
                           field_name, value, "Splice Closure ID {} is duplicated.".format(value),
                           "Assign a unique SP sequence ID.")
        if by_number:
            maximum = max(by_number)
            # The rulebook convention is SP01, SP02, ...; gaps are checked
            # from the first required ID, not merely between the observed ends.
            for missing in range(1, maximum + 1):
                if missing not in by_number:
                    counters["splice_id_gaps"] += 1
                    missing_label = "SP{:02d}".format(missing)
                    _issue(plugin, findings, "WARNING", layer_name, "—", "Splice Closure ID sequence",
                           "splice_closure_id", missing_label,
                           "Splice Closure ID sequence is missing {} between existing IDs.".format(missing_label),
                           "Check whether the splice closure sequence is complete or whether an ID was intentionally omitted.")

    # Serialize defaultdicts to normal dicts for report/export metadata.
    counters["layers_seen"] = dict(counters["layers_seen"])
    counters["missing_layers"] = sorted(set(counters["missing_layers"]))
    counters["missing_fields"] = [list(item) for item in counters["missing_fields"]]
    counters["empty_layers"] = sorted(set(counters["empty_layers"]))
    return counters
