# -*- coding: utf-8 -*-
"""Self-contained Excel and HTML report exporters for PDS Ziply QC.

Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.

Uses only the Python standard library so the exporter does not depend on
openpyxl, XlsxWriter, pandas, or a particular QGIS-bundled package version.
"""
from __future__ import print_function

import datetime
import html
import os
import re
import zipfile
from collections import defaultdict


REPORT_COPYRIGHT = "Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere"


REPORT_HEADERS = [
    "Severity", "Layer", "Feature ID", "QC Check", "Field",
    "Observed Value", "Finding", "Remark", "QGIS Select Expression",
]


def _text(value):
    if value is None:
        return ""
    return str(value)


def _excel_safe_sheet_name(name, used):
    cleaned = re.sub(r"[\\/*?:\[\]]", "_", _text(name)).strip().strip("'")
    cleaned = cleaned or "Layer"
    if cleaned.lower() == "history":
        cleaned = "Layer_History"
    cleaned = cleaned[:31]
    candidate = cleaned
    counter = 2
    while candidate.lower() in used:
        suffix = "_{}".format(counter)
        candidate = cleaned[:31 - len(suffix)] + suffix
        counter += 1
    used.add(candidate.lower())
    return candidate


def _column_letter(number):
    result = ""
    while number:
        number, remainder = divmod(number - 1, 26)
        result = chr(65 + remainder) + result
    return result


def _qgis_expression(feature_id):
    value = _text(feature_id).strip()
    if re.match(r"^-?\d+$", value):
        return "$id = {}".format(value)
    return ""


def _collect_reports(findings, stats):
    findings_by_layer = defaultdict(list)
    for finding in findings or []:
        findings_by_layer[_text(finding.get("layer") or "Project")].append(finding)

    summaries = []
    seen = set()
    for item in stats.get("layer_summaries", []) or []:
        layer_name = _text(item.get("layer") or "Layer")
        if layer_name not in seen:
            summaries.append(dict(item, layer=layer_name))
            seen.add(layer_name)

    # Retain findings for any synthetic/project layer or a layer not present in
    # layer_summaries (for example, a project-level discovery finding).
    for layer_name in findings_by_layer:
        if layer_name not in seen:
            summaries.append({
                "layer": layer_name,
                "role": "project" if layer_name == "Project" else "unknown",
                "features_scanned": 0,
                "id_values_checked": 0,
                "hub_values_checked": 0,
            })
            seen.add(layer_name)

    if not summaries:
        summaries.append({
            "layer": "Project", "role": "project", "features_scanned": 0,
            "id_values_checked": 0, "hub_values_checked": 0,
        })

    for summary in summaries:
        layer_name = summary["layer"]
        layer_findings = findings_by_layer.get(layer_name, [])
        summary["findings"] = layer_findings
        summary["errors"] = sum(1 for item in layer_findings if _text(item.get("severity")).upper() == "ERROR")
        summary["warnings"] = sum(1 for item in layer_findings if _text(item.get("severity")).upper() == "WARNING")
        summary["info"] = sum(1 for item in layer_findings if _text(item.get("severity")).upper() == "INFO")
        summary["result"] = "FAILED" if summary["errors"] else ("REVIEW" if summary["warnings"] else "PASSED")
    return summaries


def _finding_cells(finding):
    feature_id = _text(finding.get("feature_id", ""))
    return [
        _text(finding.get("severity", "")),
        _text(finding.get("layer", "")),
        feature_id,
        _text(finding.get("check", "")),
        _text(finding.get("field", "")),
        _text(finding.get("observed_value", "")),
        _text(finding.get("result", "")),
        _text(finding.get("remark", "")),
        _qgis_expression(feature_id),
    ]


def _xml_escape(value):
    value = _text(value)
    # XML 1.0 disallows most C0 control characters; strip them from source attributes.
    value = re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F]", "", value)
    return (value.replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;").replace("'", "&apos;"))


def _cell_xml(reference, value, style=None):
    style_attr = ' s="{}"'.format(style) if style is not None else ""
    if value is None:
        return '<c r="{}"{} />'.format(reference, style_attr)
    if isinstance(value, bool):
        return '<c r="{}" t="b"{}><v>{}</v></c>'.format(reference, style_attr, 1 if value else 0)
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return '<c r="{}"{}><v>{}</v></c>'.format(reference, style_attr, value)
    text_value = _xml_escape(value)
    preserve = ' xml:space="preserve"' if text_value != text_value.strip() else ""
    return '<c r="{}" t="inlineStr"{}><is><t{}>{}</t></is></c>'.format(
        reference, style_attr, preserve, text_value
    )


def _row_xml(row_number, values, styles=None, height=None):
    styles = styles or []
    height_attr = ' ht="{}" customHeight="1"'.format(height) if height else ""
    cells = []
    for index, value in enumerate(values, 1):
        style = styles[index - 1] if index - 1 < len(styles) else None
        cells.append(_cell_xml("{}{}".format(_column_letter(index), row_number), value, style))
    return '<row r="{}"{}>{}</row>'.format(row_number, height_attr, "".join(cells))


def _styles_xml():
    # Cell style IDs are deliberately stable and local to this exporter.
    fonts = [
        '<font><sz val="10"/><name val="Arial"/><color rgb="FF203247"/></font>',
        '<font><b/><sz val="17"/><name val="Arial"/><color rgb="FFFFFFFF"/></font>',
        '<font><i/><sz val="10"/><name val="Arial"/><color rgb="FFB8D4EA"/></font>',
        '<font><b/><sz val="11"/><name val="Arial"/><color rgb="FF0B4F75"/></font>',
        '<font><b/><sz val="10"/><name val="Arial"/><color rgb="FF24435D"/></font>',
        '<font><sz val="10"/><name val="Arial"/><color rgb="FF203247"/></font>',
        '<font><b/><sz val="10"/><name val="Arial"/><color rgb="FFFFFFFF"/></font>',
        '<font><b/><sz val="10"/><name val="Arial"/><color rgb="FF9E263D"/></font>',
        '<font><b/><sz val="10"/><name val="Arial"/><color rgb="FF8A5100"/></font>',
        '<font><b/><sz val="10"/><name val="Arial"/><color rgb="FF147044"/></font>',
        '<font><b/><sz val="12"/><name val="Arial"/><color rgb="FF0B4F75"/></font>',
        '<font><b/><sz val="16"/><name val="Arial"/><color rgb="FF0B4F75"/></font>',
    ]
    fills = [
        '<fill><patternFill patternType="none"/></fill>',
        '<fill><patternFill patternType="gray125"/></fill>',
        '<fill><patternFill patternType="solid"><fgColor rgb="FF10243A"/><bgColor indexed="64"/></patternFill></fill>',
        '<fill><patternFill patternType="solid"><fgColor rgb="FFDDF3FF"/><bgColor indexed="64"/></patternFill></fill>',
        '<fill><patternFill patternType="solid"><fgColor rgb="FFEAF3FA"/><bgColor indexed="64"/></patternFill></fill>',
        '<fill><patternFill patternType="solid"><fgColor rgb="FFFCE4E8"/><bgColor indexed="64"/></patternFill></fill>',
        '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF0D5"/><bgColor indexed="64"/></patternFill></fill>',
        '<fill><patternFill patternType="solid"><fgColor rgb="FFE3F5EB"/><bgColor indexed="64"/></patternFill></fill>',
        '<fill><patternFill patternType="solid"><fgColor rgb="FFF3F6F9"/><bgColor indexed="64"/></patternFill></fill>',
        '<fill><patternFill patternType="solid"><fgColor rgb="FF145A80"/><bgColor indexed="64"/></patternFill></fill>',
    ]
    borders = [
        '<border><left/><right/><top/><bottom/><diagonal/></border>',
        '<border><left style="thin"><color rgb="FFD7E1EA"/></left><right style="thin"><color rgb="FFD7E1EA"/></right><top style="thin"><color rgb="FFD7E1EA"/></top><bottom style="thin"><color rgb="FFD7E1EA"/></bottom><diagonal/></border>',
    ]
    xfs = [
        '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>',
        '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>',
        '<xf numFmtId="0" fontId="2" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>',
        '<xf numFmtId="0" fontId="3" fillId="3" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>',
        '<xf numFmtId="0" fontId="4" fillId="4" borderId="1" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>',
        '<xf numFmtId="0" fontId="5" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>',
        '<xf numFmtId="0" fontId="6" fillId="9" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>',
        '<xf numFmtId="0" fontId="7" fillId="5" borderId="1" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>',
        '<xf numFmtId="0" fontId="8" fillId="6" borderId="1" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>',
        '<xf numFmtId="0" fontId="9" fillId="7" borderId="1" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>',
        '<xf numFmtId="0" fontId="10" fillId="4" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>',
        '<xf numFmtId="0" fontId="11" fillId="3" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>',
        '<xf numFmtId="0" fontId="4" fillId="3" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>',
        '<xf numFmtId="0" fontId="5" fillId="4" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>',
        '<xf numFmtId="0" fontId="7" fillId="5" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>',
        '<xf numFmtId="0" fontId="8" fillId="6" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>',
        '<xf numFmtId="0" fontId="9" fillId="7" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>',
    ]
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<fonts count="{0}">{1}</fonts><fills count="{2}">{3}</fills>'
        '<borders count="{4}">{5}</borders>'
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        '<cellXfs count="{6}">{7}</cellXfs>'
        '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
        '</styleSheet>'
    ).format(len(fonts), "".join(fonts), len(fills), "".join(fills), len(borders), "".join(borders), len(xfs), "".join(xfs))


def _worksheet_xml(rows, widths, merges=None, freeze_row=0, autofilter_ref=None, tab_color="FF168BC5"):
    merges = merges or []
    max_row = max([row[0] for row in rows] or [1])
    max_col = max([len(row[1]) for row in rows] or [1])
    dimension = "A1:{}{}".format(_column_letter(max_col), max_row)
    cols_xml = "<cols>{}</cols>".format("".join(
        '<col min="{0}" max="{0}" width="{1}" customWidth="1"/>'.format(index, width)
        for index, width in enumerate(widths, 1)
    ))
    row_xml = "".join(_row_xml(row_number, values, styles, height) for row_number, values, styles, height in rows)
    pane_xml = ""
    if freeze_row:
        pane_xml = '<pane ySplit="{}" topLeftCell="A{}" activePane="bottomLeft" state="frozen"/>'.format(
            freeze_row, freeze_row + 1
        )
    merge_xml = ""
    if merges:
        merge_xml = '<mergeCells count="{}">{}</mergeCells>'.format(
            len(merges), "".join('<mergeCell ref="{}"/>'.format(item) for item in merges)
        )
    autofilter_xml = '<autoFilter ref="{}"/>'.format(autofilter_ref) if autofilter_ref else ""
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<sheetPr><tabColor rgb="{}"/></sheetPr>'.format(tab_color) +
        '<dimension ref="{}"/>'.format(dimension) +
        '<sheetViews><sheetView workbookViewId="0">{}</sheetView></sheetViews>'.format(pane_xml) +
        '<sheetFormatPr defaultRowHeight="20"/>' + cols_xml +
        '<sheetData>{}</sheetData>'.format(row_xml) + merge_xml + autofilter_xml +
        '<pageMargins left="0.25" right="0.25" top="0.5" bottom="0.5" header="0.2" footer="0.2"/>'
        '<pageSetup orientation="landscape" fitToWidth="1" fitToHeight="0" paperSize="9"/>'
        '</worksheet>'
    )


def _report_metadata(schema, expected_id, expected_hub, stats):
    return [
        ("Schema", _text(schema)),
        ("Expected Infinium ID", _text(expected_id)),
        ("Expected Hub Number", _text(expected_hub)),
        ("DPI Code", _text(stats.get("dpi", ""))),
        ("Project", _text(stats.get("project_name", "QGIS Project"))),
        ("Generated", datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        ("Overall QC Result", _text(stats.get("result", "INCOMPLETE"))),
        ("Rulebook Rules Configured", (stats.get("field_rulebook", {}) or {}).get("rule_rows", 0)),
        ("Rulebook Field Values Checked", (stats.get("field_rulebook", {}) or {}).get("field_values_checked", 0)),
        ("Rulebook Field Types Checked", (stats.get("field_rulebook", {}) or {}).get("field_types_checked", 0)),
        ("Rulebook Field Type Mismatches", (stats.get("field_rulebook", {}) or {}).get("field_type_mismatches", 0)),
        ("Rulebook Missing Fields", len((stats.get("field_rulebook", {}) or {}).get("missing_fields", []))),
        ("Rulebook Missing Layers", len((stats.get("field_rulebook", {}) or {}).get("missing_layers", []))),
        ("Rulebook Empty Layers", len((stats.get("field_rulebook", {}) or {}).get("empty_layers", []))),
    ]


def export_xlsx(path, schema, expected_id, expected_hub, findings, stats):
    """Write a formatted XLSX with an Overview sheet and one sheet per layer."""
    reports = _collect_reports(findings, stats)
    metadata = _report_metadata(schema, expected_id, expected_hub, stats)
    used_names = set(["overview"])
    sheet_definitions = []
    sheet_links = {}

    # Overview sheet.
    overview_rows = [
        (1, ["PDS ZIPLY QC REPORT"], [1], 34),
        (2, ["Layer-wise quality-control findings | Generated by PDS Ziply QC Check"], [2], 23),
        (4, ["PROJECT CONTEXT", "", "", "", "", "", "", ""], [3] * 8, 23),
    ]
    for offset, (label, value) in enumerate(metadata):
        row_number = 5 + offset
        overview_rows.append((row_number, [label, value], [4, 5], 22))
    overview_rows.append((20, ["QC RUN SUMMARY", "", "", "", "", "", "", ""], [3] * 8, 23))
    metric_pairs = [
        ("Eligible layers", stats.get("scanned_layers", len(reports))),
        ("Excluded layers", stats.get("excluded_layers", 0)),
        ("Features scanned", stats.get("features_scanned", 0)),
        ("Infinium ID checks", stats.get("id_values_checked", 0)),
        ("Hub Number checks", stats.get("hub_values_checked", 0)),
        ("Specialized checks", stats.get("specialized_checks", 0)),
        ("Errors", stats.get("errors", 0)),
        ("Warnings", stats.get("warnings", 0)),
        ("Rulebook rules configured", (stats.get("field_rulebook", {}) or {}).get("rule_rows", 0)),
        ("Rulebook field values checked", (stats.get("field_rulebook", {}) or {}).get("field_values_checked", 0)),
        ("Rulebook field types checked", (stats.get("field_rulebook", {}) or {}).get("field_types_checked", 0)),
        ("Rulebook field type mismatches", (stats.get("field_rulebook", {}) or {}).get("field_type_mismatches", 0)),
        ("Missing rulebook fields", len((stats.get("field_rulebook", {}) or {}).get("missing_fields", []))),
        ("Missing rulebook layers", len((stats.get("field_rulebook", {}) or {}).get("missing_layers", []))),
        ("Empty rulebook layers", len((stats.get("field_rulebook", {}) or {}).get("empty_layers", []))),
    ]
    for index, (label, value) in enumerate(metric_pairs):
        row_number = 21 + index
        overview_rows.append((row_number, [label, value], [12, 11 if label in ("Errors", "Warnings") else 13], 22))
    overview_rows.append((37, ["LAYER-WISE QC SUMMARY", "", "", "", "", "", "", ""], [3] * 8, 23))
    summary_headers = ["Layer", "Layer Type", "Features Scanned", "Infinium ID Checks", "Hub Number Checks", "Errors", "Warnings", "Result"]
    overview_rows.append((38, summary_headers, [6] * len(summary_headers), 34))

    for row_index, summary in enumerate(reports, 39):
        layer_name = summary["layer"]
        safe_sheet = _excel_safe_sheet_name(layer_name, used_names)
        sheet_links[layer_name] = safe_sheet
        layer_values = [
            layer_name, _text(summary.get("role", "")),
            summary.get("features_scanned", 0), summary.get("id_values_checked", 0),
            summary.get("hub_values_checked", 0), summary.get("errors", 0),
            summary.get("warnings", 0), summary.get("result", "PASSED"),
        ]
        severity = "ERROR" if summary.get("errors", 0) else ("WARNING" if summary.get("warnings", 0) else "INFO")
        row_styles = [14 if severity == "ERROR" else (15 if severity == "WARNING" else 16)] * len(layer_values)
        overview_rows.append((row_index, layer_values, row_styles, 25))

        # Per-layer sheet: context, summary metrics, and detailed issues.
        detail_rows = [
            (1, ["PDS ZIPLY QC — {}".format(layer_name)], [1], 34),
            (2, ["Detailed QC findings for this QGIS layer"], [2], 23),
            (4, ["SCHEMA", schema, "EXPECTED INFINIUM ID", expected_id, "EXPECTED HUB", expected_hub, "DPI CODE", _text(stats.get("dpi", ""))], [4, 5, 4, 5, 4, 5, 4, 5], 28),
            (5, ["PROJECT", _text(stats.get("project_name", "QGIS project")), "LAYER TYPE", _text(summary.get("role", ""))], [4, 5, 4, 5], 24),
            (6, ["LAYER QC SNAPSHOT", "", "", "", "", "", "", "", ""], [3] * 9, 23),
            (7, ["Features Scanned", "Infinium ID Checks", "Hub Number Checks", "Errors", "Warnings", "Result"], [12] * 6, 32),
            (8, [summary.get("features_scanned", 0), summary.get("id_values_checked", 0), summary.get("hub_values_checked", 0), summary.get("errors", 0), summary.get("warnings", 0), summary.get("result", "PASSED")], [13, 13, 13, 14 if summary.get("errors", 0) else 13, 15 if summary.get("warnings", 0) else 13, 16 if summary.get("result") == "PASSED" else (14 if summary.get("errors", 0) else 15)], 26),
            (10, ["DETAILED QC FINDINGS", "", "", "", "", "", "", "", ""], [3] * 9, 23),
            (11, REPORT_HEADERS, [6] * len(REPORT_HEADERS), 38),
        ]
        layer_findings = list(summary.get("findings", []))
        if not layer_findings:
            layer_findings = [{
                "severity": "INFO", "layer": layer_name, "feature_id": "—", "check": "QC Summary",
                "field": "—", "observed_value": "", "result": "No QC findings were raised for this layer.",
                "remark": "This layer was scanned; no issue rows were generated by the configured checks.",
            }]
        start_data_row = 12
        for detail_index, finding in enumerate(layer_findings):
            excel_row = start_data_row + detail_index
            cells = _finding_cells(dict(finding, layer=layer_name))
            sev = _text(finding.get("severity", "")).upper()
            body_style = 14 if sev == "ERROR" else (15 if sev == "WARNING" else 16)
            styles = [
                7 if sev == "ERROR" else (8 if sev == "WARNING" else 9),
                body_style, body_style, body_style, body_style, body_style,
                body_style, body_style, body_style,
            ]
            detail_rows.append((excel_row, cells, styles, 42))
        last_row = start_data_row + len(layer_findings) - 1
        copyright_row = last_row + 2
        detail_rows.append((copyright_row, [REPORT_COPYRIGHT], [2], 23))
        layer_merges = ["A1:I1", "A2:I2", "A6:I6", "A10:I10", "A{}:I{}".format(copyright_row, copyright_row)]
        sheet_definitions.append((safe_sheet, detail_rows, [13, 24, 13, 30, 22, 34, 64, 58, 32], layer_merges, 11, "A11:I{}".format(last_row), "FF168BC5" if not summary.get("errors") else "FFB93A57"))

    # Add project-only findings as an extra sheet if they exist, but avoid a duplicate
    # Project worksheet when a real scanned project layer already has that display name.
    overview_last = 38 + len(reports)
    overview_filter = "A38:H{}".format(overview_last if overview_last >= 38 else 38)
    overview_copyright_row = overview_last + 2
    overview_rows.append((overview_copyright_row, [REPORT_COPYRIGHT], [2], 23))
    overview_merges = ["A1:H1", "A2:H2", "A4:H4", "A20:H20", "A37:H37", "A{}:H{}".format(overview_copyright_row, overview_copyright_row)]
    sheet_definitions.insert(0, ("Overview", overview_rows, [28, 24, 18, 20, 20, 12, 14, 16], overview_merges, 3, overview_filter, "FF168BC5"))

    # A worksheet row limit is not expected for normal QC projects; fail clearly if exceeded.
    for sheet_name, rows, widths, merges, freeze_row, filter_ref, tab_color in sheet_definitions:
        if len(rows) > 1048500:
            raise ValueError("Too many report rows for Excel worksheet: {}".format(sheet_name))

    workbook_sheets = []
    for index, (sheet_name, rows, widths, merges, freeze_row, filter_ref, tab_color) in enumerate(sheet_definitions, 1):
        workbook_sheets.append('<sheet name="{}" sheetId="{}" r:id="rId{}"/>'.format(
            _xml_escape(sheet_name), index, index
        ))

    workbook_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<bookViews><workbookView xWindow="0" yWindow="0" windowWidth="22000" windowHeight="12000"/></bookViews>'
        '<sheets>{}</sheets><calcPr calcId="191029"/></workbook>'
    ).format("".join(workbook_sheets))
    workbook_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        + "".join('<Relationship Id="rId{}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{}.xml"/>'.format(i, i) for i in range(1, len(sheet_definitions) + 1))
        + '<Relationship Id="rId{}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'.format(len(sheet_definitions) + 1)
        + '</Relationships>'
    )
    content_overrides = ''.join(
        '<Override PartName="/xl/worksheets/sheet{}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'.format(i)
        for i in range(1, len(sheet_definitions) + 1)
    )
    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        + content_overrides + '</Types>'
    )
    root_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        '</Relationships>'
    )

    directory = os.path.dirname(os.path.abspath(path))
    if directory and not os.path.isdir(directory):
        os.makedirs(directory)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", content_types)
        archive.writestr("_rels/.rels", root_rels)
        archive.writestr("xl/workbook.xml", workbook_xml)
        archive.writestr("xl/_rels/workbook.xml.rels", workbook_rels)
        archive.writestr("xl/styles.xml", _styles_xml())
        for index, definition in enumerate(sheet_definitions, 1):
            sheet_name, rows, widths, merges, freeze_row, filter_ref, tab_color = definition
            archive.writestr(
                "xl/worksheets/sheet{}.xml".format(index),
                _worksheet_xml(rows, widths, merges, freeze_row, filter_ref, tab_color),
            )
    return path


def export_html(path, schema, expected_id, expected_hub, findings, stats):
    """Write an interactive, self-contained HTML report for browser review."""
    reports = _collect_reports(findings, stats)
    metadata = _report_metadata(schema, expected_id, expected_hub, stats)
    generated = dict(metadata).get("Generated", "")

    metric_cards = [
        ("Eligible layers", stats.get("scanned_layers", len(reports)), "blue"),
        ("Features scanned", stats.get("features_scanned", 0), "cyan"),
        ("Infinium ID checks", stats.get("id_values_checked", 0), "blue"),
        ("Hub Number checks", stats.get("hub_values_checked", 0), "cyan"),
        ("Errors", stats.get("errors", 0), "error"),
        ("Warnings", stats.get("warnings", 0), "warning"),
        ("Rulebook rules configured", (stats.get("field_rulebook", {}) or {}).get("rule_rows", 0), "blue"),
        ("Rulebook field values checked", (stats.get("field_rulebook", {}) or {}).get("field_values_checked", 0), "cyan"),
        ("Rulebook field types checked", (stats.get("field_rulebook", {}) or {}).get("field_types_checked", 0), "blue"),
        ("Field type mismatches", (stats.get("field_rulebook", {}) or {}).get("field_type_mismatches", 0), "error"),
        ("Missing rulebook fields", len((stats.get("field_rulebook", {}) or {}).get("missing_fields", [])), "warning"),
        ("Missing rulebook layers", len((stats.get("field_rulebook", {}) or {}).get("missing_layers", [])), "warning"),
        ("Empty rulebook layers", len((stats.get("field_rulebook", {}) or {}).get("empty_layers", [])), "warning"),
    ]
    cards_html = "".join(
        '<div class="metric {2}"><span>{0}</span><strong>{1}</strong></div>'.format(
            html.escape(_text(label)), html.escape(_text(value)), css_class
        ) for label, value, css_class in metric_cards
    )

    nav_items = []
    layer_sections = []
    for index, summary in enumerate(reports, 1):
        layer_name = _text(summary.get("layer", "Layer"))
        anchor = "layer-{}".format(index)
        nav_items.append('<a href="#{0}">{1}<span>{2} issue(s)</span></a>'.format(
            anchor, html.escape(layer_name), len(summary.get("findings", []))
        ))
        details = summary.get("findings", [])
        table_rows = []
        if details:
            for finding in details:
                sev = _text(finding.get("severity", "INFO")).upper()
                expression = _qgis_expression(finding.get("feature_id", ""))
                expression_html = (
                    '<button class="copy-expression" type="button" data-expression="{}">Copy</button><code>{}</code>'.format(
                        html.escape(expression, quote=True), html.escape(expression)
                    ) if expression else '<span class="muted">Not available</span>'
                )
                table_rows.append(
                    '<tr data-severity="{sev}">'
                    '<td><span class="severity {sev}">{sev}</span></td>'
                    '<td>{fid}</td><td>{check}</td><td>{field}</td><td class="observed">{observed}</td>'
                    '<td>{finding}</td><td>{remark}</td><td class="expression">{expression}</td></tr>'.format(
                        sev=html.escape(sev),
                        fid=html.escape(_text(finding.get("feature_id", ""))),
                        check=html.escape(_text(finding.get("check", ""))),
                        field=html.escape(_text(finding.get("field", ""))),
                        observed=html.escape(_text(finding.get("observed_value", ""))),
                        finding=html.escape(_text(finding.get("result", ""))),
                        remark=html.escape(_text(finding.get("remark", ""))),
                        expression=expression_html,
                    )
                )
            table_html = (
                '<div class="table-wrap"><table class="findings-table"><thead><tr>'
                '<th>Severity</th><th>Feature ID</th><th>QC Check</th><th>Field</th>'
                '<th>Observed Value</th><th>Finding</th><th>Remark / Action</th><th>QGIS Select Expression</th>'
                '</tr></thead><tbody>{}</tbody></table></div>'.format("".join(table_rows))
            )
        else:
            table_html = '<div class="clean-state">✓ No QC findings were raised for this layer.</div>'

        layer_sections.append(
            '<section class="layer-card" id="{anchor}">'
            '<div class="layer-heading"><div><div class="eyebrow">LAYER {index:02d} · {role}</div>'
            '<h2>{name}</h2></div><div class="layer-result {result}">{result}</div></div>'
            '<div class="layer-stats"><span><b>{features}</b> features scanned</span>'
            '<span><b>{ids}</b> ID checks</span><span><b>{hubs}</b> Hub checks</span>'
            '<span class="err-count"><b>{errors}</b> errors</span><span class="warn-count"><b>{warnings}</b> warnings</span></div>'
            '{table}</section>'.format(
                anchor=anchor, index=index, role=html.escape(_text(summary.get("role", "layer")).upper()),
                name=html.escape(layer_name), result=html.escape(_text(summary.get("result", "PASSED"))),
                features=summary.get("features_scanned", 0), ids=summary.get("id_values_checked", 0),
                hubs=summary.get("hub_values_checked", 0), errors=summary.get("errors", 0),
                warnings=summary.get("warnings", 0), table=table_html,
            )
        )

    metadata_html = "".join(
        '<div class="meta-item"><span>{}</span><strong>{}</strong></div>'.format(
            html.escape(_text(label)), html.escape(_text(value))
        ) for label, value in metadata if label != "Generated"
    )
    html_content = '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>PDS Ziply QC Report — {title}</title>
<style>
:root{{--bg:#0b1220;--panel:#111e30;--panel2:#15283e;--line:#28435d;--text:#e7f2ff;--muted:#9bb2c8;--blue:#168bc5;--cyan:#35d8ff;--red:#ff829b;--amber:#ffd07b;--green:#8de2b7}}
*{{box-sizing:border-box}}body{{margin:0;background:linear-gradient(135deg,#091321,#0e1b2c 55%,#0a1625);color:var(--text);font:14px/1.5 "Segoe UI",Arial,sans-serif}}
a{{color:var(--cyan);text-decoration:none}}a:hover{{text-decoration:underline}}
.topbar{{padding:28px clamp(18px,4vw,54px) 24px;border-bottom:1px solid var(--line);background:rgba(9,20,34,.88)}}
.brand{{display:flex;align-items:center;gap:13px}}.mark{{font-size:28px;font-weight:800;letter-spacing:-3px;color:var(--cyan);text-shadow:0 0 16px #168bc588}}.brand small{{display:block;color:var(--muted);letter-spacing:2px;font-size:10px;text-transform:uppercase}}
h1{{margin:20px 0 5px;font-size:clamp(24px,3vw,36px);line-height:1.15}}.subtitle{{color:var(--muted);margin:0}}
.wrap{{max-width:1600px;margin:0 auto;padding:24px clamp(14px,3vw,42px) 55px}}
.meta-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin:0 0 20px}}
.meta-item,.metric,.layer-card{{background:linear-gradient(150deg,#13243a,#101c2d);border:1px solid var(--line);border-radius:12px}}
.meta-item{{padding:12px 15px;min-width:0}}.meta-item span{{display:block;color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.8px}}.meta-item strong{{display:block;margin-top:4px;overflow-wrap:anywhere}}
.metrics{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:18px 0 25px}}.metric{{padding:15px 16px;border-left:3px solid var(--blue)}}.metric span{{display:block;color:var(--muted);font-size:12px}}.metric strong{{display:block;font-size:25px;margin-top:4px}}.metric.cyan{{border-left-color:var(--cyan)}}.metric.error{{border-left-color:#d64c6a}}.metric.warning{{border-left-color:#d79a39}}
.tools{{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:18px 0 16px}}input,select{{background:#101e30;color:var(--text);border:1px solid #35536f;border-radius:7px;padding:10px 12px;min-width:200px}}input{{flex:1}}.nav{{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 28px}}.nav a{{background:#12263b;border:1px solid var(--line);padding:7px 10px;border-radius:7px;font-size:12px}}.nav span{{color:var(--muted);margin-left:8px}}
.layer-card{{padding:18px;margin:18px 0 22px;scroll-margin-top:14px}}.layer-heading{{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}}.eyebrow{{font-size:10px;letter-spacing:1.3px;color:var(--cyan);font-weight:700}}h2{{margin:3px 0 12px;font-size:21px;overflow-wrap:anywhere}}.layer-result{{font-size:11px;font-weight:800;letter-spacing:.8px;padding:6px 10px;border-radius:20px;background:#183b30;color:var(--green)}}.layer-result.REVIEW{{background:#49391d;color:var(--amber)}}.layer-result.FAILED{{background:#482333;color:var(--red)}}
.layer-stats{{display:flex;gap:10px 18px;flex-wrap:wrap;color:var(--muted);font-size:12px;padding:11px 0 15px;border-bottom:1px solid var(--line);margin-bottom:14px}}.layer-stats b{{color:var(--text)}}.layer-stats .err-count b{{color:var(--red)}}.layer-stats .warn-count b{{color:var(--amber)}}
.table-wrap{{overflow:auto;border:1px solid var(--line);border-radius:8px}}table{{border-collapse:collapse;width:100%;min-width:1100px}}th{{background:#173450;color:#79dfff;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.5px;position:sticky;top:0}}th,td{{padding:10px 11px;border-bottom:1px solid #243b52;vertical-align:top}}td{{color:#dce9f5;max-width:340px;overflow-wrap:anywhere}}tbody tr:nth-child(even){{background:#132339}}tbody tr:hover{{background:#1b3550}}td.observed{{font-family:Consolas,monospace;color:#c6e9ff}}.severity{{display:inline-block;font-size:10px;font-weight:800;border-radius:5px;padding:4px 7px}}.severity.ERROR{{background:#482333;color:var(--red)}}.severity.WARNING{{background:#4a3a1e;color:var(--amber)}}.severity.INFO{{background:#183d32;color:var(--green)}}
.expression{{min-width:150px}}code{{display:block;font:11px Consolas,monospace;color:#8de6ff;margin-top:5px}}.copy-expression{{background:#17496a;border:1px solid #237daf;color:#e4f8ff;border-radius:5px;padding:4px 8px;cursor:pointer}}.copy-expression:hover{{background:#1b638f}}.muted{{color:var(--muted)}}.clean-state{{padding:20px;background:#12382e;color:var(--green);border:1px solid #23654c;border-radius:8px}}
.footer{{color:#7894aa;font-size:11px;padding-top:26px;text-align:center}}
@media(max-width:700px){{.layer-heading{{display:block}}.layer-result{{display:inline-block;margin-bottom:8px}}}}
@media print{{body{{background:#fff;color:#111}}.topbar{{background:#fff;color:#111;border-color:#bbb}}.subtitle,.meta-item span,.metric span,.layer-stats{{color:#444}}.meta-item,.metric,.layer-card{{background:#fff;border-color:#bbb;break-inside:avoid}}.tools,.nav,.copy-expression{{display:none!important}}table{{min-width:0}}th{{position:static;background:#e5edf5;color:#111}}td{{color:#111}}.layer-card{{margin:10px 0;padding:12px}}}}
</style></head>
<body>
<header class="topbar"><div class="brand"><div class="mark">QC</div><div><strong>PDS ZIPLY QC CHECK</strong><small>Quality control report</small></div></div>
<h1>QC Inspection Report</h1><p class="subtitle">Overall result: {overall_result} · Layer-wise findings and scan coverage · Generated {generated}</p></header>
<main class="wrap"><div class="meta-grid">{metadata}</div><div class="metrics">{cards}</div>
<h2>Layer-wise report navigation</h2><div class="nav">{nav}</div>
<div class="tools"><input id="reportSearch" type="search" placeholder="Search findings, fields, feature IDs…" aria-label="Search findings"><select id="severityFilter" aria-label="Filter severity"><option value="ALL">All severities</option><option value="ERROR">Errors</option><option value="WARNING">Warnings</option><option value="INFO">Info</option></select><button class="copy-expression" type="button" onclick="window.print()">Print / Save as PDF</button></div>
<div id="layerReports">{sections}</div>
<div class="footer">Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere · PDS Ziply QC Check</div></main>
<script>
(function(){{
 const search=document.getElementById('reportSearch');const severity=document.getElementById('severityFilter');
 function applyFilters(){{const q=(search.value||'').toLowerCase();const level=severity.value;
 document.querySelectorAll('.findings-table tbody tr').forEach(function(row){{const matchesText=!q||row.textContent.toLowerCase().includes(q);const matchesLevel=level==='ALL'||row.dataset.severity===level;row.style.display=(matchesText&&matchesLevel)?'':'none';}});
 document.querySelectorAll('.layer-card').forEach(function(card){{const visible=card.querySelectorAll('.findings-table tbody tr:not([style*="display: none"])').length;const hasTable=!!card.querySelector('.findings-table');card.style.display=(!hasTable||visible>0)?'':'none';}});
 }}
 search.addEventListener('input',applyFilters);severity.addEventListener('change',applyFilters);
 document.querySelectorAll('.copy-expression').forEach(function(button){{
  button.addEventListener('click',function(){{
   const expression=button.getAttribute('data-expression');if(!expression)return;
   const done=function(){{const old=button.textContent;button.textContent='Copied';setTimeout(function(){{button.textContent=old;}},1200);}};
   if(navigator.clipboard&&navigator.clipboard.writeText){{navigator.clipboard.writeText(expression).then(done).catch(function(){{fallback(expression,done);}});}}else{{fallback(expression,done);}}
  }});
 }});
 function fallback(value,callback){{const el=document.createElement('textarea');el.value=value;document.body.appendChild(el);el.select();try{{document.execCommand('copy');callback();}}catch(e){{}}document.body.removeChild(el);}}
}})();
</script></body></html>'''.format(
        title=html.escape(_text(schema)), overall_result=html.escape(_text(stats.get("result", "INCOMPLETE"))), generated=html.escape(generated), metadata=metadata_html,
        cards=cards_html, nav="".join(nav_items), sections="".join(layer_sections)
    )
    directory = os.path.dirname(os.path.abspath(path))
    if directory and not os.path.isdir(directory):
        os.makedirs(directory)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(html_content)
    return path


def export_reports(xlsx_path, html_path, schema, expected_id, expected_hub, findings, stats):
    """Export both companion report formats."""
    export_xlsx(xlsx_path, schema, expected_id, expected_hub, findings, stats)
    export_html(html_path, schema, expected_id, expected_hub, findings, stats)
    return xlsx_path, html_path
