# -*- coding: utf-8 -*-
"""Main dialog for Ultimate Data Migration.

Copyright © 2077 Amlan Patnaik. All rights reserved.
"""

import json
import os
import re
import uuid
from datetime import datetime

from qgis.PyQt.QtCore import Qt, QCoreApplication
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from qgis.core import QgsProject, QgsVectorLayer

from .migration_engine import PLUGIN_VERSION, layer_storage_info, preview_job, run_job


CONSTANT_FIELD = "(constant)"


def _enum(owner, group, name):
    group_obj = getattr(owner, group, None)
    if group_obj is not None and hasattr(group_obj, name):
        return getattr(group_obj, name)
    return getattr(owner, name)


def _layer_label(layer):
    info = layer_storage_info(layer)
    return "{} | {}".format(layer.name(), info["status"])


def _normalise_layer_name(name):
    value = re.sub(r"[^a-z0-9]+", "", (name or "").lower())
    for suffix in ("offline", "online", "local", "postgresql", "postgres", "copy", "new", "old"):
        if value.endswith(suffix) and len(value) > len(suffix):
            value = value[:-len(suffix)]
    return value


class UltimateDataMigrationDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Ultimate Data Migration | v{}".format(PLUGIN_VERSION))
        self.setMinimumSize(1120, 760)
        self.resize(1450, 900)
        self.setModal(False)

        self.project = QgsProject.instance()
        self.jobs = []
        self.current_job_id = None
        self._loading_mapping = False
        self._last_report = []
        self._cancel_requested = False
        self._run_active = False

        root = QVBoxLayout(self)
        header = QHBoxLayout()
        title_block = QVBoxLayout()
        title = QLabel("ULTIMATE DATA MIGRATION")
        title.setStyleSheet("font-size: 18px; font-weight: 700;")
        subtitle = QLabel("Batch migration for local files, temporary layers and PostgreSQL tables")
        subtitle.setStyleSheet("color: palette(mid);")
        title_block.addWidget(title)
        title_block.addWidget(subtitle)
        header.addLayout(title_block)
        header.addStretch(1)
        self.version_label = QLabel("Version {}".format(PLUGIN_VERSION))
        self.version_label.setStyleSheet("font-weight: 600; padding: 5px 9px; border: 1px solid palette(mid); border-radius: 4px;")
        header.addWidget(self.version_label)
        root.addLayout(header)

        self.tabs = QTabWidget()
        root.addWidget(self.tabs, 1)

        self.jobs_tab = QWidget()
        self.mapping_tab = QWidget()
        self.report_tab = QWidget()
        self.tabs.addTab(self.jobs_tab, "1. Migration Pairs")
        self.tabs.addTab(self.mapping_tab, "2. Field Mapping & Options")
        self.tabs.addTab(self.report_tab, "3. Preview & Report")
        self._build_jobs_tab()
        self._build_mapping_tab()
        self._build_report_tab()

        bottom = QHBoxLayout()
        self.status_label = QLabel("Ready. Add one or more source → target pairs.")
        self.status_label.setWordWrap(True)
        bottom.addWidget(self.status_label, 1)
        self.progress = QProgressBar()
        self.progress.setMinimumWidth(210)
        self.progress.setValue(0)
        bottom.addWidget(self.progress)
        self.preview_button = QPushButton("Preview Batch")
        self.run_button = QPushButton("Run Migration")
        self.cancel_button = QPushButton("Cancel Run")
        self.cancel_button.setEnabled(False)
        self.close_button = QPushButton("Close")
        self.preview_button.clicked.connect(self.preview_batch)
        self.run_button.clicked.connect(self.run_batch)
        self.cancel_button.clicked.connect(self._request_cancel)
        self.close_button.clicked.connect(self.close)
        bottom.addWidget(self.preview_button)
        bottom.addWidget(self.run_button)
        bottom.addWidget(self.cancel_button)
        bottom.addWidget(self.close_button)
        root.addLayout(bottom)

        self._add_pair()
        self._refresh_job_list()
        self._refresh_layer_combos()
        self._update_current_job_view()

    # ------------------------------------------------------------------ UI
    def _build_jobs_tab(self):
        layout = QVBoxLayout(self.jobs_tab)
        intro = QLabel(
            "Create a migration pair for every layer you need to transfer. "
            "The provider and source path are shown directly below each layer selector. "
            "Enable only the pairs you want to include in the batch."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        controls = QHBoxLayout()
        self.add_pair_button = QPushButton("+ Add Migration Pair")
        self.remove_pair_button = QPushButton("− Remove Selected Pair")
        self.auto_pair_button = QPushButton("Auto-Match Similar Layers")
        self.refresh_button = QPushButton("Refresh Project Layers")
        self.save_config_button = QPushButton("Save Batch Configuration")
        self.load_config_button = QPushButton("Load Batch Configuration")
        self.add_pair_button.clicked.connect(self._add_pair)
        self.remove_pair_button.clicked.connect(self._remove_selected_pair)
        self.auto_pair_button.clicked.connect(self.auto_match_pairs)
        self.refresh_button.clicked.connect(self.refresh_layers)
        self.save_config_button.clicked.connect(self.save_configuration)
        self.load_config_button.clicked.connect(self.load_configuration)
        for button in (self.add_pair_button, self.remove_pair_button, self.auto_pair_button, self.refresh_button, self.save_config_button, self.load_config_button):
            controls.addWidget(button)
        controls.addStretch(1)
        layout.addLayout(controls)

        self.jobs_table = QTableWidget(0, 6)
        self.jobs_table.setHorizontalHeaderLabels(["Use", "Source layer", "Source storage / path", "Target layer", "Target storage / path", "Pair"])
        self.jobs_table.verticalHeader().setVisible(False)
        self.jobs_table.setSelectionBehavior(_enum(QTableWidget, "SelectionBehavior", "SelectRows"))
        self.jobs_table.setSelectionMode(_enum(QTableWidget, "SelectionMode", "SingleSelection"))
        self.jobs_table.setAlternatingRowColors(True)
        self.jobs_table.setWordWrap(True)
        self.jobs_table.horizontalHeader().setSectionResizeMode(0, _enum(QHeaderView, "ResizeMode", "ResizeToContents"))
        self.jobs_table.horizontalHeader().setSectionResizeMode(1, _enum(QHeaderView, "ResizeMode", "ResizeToContents"))
        self.jobs_table.horizontalHeader().setSectionResizeMode(2, _enum(QHeaderView, "ResizeMode", "Stretch"))
        self.jobs_table.horizontalHeader().setSectionResizeMode(3, _enum(QHeaderView, "ResizeMode", "ResizeToContents"))
        self.jobs_table.horizontalHeader().setSectionResizeMode(4, _enum(QHeaderView, "ResizeMode", "Stretch"))
        self.jobs_table.horizontalHeader().setSectionResizeMode(5, _enum(QHeaderView, "ResizeMode", "ResizeToContents"))
        self.jobs_table.currentCellChanged.connect(self._on_job_selected)
        layout.addWidget(self.jobs_table, 1)

        note = QLabel(
            "Storage labels: OFFLINE = local file-backed layer (for example GeoPackage/Shapefile); "
            "ONLINE = PostgreSQL provider; TEMPORARY = memory layer; REMOTE = another service provider. "
            "These labels identify provider/storage type, not whether a network host is currently reachable."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: palette(mid); padding: 5px;")
        layout.addWidget(note)

    def _build_mapping_tab(self):
        layout = QVBoxLayout(self.mapping_tab)
        self.mapping_heading = QLabel("Select a pair on the Migration Pairs tab to configure its fields.")
        self.mapping_heading.setStyleSheet("font-weight: 600; font-size: 14px;")
        layout.addWidget(self.mapping_heading)

        splitter = QSplitter(_enum(Qt, "Orientation", "Vertical"))
        layout.addWidget(splitter, 1)

        mapping_group = QGroupBox("Field mapping for the selected pair")
        mapping_layout = QVBoxLayout(mapping_group)
        mapping_controls = QHBoxLayout()
        self.auto_map_button = QPushButton("Auto-map Same-Named Fields")
        self.add_constant_button = QPushButton("+ Add Default Value")
        self.remove_mapping_button = QPushButton("− Remove Selected Mapping")
        self.auto_map_button.clicked.connect(self.auto_map_fields)
        self.add_constant_button.clicked.connect(self.add_constant_mapping)
        self.remove_mapping_button.clicked.connect(self.remove_mapping)
        mapping_controls.addWidget(self.auto_map_button)
        mapping_controls.addWidget(self.add_constant_button)
        mapping_controls.addWidget(self.remove_mapping_button)
        mapping_controls.addStretch(1)
        mapping_layout.addLayout(mapping_controls)

        self.mapping_table = QTableWidget(0, 4)
        self.mapping_table.setHorizontalHeaderLabels(["Source field", "Target field", "Default value (optional)", "Mapping note"])
        self.mapping_table.verticalHeader().setVisible(False)
        self.mapping_table.setAlternatingRowColors(True)
        self.mapping_table.horizontalHeader().setSectionResizeMode(0, _enum(QHeaderView, "ResizeMode", "Stretch"))
        self.mapping_table.horizontalHeader().setSectionResizeMode(1, _enum(QHeaderView, "ResizeMode", "Stretch"))
        self.mapping_table.horizontalHeader().setSectionResizeMode(2, _enum(QHeaderView, "ResizeMode", "Stretch"))
        self.mapping_table.horizontalHeader().setSectionResizeMode(3, _enum(QHeaderView, "ResizeMode", "Stretch"))
        mapping_layout.addWidget(self.mapping_table, 1)
        splitter.addWidget(mapping_group)

        options_group = QGroupBox("Migration behaviour")
        grid = QGridLayout(options_group)
        grid.addWidget(QLabel("Migration mode:"), 0, 0)
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("Insert new features only", "insert")
        self.mode_combo.addItem("Upsert by matching key (update or insert)", "upsert")
        self.mode_combo.addItem("Update matching features only", "update")
        self.mode_combo.currentIndexChanged.connect(self._toggle_match_controls)
        grid.addWidget(self.mode_combo, 0, 1, 1, 3)

        grid.addWidget(QLabel("Source match field:"), 1, 0)
        self.match_source_combo = QComboBox()
        grid.addWidget(self.match_source_combo, 1, 1)
        grid.addWidget(QLabel("Target match field:"), 1, 2)
        self.match_target_combo = QComboBox()
        grid.addWidget(self.match_target_combo, 1, 3)

        self.selected_only_check = QCheckBox("Import selected source features only")
        self.copy_geometry_check = QCheckBox("Transfer geometry")
        self.copy_geometry_check.setChecked(True)
        self.copy_geometry_check.stateChanged.connect(self._toggle_match_controls)
        self.update_geometry_check = QCheckBox("Update geometry for matched records")
        self.multipart_check = QCheckBox("Convert multipart to singlepart")
        self.remove_zm_check = QCheckBox("Remove Z and M dimensions")
        self.skip_nulls_check = QCheckBox("Do not overwrite target values with NULL / empty source values")
        self.generate_uuid_check = QCheckBox("Generate UUID when inserting if target has an unmapped uuid field")
        self.generate_uuid_check.setChecked(True)
        checks = [self.selected_only_check, self.copy_geometry_check, self.update_geometry_check, self.multipart_check, self.remove_zm_check, self.skip_nulls_check, self.generate_uuid_check]
        for i, check in enumerate(checks):
            grid.addWidget(check, 2 + i // 2, i % 2, 1, 2)
        for widget in (self.mode_combo, self.match_source_combo, self.match_target_combo, *checks):
            if isinstance(widget, QComboBox):
                widget.currentIndexChanged.connect(self._store_current_job)
            else:
                widget.stateChanged.connect(self._store_current_job)
        splitter.addWidget(options_group)
        splitter.setSizes([430, 280])
        self._toggle_match_controls()

    def _build_report_tab(self):
        layout = QVBoxLayout(self.report_tab)
        summary = QLabel("Batch validation, preview counts and per-pair execution results appear here.")
        summary.setWordWrap(True)
        layout.addWidget(summary)
        self.report_text = QTextEdit()
        self.report_text.setReadOnly(True)
        self.report_text.setPlaceholderText("Run Preview Batch to inspect the selected migration pairs.")
        layout.addWidget(self.report_text, 1)
        actions = QHBoxLayout()
        self.export_report_button = QPushButton("Export Report…")
        self.export_report_button.clicked.connect(self.export_report)
        actions.addStretch(1)
        actions.addWidget(self.export_report_button)
        layout.addLayout(actions)

    # ---------------------------------------------------------- layer pairs
    def _all_vector_layers(self):
        layers = []
        for layer in self.project.mapLayers().values():
            if isinstance(layer, QgsVectorLayer) and layer.isValid():
                layers.append(layer)
        return sorted(layers, key=lambda item: item.name().lower())

    def _add_pair(self, source_id=None, target_id=None, job_data=None):
        job_id = (job_data or {}).get("id") or str(uuid.uuid4())
        job = {
            "id": job_id,
            "enabled": (job_data or {}).get("enabled", True),
            "source_layer_id": source_id or (job_data or {}).get("source_layer_id", ""),
            "target_layer_id": target_id or (job_data or {}).get("target_layer_id", ""),
            "mappings": list((job_data or {}).get("mappings", [])),
            "options": dict((job_data or {}).get("options", {})),
        }
        defaults = {
            "mode": "insert",
            "match_source_field": "",
            "match_target_field": "",
            "selected_only": False,
            "copy_geometry": True,
            "update_geometry": False,
            "multipart_to_singlepart": False,
            "remove_zm": False,
            "skip_nulls": False,
            "generate_uuid": True,
        }
        defaults.update(job["options"])
        job["options"] = defaults
        self.jobs.append(job)
        row = self.jobs_table.rowCount()
        self.jobs_table.insertRow(row)

        enabled = QCheckBox()
        enabled.setChecked(bool(job["enabled"]))
        enabled.stateChanged.connect(lambda _state, jid=job_id: self._set_job_enabled(jid, enabled.isChecked()))
        self.jobs_table.setCellWidget(row, 0, enabled)

        source_combo = QComboBox()
        target_combo = QComboBox()
        source_combo.setMinimumWidth(180)
        target_combo.setMinimumWidth(180)
        self._populate_layer_combo(source_combo, job["source_layer_id"])
        self._populate_layer_combo(target_combo, job["target_layer_id"])
        source_info = QLabel()
        target_info = QLabel()
        for label in (source_info, target_info):
            label.setWordWrap(True)
            label.setToolTip("")
            label.setTextInteractionFlags(_enum(Qt, "TextInteractionFlag", "TextSelectableByMouse"))
            label.setStyleSheet("font-size: 11px; padding: 3px;")
        remove_button = QPushButton("Remove")
        remove_button.clicked.connect(lambda _checked=False, jid=job_id: self._remove_job(jid))

        source_combo.currentIndexChanged.connect(lambda _idx, jid=job_id: self._layer_changed(jid, "source"))
        target_combo.currentIndexChanged.connect(lambda _idx, jid=job_id: self._layer_changed(jid, "target"))

        self.jobs_table.setCellWidget(row, 1, source_combo)
        self.jobs_table.setCellWidget(row, 2, source_info)
        self.jobs_table.setCellWidget(row, 3, target_combo)
        self.jobs_table.setCellWidget(row, 4, target_info)
        self.jobs_table.setCellWidget(row, 5, remove_button)
        self.jobs_table.setRowHeight(row, 68)
        self._refresh_pair_row(row)
        self.jobs_table.selectRow(row)
        self.current_job_id = job_id
        self._refresh_field_choices()
        self._load_current_job_to_controls()

    def _populate_layer_combo(self, combo, selected_id=None):
        combo.blockSignals(True)
        combo.clear()
        combo.addItem("— Select layer —", "")
        for layer in self._all_vector_layers():
            combo.addItem(layer.name(), layer.id())
        index = combo.findData(selected_id) if selected_id else 0
        combo.setCurrentIndex(index if index >= 0 else 0)
        combo.blockSignals(False)

    def _refresh_pair_row(self, row):
        if row < 0 or row >= self.jobs_table.rowCount():
            return
        source_combo = self.jobs_table.cellWidget(row, 1)
        target_combo = self.jobs_table.cellWidget(row, 3)
        source_label = self.jobs_table.cellWidget(row, 2)
        target_label = self.jobs_table.cellWidget(row, 4)
        source = self.project.mapLayer(source_combo.currentData()) if source_combo and source_combo.currentData() else None
        target = self.project.mapLayer(target_combo.currentData()) if target_combo and target_combo.currentData() else None
        source_label.setText(self._storage_label(source))
        target_label.setText(self._storage_label(target))
        source_label.setToolTip(self._storage_label(source))
        target_label.setToolTip(self._storage_label(target))
        for label, layer in ((source_label, source), (target_label, target)):
            if layer:
                info = layer_storage_info(layer)
                if info["status"] == "ONLINE":
                    label.setStyleSheet("font-size: 11px; padding: 3px; color: #16803c;")
                elif info["status"] == "OFFLINE":
                    label.setStyleSheet("font-size: 11px; padding: 3px; color: #b7791f;")
                else:
                    label.setStyleSheet("font-size: 11px; padding: 3px; color: palette(text);")

    def _storage_label(self, layer):
        if not layer:
            return "Not selected"
        info = layer_storage_info(layer)
        return "{} • {}\n{}".format(info["status"], info["provider"], info["detail"])

    def _job_by_id(self, job_id):
        return next((job for job in self.jobs if job["id"] == job_id), None)

    def _row_for_job(self, job_id):
        for row in range(self.jobs_table.rowCount()):
            combo = self.jobs_table.cellWidget(row, 1)
            if combo and combo.property("job_id") == job_id:
                return row
        # Fallback for Qt versions where dynamic widget properties are not retained
        for row, job in enumerate(self.jobs):
            if job["id"] == job_id:
                return row
        return -1

    def _set_job_enabled(self, job_id, enabled):
        job = self._job_by_id(job_id)
        if job:
            job["enabled"] = bool(enabled)

    def _layer_changed(self, job_id, side):
        self._store_current_job()
        row = self._row_for_job(job_id)
        if row < 0:
            return
        combo = self.jobs_table.cellWidget(row, 1 if side == "source" else 3)
        job = self._job_by_id(job_id)
        if not job:
            return
        id_key = "source_layer_id" if side == "source" else "target_layer_id"
        new_layer_id = combo.currentData() or ""
        if job.get(id_key) != new_layer_id:
            job["mappings"] = []
        job[id_key] = new_layer_id
        self._refresh_pair_row(row)
        if job_id == self.current_job_id:
            self._refresh_field_choices()
            self._build_mapping_for_current_job(reset_if_layer_changed=True)

    def _on_job_selected(self, current_row, _current_col, _previous_row, _previous_col):
        if current_row < 0 or current_row >= len(self.jobs):
            return
        self._store_current_job()
        self.current_job_id = self.jobs[current_row]["id"]
        self._refresh_field_choices()
        self._load_current_job_to_controls()

    def _refresh_job_list(self):
        for row in range(self.jobs_table.rowCount()):
            self._refresh_pair_row(row)

    def _remove_selected_pair(self):
        row = self.jobs_table.currentRow()
        if row >= 0 and row < len(self.jobs):
            self._remove_job(self.jobs[row]["id"])

    def _remove_job(self, job_id):
        self._store_current_job()
        row = self._row_for_job(job_id)
        if row >= 0:
            self.jobs_table.removeRow(row)
        self.jobs = [job for job in self.jobs if job["id"] != job_id]
        self.current_job_id = self.jobs[0]["id"] if self.jobs else None
        if not self.jobs:
            self._add_pair()
        else:
            self.jobs_table.selectRow(0)
            self._update_current_job_view()

    def refresh_layers(self):
        self._store_current_job()
        for row in range(self.jobs_table.rowCount()):
            for col in (1, 3):
                combo = self.jobs_table.cellWidget(row, col)
                old_id = combo.currentData()
                self._populate_layer_combo(combo, old_id)
            self._refresh_pair_row(row)
        self._refresh_field_choices()
        self._update_current_job_view()
        self.status_label.setText("Project layers refreshed.")

    def _refresh_layer_combos(self):
        for row in range(self.jobs_table.rowCount()):
            for col in (1, 3):
                combo = self.jobs_table.cellWidget(row, col)
                if combo:
                    current_id = combo.currentData()
                    self._populate_layer_combo(combo, current_id)
            self._refresh_pair_row(row)

    def auto_match_pairs(self):
        layers = self._all_vector_layers()
        by_name = {}
        for layer in layers:
            base = _normalise_layer_name(layer.name())
            if base:
                by_name.setdefault(base, []).append(layer)
        added = 0
        known = {(job.get("source_layer_id"), job.get("target_layer_id")) for job in self.jobs}
        for _base, candidates in sorted(by_name.items()):
            sources = [layer for layer in candidates if layer_storage_info(layer)["status"] in ("OFFLINE", "TEMPORARY")]
            targets = [layer for layer in candidates if layer_storage_info(layer)["status"] == "ONLINE"]
            for source in sources:
                for target in targets:
                    if source.id() != target.id() and (source.id(), target.id()) not in known:
                        self._add_pair(source.id(), target.id())
                        known.add((source.id(), target.id()))
                        added += 1
        self.status_label.setText("Auto-match added {} pair(s). Review every source and target before running.".format(added))

    # ---------------------------------------------------------- field mapping
    def _current_layers(self):
        job = self._job_by_id(self.current_job_id) if self.current_job_id else None
        if not job:
            return None, None
        return self.project.mapLayer(job.get("source_layer_id")), self.project.mapLayer(job.get("target_layer_id"))

    def _refresh_field_choices(self):
        source, target = self._current_layers()
        self.match_source_combo.blockSignals(True)
        self.match_target_combo.blockSignals(True)
        self.match_source_combo.clear()
        self.match_target_combo.clear()
        self.match_source_combo.addItem("— Select key —", "")
        self.match_target_combo.addItem("— Select key —", "")
        if source:
            for name in source.fields().names():
                self.match_source_combo.addItem(name, name)
        if target:
            for name in target.fields().names():
                self.match_target_combo.addItem(name, name)
        self.match_source_combo.blockSignals(False)
        self.match_target_combo.blockSignals(False)

    def _store_current_job(self):
        if self._loading_mapping or not self.current_job_id:
            return
        job = self._job_by_id(self.current_job_id)
        if not job:
            return
        mappings = []
        for row in range(self.mapping_table.rowCount()):
            source_item = self.mapping_table.item(row, 0)
            target_combo = self.mapping_table.cellWidget(row, 1)
            default_widget = self.mapping_table.cellWidget(row, 2)
            if not source_item or not target_combo:
                continue
            source_field = source_item.text().strip()
            target_field = target_combo.currentData() or target_combo.currentText().strip()
            default_value = default_widget.text() if default_widget else ""
            mappings.append({
                "source_field": source_field,
                "target_field": target_field,
                "default_value": default_value if default_value.strip() != "" else None,
            })
        job["mappings"] = mappings
        job["options"] = {
            "mode": self.mode_combo.currentData() or "insert",
            "match_source_field": self.match_source_combo.currentData() or "",
            "match_target_field": self.match_target_combo.currentData() or "",
            "selected_only": self.selected_only_check.isChecked(),
            "copy_geometry": self.copy_geometry_check.isChecked(),
            "update_geometry": self.update_geometry_check.isChecked(),
            "multipart_to_singlepart": self.multipart_check.isChecked(),
            "remove_zm": self.remove_zm_check.isChecked(),
            "skip_nulls": self.skip_nulls_check.isChecked(),
            "generate_uuid": self.generate_uuid_check.isChecked(),
        }

    def _load_current_job_to_controls(self):
        self._loading_mapping = True
        job = self._job_by_id(self.current_job_id) if self.current_job_id else None
        if not job:
            self.mapping_heading.setText("No migration pair selected.")
            self.mapping_table.setRowCount(0)
            self._loading_mapping = False
            return
        source, target = self._current_layers()
        self.mapping_heading.setText("{}  →  {}".format(source.name() if source else "[source not selected]", target.name() if target else "[target not selected]"))

        options = job.get("options", {})
        self.mode_combo.setCurrentIndex(max(0, self.mode_combo.findData(options.get("mode", "insert"))))
        self._set_combo_data(self.match_source_combo, options.get("match_source_field", ""))
        self._set_combo_data(self.match_target_combo, options.get("match_target_field", ""))
        self.selected_only_check.setChecked(bool(options.get("selected_only")))
        self.copy_geometry_check.setChecked(bool(options.get("copy_geometry", True)))
        self.update_geometry_check.setChecked(bool(options.get("update_geometry")))
        self.multipart_check.setChecked(bool(options.get("multipart_to_singlepart")))
        self.remove_zm_check.setChecked(bool(options.get("remove_zm")))
        self.skip_nulls_check.setChecked(bool(options.get("skip_nulls")))
        self.generate_uuid_check.setChecked(bool(options.get("generate_uuid", True)))
        self._build_mapping_for_current_job()
        self._toggle_match_controls()
        self._loading_mapping = False

    def _set_combo_data(self, combo, value):
        index = combo.findData(value)
        combo.setCurrentIndex(index if index >= 0 else 0)

    def _build_mapping_for_current_job(self, reset_if_layer_changed=False):
        job = self._job_by_id(self.current_job_id) if self.current_job_id else None
        source, target = self._current_layers()
        self.mapping_table.setRowCount(0)
        if not job or not source or not target:
            return
        saved = job.get("mappings", [])
        if saved:
            for mapping in saved:
                self._append_mapping_row(mapping.get("source_field", ""), mapping.get("target_field", ""), mapping.get("default_value"))
        else:
            target_names = {name.lower(): name for name in target.fields().names()}
            for source_name in source.fields().names():
                target_name = target_names.get(source_name.lower(), "")
                self._append_mapping_row(source_name, target_name, None)
        self._update_mapping_notes()

    def _append_mapping_row(self, source_field, target_field="", default_value=None):
        row = self.mapping_table.rowCount()
        self.mapping_table.insertRow(row)
        source_item = QTableWidgetItem(source_field or "")
        source_item.setFlags(source_item.flags() & ~_enum(Qt, "ItemFlag", "ItemIsEditable"))
        self.mapping_table.setItem(row, 0, source_item)
        target_combo = QComboBox()
        target_combo.addItem("— Skip field —", "")
        _source, target = self._current_layers()
        if target:
            target_combo.addItems([""] if False else [])
            for name in target.fields().names():
                target_combo.addItem(name, name)
        self._set_combo_data(target_combo, target_field)
        target_combo.currentIndexChanged.connect(self._update_mapping_notes)
        target_combo.currentIndexChanged.connect(self._store_current_job)
        self.mapping_table.setCellWidget(row, 1, target_combo)
        default_input = QLineEdit()
        if default_value is not None:
            default_input.setText(str(default_value))
        default_input.setPlaceholderText("Use source value when blank")
        default_input.textChanged.connect(self._store_current_job)
        self.mapping_table.setCellWidget(row, 2, default_input)
        self.mapping_table.setItem(row, 3, QTableWidgetItem(""))
        self.mapping_table.setRowHeight(row, 30)

    def _update_mapping_notes(self):
        source, target = self._current_layers()
        if not source or not target:
            return
        source_fields = {field.name(): field for field in source.fields()}
        target_fields = {field.name(): field for field in target.fields()}
        for row in range(self.mapping_table.rowCount()):
            source_name = self.mapping_table.item(row, 0).text()
            target_combo = self.mapping_table.cellWidget(row, 1)
            target_name = target_combo.currentData() or ""
            note = "Not mapped"
            if target_name:
                sf = source_fields.get(source_name)
                tf = target_fields.get(target_name)
                if source_name == CONSTANT_FIELD:
                    note = "Constant value"
                elif sf and tf and sf.type() == tf.type():
                    note = "Type matches"
                elif sf and tf:
                    note = "Check data type conversion"
                else:
                    note = "Review mapping"
            self.mapping_table.setItem(row, 3, QTableWidgetItem(note))

    def auto_map_fields(self):
        source, target = self._current_layers()
        if not source or not target:
            QMessageBox.warning(self, "Select layers", "Choose both source and target layers first.")
            return
        target_lookup = {name.lower(): name for name in target.fields().names()}
        for row in range(self.mapping_table.rowCount()):
            source_name = self.mapping_table.item(row, 0).text()
            combo = self.mapping_table.cellWidget(row, 1)
            match = target_lookup.get(source_name.lower(), "")
            self._set_combo_data(combo, match)
        self._update_mapping_notes()
        self._store_current_job()

    def add_constant_mapping(self):
        _source, target = self._current_layers()
        if not target:
            QMessageBox.warning(self, "Select target", "Choose a target layer first.")
            return
        self._append_mapping_row(CONSTANT_FIELD, "", None)
        self.mapping_table.selectRow(self.mapping_table.rowCount() - 1)
        self._store_current_job()

    def remove_mapping(self):
        row = self.mapping_table.currentRow()
        if row >= 0:
            self.mapping_table.removeRow(row)
            self._store_current_job()

    def _toggle_match_controls(self, *_args):
        mode = self.mode_combo.currentData()
        show = mode in ("upsert", "update")
        self.match_source_combo.setEnabled(show)
        self.match_target_combo.setEnabled(show)
        self.update_geometry_check.setEnabled(show and self.copy_geometry_check.isChecked())
        self.multipart_check.setEnabled(mode == "insert")

    def _update_current_job_view(self):
        if self.jobs:
            self.current_job_id = self.jobs[0]["id"]
            self._refresh_field_choices()
            self._load_current_job_to_controls()
        else:
            self.mapping_heading.setText("Add a migration pair to begin.")

    # --------------------------------------------------------------- batch
    def _enabled_jobs(self):
        self._store_current_job()
        return [job for job in self.jobs if job.get("enabled", True)]

    def _validate_batch_targets(self, jobs):
        target_ids = [job.get("target_layer_id") for job in jobs if job.get("target_layer_id")]
        duplicates = sorted({target_id for target_id in target_ids if target_ids.count(target_id) > 1})
        if duplicates:
            names = []
            for layer_id in duplicates:
                layer = self.project.mapLayer(layer_id)
                names.append(layer.name() if layer else layer_id)
            return ["The same target layer is configured in more than one enabled pair: {}. Use one source pair per target in a batch to avoid competing writes.".format(", ".join(names))]
        return []

    def preview_batch(self):
        jobs = self._enabled_jobs()
        if not jobs:
            QMessageBox.information(self, "Nothing to preview", "Enable at least one migration pair.")
            return
        lines = ["ULTIMATE DATA MIGRATION — BATCH PREVIEW", "Version: {}".format(PLUGIN_VERSION), "Created: {}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S")), ""]
        batch_errors = self._validate_batch_targets(jobs)
        all_valid = not batch_errors
        for message in batch_errors:
            lines.append("BATCH ERROR: " + message)
        for number, job in enumerate(jobs, 1):
            result = preview_job(job, self.project)
            source = result["source"]
            target = result["target"]
            lines.append("{}. {}  →  {}".format(number, source.name() if source else "[missing source]", target.name() if target else "[missing target]"))
            if source:
                lines.append("   SOURCE: {}".format(self._storage_label(source).replace("\n", " | ")))
            if target:
                lines.append("   TARGET: {}".format(self._storage_label(target).replace("\n", " | ")))
            lines.append("   Features to read: {} | Target currently contains: {}".format(result["source_count"], result["target_count"]))
            for warning in result["warnings"]:
                lines.append("   WARNING: " + warning)
            for error in result["errors"]:
                lines.append("   ERROR: " + error)
            if result["errors"]:
                all_valid = False
            else:
                lines.append("   VALIDATION: PASS")
            lines.append("")
        lines.append("BATCH VALIDATION: {}".format("PASS — ready to run after review" if all_valid else "FAILED — fix errors before running"))
        self.report_text.setPlainText("\n".join(lines))
        self._last_report = [{"type": "preview", "text": "\n".join(lines)}]
        self.tabs.setCurrentWidget(self.report_tab)
        self.status_label.setText("Preview complete: {} enabled pair(s); {}.".format(len(jobs), "all checks passed" if all_valid else "validation errors found"))
        return all_valid

    def _request_cancel(self):
        self._cancel_requested = True
        self.status_label.setText("Cancellation requested. The active pair will roll back at the next feature boundary.")

    def run_batch(self):
        jobs = self._enabled_jobs()
        if not jobs:
            QMessageBox.information(self, "Nothing to migrate", "Enable at least one migration pair.")
            return
        batch_errors = self._validate_batch_targets(jobs)
        if batch_errors:
            QMessageBox.warning(self, "Batch configuration error", "\n".join(batch_errors))
            return

        # Complete preflight for every pair before the first write.
        preview_results = [preview_job(job, self.project) for job in jobs]
        errors = []
        for job, result in zip(jobs, preview_results):
            name = result["source"].name() if result["source"] else "Unknown source"
            for error in result["errors"]:
                errors.append("{}: {}".format(name, error))
        if errors:
            QMessageBox.warning(self, "Preflight failed", "No data has been changed. Fix these issues first:\n\n" + "\n".join(errors))
            self.preview_batch()
            return

        total_features = sum(result["source_count"] for result in preview_results)
        confirmation = QMessageBox.question(
            self,
            "Confirm batch migration",
            "You are about to run {} migration pair(s) for up to {} source feature(s).\n\n"
            "Source features will be retained. Each target layer is committed separately. "
            "If one pair fails, that pair is rolled back and later pairs are still attempted.\n\nContinue?".format(len(jobs), total_features),
            _enum(QMessageBox, "StandardButton", "Yes") | _enum(QMessageBox, "StandardButton", "No"),
            _enum(QMessageBox, "StandardButton", "No"),
        )
        if confirmation != _enum(QMessageBox, "StandardButton", "Yes"):
            return

        self._cancel_requested = False
        self._run_active = True
        self.run_button.setEnabled(False)
        self.preview_button.setEnabled(False)
        self.cancel_button.setEnabled(True)
        self.close_button.setEnabled(False)
        self.tabs.setEnabled(False)
        self.progress.setRange(0, max(total_features, 1))
        self.progress.setValue(0)
        total_done = 0
        batch_results = []
        log_lines = ["ULTIMATE DATA MIGRATION — EXECUTION REPORT", "Version: {}".format(PLUGIN_VERSION), "Started: {}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S")), ""]

        try:
            for index, job in enumerate(jobs, 1):
                if self._cancel_requested:
                    log_lines.append("CANCELLED: Remaining migration pairs were not started.")
                    break
                source = self.project.mapLayer(job.get("source_layer_id"))
                target = self.project.mapLayer(job.get("target_layer_id"))
                pair_title = "{} → {}".format(source.name() if source else "Missing source", target.name() if target else "Missing target")
                self.status_label.setText("Processing pair {}/{}: {}".format(index, len(jobs), pair_title))
                QCoreApplication.processEvents()
                local_total = preview_results[index - 1]["source_count"]

                def update_progress(done, _total, _source_name, _inserted, _updated, _skipped):
                    nonlocal total_done
                    if self._cancel_requested:
                        raise RuntimeError("Migration cancelled by user; the active target pair is being rolled back.")
                    total_done = min(total_features, total_done + (1 if done > getattr(update_progress, "last_done", 0) else 0))
                    update_progress.last_done = done
                    self.progress.setValue(total_done)
                    if done % 25 == 0 or done == _total:
                        self.status_label.setText("{} — {}/{} processed".format(pair_title, done, _total))
                        QCoreApplication.processEvents()
                        if self._cancel_requested:
                            raise RuntimeError("Migration cancelled by user; the active target pair is being rolled back.")

                update_progress.last_done = 0
                try:
                    result = run_job(job, update_progress, self.project)
                    result["status"] = "SUCCESS"
                    batch_results.append(result)
                    log_lines.append("SUCCESS: {}".format(pair_title))
                    log_lines.append("  Processed: {} | Inserted: {} | Updated: {} | Skipped: {}".format(result["processed"], result["inserted"], result["updated"], result["skipped"]))
                    for warning in result.get("warnings", []):
                        log_lines.append("  WARNING: " + warning)
                except Exception as exc:
                    result = {"source_name": source.name() if source else "?", "target_name": target.name() if target else "?", "status": "FAILED", "error": str(exc), "processed": 0, "inserted": 0, "updated": 0, "skipped": 0}
                    batch_results.append(result)
                    log_lines.append("FAILED: {}".format(pair_title))
                    log_lines.append("  ERROR: {}".format(exc))
                log_lines.append("")
                total_done = min(total_features, total_done + max(0, local_total - update_progress.last_done))
                self.progress.setValue(total_done)
                QCoreApplication.processEvents()
        finally:
            self.run_button.setEnabled(True)
            self.preview_button.setEnabled(True)
            self.cancel_button.setEnabled(False)
            self.close_button.setEnabled(True)
            self.tabs.setEnabled(True)
            self._run_active = False
            self.progress.setValue(self.progress.maximum())

        success_count = sum(1 for result in batch_results if result.get("status") == "SUCCESS")
        failure_count = len(batch_results) - success_count
        log_lines.extend([
            "Finished: {}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            "SUMMARY: {} succeeded, {} failed.".format(success_count, failure_count),
            "",
            "SAFETY: Source features were not deleted. Target commits were attempted and checked per pair.",
        ])
        self._last_report = batch_results
        self.report_text.setPlainText("\n".join(log_lines))
        self.tabs.setCurrentWidget(self.report_tab)
        cancelled = self._cancel_requested
        self.status_label.setText("Batch cancelled: {} succeeded, {} failed.".format(success_count, failure_count) if cancelled else "Batch finished: {} succeeded, {} failed.".format(success_count, failure_count))
        QMessageBox.information(self, "Migration cancelled" if cancelled else "Migration finished", "{} pair(s) succeeded. {} pair(s) failed.{}\n\nOpen the Preview & Report tab for details.".format(success_count, failure_count, " Remaining pairs were not started." if cancelled else ""))

    # --------------------------------------------------------------- config
    def save_configuration(self):
        self._store_current_job()
        file_path, _ = QFileDialog.getSaveFileName(self, "Save Migration Configuration", "ultimate_data_migration.json", "JSON Files (*.json)")
        if not file_path:
            return
        payload = {
            "plugin": "Ultimate Data Migration",
            "version": PLUGIN_VERSION,
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "jobs": self.jobs,
        }
        try:
            with open(file_path, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2, ensure_ascii=False)
            QMessageBox.information(self, "Configuration saved", "Saved {} migration pair(s).".format(len(self.jobs)))
        except Exception as exc:
            QMessageBox.critical(self, "Save failed", str(exc))

    def load_configuration(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Load Migration Configuration", "", "JSON Files (*.json)")
        if not file_path:
            return
        try:
            with open(file_path, "r", encoding="utf-8") as handle:
                payload = json.load(handle)
            if not isinstance(payload, dict) or not isinstance(payload.get("jobs"), list):
                raise ValueError("This file is not a valid Ultimate Data Migration configuration.")
            self.jobs = []
            self.jobs_table.setRowCount(0)
            for job in payload["jobs"]:
                self._add_pair(job_data=job)
            if not self.jobs:
                self._add_pair()
            self.jobs_table.selectRow(0)
            self._update_current_job_view()
            QMessageBox.information(self, "Configuration loaded", "Loaded {} migration pair(s). Review the selected layers and paths before running.".format(len(self.jobs)))
        except Exception as exc:
            QMessageBox.critical(self, "Load failed", str(exc))

    def export_report(self):
        text = self.report_text.toPlainText().strip()
        if not text:
            QMessageBox.information(self, "No report", "Run a preview or migration before exporting a report.")
            return
        file_path, _ = QFileDialog.getSaveFileName(self, "Export Migration Report", "ultimate_data_migration_report.txt", "Text Files (*.txt);;Log Files (*.log)")
        if not file_path:
            return
        try:
            with open(file_path, "w", encoding="utf-8") as handle:
                handle.write(text + "\n")
            QMessageBox.information(self, "Report exported", "Report saved to:\n{}".format(file_path))
        except Exception as exc:
            QMessageBox.critical(self, "Export failed", str(exc))

    def closeEvent(self, event):
        if self._run_active:
            self._request_cancel()
            event.ignore()
            return
        self._store_current_job()
        super().closeEvent(event)
