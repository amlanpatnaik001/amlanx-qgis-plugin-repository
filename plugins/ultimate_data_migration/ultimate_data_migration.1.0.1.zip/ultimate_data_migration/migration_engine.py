# -*- coding: utf-8 -*-
"""Migration engine for Ultimate Data Migration.

Copyright © 2077 Amlan Patnaik. All rights reserved.
"""

import re
import uuid

from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureRequest,
    QgsGeometry,
    QgsMapLayer,
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
)


PLUGIN_VERSION = "1.0.0"


def _enum_value(owner, enum_group, name):
    """Return a Qt/QGIS enum member across Qt5 and Qt6 style APIs."""
    group = getattr(owner, enum_group, None)
    if group is not None and hasattr(group, name):
        return getattr(group, name)
    return getattr(owner, name)


def _redact_uri(uri):
    """Remove credential-like values before showing a provider URI in the UI."""
    text = str(uri or "")
    patterns = (
        r"(?i)(password\s*=\s*)('[^']*'|\"[^\"]*\"|[^\s]+)",
        r"(?i)(passwd\s*=\s*)('[^']*'|\"[^\"]*\"|[^\s]+)",
        r"(?i)(pwd\s*=\s*)('[^']*'|\"[^\"]*\"|[^\s]+)",
        r"(?i)(token\s*=\s*)('[^']*'|\"[^\"]*\"|[^\s]+)",
        r"(?i)(authcfg\s*=\s*)('[^']*'|\"[^\"]*\"|[^\s]+)",
    )
    for pattern in patterns:
        text = re.sub(pattern, r"\1<redacted>", text)
    # Also protect URL-style connection strings such as postgresql://user:pass@host/db.
    text = re.sub(r"(?i)(://[^:/\s]+:)[^@/\s]+(@)", r"\1<redacted>\2", text)
    return text


def _extract_postgres_details(uri):
    """Extract useful PostgreSQL connection/table labels without credentials."""
    text = _redact_uri(uri)
    details = []
    for key, label in (("host", "host"), ("port", "port"), ("dbname", "database"), ("service", "service")):
        match = re.search(r"(?i)(?:^|\s)" + key + r"\s*=\s*(?:'([^']*)'|\"([^\"]*)\"|([^\s]+))", text)
        if match:
            value = next((group for group in match.groups() if group is not None), "")
            if value:
                details.append("{}={}".format(label, value))
    table_match = re.search(r'(?i)table\s*=\s*(?:"([^"]+)"\.)?"?([^"\s(]+)', text)
    if table_match:
        schema = table_match.group(1)
        table = table_match.group(2)
        details.append("table={}".format((schema + "." if schema else "") + table))
    return details


def layer_storage_info(layer):
    """Return a human-readable storage classification and provider URI.

    OFFLINE: file-backed local providers such as OGR/GeoPackage/Shapefile.
    ONLINE: PostgreSQL provider (connection-backed database layer).
    TEMPORARY: memory layers.
    REMOTE: other service/connection providers. This is a provider classification,
    not a test of internet reachability.
    """
    if not layer or not isinstance(layer, QgsVectorLayer):
        return {"status": "UNKNOWN", "provider": "Unknown", "detail": "Layer unavailable"}

    provider = (layer.providerType() or "unknown").lower()
    uri = _redact_uri(layer.source())

    if provider in ("postgres", "postgresql"):
        status = "ONLINE"
        provider_label = "PostgreSQL"
        details = _extract_postgres_details(layer.source())
        detail = " | ".join(details) if details else uri
    elif provider == "memory":
        status = "TEMPORARY"
        provider_label = "Memory layer"
        detail = "Temporary in-project data; not saved to disk automatically"
    elif provider in ("ogr", "spatialite", "delimitedtext", "gpx"):
        if uri.lower().startswith(("http://", "https://")):
            status = "REMOTE"
            provider_label = "Remote OGR resource"
        else:
            status = "OFFLINE"
            provider_label = {
                "ogr": "Local file / OGR",
                "spatialite": "Local SpatiaLite",
                "delimitedtext": "Local delimited text",
                "gpx": "Local GPX",
            }.get(provider, provider)
        detail = uri
    else:
        status = "REMOTE"
        provider_label = provider.upper() if provider != "unknown" else "Unknown provider"
        detail = uri

    return {
        "status": status,
        "provider": provider_label,
        "detail": detail or "Provider did not expose a source path",
        "provider_key": provider,
    }


def _is_null(value):
    if value is None:
        return True
    # QGIS providers normally expose NULL as Python None. This also tolerates
    # QVariant-like values under Qt5 without importing QVariant (removed from
    # the public PyQt6 API used by QGIS 4).
    try:
        is_valid = getattr(value, "isValid", None)
        is_null = getattr(value, "isNull", None)
        if callable(is_valid) and callable(is_null):
            return (not is_valid()) or is_null()
    except Exception:
        pass
    return False


def _normalise_key(value):
    if _is_null(value):
        return None
    return str(value).strip()


def _coerce_value(value, target_field):
    """Convert common literal/default values to the target field's QVariant type."""
    if _is_null(value):
        return None

    type_name = (target_field.typeName() or "").lower()
    type_description = str(target_field.type()).lower()
    combined_type = type_name + " " + type_description
    if isinstance(value, str):
        stripped = value.strip()
        if stripped == "":
            return None
        value = stripped

    if any(token in combined_type for token in ("bool",)):
        if isinstance(value, str):
            low = value.lower()
            if low in ("1", "true", "yes", "y"):
                return True
            if low in ("0", "false", "no", "n"):
                return False
            raise ValueError("Expected true/false, yes/no or 1/0 for a Boolean field")
        return bool(value)

    if any(token in combined_type for token in ("int", "serial", "long", "short")):
        if isinstance(value, str) and value.lower() in ("true", "yes", "y"):
            return 1
        if isinstance(value, str) and value.lower() in ("false", "no", "n"):
            return 0
        return int(value)

    if any(token in combined_type for token in ("double", "real", "numeric", "decimal", "float")):
        return float(value)

    return value


def validate_job(job, project=None):
    """Validate one job and return (source_layer, target_layer, errors, warnings)."""
    project = project or QgsProject.instance()
    errors = []
    warnings = []

    source = project.mapLayer(job.get("source_layer_id"))
    target = project.mapLayer(job.get("target_layer_id"))

    if not source or not isinstance(source, QgsVectorLayer) or not source.isValid():
        errors.append("Source layer is missing or invalid.")
    if not target or not isinstance(target, QgsVectorLayer) or not target.isValid():
        errors.append("Target layer is missing or invalid.")
    if errors:
        return source, target, errors, warnings

    if source.id() == target.id():
        errors.append("Source and target cannot be the same layer.")
    if target.isEditable():
        errors.append(
            "Target layer is already in edit mode. Save or discard its pending edits before migration. "
            "The tool will not commit or roll back edits that existed before this run."
        )

    options = job.get("options", {})
    mode = options.get("mode", "insert")
    mappings = job.get("mappings", [])
    mapped_targets = set()
    valid_mapping_count = 0

    source_names = set(source.fields().names())
    target_names = set(target.fields().names())
    for number, mapping in enumerate(mappings, 1):
        source_name = (mapping.get("source_field") or "").strip()
        target_name = (mapping.get("target_field") or "").strip()
        default_value = mapping.get("default_value")
        if not target_name:
            continue
        if target_name not in target_names:
            errors.append("Mapping {}: target field '{}' does not exist.".format(number, target_name))
            continue
        if target_name in mapped_targets:
            errors.append("Target field '{}' is mapped more than once.".format(target_name))
            continue
        mapped_targets.add(target_name)
        if source_name not in ("", "(constant)") and source_name not in source_names:
            errors.append("Mapping {}: source field '{}' does not exist.".format(number, source_name))
            continue
        if source_name in ("", "(constant)") and default_value is None:
            errors.append("Mapping {}: constant mapping to '{}' needs a default value.".format(number, target_name))
            continue
        try:
            target_field = target.fields().field(target_name)
            if default_value is not None:
                _coerce_value(default_value, target_field)
        except Exception as exc:
            errors.append("Mapping {}: default value for '{}' is invalid: {}".format(number, target_name, exc))
            continue
        valid_mapping_count += 1

    if not valid_mapping_count and options.get("copy_geometry", True) is False:
        errors.append("No attribute mappings or geometry transfer are configured.")

    if mode in ("upsert", "update"):
        source_match = options.get("match_source_field", "")
        target_match = options.get("match_target_field", "")
        if source_match not in source_names:
            errors.append("Choose a valid source match field for the selected update mode.")
        if target_match not in target_names:
            errors.append("Choose a valid target match field for the selected update mode.")
        if options.get("multipart_to_singlepart"):
            errors.append("Multipart-to-singlepart conversion is disabled for key-based updates because one source key could map to several output parts.")

    selected_only = bool(options.get("selected_only"))
    if selected_only and source.selectedFeatureCount() == 0:
        errors.append("Selected-features-only is enabled, but no source features are selected.")
    if source.isEditable():
        warnings.append("Source layer is in edit mode. Migration reads its current edit buffer, including unsaved source edits.")

    copy_geometry = options.get("copy_geometry", True)
    if copy_geometry:
        source_has_geom = source.wkbType() != QgsWkbTypes.NoGeometry
        target_has_geom = target.wkbType() != QgsWkbTypes.NoGeometry
        if source_has_geom and not target_has_geom:
            errors.append("Source has geometry but target is a non-spatial table. Disable geometry transfer or choose a spatial target.")
        elif not source_has_geom and target_has_geom:
            warnings.append("Source has no geometry; target features will be created with empty geometry (if the provider permits it).")
        elif source_has_geom and target_has_geom:
            source_family = QgsWkbTypes.geometryType(source.wkbType())
            target_family = QgsWkbTypes.geometryType(target.wkbType())
            if source_family != target_family:
                errors.append("Source and target geometry families differ (for example, line versus polygon).")
            source_multi = QgsWkbTypes.isMultiType(source.wkbType())
            target_multi = QgsWkbTypes.isMultiType(target.wkbType())
            if source_multi and not target_multi and not options.get("multipart_to_singlepart"):
                errors.append("Source is multipart but target is singlepart. Enable multipart-to-singlepart conversion or choose a compatible target.")
            if source.crs().isValid() and target.crs().isValid() and source.crs() != target.crs():
                warnings.append("CRS differs: geometries will be transformed from {} to {}.".format(source.crs().authid(), target.crs().authid()))
            elif not source.crs().isValid() or not target.crs().isValid():
                errors.append("Source or target CRS is invalid; set valid coordinate reference systems before geometry migration.")

    if not target.dataProvider():
        errors.append("Target layer has no valid data provider.")

    return source, target, errors, warnings


def preview_job(job, project=None):
    source, target, errors, warnings = validate_job(job, project)
    result = {
        "source": source,
        "target": target,
        "errors": errors,
        "warnings": warnings,
        "source_count": 0,
        "selected_count": 0,
        "target_count": 0,
    }
    if source and source.isValid():
        result["source_count"] = source.featureCount()
        result["selected_count"] = source.selectedFeatureCount()
        if job.get("options", {}).get("selected_only"):
            result["source_count"] = source.selectedFeatureCount()
    if target and target.isValid():
        result["target_count"] = target.featureCount()
    return result


def run_job(job, progress_callback=None, project=None):
    """Execute one migration pair. The target edit session is owned by this call.

    Returns a result dictionary. If a feature/commit operation fails, edits from
    this job are rolled back. Existing target edit buffers are rejected in
    validate_job(), so rollback cannot erase pre-existing user edits.
    """
    project = project or QgsProject.instance()
    source, target, errors, warnings = validate_job(job, project)
    if errors:
        raise ValueError("\n".join(errors))

    options = job.get("options", {})
    mappings = [m for m in job.get("mappings", []) if (m.get("target_field") or "").strip()]
    selected_only = bool(options.get("selected_only"))
    mode = options.get("mode", "insert")
    copy_geometry = bool(options.get("copy_geometry", True))
    update_geometry = bool(options.get("update_geometry", False))
    multipart_to_singlepart = bool(options.get("multipart_to_singlepart", False))
    remove_zm = bool(options.get("remove_zm", False))
    skip_nulls = bool(options.get("skip_nulls", False))
    generate_uuid = bool(options.get("generate_uuid", True))

    if selected_only:
        request = QgsFeatureRequest().setFilterFids(list(source.selectedFeatureIds()))
        total = source.selectedFeatureCount()
        source_iterator = source.getFeatures(request)
    else:
        total = source.featureCount()
        source_iterator = source.getFeatures()

    transformer = None
    if copy_geometry and source.wkbType() != QgsWkbTypes.NoGeometry and target.wkbType() != QgsWkbTypes.NoGeometry and source.crs() != target.crs():
        transformer = QgsCoordinateTransform(source.crs(), target.crs(), project)

    source_field_indexes = {name: source.fields().indexFromName(name) for name in source.fields().names()}
    target_field_indexes = {name: target.fields().indexFromName(name) for name in target.fields().names()}
    target_fields = target.fields()

    # A unique match key must be unique in the target. Ambiguous keys are blocked.
    target_index = {}
    if mode in ("upsert", "update"):
        target_match_field = options["match_target_field"]
        for existing in target.getFeatures():
            key = _normalise_key(existing[target_match_field])
            if key is None:
                continue
            if key in target_index:
                raise ValueError("Target match field '{}' contains duplicate value '{}'. Resolve duplicates before migration.".format(target_match_field, key))
            target_index[key] = QgsFeature(existing)

    if not target.startEditing():
        raise RuntimeError("Could not start editing the target layer: {}".format(target.name()))

    inserted = 0
    updated = 0
    skipped = 0
    processed = 0
    failed = 0
    commit_ok = False
    seen_source_keys = set()

    try:
        for source_feature in source_iterator:
            processed += 1
            source_key = None
            target_feature = None

            if mode in ("upsert", "update"):
                source_key = _normalise_key(source_feature[options["match_source_field"]])
                if source_key is None:
                    skipped += 1
                    if progress_callback:
                        progress_callback(processed, total, source.name(), inserted, updated, skipped)
                    continue
                if source_key in seen_source_keys:
                    raise ValueError("Source match field '{}' contains duplicate value '{}'. Resolve duplicate source keys before migration.".format(options["match_source_field"], source_key))
                seen_source_keys.add(source_key)
                target_feature = target_index.get(source_key)

            if target_feature is None and mode == "update":
                skipped += 1
                if progress_callback:
                    progress_callback(processed, total, source.name(), inserted, updated, skipped)
                continue

            is_update = target_feature is not None
            output_geometries = [None]
            if copy_geometry and source.wkbType() != QgsWkbTypes.NoGeometry:
                geom = QgsGeometry(source_feature.geometry())
                if transformer:
                    transform_result = geom.transform(transformer)
                    try:
                        if int(transform_result) != 0:
                            raise RuntimeError("Geometry reprojection failed: {}".format(geom.lastError() or transform_result))
                    except (TypeError, ValueError):
                        # Some QGIS builds return None on successful transforms.
                        pass
                if remove_zm:
                    if hasattr(geom, "dropZValue"):
                        geom.dropZValue()
                    if hasattr(geom, "dropMValue"):
                        geom.dropMValue()
                if multipart_to_singlepart and geom.isMultipart():
                    output_geometries = geom.asGeometryCollection()
                else:
                    output_geometries = [geom]
            elif not copy_geometry or target.wkbType() == QgsWkbTypes.NoGeometry:
                output_geometries = [None]

            if not output_geometries:
                skipped += 1
                continue

            for output_geometry in output_geometries:
                feature = QgsFeature(target_fields)
                if is_update:
                    feature = QgsFeature(target_feature)
                elif output_geometry is not None:
                    feature.setGeometry(output_geometry)

                for mapping in mappings:
                    source_name = (mapping.get("source_field") or "").strip()
                    target_name = (mapping.get("target_field") or "").strip()
                    if not target_name:
                        continue
                    default_value = mapping.get("default_value")
                    if default_value is not None:
                        raw_value = default_value
                    elif source_name and source_name != "(constant)":
                        raw_value = source_feature[source_field_indexes[source_name]]
                    else:
                        raw_value = None

                    if skip_nulls and _is_null(raw_value):
                        continue
                    if skip_nulls and isinstance(raw_value, str) and raw_value.strip() == "":
                        continue
                    converted = _coerce_value(raw_value, target_fields.field(target_name))
                    feature.setAttribute(target_field_indexes[target_name], converted)

                if is_update:
                    if copy_geometry and update_geometry and output_geometry is not None:
                        feature.setGeometry(output_geometry)
                    if not target.updateFeature(feature):
                        raise RuntimeError("Failed updating target feature for key '{}'.".format(source_key))
                    updated += 1
                else:
                    if generate_uuid:
                        uuid_field = next((name for name in target_fields.names() if name.lower() == "uuid"), None)
                        mapped_uuid = any((m.get("target_field") or "").lower() == "uuid" for m in mappings)
                        if uuid_field and not mapped_uuid and _is_null(feature[uuid_field]):
                            feature.setAttribute(target_field_indexes[uuid_field], str(uuid.uuid4()))
                    if not target.addFeature(feature):
                        raise RuntimeError("Failed adding a feature to target layer '{}'.".format(target.name()))
                    inserted += 1

            if progress_callback:
                progress_callback(processed, total, source.name(), inserted, updated, skipped)

        commit_ok = target.commitChanges()
        if not commit_ok:
            commit_errors = target.commitErrors() if hasattr(target, "commitErrors") else []
            raise RuntimeError("Commit failed for '{}': {}".format(target.name(), "; ".join(commit_errors) or "provider returned failure"))

    except Exception:
        if target.isEditable():
            target.rollBack()
        raise

    return {
        "source_name": source.name(),
        "target_name": target.name(),
        "processed": processed,
        "inserted": inserted,
        "updated": updated,
        "skipped": skipped,
        "failed": failed,
        "warnings": warnings,
        "commit_ok": commit_ok,
    }
