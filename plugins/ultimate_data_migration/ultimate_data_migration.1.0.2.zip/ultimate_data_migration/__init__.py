# -*- coding: utf-8 -*-
"""Ultimate Data Migration QGIS plugin.

Copyright © 2077 Amlan Patnaik. All rights reserved.
"""


def classFactory(iface):
    from .ultimate_data_migration import UltimateDataMigrationPlugin
    return UltimateDataMigrationPlugin(iface)
