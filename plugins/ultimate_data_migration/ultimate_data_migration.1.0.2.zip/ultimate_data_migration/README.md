# Ultimate Data Migration

**Version:** 1.0.2  
**Author:** Amlan Patnaik  
**Copyright:** Copyright © 2077 Amlan Patnaik. All rights reserved.

Ultimate Data Migration is a QGIS plugin for configuring and executing several vector-layer migrations in one batch. It is designed for workflows such as moving offline GeoPackage/Shapefile edits into matching PostgreSQL/PostGIS layers.

## 1. Main workflow

1. Open the QGIS project containing the source and target layers.
2. Open **Plugins → Ultimate Data Migration** (also available from the plugin toolbar).
3. In **Migration Pairs**, add one row for every layer transfer. Example:
   - `Fiber_Cable_Offline` → `Fiber_Cable` (PostgreSQL)
   - `Equipment_Offline` → `Equipment` (PostgreSQL)
   - `Slackloop_Offline` → `Slackloop` (PostgreSQL)
4. Inspect the source and target storage labels and paths shown under each layer selector.
5. Select each pair and configure its field mapping and migration options on the **Field Mapping & Options** tab.
6. Click **Preview Batch** and review every warning/error.
7. Click **Run Migration** only after confirming the source/target pairings, field mappings, keys, and target paths.
8. Review and export the execution report from **Preview & Report**.

## 2. Storage labels

| Label | Meaning |
|---|---|
| `OFFLINE` | Common local file-backed providers such as OGR/GeoPackage/Shapefile, SpatiaLite, delimited text and GPX. |
| `ONLINE` | PostgreSQL provider. Host, port, database and table details are shown when exposed by the provider URI. |
| `TEMPORARY` | In-memory QGIS layer. It is not automatically saved to a permanent file. |
| `REMOTE` | Another service or connection provider. |

These are provider/storage classifications, not live connection tests. A PostgreSQL layer may display `ONLINE` even when the database server is unreachable or the user has no write permission. The plugin does not display passwords; credential-like values are redacted from the visible URI.

## 3. Migration modes

### Insert new features only
Adds source records as new target features. It does not check for duplicates by itself. Preview and choose this mode only when inserting new records is intended.

### Upsert by matching key
Looks up each source record using a source match field and a target match field. A matching target record is updated; otherwise a new record is inserted. The target match field must be unique. Duplicate values in the target match field stop the migration before edits begin.

### Update matching features only
Updates target records with a matching key and skips source records that do not match. It does not add new target features.

For telecom layers, a stable unique `uuid` field is usually a better key than a mutable label such as cable name. Ensure source and target UUID values use the same format.

## 4. Automatic field matching

Field matching is automatic when a source/target pair is selected. No manual selection is required for normal source fields.

- The plugin matches field names case-insensitively and ignores spaces, underscores, and punctuation.
- Example: `cable_name`, `Cable Name`, and `CABLE-NAME` are treated as the same field name.
- A source field is copied only when there is one unambiguous target field match.
- Source fields with no matching target field are skipped automatically. They are not shown as blank dropdowns and do not block the migration.
- Provider-managed identifier fields such as `fid`, `ogc_fid`, `objectid`, and `rowid` are skipped automatically to avoid copying source row IDs into target primary keys.
- Target fields that have no matching source field are left to their database/provider default or NULL behaviour.
- The mapping summary shows how many fields were matched and which source fields were skipped.
- If matching source/target field types differ, the plugin attempts the existing value conversion and reports conversion failures.
- **Add Default Value** remains available as an optional advanced feature for explicitly setting a constant value in a target field.

Automatic matching is intentionally conservative: it does not guess that unrelated names such as `fid` and `uuid` mean the same thing. For a key-based upsert/update, configure the match key separately in Migration Behaviour.

## 5. Geometry and attributes

- **Transfer geometry** transfers geometry and transforms it when source and target CRS differ.
- **Update geometry for matched records** replaces geometry only for records matched by key. It is off by default.
- **Convert multipart to singlepart** is available for insert mode. It is disabled for key-based update modes because multiple output parts can share the same source key.
- **Remove Z and M dimensions** removes those dimensions where the geometry API/provider permits it.
- **Do not overwrite target values with NULL / empty source values** preserves existing target values when a mapped source value is NULL or an empty string.
- **Generate UUID** creates a UUID for inserted features when the target has a `uuid` field that is not explicitly mapped.

## 6. Important safety behaviour

- Source features are never deleted by this plugin.
- A target layer already in edit mode is rejected. Save or discard its existing pending edits first; the plugin will not commit someone else's pre-existing edit buffer. A source layer in edit mode is allowed, but its current unsaved edit buffer is included and a warning appears in the preview.
- Preflight validation runs for all enabled pairs before the first write.
- The same target layer cannot be selected by more than one enabled pair in a single batch.
- Each target layer is committed separately. A batch spanning several layers is not a single atomic database transaction.
- If a pair fails after editing begins, the plugin calls the target layer's rollback method. Provider-side behavior can vary; inspect the report and target data after any failure.
- Always back up important PostgreSQL tables and local files before first production use.

## 7. Saving a migration setup

Use **Save Batch Configuration** to write a JSON file containing layer IDs/names, automatically detected field mappings, skipped-field summaries and options. Use **Load Batch Configuration** to restore it. Layer IDs are project-specific: after loading a configuration into another project, reselect and verify every layer because IDs may not match.

## 8. Installation

1. Download `ultimate_data_migration.1.0.2.zip`.
2. In QGIS, open **Plugins → Manage and Install Plugins → Install from ZIP**.
3. Select the ZIP and install it.
4. Enable **Ultimate Data Migration** in the Installed tab if it is not already enabled.
5. Open it from the Plugins menu or plugin toolbar.

If ZIP installation is unavailable, extract the `Ultimate_Data_Migration` folder into the active QGIS profile's `python/plugins` directory, restart QGIS, and enable the plugin.

## 9. Compatibility

- Declared minimum: QGIS 3.34.
- Intended support: QGIS 3.34+ and QGIS 4.x using `qgis.PyQt` compatibility imports.
- The plugin is not claimed to work with every historical QGIS 2.x or early QGIS 3.x release.
- Because the runtime here does not include a QGIS desktop/PyQGIS installation, this package has been syntax-checked but not GUI-tested against actual QGIS builds. Before production, test it on the exact QGIS 3.x LTR and QGIS 4.x installations used at work.

## 10. Package contents

| File | Purpose |
|---|---|
| `__init__.py` | QGIS plugin factory. |
| `metadata.txt` | Plugin Manager metadata and compatibility range. |
| `ultimate_data_migration.py` | QGIS menu/toolbar integration. |
| `ultimate_data_migration_dialog.py` | Multi-pair user interface, configuration, preview and reporting. |
| `migration_engine.py` | Provider identification, validation and migration engine. |
| `CHANGELOG.md` | Version history. |

## 11. Release history

See [CHANGELOG.md](CHANGELOG.md). Version 1.0.2 adds automatic field matching and automatic skipping of unmatched source fields.
