# -*- coding: utf-8 -*-
"""QGIS plugin entry point for Ultimate Data Migration.

Copyright © 2077 Amlan Patnaik. All rights reserved.
"""

import os

from qgis.PyQt.QtGui import QIcon, QAction

from .ultimate_data_migration_dialog import UltimateDataMigrationDialog


class UltimateDataMigrationPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        icon = QIcon(os.path.join(os.path.dirname(__file__), "icon.svg"))
        self.action = QAction(icon, "Ultimate Data Migration", self.iface.mainWindow())
        self.action.setToolTip("Migrate multiple QGIS vector layers with provider/path awareness and field mapping")
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&Ultimate Data Migration", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu("&Ultimate Data Migration", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None
        if self.dialog:
            self.dialog.close()
            self.dialog = None

    def run(self):
        if self.dialog is None:
            self.dialog = UltimateDataMigrationDialog(self.iface.mainWindow())
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
