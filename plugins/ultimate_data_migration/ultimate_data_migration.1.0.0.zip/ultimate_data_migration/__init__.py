# -*- coding: utf-8 -*-
"""Ultimate Data Migration QGIS plugin.

Copyright (c) 2026 Amlan Patnaik. All rights reserved.
"""


def classFactory(iface):
    from .ultimate_data_migration import UltimateDataMigrationPlugin
    return UltimateDataMigrationPlugin(iface)
