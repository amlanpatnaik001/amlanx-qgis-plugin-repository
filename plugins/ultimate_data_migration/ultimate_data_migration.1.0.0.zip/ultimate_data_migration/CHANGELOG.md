# Changelog — Ultimate Data Migration

All notable changes to this project are documented here.

## [1.0.0] — 2026-11-02

### Added
- Initial release of **Ultimate Data Migration**.
- Multiple source-to-target migration pairs in one batch.
- Per-layer provider classification: `OFFLINE` for common file-backed providers, `ONLINE` for PostgreSQL, `TEMPORARY` for memory layers, and `REMOTE` for other service providers.
- Sanitized source URI / path display; credential-like URI values are redacted before being shown.
- Auto-match layer pairs by normalized layer names.
- Per-pair field mapping with same-name auto-mapping and constant/default-value rows.
- Insert-only, upsert-by-key, and update-only-by-key modes.
- Optional selected-feature migration, CRS transformation, multipart-to-singlepart conversion, Z/M removal, null/empty-value skipping, and matched-feature geometry updates.
- UUID generation for inserted features when the target has an unmapped `uuid` field.
- Batch preflight, preview counts, JSON configuration save/load, progress display with cancellation, and report export.
- Per-pair edit-session ownership: target layers already in edit mode are rejected, and a failed pair is rolled back when possible.
- Source features are retained; there is no destructive source-delete option.

### Safety notes
- Each target layer is committed separately. A multi-layer batch is not one database-wide atomic transaction.
- `ONLINE` identifies a PostgreSQL provider; it does not guarantee the server is reachable or that the current user has write permissions.
- The initial release has static validation only in this build environment. Final acceptance testing must be performed inside the QGIS versions listed in `README.md` against representative local and PostgreSQL datasets.

### Compatibility
- Declared baseline: QGIS 3.34 and later QGIS 3.x releases, plus QGIS 4.x where the PyQGIS APIs used by the plugin remain available.
- Qt enum access uses a compatibility helper for Qt 5 / Qt 6 style enums.
