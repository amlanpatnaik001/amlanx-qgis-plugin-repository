# Slackloop Auto Naming — AMLAN-X Edition

**Version:** 2.0.0  
**Category:** Vector  
**Maintainer:** Amlan Patnaik  
**QGIS metadata range:** 3.28–4.99 (Qt5/Qt6 compatibility code included; see testing note below)

> Copyright © Amlan Patnaik @2077. All rights reserved.

## Purpose

Copies the selected eligible Fiber Cable attributes into Slackloop features:

- `Fiber Cable.naming` → `Slackloop.cable_name`
- `Fiber Cable.size` → `Slackloop.cable_size`

Only Fiber Cable features with category `F2` are eligible.

## Matching rules

1. Slackloop input must be a point or multipoint layer.
2. Fiber Cable input must be a line or multiline layer.
3. The plugin reads `cable_category` first and falls back to `category` when `cable_category` is unavailable or blank.
4. Category comparison is case-insensitive and trims surrounding whitespace.
5. A cable is a candidate when it intersects the Slackloop point or is within the configured search tolerance.
6. When multiple F2 cables match, the naturally earliest non-empty `Fiber Cable.naming` value wins. For example, `A10` sorts before `A11` and `A12`.
7. The chosen cable's `naming` and `size` values are proposed for the Slackloop feature's `cable_name` and `cable_size` fields.
8. Numeric source sizes are converted to integers when the target `Slackloop.cable_size` field is an integer field. Invalid integer values are reported in the preview and not applied.

## Coordinate systems and tolerance

Slackloop geometries are transformed into the Fiber Cable layer CRS before matching. The search tolerance is entered in metres. For projected CRSs, the metre tolerance is converted to the layer's map units. For geographic CRSs, the spatial-index search rectangle is approximated in degrees and final point-to-line distance is measured geodesically using the project ellipsoid where available. Multipoint Slackloop geometries are handled using their bounding box and the minimum distance across their component points.

A tolerance of `0` requires a direct geometry intersection/touch (with a small numerical tolerance for the distance comparison).

## Safe editing workflow

1. Load both source layers into the QGIS project.
2. Open **Plugins → Slackloop Auto Naming**.
3. Select the Slackloop point layer and Fiber Cable line layer.
4. Set the search tolerance in metres. Optionally enable **Process selected Slackloop points only**.
5. Click **Preview Naming** and inspect the proposed cable name, size, matched cable and status.
6. Click **Apply Naming** only after reviewing the preview.
7. The plugin writes changes to the Slackloop layer's QGIS edit buffer and groups them into one undo command. It does **not** commit the provider or save the data source automatically.
8. Review the edits and save the Slackloop layer using QGIS when ready.

Work on a copy or ensure a recoverable backup before applying bulk edits to production data.

## Required fields

| Layer | Required fields |
|---|---|
| Slackloop | `cable_name`, `cable_size` |
| Fiber Cable | `naming`, `size`, and either `cable_category` or `category` |

## Installation

### From the AMLAN-X QGIS plugin repository

Add this repository URL in **QGIS → Plugins → Manage and Install Plugins → Settings → Plugin Repositories**:

`https://amlanpatnaik001.github.io/amlanx-qgis-plugin-repository/plugins.xml`

Refresh the repository list and install **Slackloop Auto Naming**.

### Manual installation

1. Extract the release ZIP.
2. Copy the single `slackloop_auto_naming` folder into your active QGIS profile's `python/plugins` directory.
3. Restart QGIS.
4. Enable **Slackloop Auto Naming** under **Plugins → Manage and Install Plugins → Installed**.

## QGIS 4 / Qt6 compatibility

Version 2.0.0 includes compatibility handling for Qt5 and Qt6 enum scoping, the QAction module move, and QGIS geometry/distance enum changes. The source imports PyQt through `qgis.PyQt` and declares `qgisMaximumVersion=4.99`.

**Testing status:** Python syntax and compatibility-path checks are performed during packaging. This release has not been executed inside a real QGIS 4 desktop session in this build environment. The metadata range is a compatibility target, not a claim of completed runtime certification. Please test with a copy of a representative project in the exact QGIS 3 and QGIS 4 builds used in production before broad deployment.

## Troubleshooting

- **Missing fields:** Confirm the exact field names in the Required fields table.
- **No F2 candidates:** Confirm that `cable_category` or `category` contains `F2` and that `naming` is populated.
- **No match:** Check the layer CRS values and increase the tolerance carefully; the tolerance is in metres.
- **Unexpected selected cable:** Review nearby F2 cable names; natural ascending order chooses the earliest name, not necessarily the nearest cable.
- **Apply disabled:** Run Preview Naming and check whether any row has `Ready to update` status.
- **Unsaved changes:** Apply only changes the QGIS edit buffer. Save the Slackloop layer from QGIS when satisfied.

## Project links

- [AMLAN-X QGIS Plugin Repository](https://github.com/amlanpatnaik001/amlanx-qgis-plugin-repository)
- [Slackloop Auto Naming releases](https://github.com/amlanpatnaik001/amlanx-qgis-plugin-repository/tree/main/plugins/slackloop_auto_naming)
- [Report an issue](https://github.com/amlanpatnaik001/amlanx-qgis-plugin-repository/issues)

---

Copyright © Amlan Patnaik @2077. All rights reserved.
