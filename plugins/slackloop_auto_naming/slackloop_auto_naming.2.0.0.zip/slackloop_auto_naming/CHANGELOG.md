# Changelog

All notable changes to Slackloop Auto Naming are documented here.

## [2.0.0] - 2026-11-23

### Added
- Multipoint-safe search envelopes and minimum geodesic distance checks for multipart Slackloop geometries.
- Qt5/Qt6 enum compatibility helpers for alignment, match flags, table view configuration and message-box buttons.
- QAction import fallback for the Qt6 move from QtWidgets to QtGui.
- QGIS 3/QGIS 4 geometry and distance unit enum compatibility.
- AMLAN-X repository metadata and release documentation.

### Updated
- Plugin metadata version to 2.0.0 and declared QGIS compatibility target through 4.99.
- Dialog title and documentation to identify the 2.0.0 release.

### Preserved
- F2-only Fiber Cable filtering.
- `cable_category` preference with `category` fallback.
- Natural ascending cable naming selection (e.g. A10 before A11).
- CRS transformation and metre-based matching tolerance.
- Preview-before-apply workflow.
- Edit-buffer-only updates; no automatic provider commit.

### Compatibility and testing
- Python source syntax-checked and compatibility enum paths checked using Qt5/QGIS3-style and Qt6/QGIS4-style API stubs.
- Not runtime-certified in an actual QGIS 4 desktop session as part of this package build.

---

Copyright © Amlan Patnaik @2077. All rights reserved.
