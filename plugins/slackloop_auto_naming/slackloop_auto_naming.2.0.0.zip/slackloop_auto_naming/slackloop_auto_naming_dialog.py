# -*- coding: utf-8 -*-
"""Dialog and naming logic for Slackloop Auto Naming.

Copyright © Amlan Patnaik @2077. All rights reserved.
"""
import re

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QHBoxLayout, QLabel,
    QMessageBox, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout,
    QHeaderView, QAbstractItemView, QGroupBox
)
from qgis.core import (
    Qgis, QgsCoordinateTransform, QgsDistanceArea, QgsGeometry,
    QgsProject, QgsRectangle, QgsSpatialIndex, QgsUnitTypes, QgsWkbTypes
)


def _enum_value(owner, scoped_group, member):
    """Return a Qt enum member using Qt6's scoped or Qt5's legacy spelling."""
    group = getattr(owner, scoped_group, None)
    if group is not None and hasattr(group, member):
        return getattr(group, member)
    return getattr(owner, member)


# PyQt6 scopes enums (for example Qt.AlignmentFlag.AlignRight), while PyQt5
# commonly exposes the legacy QT_ALIGN_RIGHT spelling.
QT_ALIGN_RIGHT = _enum_value(Qt, "AlignmentFlag", "AlignRight")
QT_ALIGN_CENTER = _enum_value(Qt, "AlignmentFlag", "AlignCenter")
QT_MATCH_CONTAINS = _enum_value(Qt, "MatchFlag", "MatchContains")
VIEW_NO_EDIT_TRIGGERS = _enum_value(QAbstractItemView, "EditTrigger", "NoEditTriggers")
VIEW_SELECT_ROWS = _enum_value(QAbstractItemView, "SelectionBehavior", "SelectRows")
HEADER_RESIZE_TO_CONTENTS = _enum_value(QHeaderView, "ResizeMode", "ResizeToContents")
MESSAGE_YES = _enum_value(QMessageBox, "StandardButton", "Yes")
MESSAGE_NO = _enum_value(QMessageBox, "StandardButton", "No")


def _geometry_type(name):
    """Resolve geometry group enums in QGIS 3.28+ and QGIS 4."""
    modern_enum = getattr(Qgis, "GeometryType", None)
    if modern_enum is not None:
        modern_name = {"PointGeometry": "Point", "LineGeometry": "Line"}.get(name, name)
        if hasattr(modern_enum, modern_name):
            return getattr(modern_enum, modern_name)
    return getattr(QgsWkbTypes, name)


GEOMETRY_POINT = _geometry_type("PointGeometry")
GEOMETRY_LINE = _geometry_type("LineGeometry")


def _distance_unit(legacy_name, modern_name):
    """Resolve distance units moved to Qgis.DistanceUnit in newer QGIS."""
    modern_enum = getattr(Qgis, "DistanceUnit", None)
    if modern_enum is not None and hasattr(modern_enum, modern_name):
        return getattr(modern_enum, modern_name)
    return getattr(QgsUnitTypes, legacy_name)


DISTANCE_METERS = _distance_unit("DistanceMeters", "Meters")
DISTANCE_DEGREES = _distance_unit("DistanceDegrees", "Degrees")


class SlackloopAutoNamingDialog(QDialog):
    """Preview and apply naming from nearby eligible F2 Fiber Cable features."""

    COPYRIGHT = "Copyright © Amlan Patnaik @2077. All rights reserved."

    @classmethod
    def _with_copyright(cls, message):
        """Append the copyright line to every message-box prompt, without duplicating it."""
        text = str(message)
        if cls.COPYRIGHT.casefold() not in text.casefold():
            text = text.rstrip() + "\n\n" + cls.COPYRIGHT
        return text

    @staticmethod
    def _dialog_title(title):
        """Mark every modal prompt title with the copyright owner."""
        marker = "© Amlan Patnaik @2077"
        return title if marker.casefold() in title.casefold() else "{0} — {1}".format(title, marker)

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.project = QgsProject.instance()
        self.setWindowTitle("Slackloop Auto Naming v2.0.0 — © Amlan Patnaik @2077")
        self.setMinimumSize(920, 590)
        self._proposals = []
        self._issues = []
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        intro = QLabel(
            "Copies Fiber Cable.naming into Slackloop.cable_name and Fiber Cable.size into Slackloop.cable_size. "
            "Only F2 cables are considered. The category field is read from cable_category first, with "
            "category used as a fallback when cable_category is unavailable or blank. If multiple cables match, the naturally earliest "
            "non-empty value in Fiber Cable.naming wins (for example, A10 before A11 and A12)."
        )
        intro.setWordWrap(True)
        root.addWidget(intro)

        layers_group = QGroupBox("Input layers")
        layers_layout = QVBoxLayout(layers_group)
        sl_row = QHBoxLayout()
        sl_row.addWidget(QLabel("Slackloop point layer:"))
        self.slackloop_combo = QComboBox()
        self.slackloop_combo.setMinimumWidth(270)
        sl_row.addWidget(self.slackloop_combo, 1)
        layers_layout.addLayout(sl_row)
        cable_row = QHBoxLayout()
        cable_row.addWidget(QLabel("Fiber Cable line layer:"))
        self.cable_combo = QComboBox()
        self.cable_combo.setMinimumWidth(270)
        cable_row.addWidget(self.cable_combo, 1)
        layers_layout.addLayout(cable_row)

        options_row = QHBoxLayout()
        options_row.addWidget(QLabel("Search tolerance (metres):"))
        self.tolerance_spin = QDoubleSpinBox()
        self.tolerance_spin.setRange(0.0, 100.0)
        self.tolerance_spin.setDecimals(3)
        self.tolerance_spin.setSingleStep(0.1)
        self.tolerance_spin.setValue(0.25)
        self.tolerance_spin.setToolTip("0 means the Slackloop point must lie directly on the cable geometry.")
        options_row.addWidget(self.tolerance_spin)
        self.selected_only = QCheckBox("Process selected Slackloop points only")
        options_row.addWidget(self.selected_only)
        options_row.addStretch(1)
        layers_layout.addLayout(options_row)
        root.addWidget(layers_group)

        button_row = QHBoxLayout()
        self.refresh_button = QPushButton("Refresh Layers")
        self.preview_button = QPushButton("Preview Naming")
        self.apply_button = QPushButton("Apply Naming")
        self.apply_button.setEnabled(False)
        self.close_button = QPushButton("Close")
        button_row.addWidget(self.refresh_button)
        button_row.addStretch(1)
        button_row.addWidget(self.preview_button)
        button_row.addWidget(self.apply_button)
        button_row.addWidget(self.close_button)
        root.addLayout(button_row)

        self.status_label = QLabel("Choose the layers, then click Preview Naming.")
        self.status_label.setWordWrap(True)
        root.addWidget(self.status_label)

        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels([
            "Slackloop FID", "Current cable_name", "Proposed cable_name",
            "Proposed cable_size", "Selected cable naming", "Cable category", "Status"
        ])
        self.table.setEditTriggers(VIEW_NO_EDIT_TRIGGERS)
        self.table.setSelectionBehavior(VIEW_SELECT_ROWS)
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(HEADER_RESIZE_TO_CONTENTS)
        self.table.horizontalHeader().setStretchLastSection(True)
        root.addWidget(self.table, 1)

        foot = QLabel(self.COPYRIGHT)
        foot.setAlignment(QT_ALIGN_RIGHT)
        foot.setStyleSheet("color: #777; font-size: 10px;")
        root.addWidget(foot)

        self.refresh_button.clicked.connect(self.refresh_layers)
        self.preview_button.clicked.connect(self.preview)
        self.apply_button.clicked.connect(self.apply_naming)
        self.close_button.clicked.connect(self.close)

    def refresh_layers(self):
        old_slack = self.slackloop_combo.currentData()
        old_cable = self.cable_combo.currentData()
        self.slackloop_combo.clear()
        self.cable_combo.clear()
        vector_layers = [layer for layer in self.project.mapLayers().values() if hasattr(layer, "getFeatures") and layer.isValid()]
        for layer in vector_layers:
            self.slackloop_combo.addItem(layer.name(), layer.id())
            self.cable_combo.addItem(layer.name(), layer.id())
        self._select_layer(self.slackloop_combo, old_slack, "Slackloop")
        self._select_layer(self.cable_combo, old_cable, "Fiber Cable")
        self._proposals = []
        self.apply_button.setEnabled(False)
        if not vector_layers:
            self.status_label.setText("No valid vector layers were found in the current project.")
        else:
            self.status_label.setText("Layers refreshed. Click Preview Naming to calculate proposed values.")

    @staticmethod
    def _select_layer(combo, layer_id, preferred_name):
        if layer_id:
            idx = combo.findData(layer_id)
            if idx >= 0:
                combo.setCurrentIndex(idx)
                return
        for i in range(combo.count()):
            if combo.itemText(i).strip().lower() == preferred_name.lower():
                combo.setCurrentIndex(i)
                return
        idx = combo.findText(preferred_name, QT_MATCH_CONTAINS)
        if idx >= 0:
            combo.setCurrentIndex(idx)

    def _get_layer(self, combo):
        layer_id = combo.currentData()
        return self.project.mapLayer(layer_id) if layer_id else None

    def _validate_layers(self):
        slack = self._get_layer(self.slackloop_combo)
        cable = self._get_layer(self.cable_combo)
        if slack is None or cable is None:
            raise ValueError("Select both the Slackloop and Fiber Cable layers.")
        if slack.id() == cable.id():
            raise ValueError("Slackloop and Fiber Cable must be different layers.")
        if QgsWkbTypes.geometryType(slack.wkbType()) != GEOMETRY_POINT:
            raise ValueError("The selected Slackloop layer must contain point or multipoint features.")
        if QgsWkbTypes.geometryType(cable.wkbType()) != GEOMETRY_LINE:
            raise ValueError("The selected Fiber Cable layer must contain line or multiline features.")
        required_slack = ["cable_name", "cable_size"]
        category_fields = [
            name for name in ("cable_category", "category")
            if cable.fields().indexFromName(name) >= 0
        ]
        required_cable = ["naming", "size"]
        missing_slack = [name for name in required_slack if slack.fields().indexFromName(name) < 0]
        missing_cable = [name for name in required_cable if cable.fields().indexFromName(name) < 0]
        if missing_slack:
            raise ValueError("Slackloop layer is missing required field(s): " + ", ".join(missing_slack))
        if not category_fields:
            missing_cable.insert(0, "cable_category or category")
        if missing_cable:
            raise ValueError("Fiber Cable layer is missing required field(s): " + ", ".join(missing_cable))
        if self.selected_only.isChecked() and not slack.selectedFeatureCount():
            raise ValueError("'Process selected Slackloop points only' is checked, but no Slackloop features are selected.")
        return slack, cable

    @staticmethod
    def _natural_key(value):
        """Natural, case-insensitive sort key: A10 sorts before A11 and A12."""
        text = "" if value is None else str(value).strip()
        # Tag each token so mixed values such as A10, B1 and 12C remain comparable.
        return tuple((1, int(part)) if part.isdigit() else (0, part.casefold())
                     for part in re.split(r"(\d+)", text))

    @staticmethod
    def _value(feature, field_name):
        value = feature[field_name]
        if value is None:
            return ""
        try:
            if value.isNull():
                return ""
        except AttributeError:
            pass
        return value

    @staticmethod
    def _category_value(feature, available_fields):
        """Prefer cable_category; fall back to the client's alternate spelling, category.

        If both fields exist, a non-empty cable_category value wins. A blank/null value
        falls back to category, allowing mixed or partially migrated client schemas.
        """
        for field_name in ("cable_category", "category"):
            if field_name not in available_fields:
                continue
            value = SlackloopAutoNamingDialog._value(feature, field_name)
            if str(value).strip():
                return value
        return ""

    @staticmethod
    def _display(value):
        return "" if value is None else str(value)

    def _distance_tolerance_in_layer_units(self, tolerance_m, crs):
        if tolerance_m <= 0:
            return 0.0
        units = crs.mapUnits()
        if units == DISTANCE_DEGREES:
            # Bounding boxes in geographic coordinates; final distance is geodesic.
            return tolerance_m / 111320.0
        factor = QgsUnitTypes.fromUnitToUnitFactor(DISTANCE_METERS, units)
        return tolerance_m * factor

    def _search_rect(self, point_geom, tolerance_m, cable_crs):
        """Build a search envelope for point or multipoint Slackloop geometry."""
        bounds = point_geom.boundingBox()
        if tolerance_m <= 0:
            return bounds
        if cable_crs.mapUnits() == DISTANCE_DEGREES:
            # Convert the metre tolerance to a conservative degree envelope. Using
            # the largest absolute latitude in the geometry avoids under-searching
            # multipoints which span more than one latitude.
            lat = max(abs(bounds.yMinimum()), abs(bounds.yMaximum()))
            lat = max(-89.9, min(89.9, lat))
            dy = tolerance_m / 111320.0
            import math
            dx = tolerance_m / max(111320.0 * abs(math.cos(math.radians(lat))), 1000.0)
            return QgsRectangle(
                bounds.xMinimum() - dx, bounds.yMinimum() - dy,
                bounds.xMaximum() + dx, bounds.yMaximum() + dy
            )
        tol_units = self._distance_tolerance_in_layer_units(tolerance_m, cable_crs)
        return QgsRectangle(
            bounds.xMinimum() - tol_units, bounds.yMinimum() - tol_units,
            bounds.xMaximum() + tol_units, bounds.yMaximum() + tol_units
        )

    def _distance_to_geometry(self, point_geom, line_geom, cable_layer):
        if point_geom.intersects(line_geom):
            return 0.0
        if cable_layer.crs().mapUnits() != DISTANCE_DEGREES:
            return point_geom.distance(line_geom)

        # QgsGeometry.asPoint() is only valid for single-point geometries. For a
        # multipoint Slackloop feature, calculate the minimum geodesic distance
        # over its constituent points instead of treating it as a single point.
        points = point_geom.asMultiPoint() if point_geom.isMultipart() else [point_geom.asPoint()]
        da = QgsDistanceArea()
        da.setSourceCrs(cable_layer.crs(), self.project.transformContext())
        ellipsoid = self.project.ellipsoid()
        if ellipsoid:
            da.setEllipsoid(ellipsoid)

        distances = []
        for point in points:
            point_geometry = QgsGeometry.fromPointXY(point)
            closest = line_geom.closestPoint(point_geometry)
            if closest.isNull() or closest.isEmpty():
                continue
            distances.append(da.measureLine(point, closest.asPoint()))
        return min(distances) if distances else float("inf")

    def _build_proposals(self):
        slack, cable = self._validate_layers()
        slack_name_idx = slack.fields().indexFromName("cable_name")
        slack_size_idx = slack.fields().indexFromName("cable_size")
        tolerance_m = float(self.tolerance_spin.value())

        # Transform each Slackloop point to the cable layer CRS before geometry matching.
        transform = None
        if slack.crs() != cable.crs():
            transform = QgsCoordinateTransform(slack.crs(), cable.crs(), self.project.transformContext())

        cable_features = list(cable.getFeatures())
        category_fields = [
            name for name in ("cable_category", "category")
            if cable.fields().indexFromName(name) >= 0
        ]
        # Keep only F2 features up front, case-insensitive and whitespace-tolerant.
        # cable_category is preferred; category is used if it is missing/blank.
        eligible = []
        for feat in cable_features:
            category = self._category_value(feat, category_fields)
            cable_name_value = self._value(feat, "naming")
            if (str(category).strip().casefold() == "f2"
                    and str(cable_name_value).strip()
                    and not feat.geometry().isNull()
                    and not feat.geometry().isEmpty()):
                eligible.append(feat)
        if not eligible:
            raise ValueError(
                "No Fiber Cable features with F2 in cable_category or category and a non-empty naming value were found."
            )

        # Index only eligible F2 cable geometries, so large projects do not need a full scan
        # for every Slackloop point. Add features one by one for QGIS-version compatibility.
        cable_index = QgsSpatialIndex()
        eligible_by_id = {}
        for feat in eligible:
            cable_index.addFeature(feat)
            eligible_by_id[feat.id()] = feat

        target_features = list(slack.getSelectedFeatures()) if self.selected_only.isChecked() else list(slack.getFeatures())
        proposals = []
        for sf in target_features:
            sgeom = sf.geometry()
            if sgeom.isNull() or sgeom.isEmpty():
                proposals.append({"slack_fid": sf.id(), "current_name": self._value(sf, "cable_name"), "name": "", "size": "", "naming": "", "category": "F2", "status": "Skipped: empty geometry", "cable_fid": None})
                continue
            point_geom = QgsGeometry(sgeom)
            if transform is not None:
                try:
                    point_geom.transform(transform)
                except Exception as exc:
                    proposals.append({"slack_fid": sf.id(), "current_name": self._value(sf, "cable_name"), "name": "", "size": "", "naming": "", "category": "F2", "status": "Skipped: CRS transform failed", "cable_fid": None, "error": str(exc)})
                    continue
            search_rect = self._search_rect(point_geom, tolerance_m, cable.crs())
            candidates = []
            for candidate_fid in cable_index.intersects(search_rect):
                cf = eligible_by_id.get(candidate_fid)
                if cf is None:
                    continue
                geom = cf.geometry()
                distance = self._distance_to_geometry(point_geom, geom, cable)
                if tolerance_m <= 0:
                    within_tolerance = distance <= 1e-9
                elif cable.crs().mapUnits() == DISTANCE_DEGREES:
                    # Geographic layer distance is geodesic metres.
                    within_tolerance = distance <= tolerance_m
                else:
                    within_tolerance = distance <= self._distance_tolerance_in_layer_units(tolerance_m, cable.crs())
                if within_tolerance:
                    candidates.append((cf, distance))
            if not candidates:
                proposals.append({"slack_fid": sf.id(), "current_name": self._value(sf, "cable_name"), "name": "", "size": "", "naming": "", "category": "F2", "status": "No eligible F2 cable within tolerance", "cable_fid": None})
                continue
            # Natural ascending naming sort makes A10 win over A11 and A12.
            candidates.sort(key=lambda item: (self._natural_key(self._value(item[0], "naming")), item[0].id()))
            chosen, distance = candidates[0]
            name = self._value(chosen, "naming")
            size = self._value(chosen, "size")
            old_name = self._value(sf, "cable_name")
            old_size = self._value(sf, "cable_size")

            # Slackloop.cable_size is commonly an integer field, while Fiber Cable.size
            # is a text field in the user's schema (for example, "48", "72", "144").
            # Convert numeric strings before passing them to QGIS; do not apply invalid sizes.
            target_size_type = slack.fields().field(slack_size_idx).typeName().lower()
            if "int" in target_size_type:
                if str(size).strip() == "":
                    size = None
                else:
                    try:
                        size = int(str(size).strip())
                    except (TypeError, ValueError):
                        proposals.append({
                            "slack_fid": sf.id(), "current_name": old_name, "current_size": old_size,
                            "name": name, "size": self._value(chosen, "size"),
                            "naming": self._value(chosen, "naming"),
                            "category": self._category_value(chosen, category_fields),
                            "status": "Invalid source size (expected an integer)",
                            "cable_fid": chosen.id(), "distance": distance,
                            "match_count": len(candidates)
                        })
                        continue
            same = str(old_name) == str(name) and str(old_size) == str(size)
            proposals.append({
                "slack_fid": sf.id(), "current_name": old_name, "current_size": old_size,
                "name": name, "size": size, "naming": self._value(chosen, "naming"),
                "category": self._category_value(chosen, category_fields), "status": "Already correct" if same else "Ready to update",
                "cable_fid": chosen.id(), "distance": distance, "match_count": len(candidates),
                "slack_feature": sf
            })
        return slack, cable, proposals

    def preview(self):
        try:
            slack, cable, proposals = self._build_proposals()
        except Exception as exc:
            QMessageBox.warning(self, self._dialog_title("Slackloop Auto Naming"), self._with_copyright(str(exc)))
            self.apply_button.setEnabled(False)
            return
        self._proposals = proposals
        self.table.setRowCount(0)
        ready = 0
        matched = 0
        for proposal in proposals:
            row = self.table.rowCount()
            self.table.insertRow(row)
            values = [
                proposal.get("slack_fid", ""),
                self._display(proposal.get("current_name", "")),
                self._display(proposal.get("name", "")),
                self._display(proposal.get("size", "")),
                self._display(proposal.get("naming", "")),
                self._display(proposal.get("category", "")),
                proposal.get("status", "")
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if col == 0:
                    item.setTextAlignment(QT_ALIGN_CENTER)
                self.table.setItem(row, col, item)
            if proposal.get("cable_fid") is not None:
                matched += 1
                if proposal.get("status") == "Ready to update":
                    ready += 1
        self.apply_button.setEnabled(ready > 0)
        self.status_label.setText(
            "Preview complete: {0} Slackloop feature(s) checked; {1} matched to F2 cable(s); "
            "{2} ready to update. Apply will create uncommitted edits in QGIS; save the layer when satisfied.".format(
                len(proposals), matched, ready
            )
        )

    def apply_naming(self):
        if not self._proposals:
            QMessageBox.information(self, self._dialog_title("Slackloop Auto Naming"), self._with_copyright("Run Preview Naming first."))
            return
        ready = [p for p in self._proposals if p.get("status") == "Ready to update" and p.get("cable_fid") is not None]
        if not ready:
            QMessageBox.information(self, self._dialog_title("Slackloop Auto Naming"), self._with_copyright("There are no proposed changes to apply."))
            return
        slack = self._get_layer(self.slackloop_combo)
        # Revalidate layer and fields before altering the edit buffer.
        try:
            slack, _cable = self._validate_layers()
        except Exception as exc:
            QMessageBox.warning(self, self._dialog_title("Slackloop Auto Naming"), self._with_copyright(str(exc)))
            return
        response = QMessageBox.question(
            self, self._dialog_title("Confirm Slackloop Updates"),
            self._with_copyright("Update {0} Slackloop feature(s)?\n\nChanges will remain in QGIS's edit buffer and will not be committed automatically.".format(len(ready))),
            MESSAGE_YES | MESSAGE_NO, MESSAGE_NO
        )
        if response != MESSAGE_YES:
            return

        was_editable = slack.isEditable()
        if not was_editable and not slack.startEditing():
            QMessageBox.critical(self, self._dialog_title("Slackloop Auto Naming"), self._with_copyright("Could not start editing on the Slackloop layer."))
            return

        changed = 0
        slack_name_idx = slack.fields().indexFromName("cable_name")
        slack_size_idx = slack.fields().indexFromName("cable_size")
        slack.beginEditCommand("Slackloop Auto Naming: Update cable_name and cable_size")
        try:
            for p in ready:
                fid = p["slack_fid"]
                if not slack.changeAttributeValue(fid, slack_name_idx, p["name"]):
                    raise RuntimeError("Failed to set cable_name for Slackloop feature ID {0}.".format(fid))
                if not slack.changeAttributeValue(fid, slack_size_idx, p["size"]):
                    raise RuntimeError("Failed to set cable_size for Slackloop feature ID {0}.".format(fid))
                changed += 1
            slack.endEditCommand()
        except Exception as exc:
            slack.destroyEditCommand()
            QMessageBox.critical(self, self._dialog_title("Slackloop Auto Naming"), self._with_copyright("No changes were applied by this command.\n\n{0}".format(exc)))
            return

        self.preview()
        QMessageBox.information(
            self, self._dialog_title("Slackloop Auto Naming"),
            self._with_copyright("Updated {0} Slackloop feature(s) in the QGIS edit buffer.\n\nNo database/file commit was performed. Review the changes, then save edits on the Slackloop layer when ready.".format(changed))
        )
