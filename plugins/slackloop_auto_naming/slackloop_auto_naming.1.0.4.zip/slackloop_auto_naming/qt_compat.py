# -*- coding: utf-8 -*-
"""Qt enum compatibility helpers for supported QGIS/PyQt builds.

Copyright © Amlan Patnaik @2077. All rights reserved.
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QAbstractItemView, QHeaderView, QMessageBox


def enum_value(owner, group_name, member_name, legacy_name=None):
    """Return a scoped Qt enum member, with a legacy alias fallback."""
    group = getattr(owner, group_name, None)
    if group is not None and hasattr(group, member_name):
        return getattr(group, member_name)
    fallback = legacy_name or member_name
    if hasattr(owner, fallback):
        return getattr(owner, fallback)
    raise AttributeError(
        "No compatible enum member {0}.{1}/{2} on {3}".format(
            group_name, member_name, fallback, getattr(owner, "__name__", owner)
        )
    )


# New scoped forms work on current Qt 5 and Qt 6; legacy aliases cover older Qt 5.
ALIGN_RIGHT = enum_value(Qt, "AlignmentFlag", "AlignRight")
ALIGN_CENTER = enum_value(Qt, "AlignmentFlag", "AlignCenter")
MATCH_CONTAINS = enum_value(Qt, "MatchFlag", "MatchContains")
WINDOW_MODAL = enum_value(Qt, "WindowModality", "WindowModal")

NO_EDIT_TRIGGERS = enum_value(
    QAbstractItemView, "EditTrigger", "NoEditTriggers"
)
SELECT_ROWS = enum_value(
    QAbstractItemView, "SelectionBehavior", "SelectRows"
)
RESIZE_TO_CONTENTS = enum_value(
    QHeaderView, "ResizeMode", "ResizeToContents"
)
MESSAGE_YES = enum_value(QMessageBox, "StandardButton", "Yes")
MESSAGE_NO = enum_value(QMessageBox, "StandardButton", "No")
