# Copyright and attribution

Copyright © Amlan Patnaik @2077. All rights reserved.

Slackloop Auto Naming first-party source code, interface text and documentation carry the copyright notice above. Existing third-party notices and dependencies, if any, remain governed by their respective terms and must be preserved.
