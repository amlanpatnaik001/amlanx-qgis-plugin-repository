# -*- coding: utf-8 -*-
"""QGIS entry point for Slackloop Auto Naming.

Copyright © Amlan Patnaik @2077. All rights reserved.
"""

def classFactory(iface):  # pylint: disable=invalid-name
    from .slackloop_auto_naming import SlackloopAutoNaming
    return SlackloopAutoNaming(iface)
