# Changelog — Slackloop Auto Naming

Copyright © Amlan Patnaik @2077. All rights reserved.

## 1.0.4 — Compatibility, reliability and performance update

- Added a Qt compatibility layer for scoped Qt 6 enums and legacy Qt 5 enum aliases.
- Moved `QAction` import to QtGui with a QtWidgets fallback for older Qt 5 builds.
- Added QGIS geometry-type and distance-unit enum resolution across QGIS API generations.
- Added point and multipoint matching support, including geographic-CRS geodesic measurement per point vertex and a WGS84 fallback when no project ellipsoid is configured.
- Added cancellable progress feedback during cable scanning and Slackloop matching.
- Added provider attribute-subset requests where supported to reduce unnecessary feature data retrieval.
- Added per-feature diagnostics for invalid geometries, failed CRS transforms, indexing and distance calculations.
- Added safe edit-command rollback and more explicit apply-failure reporting.
- Preserved category precedence: `cable_category` first, `categoy` fallback when missing or blank.
- Preserved natural ascending cable naming selection (A10 before A11/A12).
- Preserved preview-before-apply and the rule that the plugin does not commit layer edits automatically.
- Updated QGIS metadata compatibility range to 3.28–4.99.

## 1.0.3

- Added `cable_category` preferred field with `categoy` fallback.
- Added natural ascending naming selection for multiple matching F2 cables.
- Added preview-before-apply and grouped edit-buffer updates.

Copyright © Amlan Patnaik @2077. All rights reserved.
