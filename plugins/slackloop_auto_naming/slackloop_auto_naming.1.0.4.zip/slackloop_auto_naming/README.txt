SLACKLOOP AUTO NAMING — QGIS PLUGIN v1.0.4
Copyright © Amlan Patnaik @2077. All rights reserved.

PURPOSE
Copies Fiber Cable.naming into Slackloop.cable_name and Fiber Cable.size into Slackloop.cable_size using nearby eligible F2 Fiber Cable features.

MATCH RULES
1. Slackloop must be a point or multipoint vector layer; Fiber Cable must be a line or multiline vector layer.
2. Only Fiber Cable features with a category value of F2 (case-insensitive, whitespace-trimmed) are eligible.
3. The plugin prefers cable_category. If it is missing or blank, it falls back to the alternate field spelling categoy. When both fields exist, a non-empty cable_category value wins.
4. A cable is a match when it intersects the Slackloop point/multipoint geometry or lies within the configured search tolerance.
5. If multiple eligible cables match, the naturally earliest Fiber Cable.naming value wins. For example, A10 sorts before A11 and A12. Sorting is case-insensitive and natural-number aware.
6. Fiber Cable.naming is copied to Slackloop.cable_name; Fiber Cable.size is copied to Slackloop.cable_size.
7. If Slackloop.cable_size is an integer field, numeric source text such as "48", "72" and "144" is converted to an integer. Invalid values are reported in Preview and are not applied.

SAFE EDITING
- Use Preview Naming before Apply Naming.
- Preview does not modify any layer.
- Apply groups attribute changes into one QGIS edit command, so the action can be undone through the layer's edit history.
- Changes are written to the Slackloop layer's edit buffer only. The plugin does not commit changes to the database or file automatically.
- If a change fails during Apply, the plugin attempts to destroy the current edit command, rolling back that command without committing the layer.
- The plugin never commits, saves, or discards the user's pre-existing edit session automatically.
- Review the edits and save the Slackloop layer when ready.

PERFORMANCE AND ERROR HANDLING
- Uses a spatial index containing eligible F2 cable features to reduce repeated full-layer scans.
- Requests only the source/target attributes needed for matching where the provider supports subset-attribute requests.
- Displays a progress dialog during layer scans and point matching.
- Allows cancellation at processing checkpoints. Cancellation does not apply edits.
- Records per-feature transform, geometry, measurement and indexing issues in the QGIS Log Messages panel.
- Keeps processing when an individual feature fails where it is safe to continue.
- A slow remote provider request or a single geometry/provider operation can still temporarily block the QGIS main thread; cancellation is checked between operations.

INSTALLATION
1. Install from the AMLAN-X QGIS Plugin Repository or install the ZIP through Plugins > Manage and Install Plugins > Install from ZIP.
2. Enable Slackloop Auto Naming in Plugins > Manage and Install Plugins > Installed.
3. Open Plugins > Slackloop Auto Naming or use the toolbar action.

REQUIRED FIELDS
Slackloop layer:
- cable_name
- cable_size

Fiber Cable layer:
- naming
- size
- cable_category OR categoy

CRS AND TOLERANCE
- Slackloop geometries are transformed to the Fiber Cable layer CRS before matching.
- Search tolerance is entered in metres.
- A tolerance of 0 requires an exact geometry intersection (with a tiny numeric tolerance for floating-point distance comparisons).
- Geographic CRS distance checks use QgsDistanceArea and the project ellipsoid; WGS84 is used when the project has no ellipsoid configured.
- Projected CRS distance checks use the layer's map units and QGIS unit-conversion factors.

COMPATIBILITY
- Declared QGIS compatibility: 3.28 through 4.99.
- Uses qgis.PyQt and scoped-enum/legacy-enum resolution for Qt 5/PyQt5 and Qt 6/PyQt6 QGIS builds.
- QGIS 3.44.x and QGIS 4.2.x are explicit testing targets for the maintainer.
- This is not a promise of compatibility with QGIS 2, every historical QGIS 3 release, arbitrary standalone PyQt installations, or future versions beyond the declared maximum. Runtime testing is required on each QGIS build/provider combination.

CHANGELOG
See CHANGELOG.md for release history.

COPYRIGHT
Copyright © Amlan Patnaik @2077. All rights reserved.
