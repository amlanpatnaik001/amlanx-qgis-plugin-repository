# -*- coding: utf-8 -*-
"""Dialog and naming logic for Slackloop Auto Naming.

Copyright © Amlan Patnaik @2077. All rights reserved.
"""
import re
import traceback

from qgis.PyQt.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QHBoxLayout, QLabel,
    QMessageBox, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout,
    QGroupBox, QProgressDialog
)
from qgis.core import (
    QgsCoordinateTransform, QgsDistanceArea, QgsGeometry, QgsPointXY,
    Qgis, QgsProject, QgsRectangle, QgsSpatialIndex, QgsUnitTypes, QgsWkbTypes, QgsMessageLog
)
from .qt_compat import (
    ALIGN_RIGHT, ALIGN_CENTER, MATCH_CONTAINS, WINDOW_MODAL,
    NO_EDIT_TRIGGERS, SELECT_ROWS, RESIZE_TO_CONTENTS, MESSAGE_YES, MESSAGE_NO,
)


class ProcessingCancelled(Exception):
    """Raised when the user cancels a preview calculation."""


class SlackloopAutoNamingDialog(QDialog):
    """Preview and apply naming from nearby eligible F2 Fiber Cable features."""

    COPYRIGHT = "Copyright © Amlan Patnaik @2077. All rights reserved."

    @classmethod
    def _with_copyright(cls, message):
        """Append the copyright line to every message-box prompt, without duplicating it."""
        text = str(message)
        if cls.COPYRIGHT.casefold() not in text.casefold():
            text = text.rstrip() + "\n\n" + cls.COPYRIGHT
        return text

    @staticmethod
    def _dialog_title(title):
        """Mark every modal prompt title with the copyright owner."""
        marker = "© Amlan Patnaik @2077"
        return title if marker.casefold() in title.casefold() else "{0} — {1}".format(title, marker)

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.project = QgsProject.instance()
        self.setWindowTitle("Slackloop Auto Naming — © Amlan Patnaik @2077")
        self.setMinimumSize(920, 590)
        self._proposals = []
        self._issues = []
        self._progress = None
        self._busy = False
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        intro = QLabel(
            "Copies Fiber Cable.naming into Slackloop.cable_name and Fiber Cable.size into Slackloop.cable_size. "
            "Only F2 cables are considered. The category field is read from cable_category first, with "
            "categoy used as a fallback when cable_category is unavailable or blank. If multiple cables match, the naturally earliest "
            "non-empty value in Fiber Cable.naming wins (for example, A10 before A11 and A12)."
        )
        intro.setWordWrap(True)
        root.addWidget(intro)

        layers_group = QGroupBox("Input layers")
        layers_layout = QVBoxLayout(layers_group)
        sl_row = QHBoxLayout()
        sl_row.addWidget(QLabel("Slackloop point layer:"))
        self.slackloop_combo = QComboBox()
        self.slackloop_combo.setMinimumWidth(270)
        sl_row.addWidget(self.slackloop_combo, 1)
        layers_layout.addLayout(sl_row)
        cable_row = QHBoxLayout()
        cable_row.addWidget(QLabel("Fiber Cable line layer:"))
        self.cable_combo = QComboBox()
        self.cable_combo.setMinimumWidth(270)
        cable_row.addWidget(self.cable_combo, 1)
        layers_layout.addLayout(cable_row)

        options_row = QHBoxLayout()
        options_row.addWidget(QLabel("Search tolerance (metres):"))
        self.tolerance_spin = QDoubleSpinBox()
        self.tolerance_spin.setRange(0.0, 100.0)
        self.tolerance_spin.setDecimals(3)
        self.tolerance_spin.setSingleStep(0.1)
        self.tolerance_spin.setValue(0.25)
        self.tolerance_spin.setToolTip("0 means the Slackloop point must lie directly on the cable geometry.")
        options_row.addWidget(self.tolerance_spin)
        self.selected_only = QCheckBox("Process selected Slackloop points only")
        options_row.addWidget(self.selected_only)
        options_row.addStretch(1)
        layers_layout.addLayout(options_row)
        root.addWidget(layers_group)

        button_row = QHBoxLayout()
        self.refresh_button = QPushButton("Refresh Layers")
        self.preview_button = QPushButton("Preview Naming")
        self.apply_button = QPushButton("Apply Naming")
        self.apply_button.setEnabled(False)
        self.close_button = QPushButton("Close")
        button_row.addWidget(self.refresh_button)
        button_row.addStretch(1)
        button_row.addWidget(self.preview_button)
        button_row.addWidget(self.apply_button)
        button_row.addWidget(self.close_button)
        root.addLayout(button_row)

        self.status_label = QLabel("Choose the layers, then click Preview Naming.")
        self.status_label.setWordWrap(True)
        root.addWidget(self.status_label)

        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels([
            "Slackloop FID", "Current cable_name", "Proposed cable_name",
            "Proposed cable_size", "Selected cable naming", "Cable category", "Status"
        ])
        self.table.setEditTriggers(NO_EDIT_TRIGGERS)
        self.table.setSelectionBehavior(SELECT_ROWS)
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(RESIZE_TO_CONTENTS)
        self.table.horizontalHeader().setStretchLastSection(True)
        root.addWidget(self.table, 1)

        foot = QLabel(self.COPYRIGHT)
        foot.setAlignment(ALIGN_RIGHT)
        foot.setStyleSheet("color: #777; font-size: 10px;")
        root.addWidget(foot)

        self.refresh_button.clicked.connect(self.refresh_layers)
        self.preview_button.clicked.connect(self.preview)
        self.apply_button.clicked.connect(self.apply_naming)
        self.close_button.clicked.connect(self.close)

    def _log(self, message):
        """Write diagnostics to the QGIS Log Messages panel without masking errors."""
        try:
            QgsMessageLog.logMessage(str(message), "Slackloop Auto Naming")
        except Exception:
            pass

    def _start_progress(self, label, maximum):
        """Create a cancellable modal progress dialog for long provider scans."""
        maximum = max(1, int(maximum))
        self._progress = QProgressDialog(label, "Cancel", 0, maximum, self)
        self._progress.setWindowTitle("Slackloop Auto Naming — © Amlan Patnaik @2077")
        self._progress.setWindowModality(WINDOW_MODAL)
        self._progress.setMinimumDuration(250)
        self._progress.setAutoClose(False)
        self._progress.setAutoReset(False)
        self._progress.setValue(0)
        self._progress.show()
        QApplication.processEvents()

    def _progress_step(self, value, label=None, force=False):
        if self._progress is None:
            return
        if label:
            self._progress.setLabelText(label)
        self._progress.setValue(min(value, self._progress.maximum()))
        if force or value % 25 == 0:
            QApplication.processEvents()
        if self._progress.wasCanceled():
            raise ProcessingCancelled("Preview cancelled by user.")

    def _finish_progress(self):
        if self._progress is not None:
            try:
                self._progress.close()
                self._progress.deleteLater()
            except Exception:
                pass
            self._progress = None

    @staticmethod
    def _distance_unit(name):
        """Resolve distance units across QGIS 3 legacy and scoped enum APIs."""
        scoped = getattr(QgsUnitTypes, "DistanceUnit", None)
        if scoped is not None and hasattr(scoped, name):
            return getattr(scoped, name)
        legacy_name = "Distance" + name
        if hasattr(QgsUnitTypes, legacy_name):
            return getattr(QgsUnitTypes, legacy_name)
        # Older QGIS 3 builds also expose some units through their legacy names.
        if hasattr(QgsUnitTypes, name):
            return getattr(QgsUnitTypes, name)
        raise AttributeError("This QGIS build does not expose distance unit {0}.".format(name))

    @staticmethod
    def _is_geometry_type(wkb_type, name):
        """Compare geometry categories using the enum class returned by this QGIS build."""
        actual = QgsWkbTypes.geometryType(wkb_type)
        # The return enum moved between QGIS API generations. Resolve the
        # expected member from the actual enum type first, then known owners.
        candidates = (name, name + "Geometry")
        owners = (type(actual), getattr(Qgis, "GeometryType", None),
                  getattr(QgsWkbTypes, "GeometryType", None), Qgis, QgsWkbTypes)
        for owner in owners:
            if owner is None:
                continue
            for candidate in candidates:
                if hasattr(owner, candidate):
                    if actual == getattr(owner, candidate):
                        return True
        return False

    def _set_busy(self, busy):
        self._busy = bool(busy)
        for button in (self.refresh_button, self.preview_button, self.apply_button, self.close_button):
            button.setEnabled(not busy)

    def refresh_layers(self):
        old_slack = self.slackloop_combo.currentData()
        old_cable = self.cable_combo.currentData()
        self.slackloop_combo.clear()
        self.cable_combo.clear()
        vector_layers = [layer for layer in self.project.mapLayers().values() if hasattr(layer, "getFeatures") and layer.isValid()]
        for layer in vector_layers:
            self.slackloop_combo.addItem(layer.name(), layer.id())
            self.cable_combo.addItem(layer.name(), layer.id())
        self._select_layer(self.slackloop_combo, old_slack, "Slackloop")
        self._select_layer(self.cable_combo, old_cable, "Fiber Cable")
        self._proposals = []
        self.apply_button.setEnabled(False)
        if not vector_layers:
            self.status_label.setText("No valid vector layers were found in the current project.")
        else:
            self.status_label.setText("Layers refreshed. Click Preview Naming to calculate proposed values.")

    @staticmethod
    def _select_layer(combo, layer_id, preferred_name):
        if layer_id:
            idx = combo.findData(layer_id)
            if idx >= 0:
                combo.setCurrentIndex(idx)
                return
        for i in range(combo.count()):
            if combo.itemText(i).strip().lower() == preferred_name.lower():
                combo.setCurrentIndex(i)
                return
        idx = combo.findText(preferred_name, MATCH_CONTAINS)
        if idx >= 0:
            combo.setCurrentIndex(idx)

    def _get_layer(self, combo):
        layer_id = combo.currentData()
        return self.project.mapLayer(layer_id) if layer_id else None

    def _validate_layers(self):
        slack = self._get_layer(self.slackloop_combo)
        cable = self._get_layer(self.cable_combo)
        if slack is None or cable is None:
            raise ValueError("Select both the Slackloop and Fiber Cable layers.")
        if slack.id() == cable.id():
            raise ValueError("Slackloop and Fiber Cable must be different layers.")
        if not self._is_geometry_type(slack.wkbType(), "Point"):
            raise ValueError("The selected Slackloop layer must contain point or multipoint features.")
        if not self._is_geometry_type(cable.wkbType(), "Line"):
            raise ValueError("The selected Fiber Cable layer must contain line or multiline features.")
        required_slack = ["cable_name", "cable_size"]
        category_fields = [
            name for name in ("cable_category", "categoy")
            if cable.fields().indexFromName(name) >= 0
        ]
        required_cable = ["naming", "size"]
        missing_slack = [name for name in required_slack if slack.fields().indexFromName(name) < 0]
        missing_cable = [name for name in required_cable if cable.fields().indexFromName(name) < 0]
        if missing_slack:
            raise ValueError("Slackloop layer is missing required field(s): " + ", ".join(missing_slack))
        if not category_fields:
            missing_cable.insert(0, "cable_category or categoy")
        if missing_cable:
            raise ValueError("Fiber Cable layer is missing required field(s): " + ", ".join(missing_cable))
        if self.selected_only.isChecked() and not slack.selectedFeatureCount():
            raise ValueError("'Process selected Slackloop points only' is checked, but no Slackloop features are selected.")
        return slack, cable

    @staticmethod
    def _natural_key(value):
        """Natural, case-insensitive sort key: A10 sorts before A11 and A12."""
        text = "" if value is None else str(value).strip()
        # Tag each token so mixed values such as A10, B1 and 12C remain comparable.
        return tuple((1, int(part)) if part.isdigit() else (0, part.casefold())
                     for part in re.split(r"(\d+)", text))

    @staticmethod
    def _value(feature, field_name):
        value = feature[field_name]
        if value is None:
            return ""
        try:
            if value.isNull():
                return ""
        except AttributeError:
            pass
        return value

    @staticmethod
    def _category_value(feature, available_fields):
        """Prefer cable_category; fall back to the client's alternate spelling, categoy.

        If both fields exist, a non-empty cable_category value wins. A blank/null value
        falls back to categoy, allowing mixed or partially migrated client schemas.
        """
        for field_name in ("cable_category", "categoy"):
            if field_name not in available_fields:
                continue
            value = SlackloopAutoNamingDialog._value(feature, field_name)
            if str(value).strip():
                return value
        return ""

    @staticmethod
    def _display(value):
        return "" if value is None else str(value)

    def _distance_tolerance_in_layer_units(self, tolerance_m, crs):
        if tolerance_m <= 0:
            return 0.0
        units = crs.mapUnits()
        if units == self._distance_unit("Degrees"):
            # Bounding boxes in geographic coordinates; final distance is geodesic.
            return tolerance_m / 111320.0
        factor = QgsUnitTypes.fromUnitToUnitFactor(self._distance_unit("Meters"), units)
        return tolerance_m * factor

    def _search_rect(self, point, tolerance_m, cable_crs):
        """Return an expanded bounding box; supports Point and MultiPoint Slackloop layers."""
        bbox = point.boundingBox()
        if tolerance_m <= 0:
            return bbox
        if cable_crs.mapUnits() == self._distance_unit("Degrees"):
            import math
            lat_values = (bbox.yMinimum(), bbox.yMaximum())
            lat = max(-89.9, min(89.9, max(abs(v) for v in lat_values)))
            dy = tolerance_m / 111320.0
            # Use the most conservative longitude expansion across the feature extent.
            cosine = max(abs(math.cos(math.radians(lat))), 0.001)
            dx = tolerance_m / (111320.0 * cosine)
            return QgsRectangle(
                bbox.xMinimum() - dx, bbox.yMinimum() - dy,
                bbox.xMaximum() + dx, bbox.yMaximum() + dy
            )
        tol_units = self._distance_tolerance_in_layer_units(tolerance_m, cable_crs)
        return QgsRectangle(
            bbox.xMinimum() - tol_units, bbox.yMinimum() - tol_units,
            bbox.xMaximum() + tol_units, bbox.yMaximum() + tol_units
        )

    def _distance_to_geometry(self, point_geom, line_geom, cable_layer):
        """Measure shortest point/multipoint-to-line distance, geodesically for degrees."""
        try:
            if point_geom.intersects(line_geom):
                return 0.0
        except Exception:
            pass
        if cable_layer.crs().mapUnits() != self._distance_unit("Degrees"):
            return point_geom.distance(line_geom)

        da = QgsDistanceArea()
        da.setSourceCrs(cable_layer.crs(), self.project.transformContext())
        ellipsoid = self.project.ellipsoid()
        if not ellipsoid or str(ellipsoid).strip().upper() == "NONE":
            ellipsoid = "WGS84"
        da.setEllipsoid(ellipsoid)

        distances = []
        # QgsGeometry.vertices() works for both Point and MultiPoint geometries.
        for vertex in point_geom.vertices():
            vertex_xy = QgsPointXY(vertex)
            vertex_geom = QgsGeometry.fromPointXY(vertex_xy)
            closest = line_geom.closestPoint(vertex_geom)
            if closest.isNull() or closest.isEmpty():
                continue
            distances.append(da.measureLine(vertex_xy, closest.asPoint()))
        return min(distances) if distances else float("inf")

    def _build_proposals(self):
        slack, cable = self._validate_layers()
        slack_size_idx = slack.fields().indexFromName("cable_size")
        tolerance_m = float(self.tolerance_spin.value())

        transform = None
        if slack.crs() != cable.crs():
            transform = QgsCoordinateTransform(slack.crs(), cable.crs(), self.project.transformContext())
            if hasattr(transform, "isValid") and not transform.isValid():
                raise ValueError("The coordinate transformation between Slackloop and Fiber Cable CRS is invalid.")

        category_fields = [
            name for name in ("cable_category", "categoy")
            if cable.fields().indexFromName(name) >= 0
        ]
        cable_count = max(0, int(cable.featureCount()))
        target_count = (
            max(0, int(slack.selectedFeatureCount()))
            if self.selected_only.isChecked()
            else max(0, int(slack.featureCount()))
        )
        total_steps = max(1, cable_count + target_count)
        self._start_progress("Scanning eligible Fiber Cable features…", total_steps)
        processed = 0

        eligible = []
        cable_request = None
        try:
            from qgis.core import QgsFeatureRequest
            cable_request = QgsFeatureRequest()
            cable_indices = [cable.fields().indexFromName(name) for name in ("naming", "size") + tuple(category_fields)]
            cable_request.setSubsetOfAttributes([idx for idx in cable_indices if idx >= 0])
        except Exception as request_exc:
            self._log("Could not optimize Fiber Cable attribute request; using provider defaults: {0}".format(request_exc))
            cable_request = None

        cable_iterator = cable.getFeatures(cable_request) if cable_request is not None else cable.getFeatures()
        for feat in cable_iterator:
            processed += 1
            if processed % 25 == 0:
                self._progress_step(processed, "Scanning Fiber Cable features…")
            try:
                category = self._category_value(feat, category_fields)
                cable_name_value = self._value(feat, "naming")
                geometry = feat.geometry()
                if (str(category).strip().casefold() == "f2"
                        and str(cable_name_value).strip()
                        and geometry is not None
                        and not geometry.isNull()
                        and not geometry.isEmpty()):
                    eligible.append(feat)
            except Exception as exc:
                self._issues.append("Fiber Cable feature {0} skipped during eligibility check: {1}".format(feat.id(), exc))
                self._log(traceback.format_exc())

        if not eligible:
            raise ValueError(
                "No Fiber Cable features with F2 in cable_category or categoy and a non-empty naming value were found."
            )

        cable_index = QgsSpatialIndex()
        eligible_by_id = {}
        for feat in eligible:
            try:
                added = cable_index.addFeature(feat)
                if added is False:
                    raise RuntimeError("QgsSpatialIndex rejected the feature.")
                eligible_by_id[feat.id()] = feat
            except Exception as exc:
                self._issues.append("Fiber Cable feature {0} could not be indexed: {1}".format(feat.id(), exc))
                self._log(traceback.format_exc())

        if not eligible_by_id:
            raise RuntimeError("No eligible Fiber Cable features could be indexed. Check geometry validity and provider access.")

        try:
            from qgis.core import QgsFeatureRequest
            slack_request = QgsFeatureRequest()
            slack_indices = [slack.fields().indexFromName(name) for name in ("cable_name", "cable_size")]
            slack_request.setSubsetOfAttributes([idx for idx in slack_indices if idx >= 0])
        except Exception as request_exc:
            self._log("Could not optimize Slackloop attribute request; using provider defaults: {0}".format(request_exc))
            slack_request = None

        if self.selected_only.isChecked():
            target_iterator = slack.getSelectedFeatures(slack_request) if slack_request is not None else slack.getSelectedFeatures()
        else:
            target_iterator = slack.getFeatures(slack_request) if slack_request is not None else slack.getFeatures()

        proposals = []
        for sf in target_iterator:
            processed += 1
            if processed % 25 == 0:
                self._progress_step(processed, "Matching Slackloop points to nearby F2 cables…")
            try:
                sgeom = sf.geometry()
                if sgeom is None or sgeom.isNull() or sgeom.isEmpty():
                    proposals.append({"slack_fid": sf.id(), "current_name": self._value(sf, "cable_name"), "name": "", "size": "", "naming": "", "category": "F2", "status": "Skipped: empty geometry", "cable_fid": None})
                    continue
                point_geom = QgsGeometry(sgeom)
                if transform is not None:
                    try:
                        point_geom.transform(transform)
                    except Exception as exc:
                        proposals.append({"slack_fid": sf.id(), "current_name": self._value(sf, "cable_name"), "name": "", "size": "", "naming": "", "category": "F2", "status": "Skipped: CRS transform failed", "cable_fid": None, "error": str(exc)})
                        self._issues.append("Slackloop feature {0}: CRS transform failed: {1}".format(sf.id(), exc))
                        continue

                search_rect = self._search_rect(point_geom, tolerance_m, cable.crs())
                candidates = []
                for candidate_fid in cable_index.intersects(search_rect):
                    cf = eligible_by_id.get(candidate_fid)
                    if cf is None:
                        continue
                    try:
                        geom = cf.geometry()
                        distance = self._distance_to_geometry(point_geom, geom, cable)
                        if tolerance_m <= 0:
                            within_tolerance = distance <= 1e-9
                        elif cable.crs().mapUnits() == self._distance_unit("Degrees"):
                            within_tolerance = distance <= tolerance_m
                        else:
                            within_tolerance = distance <= self._distance_tolerance_in_layer_units(tolerance_m, cable.crs())
                        if within_tolerance:
                            candidates.append((cf, distance))
                    except Exception as exc:
                        self._issues.append("Cable feature {0} could not be measured against Slackloop feature {1}: {2}".format(candidate_fid, sf.id(), exc))
                        self._log(traceback.format_exc())

                if not candidates:
                    proposals.append({"slack_fid": sf.id(), "current_name": self._value(sf, "cable_name"), "name": "", "size": "", "naming": "", "category": "F2", "status": "No eligible F2 cable within tolerance", "cable_fid": None})
                    continue

                candidates.sort(key=lambda item: (self._natural_key(self._value(item[0], "naming")), item[0].id()))
                chosen, distance = candidates[0]
                name = self._value(chosen, "naming")
                source_size = self._value(chosen, "size")
                size = source_size
                old_name = self._value(sf, "cable_name")
                old_size = self._value(sf, "cable_size")

                target_size_type = slack.fields().field(slack_size_idx).typeName().lower()
                if "int" in target_size_type:
                    if str(size).strip() == "":
                        size = None
                    else:
                        try:
                            size = int(str(size).strip())
                        except (TypeError, ValueError):
                            proposals.append({
                                "slack_fid": sf.id(), "current_name": old_name, "current_size": old_size,
                                "name": name, "size": source_size,
                                "naming": self._value(chosen, "naming"),
                                "category": self._category_value(chosen, category_fields),
                                "status": "Invalid source size (expected an integer)",
                                "cable_fid": chosen.id(), "distance": distance,
                                "match_count": len(candidates)
                            })
                            continue
                same = str(old_name) == str(name) and str(old_size) == str(size)
                proposals.append({
                    "slack_fid": sf.id(), "current_name": old_name, "current_size": old_size,
                    "name": name, "size": size, "naming": self._value(chosen, "naming"),
                    "category": self._category_value(chosen, category_fields), "status": "Already correct" if same else "Ready to update",
                    "cable_fid": chosen.id(), "distance": distance, "match_count": len(candidates),
                    "slack_feature": sf
                })
            except ProcessingCancelled:
                raise
            except Exception as exc:
                self._issues.append("Slackloop feature {0} failed during matching: {1}".format(sf.id(), exc))
                self._log(traceback.format_exc())
                proposals.append({"slack_fid": sf.id(), "current_name": self._value(sf, "cable_name"), "name": "", "size": "", "naming": "", "category": "", "status": "Error: {0}".format(exc), "cable_fid": None})

        self._progress_step(total_steps, "Preview completed.", force=True)
        return slack, cable, proposals

    def preview(self):
        if self._busy:
            return
        self._issues = []
        self._set_busy(True)
        self.status_label.setText("Preparing preview…")
        self.apply_button.setEnabled(False)
        try:
            slack, cable, proposals = self._build_proposals()
        except ProcessingCancelled:
            self._proposals = []
            self.table.setRowCount(0)
            self.status_label.setText("Preview cancelled. No edits were applied.")
            self._log("Preview cancelled by user. No layer edits were made.")
            return
        except Exception as exc:
            self._proposals = []
            self.apply_button.setEnabled(False)
            self.status_label.setText("Preview failed: {0}".format(exc))
            self._log("Preview failed: {0}\n{1}".format(exc, traceback.format_exc()))
            QMessageBox.warning(self, self._dialog_title("Slackloop Auto Naming"), self._with_copyright(str(exc)))
            return
        finally:
            self._finish_progress()
            self._set_busy(False)

        self._set_busy(True)
        self._proposals = proposals
        self.table.setRowCount(0)
        ready = 0
        matched = 0
        for index, proposal in enumerate(proposals, 1):
            row = self.table.rowCount()
            self.table.insertRow(row)
            values = [
                proposal.get("slack_fid", ""),
                self._display(proposal.get("current_name", "")),
                self._display(proposal.get("name", "")),
                self._display(proposal.get("size", "")),
                self._display(proposal.get("naming", "")),
                self._display(proposal.get("category", "")),
                proposal.get("status", "")
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if col == 0:
                    item.setTextAlignment(ALIGN_CENTER)
                self.table.setItem(row, col, item)
            if proposal.get("cable_fid") is not None:
                matched += 1
                if proposal.get("status") == "Ready to update":
                    ready += 1
            if index % 100 == 0:
                QApplication.processEvents()
        self._set_busy(False)
        self.apply_button.setEnabled(ready > 0)
        issue_summary = " {0} issue(s) were logged; see QGIS Log Messages for details.".format(len(self._issues)) if self._issues else ""
        self.status_label.setText(
            "Preview complete: {0} Slackloop feature(s) checked; {1} matched to F2 cable(s); "
            "{2} ready to update.{3} Apply creates uncommitted edits; save the layer when satisfied.".format(
                len(proposals), matched, ready, issue_summary
            )
        )
        if self._issues:
            self._log("Preview completed with {0} issue(s). First issue: {1}".format(len(self._issues), self._issues[0]))

    def apply_naming(self):
        if self._busy:
            return
        if not self._proposals:
            QMessageBox.information(self, self._dialog_title("Slackloop Auto Naming"), self._with_copyright("Run Preview Naming first."))
            return
        ready = [p for p in self._proposals if p.get("status") == "Ready to update" and p.get("cable_fid") is not None]
        if not ready:
            QMessageBox.information(self, self._dialog_title("Slackloop Auto Naming"), self._with_copyright("There are no proposed changes to apply."))
            return
        try:
            slack, _cable = self._validate_layers()
        except Exception as exc:
            self._log("Apply validation failed: {0}\n{1}".format(exc, traceback.format_exc()))
            QMessageBox.warning(self, self._dialog_title("Slackloop Auto Naming"), self._with_copyright(str(exc)))
            return

        response = QMessageBox.question(
            self, self._dialog_title("Confirm Slackloop Updates"),
            self._with_copyright("Update {0} Slackloop feature(s)?\n\nChanges will remain in QGIS's edit buffer and will not be committed automatically.".format(len(ready))),
            MESSAGE_YES | MESSAGE_NO, MESSAGE_NO
        )
        if response != MESSAGE_YES:
            return

        was_editable = slack.isEditable()
        if not was_editable:
            try:
                if not slack.startEditing():
                    raise RuntimeError("The Slackloop layer refused to enter edit mode.")
            except Exception as exc:
                self._log("Could not start Slackloop edit session: {0}\n{1}".format(exc, traceback.format_exc()))
                QMessageBox.critical(self, self._dialog_title("Slackloop Auto Naming"), self._with_copyright("Could not start editing on the Slackloop layer: {0}".format(exc)))
                return

        changed = 0
        slack_name_idx = slack.fields().indexFromName("cable_name")
        slack_size_idx = slack.fields().indexFromName("cable_size")
        command_started = False
        try:
            slack.beginEditCommand("Slackloop Auto Naming: Update cable_name and cable_size")
            command_started = True
            for p in ready:
                fid = p["slack_fid"]
                if not slack.changeAttributeValue(fid, slack_name_idx, p["name"]):
                    raise RuntimeError("Failed to set cable_name for Slackloop feature ID {0}. The feature may have changed since preview.".format(fid))
                if not slack.changeAttributeValue(fid, slack_size_idx, p["size"]):
                    raise RuntimeError("Failed to set cable_size for Slackloop feature ID {0}. The feature may have changed since preview.".format(fid))
                changed += 1
            slack.endEditCommand()
            command_started = False
        except Exception as exc:
            if command_started:
                try:
                    slack.destroyEditCommand()
                except Exception:
                    self._log("Failed to destroy the incomplete edit command: {0}".format(traceback.format_exc()))
            self._log("Apply failed after {0} feature(s); the current edit command was rolled back: {1}\n{2}".format(changed, exc, traceback.format_exc()))
            QMessageBox.critical(
                self, self._dialog_title("Slackloop Auto Naming"),
                self._with_copyright("The update command failed and was rolled back.\n\n{0}\n\nExisting edits in the layer were not committed.".format(exc))
            )
            return

        self.preview()
        QMessageBox.information(
            self, self._dialog_title("Slackloop Auto Naming"),
            self._with_copyright("Updated {0} Slackloop feature(s) in the QGIS edit buffer.\n\nNo database/file commit was performed. Review the changes, then save edits on the Slackloop layer when ready.".format(changed))
        )

