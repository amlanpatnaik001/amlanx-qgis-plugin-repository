# -*- coding: utf-8 -*-
"""Slackloop Auto Naming QGIS plugin.

Copyright © Amlan Patnaik @2077. All rights reserved.
"""
import os

from qgis.PyQt.QtGui import QIcon
try:
    # Qt 6 moved QAction from QtWidgets to QtGui.
    from qgis.PyQt.QtGui import QAction
except ImportError:  # Qt 5 / older QGIS compatibility
    from qgis.PyQt.QtWidgets import QAction

from .slackloop_auto_naming_dialog import SlackloopAutoNamingDialog


class SlackloopAutoNaming:
    """Add the Slackloop Auto Naming action to QGIS."""

    def __init__(self, iface):
        self.iface = iface
        self.actions = []
        self.menu = "&Slackloop Auto Naming"
        self.dlg = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.svg")
        action = QAction(QIcon(icon_path), "Slackloop Auto Naming", self.iface.mainWindow())
        action.setStatusTip("Populate Slackloop cable_name and cable_size from snapped F2 Fiber Cable.naming and size fields, reading cable_category with categoy as fallback. "
                            "Copyright © Amlan Patnaik @2077. All rights reserved.")
        action.setWhatsThis("Slackloop Auto Naming. Copyright © Amlan Patnaik @2077. All rights reserved.")
        action.triggered.connect(self.run)
        self.iface.addPluginToMenu(self.menu, action)
        self.iface.addToolBarIcon(action)
        self.actions.append(action)

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)
        self.actions.clear()
        if self.dlg is not None:
            self.dlg.close()
            self.dlg = None

    def run(self):
        if self.dlg is None:
            self.dlg = SlackloopAutoNamingDialog(self.iface, self.iface.mainWindow())
        self.dlg.refresh_layers()
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()
