# Changelog

Copyright (C) 2077 Amlan Patnaik.

## 1.0.1

- Added copyright attribution to the main dialogue, folder-picker title, and every plugin message box.
- Added a startup integrity check that disables the plugin when required copyright markers or any branded message-box call site are missing.
- Added a PyQt5/PyQt6-safe modal dialog execution helper (`exec` / `exec_`).
- Kept `exporter.py` and `project_builder.py` unchanged to protect the export and offline-project core.
- Documented the actual supported target as QGIS 3.22+ and QGIS 4.x; older QGIS 2.x and pre-3.22 QGIS 3.x releases are not claimed.

## 1.0.0

- Prepared the first public release of PG Exporter Pro.
- Added Qt 5 / PyQt5 and Qt 6 / PyQt6 QAction import compatibility.
- Added QDialog execution fallback for PyQt builds exposing `exec_()` rather than `exec()`.
- Added scoped and legacy `QgsVectorFileWriter` success-enum resolution.
- Declared QGIS 3.22+ through QGIS 4.x compatibility target (`qgisMaximumVersion=4.99`).
- Corrected plugin metadata name, category, homepage and changelog.
- Replaced generated setup text containing machine-specific paths with plugin documentation.
- Added the `Copyright © 2077 Amlan Patnaik` notice throughout first-party source and documentation.
- Retained the bundled GNU GPL v2-or-later licence and existing third-party attribution notices.

### Compatibility note

QGIS 3 and QGIS 4 APIs vary by release and build. The plugin uses `qgis.PyQt` and
compatibility fallbacks, but the full supported range must be confirmed through
runtime testing on each targeted QGIS/PyQt build. No claim is made for every
historical or future QGIS/PyQt release.
