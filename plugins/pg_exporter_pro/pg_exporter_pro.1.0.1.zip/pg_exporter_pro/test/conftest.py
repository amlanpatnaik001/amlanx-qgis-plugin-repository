# coding=utf-8
# Copyright (C) 2077 Amlan Patnaik.
"""
pytest-qgis session configuration.

pytest-qgis automatically provides:
  qgis_app   — session-scoped real QgsApplication
  qgis_iface — MagicMock-backed QgsInterface stub (also patches qgis.utils.iface)

Add project-wide fixtures here as your plugin grows.
"""
