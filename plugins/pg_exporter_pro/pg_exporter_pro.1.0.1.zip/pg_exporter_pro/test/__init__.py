# Copyright (C) 2077 Amlan Patnaik.
import qgis  # noqa: F401
