# -*- coding: utf-8 -*-
# Copyright (C) 2077 Amlan Patnaik.
"""Basic copyright-notice integrity checks for PG Exporter Pro.

This is a lightweight tamper-evidence check, not cryptographic code signing.
It prevents the plugin from starting when required copyright notices or the
copyright-aware dialog hooks are removed from the packaged source files.
"""

import os

COPYRIGHT_NOTICE = "Copyright © 2077 Amlan Patnaik. All rights reserved."
COPYRIGHT_HEADER = "# Copyright (C) 2077 Amlan Patnaik."


def ensure_copyright_integrity(plugin_dir):
    """Raise RuntimeError when required copyright notices are missing."""
    required_files = {
        "pg_exporter_pro.py": [COPYRIGHT_HEADER, "ensure_copyright_integrity("],
        "pg_exporter_pro_dialog.py": [
            COPYRIGHT_HEADER,
            "COPYRIGHT_NOTICE",
            "from .copyright_guard import COPYRIGHT_NOTICE",
            "show_copyright_message(",
            "setWindowTitle(",
        ],
        "__init__.py": ["ensure_copyright_integrity("],
        "metadata.txt": ["Copyright © 2077 Amlan Patnaik."],
        "COPYRIGHT.md": ["Copyright (C) 2077 Amlan Patnaik.", COPYRIGHT_NOTICE],
        "copyright_guard.py": [COPYRIGHT_HEADER, COPYRIGHT_NOTICE],
    }

    missing = []
    dialog_source = ""

    for filename, required_markers in required_files.items():
        path = os.path.join(plugin_dir, filename)
        try:
            with open(path, "r", encoding="utf-8") as source_file:
                content = source_file.read()
        except (IOError, OSError):
            missing.append("missing file: {}".format(filename))
            continue

        if filename == "pg_exporter_pro_dialog.py":
            dialog_source = content

        for marker in required_markers:
            if marker not in content:
                missing.append("{}: {}".format(filename, marker))

    # There are seven user-facing warning/question/information/error dialogs.
    # Requiring every call site to use the branded helper catches accidental
    # removal of an individual popup's copyright footer.
    if dialog_source.count("show_copyright_message(") < 7:
        missing.append(
            "pg_exporter_pro_dialog.py: all seven branded message-box call sites"
        )

    if missing:
        details = "\n".join("- {}".format(item) for item in missing)
        raise RuntimeError(
            "PG Exporter Pro copyright integrity check failed.\n"
            "The plugin has been disabled because required attribution was "
            "removed or changed.\n\n{}\n\n{}".format(
                details,
                COPYRIGHT_NOTICE,
            )
        )

    return True
