PG EXPORTER PRO
===============

Copyright (C) 2077 Amlan Patnaik.
All rights reserved.

Export selected PostgreSQL/PostGIS layers into:
- A single GeoPackage
- Optional QML styles
- A detailed export log
- An offline QGIS project (.qgz)

The offline project preserves the source project's CRS, layer groups,
layer order, visibility, and saved styles for successfully exported layers.

COMPATIBILITY TARGET
--------------------
- QGIS 3.22 and later within the QGIS 3.x series
- QGIS 4.x (maximum metadata version 4.99)
- Qt 5 / PyQt5 and Qt 6 / PyQt6 through qgis.PyQt

The declared compatibility range is a target, not a claim that every
historical QGIS/PyQt build has been runtime-tested. Verify the plugin in
each target QGIS installation before production use.

INSTALLATION
------------
Install from the QGIS Plugin Manager using your plugin repository, or
install the ZIP via Plugins > Manage and Install Plugins > Install from ZIP.

USAGE
-----
1. Open PG Exporter Pro from the Plugins menu or toolbar.
2. Select the PostgreSQL/PostGIS layers to export.
3. Choose an output folder.
4. Choose whether to save layer styles, if that option is enabled.
5. Confirm the export and review the completion summary.
6. Check export_log.txt for per-layer results and diagnostic details.

LICENCE
-------
This plugin is distributed under the GNU General Public License,
version 2 or (at your option) any later version. See the bundled LICENSE.

The original Plugin Builder and test-scaffold attribution notices are
retained in the files where those components appear.

The original generated Plugin Builder README template included the notice © 2011–2026 GeoApt LLC / Jonah Sullivan; that template acknowledgement is retained here.


COPYRIGHT DISPLAY AND INTEGRITY
-------------------------------
The main plugin dialogue, folder picker title, and every plugin warning,
question, information, and error message display the copyright notice.
A startup integrity check disables the plugin if required attribution or
message-box branding markers have been removed from the packaged source.
This is a basic tamper-evidence measure, not cryptographic code signing.

VERSION SUPPORT NOTE
--------------------
The supported target is QGIS 3.22+ and QGIS 4.x (up to the declared metadata
maximum), using the Qt abstraction shipped with QGIS. QGIS 2.x and older QGIS
3.x releases are not claimed as supported because the export engine uses the
QGIS 3 vector-writer API. The export engine and project-builder core modules
are intentionally retained unchanged in this update.
