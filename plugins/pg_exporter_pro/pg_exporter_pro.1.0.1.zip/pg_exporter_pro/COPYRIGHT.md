# Copyright and acknowledgements

**Copyright (C) 2077 Amlan Patnaik.**

Copyright © 2077 Amlan Patnaik. All rights reserved.

PG Exporter Pro is distributed under the GNU General Public License,
version 2 or (at your option) any later version. The exact licence terms
are in the bundled `LICENSE` file. The copyright notice does not remove
the rights granted by that licence.

The plugin was initially scaffolded with QGIS Plugin Builder. Existing
third-party notices in generated helper and test files are intentionally
retained. The test helper `test/qgis_interface.py` contains original
attribution notices for Ivan Mincik, German Carrillo and Tim Sutton;
those notices remain applicable to that helper file.

The original generated Plugin Builder README template included the notice © 2011–2026 GeoApt LLC / Jonah Sullivan; that template acknowledgement is retained here.
