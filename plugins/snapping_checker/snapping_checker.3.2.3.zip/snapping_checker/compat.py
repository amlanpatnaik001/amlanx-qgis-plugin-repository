# Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere
"""Minimal Qt compatibility helpers for QGIS / PyQt5 / PyQt6."""

try:
    from qgis.PyQt.QtGui import QAction
except ImportError:  # Compatibility with Qt builds exposing QAction in QtWidgets.
    from qgis.PyQt.QtWidgets import QAction


def dialog_exec(dialog):
    """Execute a modal dialog on both Qt5 and Qt6."""
    execute = getattr(dialog, 'exec', None)
    if execute is None:
        execute = getattr(dialog, 'exec_', None)
    if execute is None:
        raise RuntimeError('This QGIS Qt build does not expose a dialog execution method.')
    return execute()


def geometry_type_value(qgis_class, wkb_types_class, scoped_name, legacy_name):
    """Resolve QGIS geometry-type enums across QGIS 3 and QGIS 4.

    QGIS 3.30+ and QGIS 4 expose Qgis.GeometryType.Point/Line/Polygon.
    Older QGIS 3 builds expose QgsWkbTypes.PointGeometry/LineGeometry/
    PolygonGeometry. Prefer the scoped enum and fall back to the legacy name.
    """
    geometry_scope = getattr(qgis_class, 'GeometryType', None)
    if geometry_scope is not None:
        value = getattr(geometry_scope, scoped_name, None)
        if value is not None:
            return value

    value = getattr(wkb_types_class, legacy_name, None)
    if value is not None:
        return value

    raise RuntimeError(
        'This QGIS build does not expose a compatible geometry enum: %s / %s'
        % (scoped_name, legacy_name)
    )
