# Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere

def classFactory(iface):
    from .plugin import SnappingCheckerPlugin
    return SnappingCheckerPlugin(iface)
