SNAPPING CHECKER 3.2.3 — QGIS 3 / QGIS 4 RELEASE

Purpose
-------
Snapping Checker preserves the original compiled snapping algorithms and
licence system. It also provides custom One-to-Many and Many-to-Many layer
workflows, line-path alignment checking, and clean QC result handling.

QGIS 4 / Qt6 compatibility
--------------------------
- Uses the QGIS-provided qgis.PyQt abstraction rather than importing PyQt5 or
  PyQt6 directly.
- Resolves QAction from the QtGui module, with a QtWidgets fallback.
- Executes dialogs through exec() with exec_() fallback.
- Resolves scoped Qgis.GeometryType.Point/Line/Polygon values where available,
  with legacy QgsWkbTypes geometry constants as fallback.
- Handles Qt5/Qt6 scoped and legacy enum values used by the wrapper.
- metadata.txt declares qgisMinimumVersion=3.28 and qgisMaximumVersion=4.99.

Compiled engine runtime requirement
-----------------------------------
The original compiled snapping and licence engine builds are provided for
Python 3.9, 3.10, 3.11, 3.12 and 3.13. At startup the plugin loads the build
matching the Python minor version bundled with QGIS. If the running QGIS uses a
Python minor version outside this list, the compiled engines cannot be loaded;
matching original builds would be required. This archive cannot guarantee
future Python ABI compatibility without those builds.

The wrapper is prepared for QGIS 3 / Qt5 and QGIS 4 / Qt6 API layouts. Static
compatibility checks have been run, but production compatibility must still
be confirmed in the actual QGIS installation and operating system. In
particular, test QGIS 4.2.3 and confirm its Python minor version in the QGIS
Python Console using: import sys; print(sys.version)

Four workflows
--------------
1. Check Snapping (two layers): original single source / target check.
2. Check All Layers (fiber network): original telecom / fiber rule-set check.
3. Custom Check (One-to-Many): one source against multiple targets.
4. Custom Check (Many-to-Many): every selected source against every selected target.

Custom workflows
----------------
- Any valid vector layer in the current project can be selected.
- Select All and Clear controls are provided for multi-select lists.
- The original snapping parameters are retained.
- Each source/target pair runs sequentially through the original checker.
- Progress, cancellation and per-pair error reporting are provided.
- Results are grouped by run; source layer geometry and attributes are not edited.
- Empty error and connector layers are suppressed.
- Correctly snapped SNAPPED records are excluded from custom error outputs.
- Line-to-line custom checks can sample between stored vertices and report
  LINE_OFFSET when repeated samples exceed precision but remain within tolerance.

Installation
------------
1. In QGIS, open Plugins > Manage and Install Plugins.
2. Choose Install from ZIP and select snapping_checker.3.2.3.zip, or install
   through the AMLAN-X QGIS Plugin Repository.
3. Restart QGIS if the previous release is already loaded.
4. Open Vector > Snapping Checker or use the toolbar actions.

Changelog
---------
See metadata.txt (the Plugin Manager changelog), CHANGELOG, or CHANGELOG.txt.

Copyright
---------
Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.

Original compiled snapping and licence components retain their original
ownership, notices and applicable terms.
