# Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere
"""Minimal Qt compatibility helpers for QGIS / PyQt5 / PyQt6."""

try:
    from qgis.PyQt.QtGui import QAction
except ImportError:  # Compatibility with Qt builds exposing QAction in QtWidgets.
    from qgis.PyQt.QtWidgets import QAction


def dialog_exec(dialog):
    """Execute a modal dialog on both Qt5 and Qt6."""
    execute = getattr(dialog, 'exec', None)
    if execute is None:
        execute = getattr(dialog, 'exec_', None)
    if execute is None:
        raise RuntimeError('This QGIS Qt build does not expose a dialog execution method.')
    return execute()
