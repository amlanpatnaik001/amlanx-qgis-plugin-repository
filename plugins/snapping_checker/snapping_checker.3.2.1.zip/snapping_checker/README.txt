SNAPPING CHECKER 3.2.0 — CUSTOM LAYER EDITION

Purpose
-------
This release preserves the original compiled snapping algorithms and license
system. It adds two custom ways to run the original two-layer checker across
user-selected project layers. The core snapping implementation is not rewritten.

Four workflows
--------------
1. Check Snapping (two layers)
   Opens the original Processing algorithm for one source and one target.

2. Check All Layers (fiber network)
   Opens the original telecom/fiber rule-set algorithm unchanged.

3. Custom Check (One-to-Many)
   Select one source layer and any number of target layers. The original
   two-layer checker runs once for each selected target against that source.

4. Custom Check (Many-to-Many)
   Select any number of source layers and any number of target layers. Every
   selected source is checked against every selected target (Cartesian pairing).

Custom layer workflow
---------------------
- Both custom actions open a dialog with radio buttons for One-to-Many and
  Many-to-Many. The action determines the initial selection; the radio button
  can be changed in the dialog.
- Any valid vector layer currently loaded in the QGIS project can be selected.
- Select-all and clear controls are provided for multi-select lists.
- The original snapping controls are available: endpoint/all-vertex mode,
  target vertex/edge mode, tolerance, precision, overshoot, self-loop check,
  crossing/overlap check, selected-features-only and optional NOT_CONNECTED/
  SNAPPED output.
- Each source-target pair invokes the original checksnapping algorithm.
- Result point and connector layers are placed in a timestamped QGIS layer-tree
  group. Outputs are kept even if a later pair fails or the user cancels.
- Source layers are read only by the custom workflow. No source geometry or
  attributes are edited.
- If one pair fails, remaining pairs continue and the failed pair is reported.

Safety and integrity
--------------------
- Original snap_core_py*.pyc modules are preserved byte-for-byte.
- Original license_py*.pyc modules are preserved byte-for-byte.
- The original two-layer and all-layer Processing algorithms remain available.
- Custom runs are sequential and use the same original single-pair algorithm.
- No external dependencies are introduced.

Compatibility
-------------
The supplied original core and license builds are for Python 3.9, 3.10, 3.11,
3.12 and 3.13. QGIS 3.28–3.x and QGIS 4.x are declared in metadata, but actual
support depends on the Python minor version shipped by the QGIS installation
and availability of a matching original compiled module. Live QGIS testing is
required on each target installation before production deployment.

Installation
------------
1. In QGIS, open Plugins > Manage and Install Plugins.
2. Choose Install from ZIP.
3. Select Snapping_Checker_v3.2.1_Line_QC.zip.
4. Restart QGIS if Snapping Checker was already installed or loaded.
5. Open Vector > Snapping Checker or use the four toolbar icons.

Copyright
---------
Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.


Version 3.2.1 result behavior
- Custom checks add an error point layer only when it contains at least one real error.
- Connector layers are added only when they contain connectors for actual errors.
- Correctly snapped SNAPPED records are never shown by custom checks.
- If every source/target pair is clean, the temporary result group is removed.
- For line-to-line pairs, optional path-alignment sampling checks geometry between stored vertices.
  LINE_OFFSET means multiple interior samples are displaced from the target by more than
  the precision but remain within the configured search tolerance. This assumes the selected
  lines are intended to follow the same path; nearby parallel utilities can be flagged if
  they fall within the chosen tolerance.

Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.
