AMLAN-X SNAPPING CHECKER 3.8.8 — LICENCE-FREE BUILD
=================================================

Purpose
-------
A licence-free build of Snapping Checker. Product-key activation, machine ID,
licence dialogs and compiled licence modules have been removed. The supplied
compiled snapping engines and the plugin's existing QC workflows are retained.

Preserved workflows
-------------------
1. Line Alignment Offset (LINE_OFFSET): one source line layer against one or
   more target line layers. Creates LINE_OFFSET points and Gap connectors.
2. Check All Layers (fiber network): original compiled telecom/fiber rules.
3. Custom Check (One-to-Many): one source against multiple targets.
4. Custom Check (Many-to-Many): multiple sources against multiple targets.
5. Original two-layer and rule-set algorithms remain in the Snapping QC
   Processing provider.

Error-handling improvements
---------------------------
- Preflight checks for missing/invalid layers and unavailable providers.
- CRS validity checks before processing; line-only validation for LINE_OFFSET.
- Each source/target pair is isolated so one failed pair does not stop later pairs.
- Best-effort temporary output cleanup after failed pairs.
- Invalid selections are reported and skipped before processing starts.
- Rotating diagnostic log (2 MB per file, three backups) at:
  ~/.qgis/snapping_checker/snapping_checker.log
- Completed output layers are retained if the user cancels later processing.
- Source layers are not edited by the custom workflows.

Important compatibility limitation
----------------------------------
The original snapping engine is supplied as compiled Python bytecode for Python
3.9, 3.10, 3.11, 3.12 and 3.13. The licence-free wrapper does not change that
binary compatibility requirement. QGIS builds using another Python minor
version require a matching original snap_core build. QGIS 3/4 and Qt5/Qt6
compatibility is declared by the wrapper, but cannot be guaranteed for every
future QGIS/Python combination without runtime testing.

Crash-resistance note
---------------------
The plugin catches and isolates Python-level processing errors. No Python
plugin can guarantee prevention of native QGIS/GEOS/provider segmentation
faults. Use a project backup and test on a copy of production data first.

Installation
------------
1. QGIS > Plugins > Manage and Install Plugins > Install from ZIP.
2. Select snapping_checker_3.8.8.zip.
3. Restart QGIS if an older Snapping Checker is already loaded.

Copyright
---------
Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.
