# Snapping Checker 3.8.8

QGIS plugin repository package for **Snapping Checker**.

## Install in QGIS
1. Download the ZIP from the repository's Releases page (or use the plugin ZIP).
2. In QGIS, open **Plugins → Manage and Install Plugins → Install from ZIP**.
3. Select the ZIP. The archive must contain the `snapping_checker/` folder at its top level.

## GitHub repository layout
Keep the `snapping_checker/` directory at the repository root. Do not upload an extra enclosing directory around it. The folder contains `metadata.txt`, `__init__.py`, the plugin implementation, icons, and the original compiled snapping engines.

## Compatibility — important
This release includes original compiled Python bytecode engines for **Python 3.9, 3.10, 3.11, 3.12 and 3.13** only. QGIS compatibility therefore depends on the Python version bundled with that QGIS build, not just its QGIS major version. QGIS builds using Python 3.14+ (or below 3.9) do not have a matching engine in this archive and cannot run the original snapping algorithms.

The wrapper declares QGIS 3.28+ and QGIS 4.x metadata compatibility, but this is not a guarantee that every QGIS/Qt/Python combination works. Full cross-version support requires the original snapping engine source and a rebuild/test for each supported Python ABI. The compiled engine files are preserved unchanged.

## Licence and source
The supplied plugin code and compiled engine files are preserved. No licence activation component is included in this release. See `COPYRIGHT.txt`.

## Diagnostics
Runtime logs are written to:
`~/.qgis/snapping_checker/snapping_checker.log`

Python-level failures are logged and reported. This cannot prevent native QGIS, GEOS, or provider-level crashes.

Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.
