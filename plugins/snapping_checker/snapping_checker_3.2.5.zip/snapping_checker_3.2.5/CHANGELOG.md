# Changelog

## 3.2.5 — Dedicated Line Alignment Offset toolbar tool

- Replaced the first toolbar/menu action, **Check Snapping (two layers)**, with **Line Alignment Offset (`LINE_OFFSET`)**.
- The first action opens a focused One-to-Many dialog with one source line layer and one or more target line layers.
- The dedicated dialog exposes offset distance, precision, and selected-feature filters; unrelated snapping controls are hidden.
- Dedicated runs create only `LINE_OFFSET` point findings and matching Gap connectors.
- The original two-layer Processing algorithm remains registered in the **Snapping QC** provider; other toolbar workflows remain available.

## 3.2.4 — Line Alignment Offset option and connector symbology

- Renamed the custom detection option to **Line Alignment Offset (`LINE_OFFSET`)**.
- Kept the option available in custom One-to-Many and Many-to-Many workflows.
- Updated Gap connector styling to a red line with endpoint markers where supported by the QGIS symbology API.
- Preserved the existing offset sampling logic and supplied compiled snapping/licence engines.

## 3.2.3 — QGIS 4 compatibility metadata and in-app release notes

- Added changelog entries to Plugin Manager details.
- Declared QGIS 3.28–4.99 compatibility in plugin metadata.
- Retained Qt5/Qt6 and scoped/legacy geometry-enum handling.
- Preserved the supplied compiled snapping and licence engines.

## 3.2.2 — Geometry enum compatibility

- Added QGIS 3/QGIS 4 geometry enum compatibility handling.
- Preserved the supplied compiled snapping and licence engines.

## 3.2.1 — Focused line QC and clean results

- Added interior line-path alignment sampling between stored vertices.
- Added `LINE_OFFSET` findings with nearest-point gap connectors.
- Suppressed empty outputs and successful `SNAPPED` records.

## 3.2.0 — Custom layer workflows

- Added custom One-to-Many and Many-to-Many workflows.
- Added multi-layer selection, progress, cancellation, and per-pair error reporting.
- Preserved the original snapping algorithms and licence system.

---

Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.
