# Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere
"""Snapping Checker plugin wrapper and custom multi-layer runner.

The first toolbar action runs dedicated LINE_OFFSET detection. The original
compiled two-layer and all-layer snapping algorithms remain available, and
custom One-to-Many / Many-to-Many workflows continue to use the original
single-pair algorithm. Source layers are never edited.
"""

import importlib
import math
import os
import sys
from datetime import datetime

from qgis.core import (
    QgsApplication,
    QgsProcessingProvider,
    QgsProcessing,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProcessingUtils,
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
    Qgis,
    QgsGeometry,
    QgsFeature,
    QgsField,
    QgsSpatialIndex,
    QgsCoordinateTransform,
    QgsRectangle,
    QgsPointXY,
    QgsMarkerSymbol,
    QgsMarkerLineSymbolLayer,
    QgsLineSymbol,
    QgsSingleSymbolRenderer,
)
from qgis.PyQt.QtGui import QIcon, QGuiApplication
from qgis.PyQt.QtCore import Qt
try:
    from qgis.PyQt.QtCore import QVariant
except ImportError:  # Qt6/QGIS 4 uses QMetaType field type IDs.
    QVariant = None
from qgis.PyQt.QtWidgets import (
    QApplication,
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QMessageBox,
    QFileDialog,
    QRadioButton,
    QComboBox,
    QListWidget,
    QListWidgetItem,
    QStackedWidget,
    QDoubleSpinBox,
    QCheckBox,
    QProgressDialog,
)

from .compat import QAction, dialog_exec, geometry_type_value

PLUGIN_NAME = 'Snapping Checker'
PLUGIN_VERSION = '3.2.5'
COPYRIGHT = 'Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere'
# GeometryType moved to scoped Qgis.GeometryType values in newer QGIS releases.
# Resolve once at import time so the custom wrapper works on both legacy QGIS 3
# and scoped-enum QGIS 3.30+/QGIS 4 builds.
GEOMETRY_POINT = geometry_type_value(Qgis, QgsWkbTypes, 'Point', 'PointGeometry')
GEOMETRY_LINE = geometry_type_value(Qgis, QgsWkbTypes, 'Line', 'LineGeometry')
GEOMETRY_POLYGON = geometry_type_value(Qgis, QgsWkbTypes, 'Polygon', 'PolygonGeometry')
PLUGIN_DIR = os.path.dirname(__file__)
ICON_LINE_ALIGNMENT = os.path.join(PLUGIN_DIR, 'icon_line_alignment.svg')
ICON_ALL = os.path.join(PLUGIN_DIR, 'icon_all.svg')
ICON_ONE_TO_MANY = os.path.join(PLUGIN_DIR, 'icon_one_to_many.svg')
ICON_MANY_TO_MANY = os.path.join(PLUGIN_DIR, 'icon_many_to_many.svg')


def _load_matching_module(stem):
    """Load the original module compiled for the running Python minor version."""
    tag = 'py%d%d' % sys.version_info[:2]
    module_name = '%s.%s_%s' % (__package__, stem, tag)
    try:
        importlib.invalidate_caches()
        return importlib.import_module(module_name), None
    except Exception as exc:
        return None, exc


def _enum_value(flat_name, scoped_name, fallback):
    """Read Qt5 or Qt6 enum values without assuming one enum layout."""
    value = getattr(Qt, flat_name, None)
    if value is not None:
        return value
    scope = getattr(Qt, scoped_name[0], None)
    if scope is not None:
        value = getattr(scope, scoped_name[1], None)
        if value is not None:
            return value
    return fallback


def _message_button(name, fallback):
    """Read QMessageBox standard buttons across Qt5 and Qt6."""
    value = getattr(QMessageBox, name, None)
    if value is not None:
        return value
    scope = getattr(QMessageBox, 'StandardButton', None)
    return getattr(scope, name, fallback) if scope is not None else fallback


def _dialog_accepted():
    """Return the accepted dialog code across Qt5 and Qt6."""
    value = getattr(QDialog, 'Accepted', None)
    if value is not None:
        return value
    scope = getattr(QDialog, 'DialogCode', None)
    return getattr(scope, 'Accepted', 1) if scope is not None else 1


QT_ITEM_USER_CHECKABLE = _enum_value(
    'ItemIsUserCheckable', ('ItemFlag', 'ItemIsUserCheckable'), 16
)
QT_CHECKED = _enum_value('Checked', ('CheckState', 'Checked'), 2)
QT_UNCHECKED = _enum_value('Unchecked', ('CheckState', 'Unchecked'), 0)
QT_USER_ROLE = _enum_value('UserRole', ('ItemDataRole', 'UserRole'), 32)


class LicenseDialog(QDialog):
    """Small license dialog using the original license verifier."""

    def __init__(self, license_module, parent=None):
        super().__init__(parent)
        self.license_module = license_module
        self.setWindowTitle('Snapping Checker — License | Copyright Amlan Patnaik')
        self.resize(500, 300)
        layout = QVBoxLayout(self)

        status = self.license_module.status()
        state = status.get('state', 'unknown')
        heading = {
            'active': 'License active.',
            'expired': 'License expired.',
            'none': 'No product key entered yet.',
            'tampered': 'License validation problem.',
            'wrong_machine': 'License belongs to a different computer.',
        }.get(state, 'License status: ' + str(state))
        status_label = QLabel('<b>%s</b><br>%s' % (heading, status.get('message', '')))
        status_label.setWordWrap(True)
        layout.addWidget(status_label)

        machine_id = self.license_module.machine_id_display()
        machine_row = QHBoxLayout()
        machine_label = QLabel('Machine ID: <b>%s</b>' % machine_id)
        selectable_flag = _enum_value(
            'TextSelectableByMouse', ('TextInteractionFlag', 'TextSelectableByMouse'), 1
        )
        machine_label.setTextInteractionFlags(machine_label.textInteractionFlags() | selectable_flag)
        machine_row.addWidget(machine_label)
        copy_button = QPushButton('Copy ID')
        copy_button.clicked.connect(lambda: QGuiApplication.clipboard().setText(machine_id))
        machine_row.addWidget(copy_button)
        layout.addLayout(machine_row)

        hint = QLabel('Paste your product key or load an existing .lic file.')
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.key_box = QPlainTextEdit()
        self.key_box.setPlaceholderText('Paste product key…')
        self.key_box.setMaximumHeight(90)
        layout.addWidget(self.key_box)

        buttons = QHBoxLayout()
        load_button = QPushButton('Load .lic file…')
        load_button.clicked.connect(self._load_file)
        buttons.addWidget(load_button)
        buttons.addStretch(1)
        activate_button = QPushButton('Activate')
        activate_button.clicked.connect(self._activate)
        buttons.addWidget(activate_button)
        close_button = QPushButton('Close')
        close_button.clicked.connect(self.reject)
        buttons.addWidget(close_button)
        layout.addLayout(buttons)

        copyright_label = QLabel(COPYRIGHT)
        copyright_label.setWordWrap(True)
        layout.addWidget(copyright_label)

    def _load_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, 'Choose license file | Copyright Amlan Patnaik', '',
            'License files (*.lic *.txt);;All files (*)'
        )
        if not path:
            return
        try:
            with open(path, 'r', encoding='utf-8') as handle:
                self.key_box.setPlainText(handle.read())
        except Exception as exc:
            QMessageBox.warning(
                self, 'Snapping Checker — License',
                'Could not read the file:\n%s\n\n%s' % (exc, COPYRIGHT)
            )

    def _activate(self):
        key_text = self.key_box.toPlainText().strip()
        if not key_text:
            QMessageBox.information(
                self, 'Snapping Checker — License',
                'Enter a product key first.\n\n' + COPYRIGHT
            )
            return
        try:
            status = self.license_module.activate(key_text)
        except Exception as exc:
            QMessageBox.critical(
                self, 'Snapping Checker — License',
                'Activation failed:\n%s\n\n%s' % (exc, COPYRIGHT)
            )
            return
        if status.get('state') == 'active':
            QMessageBox.information(
                self, 'Snapping Checker — License',
                'Activation successful.\n%s\n\n%s' %
                (status.get('message', ''), COPYRIGHT)
            )
            self.accept()
        else:
            QMessageBox.warning(
                self, 'Snapping Checker — License',
                status.get('message', 'Activation did not complete.') + '\n\n' + COPYRIGHT
            )


class CustomLayerDialog(QDialog):
    """Layer picker for one-to-many and many-to-many checks."""

    def __init__(self, parent=None, initial_mode='one_to_many', alignment_only=False):
        super().__init__(parent)
        self.alignment_only = bool(alignment_only)
        if self.alignment_only:
            self.setWindowTitle('Line Alignment Offset (LINE_OFFSET) | Copyright Amlan Patnaik')
            self.setMinimumSize(700, 590)
        else:
            self.setWindowTitle('Snapping Checker — Custom Layers | Copyright Amlan Patnaik')
            self.setMinimumSize(760, 690)
        self.setSizeGripEnabled(True)
        self.project = QgsProject.instance()
        self._layers = self._project_vector_layers()
        if self.alignment_only:
            self._layers = [layer for layer in self._layers
                            if layer.geometryType() == GEOMETRY_LINE]

        root = QVBoxLayout(self)
        heading = ('Line Alignment Offset (LINE_OFFSET)' if self.alignment_only
                   else 'Custom snapping check')
        title = QLabel('<b>%s</b>' % heading)
        root.addWidget(title)
        if self.alignment_only:
            intro_text = (
                'Find line features whose paths are separated along their length. '
                'Choose one source layer and one or more target layers. '
                'Only LINE_OFFSET findings and their Gap connectors will be created.'
            )
        else:
            intro_text = (
                'Choose how the original snapping checker should compare your layers. '
                'The source layers are never edited.'
            )
        intro = QLabel(intro_text)
        intro.setWordWrap(True)
        root.addWidget(intro)

        mode_box = QGroupBox('Check relationship')
        self.mode_box = mode_box
        mode_layout = QHBoxLayout(mode_box)
        self.one_radio = QRadioButton('One-to-Many  —  one source → multiple targets')
        self.many_radio = QRadioButton('Many-to-Many  —  multiple sources → multiple targets')
        self.many_radio.setVisible(not self.alignment_only)
        mode_layout.addWidget(self.one_radio)
        mode_layout.addWidget(self.many_radio)
        root.addWidget(mode_box)
        if self.alignment_only:
            self.mode_box.hide()

        self.pages = QStackedWidget()
        root.addWidget(self.pages, 1)
        self.one_page = self._build_one_to_many_page()
        self.many_page = self._build_many_to_many_page()
        self.pages.addWidget(self.one_page)
        self.pages.addWidget(self.many_page)
        self.one_radio.toggled.connect(self._mode_changed)
        self.many_radio.toggled.connect(self._mode_changed)

        options_box = QGroupBox(
            'Line offset parameters' if self.alignment_only else 'Detection settings'
        )
        options_grid = QGridLayout(options_box)
        self.vertex_mode = QComboBox()
        self.vertex_mode.addItems(['Line endpoints only (start / end)', 'All vertices'])
        self.snap_to = QComboBox()
        self.snap_to.addItems(['Anywhere on target (vertex or edge)', 'Target vertex only'])
        self.vertex_label = QLabel('Source vertices:')
        self.snap_to_label = QLabel('Snap must be to:')
        options_grid.addWidget(self.vertex_label, 0, 0)
        options_grid.addWidget(self.vertex_mode, 0, 1)
        options_grid.addWidget(self.snap_to_label, 0, 2)
        options_grid.addWidget(self.snap_to, 0, 3)

        self.tolerance = self._spin(0.5, 0.0, 1000000000.0, 6)
        self.precision = self._spin(0.000001, 0.0, 1.0, 9)
        self.max_overshoot = self._spin(10.0, 0.0, 1000000000.0, 6)
        self.tolerance_label = QLabel(
            'Maximum offset distance:' if self.alignment_only else 'Search tolerance:'
        )
        self.precision_label = QLabel(
            'Minimum offset precision:' if self.alignment_only else 'Precision:'
        )
        self.max_overshoot_label = QLabel('Maximum overshoot:')
        options_grid.addWidget(self.tolerance_label, 1, 0)
        options_grid.addWidget(self.tolerance, 1, 1)
        options_grid.addWidget(self.precision_label, 1, 2)
        options_grid.addWidget(self.precision, 1, 3)
        options_grid.addWidget(self.max_overshoot_label, 2, 0)
        options_grid.addWidget(self.max_overshoot, 2, 1)

        self.source_selected = QCheckBox('Source: selected features only')
        self.target_selected = QCheckBox('Target: selected features only')
        self.check_self = QCheckBox('Check line ends against their own feature (loops)')
        self.check_self.setChecked(True)
        self.check_crossings = QCheckBox('Check crossings and overlaps')
        self.check_crossings.setChecked(True)
        self.report_not_connected = QCheckBox('Report vertices with nothing within tolerance')
        self.check_line_alignment = QCheckBox(
            'Line Alignment Offset (LINE_OFFSET)'
        )
        self.check_line_alignment.setChecked(True)
        self.check_line_alignment.setToolTip(
            'Detect line-to-line path separation between existing vertices. '
            'When enabled, One-to-Many and Many-to-Many checks can report '
            'LINE_OFFSET findings and add a matching gap connector.'
        )
        options_grid.addWidget(self.source_selected, 3, 0, 1, 2)
        options_grid.addWidget(self.target_selected, 3, 2, 1, 2)
        options_grid.addWidget(self.check_self, 4, 0, 1, 2)
        options_grid.addWidget(self.check_crossings, 4, 2, 1, 2)
        options_grid.addWidget(self.check_line_alignment, 5, 0, 1, 4)
        options_grid.addWidget(self.report_not_connected, 6, 0, 1, 4)
        root.addWidget(options_box)

        if self.alignment_only:
            # The dedicated toolbar entry is deliberately focused: expose only
            # settings that affect LINE_OFFSET, not the general snapping rules.
            for widget in (
                self.vertex_label, self.vertex_mode, self.snap_to_label, self.snap_to,
                self.max_overshoot_label, self.max_overshoot, self.check_self,
                self.check_crossings, self.check_line_alignment, self.report_not_connected,
            ):
                widget.hide()
            note_text = (
                'This tool checks line-to-line pairs only. It samples the source path '
                'between stored vertices and reports the maximum detected separation. '
                'The connector is created in the source layer CRS and uses the Gap connectors style. '
                'Maximum offset distance and precision use source CRS map units. '
                'Source layers are never edited.\n' + COPYRIGHT
            )
        else:
            note_text = (
                'Tolerance and overshoot use the source layer CRS map units. '
                'Targets in another CRS are transformed by the original algorithm. '
                'For a geographic CRS, map units are degrees. Correctly snapped features are never shown as errors. '
                'Line Alignment Offset (LINE_OFFSET) checks line-to-line pairs only. '
                'It samples the full line between existing vertices and creates a gap connector '
                'at the maximum detected separation.\n' + COPYRIGHT
            )
        note = QLabel(note_text)
        note.setWordWrap(True)
        root.addWidget(note)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        self.run_button = QPushButton(
            'Run Line Alignment Offset' if self.alignment_only else 'Run snapping checks'
        )
        self.run_button.clicked.connect(self._validate_and_accept)
        cancel_button = QPushButton('Cancel')
        cancel_button.clicked.connect(self.reject)
        buttons.addWidget(self.run_button)
        buttons.addWidget(cancel_button)
        root.addLayout(buttons)

        self.one_radio.setChecked(initial_mode != 'many_to_many')
        self.many_radio.setChecked(initial_mode == 'many_to_many')
        self._mode_changed(self.one_radio.isChecked())

    @staticmethod
    def _spin(value, minimum, maximum, decimals):
        spin = QDoubleSpinBox()
        spin.setDecimals(decimals)
        spin.setRange(minimum, maximum)
        spin.setValue(value)
        spin.setKeyboardTracking(False)
        return spin

    def _project_vector_layers(self):
        layers = []
        try:
            for layer in self.project.mapLayers().values():
                if isinstance(layer, QgsVectorLayer) and layer.isValid():
                    layers.append(layer)
        except Exception:
            return []
        layers.sort(key=lambda item: item.name().lower())
        return layers

    def _new_check_list(self, layers):
        widget = QListWidget()
        for layer in layers:
            item = QListWidgetItem(layer.name())
            item.setData(QT_USER_ROLE, layer.id())
            item.setToolTip(
                'Layer: %s\nProvider: %s\nCRS: %s\nID: %s' %
                (layer.name(), layer.providerType(), layer.crs().authid(), layer.id())
            )
            item.setFlags(item.flags() | QT_ITEM_USER_CHECKABLE)
            item.setCheckState(QT_UNCHECKED)
            widget.addItem(item)
        return widget

    def _add_list_shortcuts(self, layout, widget):
        row = QHBoxLayout()
        select_all = QPushButton('Select all')
        clear = QPushButton('Clear')
        select_all.clicked.connect(lambda: self._set_all_checked(widget, True))
        clear.clicked.connect(lambda: self._set_all_checked(widget, False))
        row.addWidget(select_all)
        row.addWidget(clear)
        row.addStretch(1)
        layout.addLayout(row)

    @staticmethod
    def _set_all_checked(widget, checked):
        state = QT_CHECKED if checked else QT_UNCHECKED
        for index in range(widget.count()):
            widget.item(index).setCheckState(state)

    def _build_one_to_many_page(self):
        page = QGroupBox('One source checked against many targets')
        layout = QGridLayout(page)
        self.one_source = QComboBox()
        for layer in self._layers:
            self.one_source.addItem(layer.name(), layer.id())
        self.one_targets = self._new_check_list(self._layers)
        layout.addWidget(QLabel('Single source layer:'), 0, 0)
        layout.addWidget(self.one_source, 1, 0)
        target_box = QGroupBox('Target layers (select one or more)')
        target_layout = QVBoxLayout(target_box)
        target_layout.addWidget(self.one_targets)
        self._add_list_shortcuts(target_layout, self.one_targets)
        layout.addWidget(target_box, 0, 1, 3, 1)
        layout.setColumnStretch(1, 2)
        return page

    def _build_many_to_many_page(self):
        page = QGroupBox('Every selected source checked against every selected target')
        layout = QHBoxLayout(page)
        source_box = QGroupBox('Source layers (select one or more)')
        source_layout = QVBoxLayout(source_box)
        self.many_sources = self._new_check_list(self._layers)
        source_layout.addWidget(self.many_sources)
        self._add_list_shortcuts(source_layout, self.many_sources)

        target_box = QGroupBox('Target layers (select one or more)')
        target_layout = QVBoxLayout(target_box)
        self.many_targets = self._new_check_list(self._layers)
        target_layout.addWidget(self.many_targets)
        self._add_list_shortcuts(target_layout, self.many_targets)
        layout.addWidget(source_box, 1)
        layout.addWidget(target_box, 1)
        return page

    def _mode_changed(self, checked):
        if self.one_radio.isChecked():
            self.pages.setCurrentIndex(0)
        elif self.many_radio.isChecked():
            self.pages.setCurrentIndex(1)

    def _checked_layers(self, widget):
        chosen = []
        for index in range(widget.count()):
            item = widget.item(index)
            if item.checkState() == QT_CHECKED:
                layer = self.project.mapLayer(str(item.data(QT_USER_ROLE)))
                if isinstance(layer, QgsVectorLayer) and layer.isValid():
                    chosen.append(layer)
        return chosen

    def _selected_layers_for_run(self):
        if self.alignment_only or self.one_radio.isChecked():
            source_id = self.one_source.currentData()
            source = self.project.mapLayer(str(source_id)) if source_id else None
            return ([source] if isinstance(source, QgsVectorLayer) and source.isValid() else [],
                    self._checked_layers(self.one_targets), 'one_to_many')
        return (self._checked_layers(self.many_sources),
                self._checked_layers(self.many_targets), 'many_to_many')

    def _validate_and_accept(self):
        sources, targets, mode = self._selected_layers_for_run()
        if not sources or not targets:
            QMessageBox.warning(
                self, ('Line Alignment Offset — Layer selection' if self.alignment_only
                       else 'Snapping Checker — Layer selection'),
                'Select one valid source layer and at least one valid target layer.\n\n' + COPYRIGHT
            )
            return
        if self.alignment_only:
            non_line_sources = [layer.name() for layer in sources
                                if layer.geometryType() != GEOMETRY_LINE]
            non_line_targets = [layer.name() for layer in targets
                                if layer.geometryType() != GEOMETRY_LINE]
            if non_line_sources or non_line_targets:
                bad = non_line_sources + non_line_targets
                QMessageBox.warning(
                    self, 'Line Alignment Offset — Line layers required',
                    'LINE_OFFSET works only with line geometry. Remove these non-line layers:\n\n'
                    + '\n'.join(bad) + '\n\n' + COPYRIGHT
                )
                return
        if self.tolerance.value() <= self.precision.value():
            QMessageBox.warning(
                self, ('Line Alignment Offset — Detection settings' if self.alignment_only
                       else 'Snapping Checker — Detection settings'),
                'Maximum offset distance must be greater than minimum offset precision.\n\n' + COPYRIGHT
            )
            return
        if self.source_selected.isChecked():
            empty = [layer.name() for layer in sources if layer.selectedFeatureCount() < 1]
            if empty:
                QMessageBox.warning(
                    self, ('Line Alignment Offset — Source selection' if self.alignment_only
                           else 'Snapping Checker — Source selection'),
                    'Selected-features-only is enabled, but these source layers have no selected features:\n\n'
                    + '\n'.join(empty) + '\n\n' + COPYRIGHT
                )
                return
        if self.target_selected.isChecked():
            empty = [layer.name() for layer in targets if layer.selectedFeatureCount() < 1]
            if empty:
                QMessageBox.warning(
                    self, ('Line Alignment Offset — Target selection' if self.alignment_only
                           else 'Snapping Checker — Target selection'),
                    'Selected-features-only is enabled, but these target layers have no selected features:\n\n'
                    + '\n'.join(empty) + '\n\n' + COPYRIGHT
                )
                return
        pair_count = len(sources) * len(targets)
        if pair_count > 1:
            self.run_button.setText(
                'Run %d Line Alignment checks' % pair_count if self.alignment_only
                else 'Run %d checks' % pair_count
            )
        self.accept()

    def run_spec(self):
        sources, targets, mode = self._selected_layers_for_run()
        return {
            'sources': sources,
            'targets': targets,
            'mode': mode,
            'alignment_only': self.alignment_only,
            'source_selected': self.source_selected.isChecked(),
            'target_selected': self.target_selected.isChecked(),
            'vertex_mode': self.vertex_mode.currentIndex(),
            'snap_to': self.snap_to.currentIndex(),
            'tolerance': self.tolerance.value(),
            'precision': self.precision.value(),
            'max_overshoot': self.max_overshoot.value(),
            'check_self': self.check_self.isChecked(),
            'check_crossings': self.check_crossings.isChecked(),
            'report_not_connected': self.report_not_connected.isChecked(),
            'include_snapped': False,
            'check_line_alignment': self.check_line_alignment.isChecked(),
        }


class _DialogFeedback(QgsProcessingFeedback):
    """Feed Processing progress to the custom multi-pair progress dialog."""

    def __init__(self, progress_dialog, pair_index, pair_count):
        super().__init__()
        self.progress_dialog = progress_dialog
        self.pair_index = pair_index
        self.pair_count = max(1, pair_count)

    def setProgress(self, progress):
        try:
            value = self.pair_index * 100 + int(max(0.0, min(100.0, float(progress))))
            self.progress_dialog.setValue(value)
            QApplication.processEvents()
        except Exception:
            pass
        try:
            super().setProgress(progress)
        except Exception:
            pass

    def isCanceled(self):
        try:
            if self.progress_dialog.wasCanceled():
                return True
        except Exception:
            pass
        try:
            return super().isCanceled()
        except Exception:
            return False


class SnappingCheckerPlugin:
    """Register original Processing algorithms and custom layer modes."""

    def __init__(self, iface):
        self.iface = iface
        self.actions = []
        self.toolbar_actions = []
        self.provider = None
        self.core_module, self.core_error = _load_matching_module('snap_core')
        self.license_module, self.license_error = _load_matching_module('license')

    def _show_message(self, title, message, level='warning'):
        box = getattr(QMessageBox, level, QMessageBox.warning)
        box(self.iface.mainWindow(), title, message + '\n\n' + COPYRIGHT)

    def initGui(self):
        if self.core_module is not None and self.license_module is not None:
            try:
                self.provider = self._create_provider()
                registry = QgsApplication.processingRegistry()
                existing = registry.providerById('snappingqc')
                if existing is not None:
                    registry.removeProvider(existing)
                if not registry.addProvider(self.provider):
                    raise RuntimeError('QGIS could not register the Snapping QC Processing provider.')

                self._add_custom_action(
                    'Line Alignment Offset (LINE_OFFSET)', ICON_LINE_ALIGNMENT,
                    'one_to_many', alignment_only=True
                )
                self._add_algorithm_action(
                    'Check All Layers (fiber network)', 'checkallfiber', ICON_ALL
                )
                self._add_custom_action(
                    'Custom Check (One-to-Many)', ICON_ONE_TO_MANY, 'one_to_many'
                )
                self._add_custom_action(
                    'Custom Check (Many-to-Many)', ICON_MANY_TO_MANY, 'many_to_many'
                )
            except Exception as exc:
                if self.provider is not None:
                    try:
                        QgsApplication.processingRegistry().removeProvider(self.provider)
                    except Exception:
                        pass
                self.provider = None
                self._show_message(
                    'Snapping Checker — Initialization',
                    'Could not register the original snapping algorithms:\n%s' % exc,
                    'critical'
                )
        else:
            py_version = '%d.%d' % sys.version_info[:2]
            self._show_message(
                'Snapping Checker — Compatibility',
                'No original core/license build is available for Python %s. '
                'The supplied original builds cover Python 3.9 through 3.13. '
                'The snapping algorithms have not been rewritten or replaced.' % py_version
            )

        license_action = QAction('Enter / Update License…', self.iface.mainWindow())
        license_action.triggered.connect(self.show_license)
        self.iface.addPluginToVectorMenu(PLUGIN_NAME, license_action)
        self.actions.append(license_action)

        about_action = QAction('About / Copyright…', self.iface.mainWindow())
        about_action.triggered.connect(self.show_about)
        self.iface.addPluginToVectorMenu(PLUGIN_NAME, about_action)
        self.actions.append(about_action)

        if self.license_module is not None:
            try:
                if self.license_module.status().get('state') != 'active':
                    self.show_license()
            except Exception:
                pass

    def _create_provider(self):
        core = self.core_module

        class CopyrightSnappingAlgorithm(core.SnappingCheckerAlgorithm):
            def createInstance(self):
                return CopyrightSnappingAlgorithm()

            def shortHelpString(self):
                help_text = super().shortHelpString()
                return help_text if COPYRIGHT in help_text else help_text + '\n\n' + COPYRIGHT

        class CopyrightRuleSetAlgorithm(core.SnappingRuleSetAlgorithm):
            def createInstance(self):
                return CopyrightRuleSetAlgorithm()

            def shortHelpString(self):
                help_text = super().shortHelpString()
                return help_text if COPYRIGHT in help_text else help_text + '\n\n' + COPYRIGHT

        class SnappingProvider(QgsProcessingProvider):
            def loadAlgorithms(provider_self):
                provider_self.addAlgorithm(CopyrightSnappingAlgorithm())
                provider_self.addAlgorithm(CopyrightRuleSetAlgorithm())

            def id(provider_self):
                return 'snappingqc'

            def name(provider_self):
                return 'Snapping QC'

            def icon(provider_self):
                return QIcon(ICON_LINE_ALIGNMENT)

        return SnappingProvider()

    def _add_algorithm_action(self, label, algorithm_id, icon_path):
        action = QAction(QIcon(icon_path), label, self.iface.mainWindow())
        action.triggered.connect(
            lambda _checked=False, alg=algorithm_id: self.run_algorithm(alg)
        )
        self.iface.addPluginToVectorMenu(PLUGIN_NAME, action)
        self.iface.addToolBarIcon(action)
        self.actions.append(action)
        self.toolbar_actions.append(action)

    def _add_custom_action(self, label, icon_path, mode, alignment_only=False):
        action = QAction(QIcon(icon_path), label, self.iface.mainWindow())
        if alignment_only:
            action.setToolTip(
                'Compare one source line layer against one or more target line layers; '
                'report only Line Alignment Offset (LINE_OFFSET).'
            )
            action.setStatusTip(action.toolTip())
        action.triggered.connect(
            lambda _checked=False, selected_mode=mode, offset_only=alignment_only: 
                self.run_custom_layers(selected_mode, alignment_only=offset_only)
        )
        self.iface.addPluginToVectorMenu(PLUGIN_NAME, action)
        self.iface.addToolBarIcon(action)
        self.actions.append(action)
        self.toolbar_actions.append(action)

    def _license_ok(self):
        if self.license_module is None:
            self._show_message(
                'Snapping Checker — License',
                'The original license verifier is unavailable for this Python version.'
            )
            return False
        try:
            status = self.license_module.status()
        except Exception as exc:
            self._show_message(
                'Snapping Checker — License',
                'Could not check the license:\n%s' % exc,
                'critical'
            )
            return False
        if status.get('state') == 'active':
            return True
        self._show_message(
            'Snapping Checker — License',
            status.get('message', 'A valid product key is required.')
        )
        self.show_license()
        try:
            return self.license_module.status().get('state') == 'active'
        except Exception:
            return False

    def run_algorithm(self, algorithm_id):
        if self.provider is None:
            self._show_message(
                'Snapping Checker — Unavailable',
                'The original snapping algorithms could not be loaded for this QGIS/Python build.'
            )
            return
        if not self._license_ok():
            return
        try:
            import processing
            processing.execAlgorithmDialog('snappingqc:' + algorithm_id)
        except Exception as exc:
            self._show_message(
                'Snapping Checker — Processing',
                'Could not open the snapping algorithm:\n%s' % exc,
                'critical'
            )

    def run_custom_layers(self, initial_mode='one_to_many', alignment_only=False):
        if self.provider is None:
            self._show_message(
                'Snapping Checker — Unavailable',
                'The original snapping algorithms could not be loaded for this QGIS/Python build.'
            )
            return
        if not self._license_ok():
            return
        try:
            dialog = CustomLayerDialog(
                self.iface.mainWindow(), initial_mode, alignment_only=alignment_only
            )
            if dialog_exec(dialog) != _dialog_accepted():
                return
            self._run_custom_pairs(dialog.run_spec())
        except Exception as exc:
            self._show_message(
                'Snapping Checker — Custom layers',
                'Could not open or run the custom layer checker:\n%s' % exc,
                'critical'
            )

    @staticmethod
    def _resolve_layer(output_value, context, geometry_type):
        """Resolve a child Processing output from its result ID or temp store."""
        if isinstance(output_value, QgsVectorLayer) and output_value.isValid():
            return output_value
        if output_value is not None:
            try:
                layer = context.getMapLayer(str(output_value))
                if isinstance(layer, QgsVectorLayer) and layer.isValid():
                    return layer
            except Exception:
                pass
            try:
                layer = QgsProcessingUtils.mapLayerFromString(str(output_value), context, False)
                if isinstance(layer, QgsVectorLayer) and layer.isValid():
                    return layer
            except TypeError:
                try:
                    layer = QgsProcessingUtils.mapLayerFromString(str(output_value), context)
                    if isinstance(layer, QgsVectorLayer) and layer.isValid():
                        return layer
                except Exception:
                    pass
            except Exception:
                pass
        # Do not guess from all temporary layers: in a multi-pair run that can
        # accidentally return a previous pair's output and mislabel its errors.
        return None

    @staticmethod
    def _remove_snapped_rows(layer):
        """Remove successful SNAPPED records; only genuine problems belong in results."""
        if layer is None or not isinstance(layer, QgsVectorLayer) or not layer.isValid():
            return 0
        try:
            status_index = layer.fields().indexFromName('status')
            if status_index >= 0:
                remove_ids = []
                for feature in layer.getFeatures():
                    try:
                        if str(feature.attribute(status_index)).strip().upper() == 'SNAPPED':
                            remove_ids.append(feature.id())
                    except Exception:
                        continue
                if remove_ids:
                    layer.dataProvider().deleteFeatures(remove_ids)
                    layer.updateExtents()
            return int(layer.featureCount())
        except Exception:
            try:
                return int(layer.featureCount())
            except Exception:
                return 0

    @staticmethod
    def _discard_temporary_output(layer, context):
        """Release an output that contains no errors instead of adding an empty layer."""
        if layer is None:
            return
        try:
            context.temporaryLayerStore().removeMapLayer(layer.id())
        except Exception:
            pass

    @staticmethod
    def _variant_field_type(name):
        """Resolve QVariant field types on both Qt5 and Qt6 builds."""
        direct = getattr(QVariant, name, None) if QVariant is not None else None
        if direct is not None:
            return direct
        try:
            from qgis.PyQt.QtCore import QMetaType
            scope = getattr(QMetaType, 'Type', QMetaType)
            mapped = {'String': 'QString', 'LongLong': 'LongLong',
                      'Int': 'Int', 'Double': 'Double'}.get(name, name)
            return getattr(scope, mapped)
        except Exception as exc:
            raise RuntimeError('Qt does not expose the required field type %s: %s' %
                               (name, exc))

    @staticmethod
    def _create_alignment_output_layers(source, target):
        """Create point and connector memory layers containing only LINE_OFFSET fields."""
        point_layer = QgsVectorLayer('Point', 'Line Alignment Offset points', 'memory')
        connector_layer = QgsVectorLayer('LineString', 'Gap connectors', 'memory')
        if not point_layer.isValid() or not connector_layer.isValid():
            raise RuntimeError('Could not create temporary LINE_OFFSET output layers.')

        point_layer.setCrs(source.crs())
        connector_layer.setCrs(source.crs())
        field_specs = [
            ('rule', 'String'),
            ('status', 'String'),
            ('src_layer', 'String'),
            ('src_fid', 'LongLong'),
            ('vtx_role', 'String'),
            ('vtx_index', 'Int'),
            ('tgt_layer', 'String'),
            ('tgt_fid', 'LongLong'),
            ('distance', 'Double'),
            ('near_x', 'Double'),
            ('near_y', 'Double'),
            ('note', 'String'),
        ]
        fields = [QgsField(name, SnappingCheckerPlugin._variant_field_type(kind))
                  for name, kind in field_specs]
        for layer in (point_layer, connector_layer):
            provider = layer.dataProvider()
            result = provider.addAttributes(fields)
            if result is False:
                raise RuntimeError('Could not create LINE_OFFSET output fields.')
            layer.updateFields()
        return point_layer, connector_layer

    def _append_line_alignment_errors(self, source, target, spec, error_layer,
                                      connector_layer, context):
        """Find consistent line-to-line path offsets between stored vertices.

        A single LINE_OFFSET point/connector is created for each source feature and
        target feature pair where multiple interior samples are displaced by more
        than precision but remain within the configured search tolerance.
        """
        if not spec.get('check_line_alignment', True):
            return 0
        if (source.geometryType() != GEOMETRY_LINE or
                target.geometryType() != GEOMETRY_LINE):
            return 0
        if error_layer is None or not error_layer.isValid():
            return 0

        tolerance = float(spec['tolerance'])
        precision = float(spec['precision'])
        if tolerance <= precision:
            return 0

        fields = error_layer.fields()
        names = {field.name(): fields.indexFromName(field.name()) for field in fields}
        required = ('rule', 'status', 'src_layer', 'src_fid', 'vtx_role',
                    'vtx_index', 'tgt_layer', 'tgt_fid', 'distance',
                    'near_x', 'near_y', 'note')
        if any(names.get(name, -1) < 0 for name in required):
            return 0

        project = QgsProject.instance()
        transform = None
        if target.crs() != source.crs():
            transform = QgsCoordinateTransform(target.crs(), source.crs(), project)

        target_index = QgsSpatialIndex()
        target_geometries = {}
        target_iter = (target.getSelectedFeatures() if spec.get('target_selected')
                       else target.getFeatures())
        for target_feature in target_iter:
            target_geom = QgsGeometry(target_feature.geometry())
            if target_geom.isNull() or target_geom.isEmpty():
                continue
            if transform is not None:
                try:
                    target_geom.transform(transform)
                except Exception:
                    continue
            target_geometries[target_feature.id()] = target_geom
            index_feature = QgsFeature(target_feature)
            index_feature.setGeometry(target_geom)
            target_index.addFeature(index_feature)

        if not target_geometries:
            return 0

        source_iter = (source.getSelectedFeatures() if spec.get('source_selected')
                       else source.getFeatures())
        error_provider = error_layer.dataProvider()
        connector_provider = (connector_layer.dataProvider()
                              if connector_layer is not None and connector_layer.isValid()
                              else None)
        added = 0

        for source_feature in source_iter:
            source_geom = QgsGeometry(source_feature.geometry())
            if source_geom.isNull() or source_geom.isEmpty():
                continue
            length = float(source_geom.length())
            if length <= precision:
                continue

            # At most 80 intervals per feature. This checks the actual path between
            # vertices without creating thousands of sample points on long cables.
            interval_size = max(tolerance * 2.0, length / 80.0)
            intervals = max(6, min(80, int(math.ceil(length / interval_size))))
            bounds = QgsRectangle(source_geom.boundingBox())
            bounds.grow(tolerance)
            candidate_ids = target_index.intersects(bounds)
            if not candidate_ids:
                continue

            max_record = None
            displaced_samples = 0
            eligible_samples = max(2, int(math.ceil((intervals - 1) * 0.20)))

            for sample_index in range(1, intervals):
                distance_along = length * float(sample_index) / float(intervals)
                sample_geom = source_geom.interpolate(distance_along)
                if sample_geom is None or sample_geom.isEmpty():
                    continue
                sample_point = sample_geom.asPoint()
                sample_point_geom = QgsGeometry.fromPointXY(QgsPointXY(sample_point))

                best_distance = None
                best_near = None
                best_target_id = None
                for target_id in candidate_ids:
                    target_geom = target_geometries.get(target_id)
                    if target_geom is None:
                        continue
                    current_distance = float(target_geom.distance(sample_point_geom))
                    if best_distance is None or current_distance < best_distance:
                        nearest_geom = target_geom.nearestPoint(sample_point_geom)
                        if nearest_geom is None or nearest_geom.isEmpty():
                            continue
                        best_distance = current_distance
                        best_near = nearest_geom.asPoint()
                        best_target_id = target_id

                if (best_distance is None or best_near is None or
                        best_distance <= precision or best_distance > tolerance):
                    continue

                displaced_samples += 1
                if max_record is None or best_distance > max_record[0]:
                    max_record = (best_distance, sample_point, best_near, best_target_id)

            if max_record is None or displaced_samples < eligible_samples:
                continue

            max_distance, sample_point, near_point, target_id = max_record
            note = ('Line path is offset from target; maximum sampled separation is '
                    '%.6f map units. Review the segment alignment.' % max_distance)
            attrs = [None] * len(fields)
            values = {
                'rule': 'LINE_ALIGNMENT',
                'status': 'LINE_OFFSET',
                'src_layer': source.name(),
                'src_fid': source_feature.id(),
                'vtx_role': 'SEGMENT',
                'vtx_index': -1,
                'tgt_layer': target.name(),
                'tgt_fid': target_id,
                'distance': round(max_distance, 6),
                'near_x': near_point.x(),
                'near_y': near_point.y(),
                'note': note,
            }
            for field_name, value in values.items():
                attrs[names[field_name]] = value

            error_feature = QgsFeature(fields)
            error_feature.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(sample_point)))
            error_feature.setAttributes(attrs)
            add_result = error_provider.addFeatures([error_feature])
            success = add_result[0] if isinstance(add_result, tuple) else bool(add_result)
            if not success:
                continue

            if connector_provider is not None:
                connector_feature = QgsFeature(connector_layer.fields())
                connector_feature.setGeometry(
                    QgsGeometry.fromPolylineXY([
                        QgsPointXY(sample_point), QgsPointXY(near_point)
                    ])
                )
                connector_feature.setAttributes(attrs)
                try:
                    connector_provider.addFeatures([connector_feature])
                except Exception:
                    pass
            added += 1

        if added:
            error_layer.updateExtents()
            error_layer.triggerRepaint()
            if connector_layer is not None:
                connector_layer.updateExtents()
                connector_layer.triggerRepaint()
        return added

    @staticmethod
    def _style_custom_output(layer, geometry_type):
        """Apply familiar, high-contrast QC styling to returned output layers."""
        try:
            if geometry_type == GEOMETRY_POINT:
                symbol = QgsMarkerSymbol.createSimple({
                    'name': 'circle', 'color': '255,45,65,220', 'size': '3.5',
                    'outline_color': '25,25,35,255', 'outline_width': '0.3'
                })
            else:
                # Gap connectors use a solid red line plus endpoint markers. This
                # mirrors the Gap connectors symbol shown in the QGIS layer style
                # editor and makes the two measured locations immediately visible.
                symbol = QgsLineSymbol.createSimple({
                    'line_color': '255,45,65,230', 'line_width': '0.8'
                })
                try:
                    marker_line = QgsMarkerLineSymbolLayer(False, 3.0)
                    placements = (
                        Qgis.MarkerLinePlacement.FirstVertex |
                        Qgis.MarkerLinePlacement.LastVertex
                    )
                    marker_line.setPlacements(placements)
                    marker_line.setSubSymbol(QgsMarkerSymbol.createSimple({
                        'name': 'circle',
                        'color': '255,45,65,255',
                        'outline_color': '25,25,35,255',
                        'outline_width': '0.25',
                        'size': '3.0'
                    }))
                    symbol.appendSymbolLayer(marker_line)
                except Exception:
                    # Keep a visible connector line if a platform-specific
                    # marker-line API is unavailable.
                    pass
            layer.setRenderer(QgsSingleSymbolRenderer(symbol))
            layer.triggerRepaint()
        except Exception:
            pass

    @staticmethod
    def _move_output_to_project(layer, context, group, name, geometry_type):
        if layer is None:
            return None
        try:
            layer.setName(name)
            SnappingCheckerPlugin._style_custom_output(layer, geometry_type)
            try:
                transferred = context.takeResultLayer(layer.id())
                if transferred is not None:
                    layer = transferred
            except Exception:
                try:
                    context.temporaryLayerStore().takeMapLayer(layer)
                except Exception:
                    pass
            project = QgsProject.instance()
            project.addMapLayer(layer, False)
            group.addLayer(layer)
            return layer
        except Exception:
            return None

    def _run_custom_pairs(self, spec):
        alignment_only = bool(spec.get('alignment_only', False))
        processing = None
        if not alignment_only:
            try:
                import processing as processing_module
                processing = processing_module
            except Exception as exc:
                self._show_message(
                    'Snapping Checker — Processing unavailable',
                    'QGIS Processing could not be imported:\n%s' % exc,
                    'critical'
                )
                return

        sources = spec['sources']
        targets = spec['targets']
        pairs = [(source, target) for source in sources for target in targets]
        if not pairs:
            title = ('Line Alignment Offset' if alignment_only else 'Snapping Checker — Custom layers')
            self._show_message(title, 'No source/target pairs were selected.')
            return

        pair_count = len(pairs)
        if pair_count > 1:
            question = QMessageBox.question(
                self.iface.mainWindow(),
                ('Line Alignment Offset — Confirm checks' if alignment_only
                 else 'Snapping Checker — Confirm custom checks'),
                ('This will run %d line-alignment source-to-target checks.\n\n'
                 'The selected source will be compared with each target. '
                 'Only LINE_OFFSET points and Gap connectors will be created. Continue?\n\n%s'
                 if alignment_only else
                 'This will run %d source-to-target checks.\n\n'
                 'Every source will be checked against every target. '
                 'Original layers will not be modified. Continue?\n\n%s') %
                (pair_count, COPYRIGHT),
                _message_button('Yes', 0x00004000),
                _message_button('No', 0x00010000)
            )
            if question != _message_button('Yes', 0x00004000):
                return

        project = QgsProject.instance()
        context = QgsProcessingContext()
        context.setProject(project)
        try:
            context.setTransformContext(project.transformContext())
        except Exception:
            pass

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        mode_label = ('Line Alignment Offset (One-to-Many)' if alignment_only else
                      ('One-to-Many' if spec['mode'] == 'one_to_many' else 'Many-to-Many'))
        group_prefix = 'Line Alignment Offset' if alignment_only else 'Snapping Checker'
        group_name = (
            'Line Alignment Offset — Results — %s' % timestamp if alignment_only
            else 'Snapping Checker — %s Results — %s' % (mode_label, timestamp)
        )
        group = project.layerTreeRoot().addGroup(group_name)
        group.setExpanded(False)

        progress = QProgressDialog(
            ('Preparing line-alignment checks…' if alignment_only else
             'Preparing custom snapping checks…'),
            'Cancel', 0, pair_count * 100, self.iface.mainWindow()
        )
        progress.setWindowTitle(
            'Line Alignment Offset — Processing' if alignment_only
            else 'Snapping Checker — Custom processing'
        )
        progress.setMinimumDuration(0)
        progress.setValue(0)
        try:
            progress.setWindowModality(_enum_value(
                'WindowModal', ('WindowModality', 'WindowModal'), 1
            ))
        except Exception:
            pass

        completed = 0
        failed = []
        cancelled = False
        added_layers = 0
        output_point_features = 0
        pairs_with_errors = 0

        for index, (source, target) in enumerate(pairs):
            if progress.wasCanceled():
                cancelled = True
                break
            progress.setLabelText(
                ('Line alignment %d of %d\n%s  →  %s\n\n%s' if alignment_only
                 else 'Check %d of %d\n%s  →  %s\n\n%s') %
                (index + 1, pair_count, source.name(), target.name(), COPYRIGHT)
            )
            QApplication.processEvents()

            feedback = _DialogFeedback(progress, index, pair_count)
            parameters = {
                'SOURCE': source,
                'SOURCE_SELECTED': spec['source_selected'],
                'TARGET': target,
                'TARGET_SELECTED': spec['target_selected'],
                'VERTEX_MODE': spec['vertex_mode'],
                'SNAP_TO': spec['snap_to'],
                'TOLERANCE': spec['tolerance'],
                'CHECK_SELF': spec['check_self'],
                'MAX_OVERSHOOT': spec['max_overshoot'],
                'CHECK_CROSSINGS': spec['check_crossings'],
                'REPORT_NOT_CONNECTED': spec['report_not_connected'],
                'INCLUDE_SNAPPED': False,
                'PRECISION': spec['precision'],
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT,
                'OUTPUT_LINES': QgsProcessing.TEMPORARY_OUTPUT,
            }
            try:
                if alignment_only:
                    error_layer, connector_layer = self._create_alignment_output_layers(
                        source, target
                    )
                else:
                    result = processing.run(
                        'snappingqc:checksnapping',
                        parameters,
                        context=context,
                        feedback=feedback,
                        is_child_algorithm=True,
                    )
                    error_layer = self._resolve_layer(
                        result.get('OUTPUT'), context, GEOMETRY_POINT
                    )
                    connector_layer = self._resolve_layer(
                        result.get('OUTPUT_LINES'), context, GEOMETRY_LINE
                    )
                if error_layer is None:
                    raise RuntimeError('The checker could not create its point output.')

                # The dedicated toolbar mode writes only LINE_OFFSET features.
                # Generic custom checks retain their original snapping output and
                # optionally append the same line-path alignment findings.
                try:
                    self._append_line_alignment_errors(
                        source, target, spec, error_layer, connector_layer, context
                    )
                except Exception as alignment_exc:
                    failed.append('%s → %s (line alignment): %s' %
                                  (source.name(), target.name(), alignment_exc))

                # Successful SNAPPED records are not errors and must never appear.
                error_count = self._remove_snapped_rows(error_layer)
                connector_count = self._remove_snapped_rows(connector_layer)

                safe_source = source.name().replace('/', '_').replace('\\', '_')
                safe_target = target.name().replace('/', '_').replace('\\', '_')
                if error_count > 0:
                    error_name = (
                        'Line alignment offsets — %s → %s' % (safe_source, safe_target)
                        if alignment_only else
                        'Snapping errors — %s → %s' % (safe_source, safe_target)
                    )
                    moved_error = self._move_output_to_project(
                        error_layer, context, group, error_name, GEOMETRY_POINT
                    )
                    if moved_error is None:
                        raise RuntimeError('Could not add the point output to the QGIS project.')
                    added_layers += 1
                    pairs_with_errors += 1
                    output_point_features += error_count

                    # Connector outputs are shown only when there are real error points
                    # and the connector layer itself contains at least one feature.
                    if connector_layer is not None and connector_count > 0:
                        moved_connector = self._move_output_to_project(
                            connector_layer, context, group,
                            'Gap connectors — %s → %s' % (safe_source, safe_target),
                            GEOMETRY_LINE
                        )
                        if moved_connector is not None:
                            added_layers += 1
                    else:
                        self._discard_temporary_output(connector_layer, context)
                else:
                    self._discard_temporary_output(error_layer, context)
                    self._discard_temporary_output(connector_layer, context)
                completed += 1
            except Exception as exc:
                failed.append('%s → %s: %s' % (source.name(), target.name(), exc))
            finally:
                progress.setValue((index + 1) * 100)
                QApplication.processEvents()

            if feedback.isCanceled():
                cancelled = True
                break

        progress.close()
        if added_layers == 0:
            try:
                project.layerTreeRoot().removeChildNode(group)
            except Exception:
                pass

        message = (
            'Mode: %s\nCompleted checks: %d / %d\nPairs with errors: %d\n'
            'Output error features: %d\nOutput layers added: %d' %
            (mode_label, completed, pair_count, pairs_with_errors,
             output_point_features, added_layers)
        )
        if cancelled:
            message += '\nProcessing was cancelled. Completed outputs have been kept.'
        if failed:
            message += '\n\nFailed checks (%d):\n%s' % (
                len(failed), '\n'.join(failed[:8])
            )
            if len(failed) > 8:
                message += '\n… and %d more.' % (len(failed) - 8)
        message += '\n\n' + COPYRIGHT

        if failed or cancelled:
            QMessageBox.warning(
                self.iface.mainWindow(),
                ('Line Alignment Offset — Results' if alignment_only
                 else 'Snapping Checker — Custom results'), message
            )
        else:
            QMessageBox.information(
                self.iface.mainWindow(),
                ('Line Alignment Offset — Results' if alignment_only
                 else 'Snapping Checker — Custom results'), message
            )

    def show_license(self):
        if self.license_module is None:
            self._show_message(
                'Snapping Checker — License',
                'No matching original license build is available for Python %d.%d.' %
                sys.version_info[:2]
            )
            return
        try:
            dialog_exec(LicenseDialog(self.license_module, self.iface.mainWindow()))
        except Exception as exc:
            self._show_message(
                'Snapping Checker — License',
                'Could not open the license dialog:\n%s' % exc,
                'critical'
            )

    def show_about(self):
        QMessageBox.information(
            self.iface.mainWindow(), 'About Snapping Checker',
            '<b>Snapping Checker %s</b><br><br>'
            'Dedicated Line Alignment Offset (LINE_OFFSET) checking, the original two-layer and all-layer Processing algorithms, '
            'and custom One-to-Many / Many-to-Many snapping checks.'
            '<br><br>Custom checks show only actual errors; empty result layers and correctly snapped features are suppressed.'
            '<br>The first toolbar action runs only Line Alignment Offset (LINE_OFFSET) in One-to-Many mode and creates red Gap connectors with endpoint markers.'
            '<br>The original two-layer Check Snapping algorithm remains available in the Processing Toolbox.'
            '<br><br>Source layers are never edited by custom checks.'
            '<br><br>%s' % (PLUGIN_VERSION, COPYRIGHT)
        )

    def unload(self):
        if self.provider is not None:
            try:
                QgsApplication.processingRegistry().removeProvider(self.provider)
            except Exception:
                pass
            self.provider = None
        for action in self.actions:
            try:
                self.iface.removePluginVectorMenu(PLUGIN_NAME, action)
            except Exception:
                pass
        for action in self.toolbar_actions:
            try:
                self.iface.removeToolBarIcon(action)
            except Exception:
                pass
        self.actions = []
        self.toolbar_actions = []
