Snapping Checker v3.2.5

See README.md for the complete project overview, features, requirements,
installation steps, compatibility notes, output fields, and copyright terms.

Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.
