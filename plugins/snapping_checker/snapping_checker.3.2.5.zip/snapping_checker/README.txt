SNAPPING CHECKER 3.2.5 — QGIS 3 / QGIS 4 RELEASE

Purpose
-------
Snapping Checker preserves the original compiled snapping algorithms and
licence system. Version 3.2.5 replaces the first toolbar action with a focused
Line Alignment Offset (LINE_OFFSET) tool, while retaining the original all-layer
and custom multi-layer snapping workflows.

QGIS 4 / Qt6 compatibility
--------------------------
- Uses the QGIS-provided qgis.PyQt abstraction rather than importing PyQt5 or
  PyQt6 directly.
- Resolves QAction from the QtGui module, with a QtWidgets fallback.
- Executes dialogs through exec() with exec_() fallback.
- Resolves scoped Qgis.GeometryType.Point/Line/Polygon values where available,
  with legacy QgsWkbTypes geometry constants as fallback.
- Handles Qt5/Qt6 scoped and legacy enum values used by the wrapper.
- metadata.txt declares qgisMinimumVersion=3.28 and qgisMaximumVersion=4.99.

Compiled engine runtime requirement
-----------------------------------
The original compiled snapping and licence engine builds are provided for
Python 3.9, 3.10, 3.11, 3.12 and 3.13. At startup the plugin loads the build
matching the Python minor version bundled with QGIS. If the running QGIS uses a
Python minor version outside this list, the compiled engines cannot be loaded;
matching original builds would be required. This archive cannot guarantee
future Python ABI compatibility without those builds.

Toolbar workflows
-----------------
1. Line Alignment Offset (LINE_OFFSET): dedicated One-to-Many check. Choose
   one source line layer and one or more target line layers. The output contains
   only LINE_OFFSET points and matching Gap connectors.
2. Check All Layers (fiber network): original telecom / fiber rule-set check.
3. Custom Check (One-to-Many): one source against multiple targets using the
   original snapping checks, with the optional LINE_OFFSET detection.
4. Custom Check (Many-to-Many): every selected source against every selected
   target using the original snapping checks, with optional LINE_OFFSET.

The original single-pair Check Snapping Processing algorithm remains registered
in the Snapping QC Processing provider (Processing Toolbox), but it is no longer
the first toolbar action.

Dedicated Line Alignment Offset tool
------------------------------------
- Opens from the first toolbar button and the matching Vector menu entry.
- Uses One-to-Many selection: one source layer and one or more targets.
- Requires line geometry on both sides; non-line layers are rejected before run.
- Exposes maximum offset distance, minimum offset precision and optional
  selected-feature-only filters.
- Samples along the source path between stored vertices and finds the nearest
  position on target linework. It records the maximum qualifying separation
  for each source/target feature pair where enough samples are displaced.
- Creates a point result with status=LINE_OFFSET and a connector joining the
  measured locations. Connector style uses a red line with red endpoint markers.
- Only LINE_OFFSET points and Gap connectors are included; generic endpoint,
  crossing, overshoot and undershoot snapping findings are not run in this mode.
- Output coordinates use the source layer CRS; target geometries are transformed
  into that CRS before distance sampling.
- Source layer geometry and attributes are never edited.

Custom workflows
----------------
- Any valid vector layer in the current project can be selected.
- Select All and Clear controls are provided for multi-select lists.
- Each source/target pair runs sequentially through the original checker.
- Progress, cancellation and per-pair error reporting are provided.
- Results are grouped by run; source layers are not edited.
- Empty error and connector layers are suppressed.
- Correctly snapped SNAPPED records are excluded from custom error outputs.

Installation
------------
1. In QGIS, open Plugins > Manage and Install Plugins.
2. Choose Install from ZIP and select snapping_checker_3.2.5.zip, or install
   through the AMLAN-X QGIS Plugin Repository.
3. Restart QGIS if the previous release is already loaded.
4. The first toolbar button is Line Alignment Offset (LINE_OFFSET).

Changelog
---------
See metadata.txt (the Plugin Manager changelog), CHANGELOG, or CHANGELOG.txt.

Copyright
---------
Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.

Original compiled snapping and licence components retain their original
ownership, notices and applicable terms.
