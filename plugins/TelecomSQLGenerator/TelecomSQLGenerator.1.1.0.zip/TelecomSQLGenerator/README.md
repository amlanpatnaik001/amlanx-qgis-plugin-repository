# Telecom SQL Generator — QGIS Plugin

**Version:** 1.1.0
**Author:** Amlan Patnaik  
**Category:** Database

Copyright © 2077 Amlan Patnaik. All rights reserved.

## Overview

Telecom SQL Generator creates three separate PostgreSQL SQL files from UUIDs held in QGIS vector layers:

1. **Check** — read-only matching row counts for the UUID list.
2. **Preview** — read-only current-value results for the rows and columns to be changed.
3. **Update** — `UPDATE ... RETURNING` statements. This file changes data only if you execute it manually.

**The plugin does not connect to PostgreSQL and does not execute SQL.** It only writes SQL files for you to inspect and run yourself.

## Included workflows

- **Update Infinium ID:** extracts UUIDs from a QGIS Sites layer, sets `infinium_id` to the entered value, and sets `verification = 'Desktop Verified'`, the schema-specific build-plan column to `Yes`, and the exact `construction_type` column to `Underground`.
- **Site Fallout:** extracts UUIDs from a QGIS Sites layer and sets `verification = 'Site Fallout'`, `infinium_id = NULL`, and the schema-specific build-plan column to `No`.
- **Custom SQL:** add one or more rules by choosing a source QGIS layer, target PostgreSQL table, column, and value. Use the SQL NULL checkbox when the desired value is `NULL`.

The Infinium ID workflow uses the exact `construction_type` field in every schema and writes `Underground`. No alternate spelling, alias, normalized-name matching, or fallback is used. The bundled inventory is normalized to `construction_type` for all schemas. This construction-type update applies only to the Infinium ID workflow; Site Fallout is unchanged.

The build-plan column is resolved from the bundled schema inventory. All schemas use `include_in_build_plan` where available, including `lea_hill.sites`; `buildplan` is retained only as a fallback for schemas whose inventory contains that legacy field.

For each workflow, choose **Selected features only** or **All features**. Source layers must have a `uuid` field (case-insensitive). Null, malformed and duplicate UUIDs are handled safely and reported.

## UI refinement in 1.0.9

- Applied an explicit dark navy/gold style to all combo boxes and their dropdown lists, preventing bright host-theme colors such as the green Sites layer control shown in the prior UI.
- The same style applies to dynamically-added combo boxes in Custom SQL rules.

## Reliability improvements introduced in 1.0.3

- Uses streamed feature iteration to avoid building an additional full list of QGIS feature objects in memory.
- Reports provider/layer reading failures with the number of features read before the failure.
- Sends technical exception details to **QGIS → View → Panels → Log Messages** (QGIS Message Log).
- Handles Qt5/Qt6 enum naming differences and QAction's Qt5/Qt6 module location.
- Keeps the output operation manual: generated SQL is never executed by this plugin.

## Compatibility

**Declared target:** QGIS 3.28–3.99 and QGIS 4.x, including supported QGIS builds using Qt5/PyQt5 or Qt6/PyQt6.

This compatibility target does not include QGIS 2.x or promise support for every historical standalone PyQt release. Actual runtime testing is still required on each QGIS distribution.

## Installation

1. Download the plugin ZIP.
2. Open QGIS.
3. Go to **Plugins → Manage and Install Plugins… → Install from ZIP**.
4. Browse to the ZIP and click **Install Plugin**.
5. Enable **Telecom SQL Generator** if prompted.
6. Open it from the Plugins menu or toolbar icon.

## Usage

1. Open the QGIS project containing your source layers.
2. Choose a target schema.
3. Choose **Selected features only** or **All features**.
4. Select the Sites/source layers, enter an Infinium ID or configure custom rules.
5. Choose an output folder and generate the three SQL files.
6. Run the `01_Check` file first in your PostgreSQL client.
7. Run and inspect `02_Preview`.
8. Execute `03_Update` only after reviewing the matching counts and preview.

## Schema and column inventory

`inventory.json` is a bundled snapshot of schemas, tables and column metadata supplied with the original plugin package. It is not a live database connection and is not refreshed automatically. Update the inventory when the database schema changes.

The bundled inventory includes schema and table/column names. Review it before public distribution to ensure those database structure details are approved for publication. Never include credentials, connection strings, private records or client-restricted information.

## SQL safeguards

- Check and Preview files are read-only.
- Update SQL is data-changing only when manually executed.
- Schema, table and column identifiers are quoted as PostgreSQL identifiers.
- String inputs are escaped; common numeric, boolean, UUID and JSONB types are validated.
- Conflicting custom rules for the same UUID set and column are rejected.
- The plugin does not execute SQL, connect to the database, commit edits or alter QGIS layers.

## Release history

See [CHANGELOG.md](CHANGELOG.md).

Copyright © 2077 Amlan Patnaik. All rights reserved.
