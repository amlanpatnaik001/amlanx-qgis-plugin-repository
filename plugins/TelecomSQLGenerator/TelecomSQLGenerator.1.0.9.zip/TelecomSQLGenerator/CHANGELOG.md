# Changelog

Copyright © 2077 Amlan Patnaik. All rights reserved.

All notable changes to Telecom SQL Generator are recorded here.

## 1.0.9 — Combo-box dark theme correction

- Fixed the bright green QGIS-themed Sites layer combo box visible in the UI.
- Applied explicit dark navy combo-box styling, with readable gold selection states and matching dark dropdown lists.
- Styling covers schema, Sites layer, and dynamically-added Custom SQL combo boxes.
- No SQL-generation logic or schema mapping was changed.

## 1.0.8 — Standardized construction_type field and new professional icon

- Standardized the Sites construction field to the exact `construction_type` name in every schema inventory entry.
- Removed `constructiontype` alias detection, normalized-name matching, and all construction-field fallbacks.
- Update Infinium ID now requires `construction_type` and sets it to `Underground` for every extracted UUID.
- Replaced the old database-stack icon with a new geometric telecom-network and data-grid mark in navy, gold, and ice blue.
- Updated both SVG and PNG icon assets, plugin metadata, and user documentation.


## 1.0.7 — Infinium ID construction type automation

- Update Infinium ID now also sets the available Sites construction-type field to `Underground`.
- Automatically detects either `constructiontype` or `construction_type`, using the field actually present in the selected schema inventory.
- The construction-type assignment is included in Check, Preview and Update SQL outputs.
- Site Fallout behaviour is unchanged.

## 1.0.6 — Canonical Build Plan column for all schemas

- Updated `lea_hill.sites` inventory mapping from `buildplan` to `include_in_build_plan`.
- Standardized build-plan column resolution to prefer `include_in_build_plan` for every schema.
- Retained `buildplan` only as an inventory-backed fallback for legacy schemas that still use that column.
- Both Update Infinium ID and Site Fallout continue to set the field to `Yes` and `No`, respectively.

## 1.0.5 — Release packaging update

- Published the current 1.0.4 functionality as release 1.0.5.
- Updated the plugin metadata and README version to 1.0.5.
- No Python source code or SQL-generation behaviour was changed.
- Retained the 1.0.4 build-plan status automation and all earlier release history.


Copyright © 2077 Amlan Patnaik. All rights reserved.

All notable changes to Telecom SQL Generator are recorded here.

## 1.0.4 — Build-plan status automation

- Update Infinium ID now also sets the schema-specific Sites build-plan field to `Yes` for every extracted UUID.
- Site Fallout now also sets the schema-specific Sites build-plan field to `No` for every extracted UUID.
- Resolves `lea_hill.sites.buildplan` and uses the inventory-defined field names in other schemas (`include_in_build_plan` or `buildplan`).
- Updated tab descriptions so the additional SQL changes are visible before generation.

## 1.0.3 — QGIS / Qt compatibility and reliability update

- Added QAction import fallback for PyQt5/Qt5 and PyQt6/Qt6.
- Added scoped/legacy Qt enum resolution for alignment, frame shape and standard paths.
- Declared QGIS 3.28–3.99 and QGIS 4.x as compatibility targets.
- Streamed QGIS feature iteration when extracting UUIDs rather than materialising all feature objects in memory.
- Improved layer/provider read failure messages, including the number of features read before an error.
- Added detailed exception diagnostics to the QGIS Message Log.
- Added guarded plugin dialog startup and error reporting.
- Updated generated SQL file headers and all first-party documentation with the copyright notice.
- Preserved the three-file Check / Preview / Update workflow.
- Preserved the safety rule that SQL is generated for manual review and is never executed by the plugin.

## 1.0.2

- Generate Check, Preview and Update SQL files from QGIS UUIDs.
- Infinium ID + Desktop Verified workflow.
- Site Fallout workflow.
- Custom multi-layer and multi-column SQL update rules.
- Bundled schema/table/column inventory and UUID validation.
