# -*- coding: utf-8 -*-
"""QGIS plugin entry point for Telecom SQL Generator."""
# Copyright © 2077 Amlan Patnaik. All rights reserved.

def classFactory(iface):
    from .plugin import TelecomSQLGeneratorPlugin
    return TelecomSQLGeneratorPlugin(iface)
