# -*- coding: utf-8 -*-
"""User interface and SQL generation logic for Telecom SQL Generator."""
# Copyright © 2077 Amlan Patnaik. All rights reserved.
import json
import os
import re
import uuid as uuidlib
from datetime import datetime
import traceback

from qgis.PyQt.QtCore import Qt, QSettings, QStandardPaths, QSignalBlocker
from qgis.PyQt.QtGui import QFont
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox, QLabel,
    QComboBox, QLineEdit, QPushButton, QCheckBox, QTabWidget, QWidget,
    QFileDialog, QMessageBox, QScrollArea, QFrame, QSizePolicy, QSpacerItem
)
from qgis.core import QgsProject, QgsVectorLayer, QgsMessageLog, Qgis


PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
INVENTORY_PATH = os.path.join(PLUGIN_DIR, "inventory.json")
UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)
NUMBER_RE = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$")
INTEGER_RE = re.compile(r"^[+-]?\d+$")


def qt_enum(owner, scope_name, member_name):
    """Resolve Qt5 flat enums and Qt6 scoped enums across QGIS builds."""
    scope = getattr(owner, scope_name, None)
    if scope is not None and hasattr(scope, member_name):
        return getattr(scope, member_name)
    if hasattr(owner, member_name):
        return getattr(owner, member_name)
    raise AttributeError(
        f"Qt enum {scope_name}.{member_name} is unavailable in this QGIS build."
    )


ALIGN_RIGHT = qt_enum(Qt, "AlignmentFlag", "AlignRight")
FRAME_STYLED_PANEL = qt_enum(QFrame, "Shape", "StyledPanel")
DOCUMENTS_LOCATION = qt_enum(
    QStandardPaths, "StandardLocation", "DocumentsLocation"
)



def qi(identifier):
    """Quote a PostgreSQL identifier."""
    return '"' + str(identifier).replace('"', '""') + '"'


def qualified(schema, table):
    return f"{qi(schema)}.{qi(table)}"


def qstr(value):
    """Quote a PostgreSQL string literal."""
    return "'" + str(value).replace("'", "''") + "'"


def normalized_name(value):
    return re.sub(r"[^a-z0-9]", "", str(value or "").lower())


def literal_for_value(value, meta, use_null=False):
    """Convert user input to a conservative SQL literal based on inventory type."""
    if use_null:
        return "NULL"
    text = str(value).strip()
    if text == "":
        raise ValueError("Enter a value or select the 'Use SQL NULL' checkbox.")
    dtype = (meta or {}).get("data_type", "character varying").strip().lower()
    colname = (meta or {}).get("name", "")

    if dtype == "uuid":
        candidate = text.strip("{}").lower()
        if not UUID_RE.fullmatch(candidate):
            raise ValueError(f"Column {colname} is UUID type. Enter a valid UUID.")
        return qstr(candidate) + "::uuid"
    if dtype in ("smallint", "integer", "bigint"):
        if not INTEGER_RE.fullmatch(text):
            raise ValueError(f"Column {colname} requires a whole number.")
        return text
    if dtype in ("numeric", "real", "double precision"):
        if not NUMBER_RE.fullmatch(text):
            raise ValueError(f"Column {colname} requires a valid numeric value.")
        return text
    if dtype == "boolean":
        val = text.lower()
        if val in ("true", "t", "yes", "y", "1"):
            return "TRUE"
        if val in ("false", "f", "no", "n", "0"):
            return "FALSE"
        raise ValueError(f"Column {colname} requires true/false (or yes/no, 1/0).")
    if dtype == "jsonb":
        try:
            json.loads(text)
        except Exception as exc:
            raise ValueError(f"Column {colname} requires valid JSON: {exc}")
        return qstr(text) + "::jsonb"
    if dtype == "bytea":
        raise ValueError(f"Column {colname} is binary (bytea) and is not supported by this text-value generator.")
    # Text, dates/times and enum-like USER-DEFINED types use escaped string literals.
    # PostgreSQL validates date/time/enum values when the script is run.
    return qstr(text)


class CustomRuleRow(QFrame):
    """One custom SQL update rule."""
    def __init__(self, owner, parent=None):
        super().__init__(parent)
        self.owner = owner
        self.setFrameShape(FRAME_STYLED_PANEL)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 7, 8, 7)
        layout.setSpacing(5)

        top = QHBoxLayout()
        self.layer_combo = QComboBox()
        self.layer_combo.setMinimumWidth(210)
        self.table_combo = QComboBox()
        self.table_combo.setMinimumWidth(170)
        self.remove_button = QPushButton("Remove")
        self.remove_button.setMaximumWidth(90)
        top.addWidget(QLabel("Source QGIS layer"))
        top.addWidget(self.layer_combo, 2)
        top.addWidget(QLabel("Target table"))
        top.addWidget(self.table_combo, 2)
        top.addWidget(self.remove_button)
        layout.addLayout(top)

        bottom = QHBoxLayout()
        self.column_combo = QComboBox()
        self.column_combo.setMinimumWidth(180)
        self.value_edit = QLineEdit()
        self.value_edit.setPlaceholderText("Value to set")
        self.null_checkbox = QCheckBox("Use SQL NULL")
        bottom.addWidget(QLabel("Column"))
        bottom.addWidget(self.column_combo, 2)
        bottom.addWidget(QLabel("Value"))
        bottom.addWidget(self.value_edit, 3)
        bottom.addWidget(self.null_checkbox)
        layout.addLayout(bottom)

        self.layer_combo.currentIndexChanged.connect(self._source_changed)
        self.table_combo.currentIndexChanged.connect(self._table_changed)
        self.null_checkbox.toggled.connect(self.value_edit.setDisabled)
        self.remove_button.clicked.connect(lambda: self.owner.remove_custom_rule(self))

        self.refresh_layers()
        self.refresh_tables()

    def refresh_layers(self, preserve_id=None):
        current = preserve_id if preserve_id is not None else self.layer_combo.currentData()
        blocker = QSignalBlocker(self.layer_combo)
        self.layer_combo.clear()
        self.layer_combo.addItem("— Choose source layer —", None)
        for layer in self.owner.uuid_layers():
            hint = self.owner.layer_table_hint(layer)
            display = layer.name()
            if hint:
                display = f"{display}  [{hint}]"
            self.layer_combo.addItem(display, layer.id())
        if current:
            ix = self.layer_combo.findData(current)
            if ix >= 0:
                self.layer_combo.setCurrentIndex(ix)
        del blocker

    def refresh_tables(self, preserve=None):
        old = preserve if preserve is not None else self.table_combo.currentData()
        blocker = QSignalBlocker(self.table_combo)
        self.table_combo.clear()
        self.table_combo.addItem("— Choose target table —", None)
        schema = self.owner.schema_combo.currentText()
        for table in self.owner.tables_with_uuid(schema):
            self.table_combo.addItem(table, table)
        target = old
        if not target:
            layer = self.owner.project_layer(self.layer_combo.currentData())
            if layer:
                target = self.owner.infer_table_for_layer(layer, schema)
        if target:
            ix = self.table_combo.findData(target)
            if ix >= 0:
                self.table_combo.setCurrentIndex(ix)
        del blocker
        self.refresh_columns()

    def refresh_columns(self, preserve=None):
        old = preserve if preserve is not None else self.column_combo.currentData()
        blocker = QSignalBlocker(self.column_combo)
        self.column_combo.clear()
        self.column_combo.addItem("— Choose column —", None)
        schema = self.owner.schema_combo.currentText()
        table = self.table_combo.currentData()
        for col in self.owner.editable_columns(schema, table):
            label = f"{col['name']}  ({col.get('data_type', 'unknown')})"
            self.column_combo.addItem(label, col['name'])
        if old:
            ix = self.column_combo.findData(old)
            if ix >= 0:
                self.column_combo.setCurrentIndex(ix)
        del blocker

    def _source_changed(self, *_args):
        self.refresh_tables(preserve=None)

    def _table_changed(self, *_args):
        self.refresh_columns()


class TelecomSQLGeneratorDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("Telecom SQL Generator — Amlan Patnaik")
        self.setMinimumSize(1050, 690)
        self.resize(1180, 790)
        self.settings = QSettings("AmlanPatnaik", "TelecomSQLGenerator")
        self.inventory = self._load_inventory()
        self.custom_rows = []
        self._building = True
        self._build_ui()
        self._building = False
        self._refresh_all_layer_combos()
        self._schema_changed()

    def _load_inventory(self):
        try:
            with open(INVENTORY_PATH, "r", encoding="utf-8") as handle:
                inventory = json.load(handle)
            return inventory
        except Exception as exc:
            QMessageBox.critical(self, "Inventory Error", f"Could not load inventory.json:\n{exc}")
            return {"schemas": [], "tables": {}}

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(12, 10, 12, 8)
        root.setSpacing(8)

        title = QLabel("Telecom SQL Generator — Amlan Patnaik")
        font = title.font()
        font.setPointSize(font.pointSize() + 3)
        font.setBold(True)
        title.setFont(font)
        root.addWidget(title)
        note = QLabel("Copyright © 2077 Amlan Patnaik. All rights reserved.. Generate check, preview, and update SQL files from UUIDs in QGIS layers. This plugin does not run SQL against the database.")
        note.setWordWrap(True)
        root.addWidget(note)

        db_group = QGroupBox("1. Target schema and UUID extraction")
        db_layout = QVBoxLayout(db_group)
        schema_row = QHBoxLayout()
        schema_row.addWidget(QLabel("Schema"))
        self.schema_combo = QComboBox()
        for schema in self.inventory.get("schemas", []):
            self.schema_combo.addItem(schema, schema)
        saved_schema = self.settings.value("schema", "lea_hill")
        saved_index = self.schema_combo.findText(saved_schema)
        if saved_index >= 0:
            self.schema_combo.setCurrentIndex(saved_index)
        schema_row.addWidget(self.schema_combo, 1)
        schema_row.addWidget(QLabel("Mode"))
        self.selected_only_cb = QCheckBox("Selected features only")
        self.all_features_cb = QCheckBox("All features")
        self.selected_only_cb.setChecked(True)
        schema_row.addWidget(self.selected_only_cb)
        schema_row.addWidget(self.all_features_cb)
        db_layout.addLayout(schema_row)
        self.mode_note = QLabel("Selected features only uses the current QGIS selection in each source layer.")
        self.mode_note.setWordWrap(True)
        db_layout.addWidget(self.mode_note)
        root.addWidget(db_group)

        output_group = QGroupBox("2. SQL output folder")
        output_layout = QHBoxLayout(output_group)
        self.output_edit = QLineEdit(self.settings.value("output_dir", ""))
        self.output_edit.setPlaceholderText("Choose the folder where the three SQL files will be saved")
        browse_button = QPushButton("Browse…")
        browse_button.clicked.connect(self._browse_output)
        output_layout.addWidget(self.output_edit, 1)
        output_layout.addWidget(browse_button)
        root.addWidget(output_group)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_infinium_tab(), "1 · Update Infinium ID")
        self.tabs.addTab(self._build_fallout_tab(), "2 · Site Fallout")
        self.tabs.addTab(self._build_custom_tab(), "3 · Custom SQL")
        root.addWidget(self.tabs, 1)

        bottom = QHBoxLayout()
        self.status_label = QLabel("Ready")
        self.status_label.setWordWrap(True)
        bottom.addWidget(self.status_label, 1)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.close)
        bottom.addWidget(close_btn)
        root.addLayout(bottom)
        copyright_label = QLabel("Copyright © 2077 Amlan Patnaik. All rights reserved.")
        copyright_label.setAlignment(ALIGN_RIGHT)
        copyright_label.setStyleSheet("color: palette(mid); font-size: 9pt;")
        root.addWidget(copyright_label)

        self.schema_combo.currentIndexChanged.connect(self._schema_changed)
        self.selected_only_cb.toggled.connect(lambda checked: self._set_extraction_mode(True, checked))
        self.all_features_cb.toggled.connect(lambda checked: self._set_extraction_mode(False, checked))

    def _build_infinium_tab(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        info = QLabel("Extract UUIDs from the Sites layer and generate three separate SQL files. The update sets both infinium_id to your entered value and verification to 'Desktop Verified'.")
        info.setWordWrap(True)
        layout.addWidget(info)
        form = QFormLayout()
        self.infinium_layer_combo = QComboBox()
        form.addRow("QGIS Sites layer", self.infinium_layer_combo)
        self.infinium_id_edit = QLineEdit()
        self.infinium_id_edit.setPlaceholderText("Enter the target Infinium ID")
        form.addRow("New Infinium ID", self.infinium_id_edit)
        verification_note = QLabel("Verification will also be set to: Desktop Verified")
        verification_note.setWordWrap(True)
        form.addRow("Verification", verification_note)
        layout.addLayout(form)
        button_row = QHBoxLayout()
        button_row.addStretch(1)
        btn = QPushButton("Generate 3 SQL Files")
        btn.clicked.connect(self._generate_infinium)
        button_row.addWidget(btn)
        layout.addLayout(button_row)
        layout.addStretch(1)
        return w

    def _build_fallout_tab(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        info = QLabel("Extract UUIDs from the Sites layer. The generated update will set verification to 'Site Fallout' and infinium_id to SQL NULL.")
        info.setWordWrap(True)
        layout.addWidget(info)
        form = QFormLayout()
        self.fallout_layer_combo = QComboBox()
        form.addRow("QGIS Sites layer", self.fallout_layer_combo)
        layout.addLayout(form)
        button_row = QHBoxLayout()
        button_row.addStretch(1)
        btn = QPushButton("Generate 3 SQL Files")
        btn.clicked.connect(self._generate_fallout)
        button_row.addWidget(btn)
        layout.addLayout(button_row)
        layout.addStretch(1)
        return w

    def _build_custom_tab(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        info = QLabel("Add one or more update rules. Each rule uses UUIDs from its selected QGIS source layer and updates the chosen table in the target schema. Standard identity fields (uuid, id, geom) are excluded from the field list.")
        info.setWordWrap(True)
        layout.addWidget(info)

        self.rules_scroll = QScrollArea()
        self.rules_scroll.setWidgetResizable(True)
        self.rules_container = QWidget()
        self.rules_layout = QVBoxLayout(self.rules_container)
        self.rules_layout.setContentsMargins(4, 4, 4, 4)
        self.rules_layout.setSpacing(7)
        self.rules_scroll.setWidget(self.rules_container)
        layout.addWidget(self.rules_scroll, 1)

        actions = QHBoxLayout()
        add_btn = QPushButton("+ Add update rule")
        add_btn.clicked.connect(self.add_custom_rule)
        actions.addWidget(add_btn)
        actions.addStretch(1)
        generate_btn = QPushButton("Generate 3 SQL Files")
        generate_btn.clicked.connect(self._generate_custom)
        actions.addWidget(generate_btn)
        layout.addLayout(actions)
        self.add_custom_rule()
        return w

    def _set_extraction_mode(self, selected_mode, checked):
        if self._building:
            return
        if checked:
            if selected_mode:
                blocker = QSignalBlocker(self.all_features_cb)
                self.all_features_cb.setChecked(False)
                del blocker
            else:
                blocker = QSignalBlocker(self.selected_only_cb)
                self.selected_only_cb.setChecked(False)
                del blocker
        elif not self.selected_only_cb.isChecked() and not self.all_features_cb.isChecked():
            if selected_mode:
                blocker = QSignalBlocker(self.selected_only_cb)
                self.selected_only_cb.setChecked(True)
                del blocker
            else:
                blocker = QSignalBlocker(self.all_features_cb)
                self.all_features_cb.setChecked(True)
                del blocker
        self.mode_note.setText(
            "Selected features only uses the current QGIS selection in each source layer."
            if self.selected_only_cb.isChecked()
            else "All features uses every feature in each selected source layer. Check the layer choice carefully."
        )

    def _schema_changed(self, *_args):
        schema = self.schema_combo.currentText()
        self.settings.setValue("schema", schema)
        for row in self.custom_rows:
            row.refresh_tables()

    def _refresh_all_layer_combos(self):
        self._fill_source_combo(self.infinium_layer_combo, sites_only=True)
        self._fill_source_combo(self.fallout_layer_combo, sites_only=True)
        for row in self.custom_rows:
            row.refresh_layers()
            row.refresh_tables()

    def _fill_source_combo(self, combo, sites_only=False):
        current_id = combo.currentData()
        blocker = QSignalBlocker(combo)
        combo.clear()
        combo.addItem("— Choose Sites layer —" if sites_only else "— Choose source layer —", None)
        for layer in self.uuid_layers():
            if sites_only and not self.is_sites_layer(layer):
                continue
            hint = self.layer_table_hint(layer)
            display = layer.name()
            if hint:
                display = f"{display}  [{hint}]"
            combo.addItem(display, layer.id())
        if current_id:
            idx = combo.findData(current_id)
            if idx >= 0:
                combo.setCurrentIndex(idx)
        if combo.count() == 1 and sites_only:
            combo.setToolTip("No vector layer named Sites (or sourced from the sites table) with a UUID field was found in the current QGIS project.")
        del blocker

    def uuid_layers(self):
        result = []
        for layer in QgsProject.instance().mapLayers().values():
            try:
                if not isinstance(layer, QgsVectorLayer) or not layer.isValid():
                    continue
                if self.uuid_field(layer) is None:
                    continue
                result.append(layer)
            except Exception:
                continue
        return sorted(result, key=lambda l: l.name().lower())

    @staticmethod
    def uuid_field(layer):
        for field in layer.fields():
            if field.name().strip().lower() == "uuid":
                return field.name()
        return None

    def project_layer(self, layer_id):
        if not layer_id:
            return None
        return QgsProject.instance().mapLayer(layer_id)

    def layer_table_hint(self, layer):
        try:
            source = layer.source()
        except Exception:
            return None
        patterns = [
            r'table\s*=\s*"?([A-Za-z_][A-Za-z0-9_]*)"?\."?([A-Za-z_][A-Za-z0-9_]*)"?',
            r'table\s*=\s*\'?([A-Za-z_][A-Za-z0-9_]*)\'?\.\'?([A-Za-z_][A-Za-z0-9_]*)\'?',
        ]
        for pattern in patterns:
            match = re.search(pattern, source, re.I)
            if match:
                return f"{match.group(1)}.{match.group(2)}"
        return None

    def is_sites_layer(self, layer):
        hint = self.layer_table_hint(layer)
        if hint and normalized_name(hint.split(".")[-1]) == "sites":
            return True
        return normalized_name(layer.name()) in ("site", "sites", "sitelayer", "siteslayer") or normalized_name(layer.name()).startswith("sites")

    def infer_table_for_layer(self, layer, schema):
        tables = self.tables_with_uuid(schema)
        hint = self.layer_table_hint(layer)
        if hint:
            source_schema, source_table = hint.split(".", 1)
            if source_schema == schema and source_table in tables:
                return source_table
            if source_table in tables:
                return source_table
        layer_norm = normalized_name(layer.name())
        for table in tables:
            if normalized_name(table) == layer_norm:
                return table
        aliases = {
            "fibercable": "fibercable",
            "fiber": "fibercable",
            "fiberline": "fibercable",
            "sites": "sites",
            "site": "sites",
            "spliceclosure": "spliceclosure",
            "laborunits": "labor_units",
            "labourunits": "labor_units",
            "qcpoints": "qc_points",
            "qcpolygons": "qc_polygons",
        }
        alias_target = aliases.get(layer_norm)
        if alias_target in tables:
            return alias_target
        return None

    def _browse_output(self):
        current = self.output_edit.text().strip() or self.settings.value("output_dir", "") or QStandardPaths.writableLocation(DOCUMENTS_LOCATION)
        path = QFileDialog.getExistingDirectory(self, "Choose SQL output folder", current)
        if path:
            self.output_edit.setText(path)
            self.settings.setValue("output_dir", path)

    def _output_folder(self):
        path = self.output_edit.text().strip()
        if not path or not os.path.isdir(path):
            self._browse_output()
            path = self.output_edit.text().strip()
        if not path or not os.path.isdir(path):
            raise ValueError("Choose an existing folder to save the SQL files.")
        self.settings.setValue("output_dir", path)
        return path

    def tables_with_uuid(self, schema):
        result = []
        for table, columns in self.inventory.get("tables", {}).get(schema, {}).items():
            if any(c.get("name", "").lower() == "uuid" for c in columns):
                result.append(table)
        return sorted(result)

    def columns(self, schema, table):
        return self.inventory.get("tables", {}).get(schema, {}).get(table, [])

    def find_column(self, schema, table, name):
        for col in self.columns(schema, table):
            if col.get("name", "").lower() == name.lower():
                return col
        return None

    def editable_columns(self, schema, table):
        cols = []
        for col in self.columns(schema, table):
            name = col.get("name", "")
            dtype = col.get("data_type", "").lower()
            if name.lower() in ("uuid", "geom", "id"):
                continue
            if dtype == "bytea":
                continue
            cols.append(col)
        return cols

    def _collect_uuids(self, combo, context):
        """Collect unique UUIDs without materialising every feature in memory."""
        layer = self.project_layer(combo.currentData())
        if layer is None or not layer.isValid():
            raise ValueError(f"Choose a valid QGIS source layer for {context}.")
        uuid_name = self.uuid_field(layer)
        if not uuid_name:
            raise ValueError(f"Layer '{layer.name()}' does not have a UUID field.")
        idx = next(
            (i for i, field in enumerate(layer.fields())
             if field.name().strip().lower() == "uuid"),
            -1
        )
        if idx < 0:
            raise ValueError(f"Could not locate the UUID field in '{layer.name()}'.")

        selected_only = self.selected_only_cb.isChecked()
        try:
            # Iterating the provider iterator avoids creating a second large
            # Python list of QgsFeature objects for large production layers.
            features = layer.getSelectedFeatures() if selected_only else layer.getFeatures()
        except Exception as exc:
            raise RuntimeError(
                f"Could not start reading features from '{layer.name()}': {exc}"
            ) from exc

        uuids = []
        seen = set()
        skipped = 0
        duplicates = 0
        feature_count = 0
        try:
            for feature in features:
                feature_count += 1
                value = feature.attribute(idx)
                if value is None:
                    skipped += 1
                    continue
                value = str(value).strip()
                if value.startswith("{") and value.endswith("}"):
                    value = value[1:-1].strip()
                value = value.lower()
                try:
                    value = str(uuidlib.UUID(value))
                except (ValueError, AttributeError, TypeError):
                    skipped += 1
                    continue
                if value in seen:
                    duplicates += 1
                    continue
                seen.add(value)
                uuids.append(value)
        except Exception as exc:
            raise RuntimeError(
                f"Feature reading stopped for layer '{layer.name()}' after "
                f"{feature_count:,} feature(s). No SQL files were generated. "
                f"Provider error: {exc}"
            ) from exc

        if selected_only and feature_count == 0:
            raise ValueError(
                f"No features are selected in layer '{layer.name()}'. "
                "Select features or choose All features."
            )
        if not uuids:
            raise ValueError(
                f"No valid UUIDs found in {feature_count:,} feature(s) "
                f"from '{layer.name()}'."
            )
        return {
            "layer": layer,
            "uuids": uuids,
            "feature_count": feature_count,
            "skipped": skipped,
            "duplicates": duplicates,
        }

    def _base_operation(self, table, layer_combo, label, set_values):
        schema = self.schema_combo.currentText()
        if table not in self.inventory.get("tables", {}).get(schema, {}):
            raise ValueError(f"Table '{table}' is not listed under schema '{schema}'.")
        table_uuid = self.find_column(schema, table, "uuid")
        if not table_uuid:
            raise ValueError(f"Table {schema}.{table} does not have a UUID column in the supplied inventory.")
        extracted = self._collect_uuids(layer_combo, label)
        return {
            "schema": schema,
            "table": table,
            "uuid_column": table_uuid["name"],
            "uuids": extracted["uuids"],
            "set_values": set_values,
            "label": label,
            "source_layer": extracted["layer"].name(),
            "feature_count": extracted["feature_count"],
            "skipped": extracted["skipped"],
            "duplicates": extracted["duplicates"],
        }

    def _generate_infinium(self):
        try:
            schema = self.schema_combo.currentText()
            table = "sites"
            col = self.find_column(schema, table, "infinium_id")
            verification = self.find_column(schema, table, "verification")
            if not col:
                raise ValueError(f"{schema}.sites does not contain infinium_id according to the inventory.")
            if not verification:
                raise ValueError(f"{schema}.sites does not contain verification according to the inventory.")
            id_value = self.infinium_id_edit.text().strip()
            if not id_value:
                raise ValueError("Enter the new Infinium ID.")
            value_sql = literal_for_value(id_value, col)
            operation = self._base_operation(
                table, self.infinium_layer_combo, "Update Infinium ID + Desktop Verified",
                {
                    col["name"]: {"sql": value_sql, "meta": col},
                    verification["name"]: {"sql": qstr("Desktop Verified"), "meta": verification},
                }
            )
            self._write_bundle("Infinium_ID_Desktop_Verified", [operation])
        except Exception as exc:
            self._show_error(exc)

    def _generate_fallout(self):
        try:
            schema = self.schema_combo.currentText()
            table = "sites"
            verification = self.find_column(schema, table, "verification")
            infinium = self.find_column(schema, table, "infinium_id")
            if not verification or not infinium:
                raise ValueError(f"{schema}.sites must contain verification and infinium_id.")
            operation = self._base_operation(
                table, self.fallout_layer_combo, "Site Fallout",
                {
                    verification["name"]: {"sql": qstr("Site Fallout"), "meta": verification},
                    infinium["name"]: {"sql": "NULL", "meta": infinium},
                }
            )
            self._write_bundle("Site_Fallout", [operation])
        except Exception as exc:
            self._show_error(exc)

    def add_custom_rule(self):
        row = CustomRuleRow(self, self.rules_container)
        self.custom_rows.append(row)
        self.rules_layout.addWidget(row)
        row.refresh_tables()
        self.rules_container.adjustSize()

    def remove_custom_rule(self, row):
        if len(self.custom_rows) <= 1:
            QMessageBox.information(self, "At least one rule is needed", "Keep at least one update rule. You can clear it and reuse it.")
            row.layer_combo.setCurrentIndex(0)
            row.table_combo.setCurrentIndex(0)
            row.column_combo.setCurrentIndex(0)
            row.value_edit.clear()
            row.null_checkbox.setChecked(False)
            return
        self.custom_rows.remove(row)
        self.rules_layout.removeWidget(row)
        row.deleteLater()

    def _generate_custom(self):
        try:
            operations = []
            errors = []
            for number, row in enumerate(self.custom_rows, 1):
                layer = self.project_layer(row.layer_combo.currentData())
                table = row.table_combo.currentData()
                column_name = row.column_combo.currentData()
                if layer is None or not table or not column_name:
                    errors.append(f"Rule {number}: choose a source layer, target table, and column.")
                    continue
                schema = self.schema_combo.currentText()
                meta = self.find_column(schema, table, column_name)
                if not meta:
                    errors.append(f"Rule {number}: column '{column_name}' is not in {schema}.{table} inventory.")
                    continue
                try:
                    sql_value = literal_for_value(row.value_edit.text(), meta, row.null_checkbox.isChecked())
                except ValueError as exc:
                    errors.append(f"Rule {number}: {exc}")
                    continue
                try:
                    op = self._base_operation(
                        table,
                        row.layer_combo,
                        f"Custom rule {number}: {table}.{column_name}",
                        {column_name: {"sql": sql_value, "meta": meta}},
                    )
                    operations.append(op)
                except ValueError as exc:
                    errors.append(f"Rule {number}: {exc}")
            if errors:
                raise ValueError("Please fix these issues before generating SQL:\n\n" + "\n".join(errors))
            if not operations:
                raise ValueError("Add at least one complete custom update rule.")
            operations = self._combine_compatible_operations(operations)
            self._write_bundle("Custom_Update", operations)
        except Exception as exc:
            self._show_error(exc)

    @staticmethod
    def _combine_compatible_operations(operations):
        combined = []
        by_key = {}
        for op in operations:
            key = (op["schema"], op["table"], tuple(op["uuids"]))
            if key not in by_key:
                copy = dict(op)
                copy["set_values"] = dict(op["set_values"])
                by_key[key] = copy
                combined.append(copy)
            else:
                existing = by_key[key]
                for col, value in op["set_values"].items():
                    if col in existing["set_values"] and existing["set_values"][col]["sql"] != value["sql"]:
                        raise ValueError(f"Conflicting values were provided for {op['schema']}.{op['table']}.{col} on the same UUID set.")
                    existing["set_values"][col] = value
                existing["label"] += "; " + op["label"]
        return combined

    def _write_bundle(self, prefix, operations):
        output_dir = self._output_folder()
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_prefix = re.sub(r"[^A-Za-z0-9_]+", "_", prefix).strip("_")
        base = f"{safe_prefix}_{stamp}"
        check_path = os.path.join(output_dir, f"{base}_01_Check.sql")
        preview_path = os.path.join(output_dir, f"{base}_02_Preview.sql")
        update_path = os.path.join(output_dir, f"{base}_03_Update.sql")

        with open(check_path, "w", encoding="utf-8") as handle:
            handle.write(self._file_header("Read-only matching count check", operations))
            for i, op in enumerate(operations, 1):
                table_ref = qualified(op["schema"], op["table"])
                handle.write(f"\n-- Operation {i}: {op['label']}\n")
                handle.write(f"SELECT COUNT(*) AS matching_records_{i}\nFROM {table_ref}\nWHERE {qi(op['uuid_column'])} IN (\n{self._uuid_sql_list(op['uuids'])}\n);\n")

        with open(preview_path, "w", encoding="utf-8") as handle:
            handle.write(self._file_header("Read-only current-value preview", operations))
            for i, op in enumerate(operations, 1):
                table_ref = qualified(op["schema"], op["table"])
                columns = [op["uuid_column"]] + list(op["set_values"].keys())
                columns = list(dict.fromkeys(columns))
                select_cols = ", ".join(qi(col) for col in columns)
                handle.write(f"\n-- Operation {i}: {op['label']}\n")
                handle.write(f"SELECT {select_cols}\nFROM {table_ref}\nWHERE {qi(op['uuid_column'])} IN (\n{self._uuid_sql_list(op['uuids'])}\n)\nORDER BY {qi(op['uuid_column'])};\n")

        with open(update_path, "w", encoding="utf-8") as handle:
            handle.write(self._file_header("DATA-CHANGING UPDATE statements", operations))
            handle.write("-- CAUTION: this file changes database records when executed.\n")
            handle.write("-- Run the matching-count and preview files first. Execute this file only after reviewing those results.\n")
            handle.write("-- Statements are wrapped in a transaction so the batch can be committed as a unit.\n\n")
            handle.write("BEGIN;\n\n")
            for i, op in enumerate(operations, 1):
                table_ref = qualified(op["schema"], op["table"])
                assignments = ",\n    ".join(f"{qi(col)} = {spec['sql']}" for col, spec in op["set_values"].items())
                returning = ", ".join(qi(c) for c in [op["uuid_column"]] + list(op["set_values"].keys()))
                handle.write(f"-- Operation {i}: {op['label']}\n")
                handle.write(f"UPDATE {table_ref}\nSET {assignments}\nWHERE {qi(op['uuid_column'])} IN (\n{self._uuid_sql_list(op['uuids'])}\n)\nRETURNING {returning};\n\n")
            handle.write("COMMIT;\n")

        total_unique = sum(len(op["uuids"]) for op in operations)
        details = []
        for op in operations:
            details.append(f"{op['label']}: {len(op['uuids'])} UUID(s) from '{op['source_layer']}'")
        self.status_label.setText(f"Created 3 SQL files in: {output_dir}")
        QMessageBox.information(
            self,
            "SQL files created",
            "Created three separate SQL files:\n\n"
            f"1. Check: {os.path.basename(check_path)}\n"
            f"2. Preview: {os.path.basename(preview_path)}\n"
            f"3. Update: {os.path.basename(update_path)}\n\n"
            + "\n".join(details)
            + "\n\nRun Check and Preview first. The Update file changes data only if you execute it manually."
        )

    @staticmethod
    def _uuid_sql_list(uuids):
        return ",\n    ".join(qstr(u) + "::uuid" for u in uuids)

    def _file_header(self, purpose, operations):
        lines = [
            "-- Telecom SQL Generator | Amlan Patnaik",
            f"-- Purpose: {purpose}",
            f"-- Generated: {datetime.now().isoformat(timespec='seconds')}",
            "-- Source UUIDs were extracted from the selected QGIS features or all features, as configured.",
            "-- The bundled schema/table/column inventory is a snapshot supplied by the user.",
            "-- Copyright © 2077 Amlan Patnaik. All rights reserved.",
            "--",
            "-- Operations:",
        ]
        for op in operations:
            lines.append(f"--   {op['schema']}.{op['table']}: {len(op['uuids'])} unique UUID(s) | {op['label']}")
        lines.append("")
        return "\n".join(lines) + "\n"

    def _show_error(self, exc):
        """Show a clear user message and retain technical diagnostics in QGIS."""
        message = str(exc).strip() or exc.__class__.__name__
        self.status_label.setText(
            "Could not generate SQL. Review the message and QGIS Log Messages."
        )
        try:
            level_group = getattr(Qgis, "MessageLevel", Qgis)
            level = getattr(level_group, "Critical", getattr(Qgis, "Critical", 2))
            details = traceback.format_exc()
            if details.strip() == "NoneType: None":
                details = f"{exc.__class__.__name__}: {message}"
            QgsMessageLog.logMessage(
                f"{message}\\n\\n{details}",
                "Telecom SQL Generator",
                level
            )
        except Exception:
            pass
        QMessageBox.warning(self, "Telecom SQL Generator", message)
