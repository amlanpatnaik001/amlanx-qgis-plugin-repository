# Changelog

Copyright © 2077 Amlan Patnaik. All rights reserved.

All notable changes to Telecom SQL Generator are recorded here.

## 1.0.3 — QGIS / Qt compatibility and reliability update

- Added QAction import fallback for PyQt5/Qt5 and PyQt6/Qt6.
- Added scoped/legacy Qt enum resolution for alignment, frame shape and standard paths.
- Declared QGIS 3.28–3.99 and QGIS 4.x as compatibility targets.
- Streamed QGIS feature iteration when extracting UUIDs rather than materialising all feature objects in memory.
- Improved layer/provider read failure messages, including the number of features read before an error.
- Added detailed exception diagnostics to the QGIS Message Log.
- Added guarded plugin dialog startup and error reporting.
- Updated generated SQL file headers and all first-party documentation with the copyright notice.
- Preserved the three-file Check / Preview / Update workflow.
- Preserved the safety rule that SQL is generated for manual review and is never executed by the plugin.

## 1.0.2

- Generate Check, Preview and Update SQL files from QGIS UUIDs.
- Infinium ID + Desktop Verified workflow.
- Site Fallout workflow.
- Custom multi-layer and multi-column SQL update rules.
- Bundled schema/table/column inventory and UUID validation.
