# -*- coding: utf-8 -*-
"""Telecom SQL Generator QGIS plugin."""
# Copyright © 2077 Amlan Patnaik. All rights reserved.
from qgis.PyQt.QtGui import QIcon

try:
    # PyQt6 / Qt6 moved QAction to QtGui.
    from qgis.PyQt.QtGui import QAction
except ImportError:  # PyQt5 / Qt5
    from qgis.PyQt.QtWidgets import QAction
import os
from .dialog import TelecomSQLGeneratorDialog


class TelecomSQLGeneratorPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        # Load the bundled icon so the toolbar can use a compact graphic
        # instead of displaying the action text when no icon is available.
        icon_dir = os.path.dirname(os.path.abspath(__file__))
        icon = QIcon(os.path.join(icon_dir, "icon.svg"))
        if icon.isNull():
            icon = QIcon(os.path.join(icon_dir, "icon.png"))
        self.action = QAction(
            icon,
            "Telecom SQL Generator — Amlan Patnaik",
            self.iface.mainWindow()
        )
        self.action.setToolTip("Generate PostgreSQL SQL files. Copyright © 2077 Amlan Patnaik. All rights reserved.")
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&Telecom SQL Generator — Amlan Patnaik", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action is not None:
            self.iface.removePluginMenu("&Telecom SQL Generator — Amlan Patnaik", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None

    def run(self):
        """Open the generator, reusing an existing dialog where possible."""
        try:
            if self.dialog is None:
                self.dialog = TelecomSQLGeneratorDialog(self.iface, self.iface.mainWindow())
            self.dialog.show()
            self.dialog.raise_()
            self.dialog.activateWindow()
        except Exception as exc:
            # Keep plugin activation errors visible to the user and QGIS log.
            try:
                from qgis.PyQt.QtWidgets import QMessageBox
                QMessageBox.critical(
                    self.iface.mainWindow(),
                    "Telecom SQL Generator",
                    f"Could not open the plugin dialog: {exc}"
                )
            except Exception:
                pass
            try:
                from qgis.core import QgsMessageLog, Qgis
                level_group = getattr(Qgis, "MessageLevel", Qgis)
                level = getattr(level_group, "Critical", getattr(Qgis, "Critical", 2))
                QgsMessageLog.logMessage(
                    f"Could not open plugin dialog: {exc}",
                    "Telecom SQL Generator",
                    level
                )
            except Exception:
                pass
