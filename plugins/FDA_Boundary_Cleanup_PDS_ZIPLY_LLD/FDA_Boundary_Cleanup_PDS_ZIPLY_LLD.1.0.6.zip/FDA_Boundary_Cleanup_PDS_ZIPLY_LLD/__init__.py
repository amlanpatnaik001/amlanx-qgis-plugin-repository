# -*- coding: utf-8 -*-
"""FDA Boundary Cleanup plugin entry point.

Copyright © 2077 Amlan Patnaik. All rights reserved.
"""


def classFactory(iface):
    from .plugin import FDABoundaryCleanupPlugin
    return FDABoundaryCleanupPlugin(iface)
