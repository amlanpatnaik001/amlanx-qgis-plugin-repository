# FDA Boundary Cleanup PDS_ZIPLY_LLD

**Version:** 1.0.6  
**Category:** Vector  
**Author:** Amlan Patnaik  
**QGIS metadata range:** 3.28–4.99  
**Repository:** [https://github.com/amlanpatnaik001/amlanx-qgis-plugin-repository](https://github.com/amlanpatnaik001/amlanx-qgis-plugin-repository)

Copyright © 2077 Amlan Patnaik. All rights reserved.

A QGIS plugin for cleaning selected vector layers against one or more FDA Boundaries `infinium_id` values.

## Version 1.0.6 highlights

- **Cancellable background scans:** eligible provider-backed target layers are scanned in a `QgsTask` using an independently reopened provider layer.
- **Safe thread separation:** the worker returns feature IDs; it does not access the live project, widgets or edit buffers. Deletion and commits remain on QGIS's main thread.
- **Large-layer filtering:** bounding-box rejection runs before exact prepared-geometry intersection tests.
- **Reduced interface overhead:** progress and event-loop updates are throttled, and diagnostic log growth is bounded.
- **Batched deletes:** deletion requests are queued in batches of up to 5,000 feature IDs.
- **Delayed edit-session opening:** edit transactions are opened after scanning, reducing the time edit locks are held.
- **CRS safety:** geographic-degree FDA Boundary CRS is rejected so a feet-based tolerance is not accidentally treated as degrees.
- **Fallback paths:** memory layers and layers already in edit mode use the guarded synchronous scan because a separate provider instance cannot see their unsaved edit-buffer state.

## What the plugin does

1. Reads one or more selected `infinium_id` values from the **FDA Boundaries** layer.
2. Dissolves the geometries for the selected boundary IDs.
3. Optionally deletes FDA Boundaries records whose IDs are not selected.
4. Buffers the dissolved geometry using the entered tolerance (default **20 ft**).
5. Transforms the buffered geometry into each selected target layer's CRS.
6. Deletes target features that do **not** intersect the buffered boundary.
7. Commits deletions per layer and reports deleted counts and processing warnings.

Empty geometries and features whose intersection checks fail are preserved.

## Installation

1. In QGIS, open **Plugins → Manage and Install Plugins… → Install from ZIP**.
2. Select `FDA_Boundary_Cleanup_PDS_ZIPLY_LLD.1.0.6.zip`.
3. If upgrading an older copy, remove or overwrite the old installation to avoid duplicate plugin folders.
4. Open **FDA Boundary Cleanup** from the Plugins menu or toolbar.

## Basic workflow

1. Ensure the project contains a valid vector layer named **FDA Boundaries** with an **`infinium_id`** field.
2. Select the boundary ID value(s) to retain.
3. Review **Select layers to clean** and uncheck any layer that must not be modified.
4. Set the buffer tolerance in feet. The default is **20 ft**.
5. Decide whether to delete FDA Boundaries records whose IDs are not selected.
6. Read the destructive-action confirmation carefully, then execute the cleanup.
7. Monitor the progress and diagnostic log. Use **Copy diagnostic log** when reporting a problem.

## Buffer and cleanup rules

- A boundary CRS in feet uses the entered feet value directly as map units.
- A boundary CRS in metres converts feet using `0.3048`.
- For another projected unit, the plugin retains the legacy fixed fallback of **6.096 map units**, regardless of the entered feet value.
- Geographic-degree boundary CRS is rejected; reproject the FDA Boundaries layer into a suitable projected CRS in feet or metres.
- Target features outside the buffered selected boundary are deletion candidates.
- Empty geometries and features whose intersection test fails are preserved.
- When a source or target layer is already in edit mode, its pending edits may be committed with the cleanup. Review the confirmation dialog and save a backup first.

## Large-data behavior and limitations

Version 1.0.6 reduces GUI freezing during eligible provider-backed target-layer scans, but it does **not** make every processing stage asynchronous.

The following operations can still run synchronously and may temporarily block QGIS:

- Reading and dissolving the FDA Boundaries source geometries.
- Synchronous fallback scans for memory/temporary layers, layers already in edit mode, or providers that cannot be independently reopened.
- Deletion queuing and edit-buffer operations.
- Provider commits, including database or network-driver calls.

Cancellation is cooperative and occurs at safe checkpoints. It cannot forcibly interrupt a single blocked provider read, one complex geometry operation, or a provider commit already in progress. A slow or unresponsive external provider can still pause the interface. **Do not force-close QGIS during a commit.**

The background scan assumes that feature IDs returned by the reopened provider correspond to the same underlying dataset. Validate this for each provider used in your workflow (for example, PostgreSQL/PostGIS, GeoPackage or Shapefile).

## Compatibility

The plugin declares a QGIS metadata range of **3.28–4.99** and includes Qt5/Qt6 and QGIS 3/QGIS 4 enum compatibility fallbacks. This is a declared compatibility target, not proof of runtime testing on every QGIS/PyQt combination. Test on the exact QGIS build and providers used by your team before production use.

## Repository upload

Upload the release archive and this README into:

`plugins/FDA_Boundary_Cleanup_PDS_ZIPLY_LLD/`

Expected folder layout:

```text
plugins/
└── FDA_Boundary_Cleanup_PDS_ZIPLY_LLD/
    ├── README.md
    ├── FDA_Boundary_Cleanup_PDS_ZIPLY_LLD.1.0.6.zip
    └── (previous version ZIP files, if retained)
```

GitHub folder: [https://github.com/amlanpatnaik001/amlanx-qgis-plugin-repository/tree/main/plugins/FDA_Boundary_Cleanup_PDS_ZIPLY_LLD](https://github.com/amlanpatnaik001/amlanx-qgis-plugin-repository/tree/main/plugins/FDA_Boundary_Cleanup_PDS_ZIPLY_LLD)

After committing, check the repository's **Actions** tab for a successful Pages deployment. The repository feed is:

`https://amlanpatnaik001.github.io/amlanx-qgis-plugin-repository/plugins.xml`

## Data safety

**This plugin deletes features. Deleted data may not be recoverable.** Back up the project and all affected data sources before running cleanup. Test first on a copy or a small representative area, and verify the deletion counts before using it on production data.

For diagnostics, inspect the QGIS **Log Messages** panel and share the plugin's copied diagnostic log. Do not force-terminate QGIS while a provider is committing changes.

## Copyright

Copyright © 2077 Amlan Patnaik. All rights reserved.

Third-party components, if any are introduced separately, remain subject to their own applicable licence and attribution terms.
