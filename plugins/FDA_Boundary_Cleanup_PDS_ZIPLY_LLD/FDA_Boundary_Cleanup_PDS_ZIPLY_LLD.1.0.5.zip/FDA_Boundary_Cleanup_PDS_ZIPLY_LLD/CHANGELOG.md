# Changelog

## 1.0.5
- Added scoped PyQGIS enum resolution for QGIS 4 while retaining QGIS 3 legacy enum fallbacks (`QgsMapLayer.LayerType`, `QgsWkbTypes.GeometryType`, and `QgsUnitTypes.DistanceUnit`).
- Declared the supported metadata range as QGIS 3.28 through 4.99 and removed the obsolete `supportsQt6` metadata flag.
- Removed a duplicated boundary CRS validation block.
- Retained the Qt binding shim, cancellation checkpoints, edit-command protection, diagnostics and cleanup behavior from 1.0.4.
- Static Python compilation and archive checks pass. Runtime testing in actual QGIS 3.44 and QGIS 4.2 installations is still required before claiming tested compatibility.

## 1.0.4
- Added a Cancel preparation / Cancel cleanup control with safe checkpoints during source scans, CRS preparation, target scans and deletion batches.
- Wrapped plugin-generated delete batches in a QGIS edit command so a cancellation or batch failure can undo only this cleanup command; plugin-created edit sessions are rolled back where possible.
- Reduced deletion batch size to 250 to improve progress feedback and reduce long edit-buffer calls.
- Added progress/checkpoint messages around boundary reading, dissolve, buffering, CRS preparation and provider commits.
- Dissolves very large selected-boundary sets in chunks and limits boundary attribute fetching to the required `infinium_id` field where supported.
- Added PyQt5/PyQt6 enum, modal-dialog and QAction import compatibility.
- Preserved cleanup selection rules, buffer conversions, conservative geometry-error behavior and per-layer commit handling.
- Note: QGIS provider feature reads, a single complex GEOS operation and provider commits remain synchronous; these individual calls cannot be forcibly cancelled safely.

## 1.0.3
- Added scrollable, resizable dialog with fixed action footer for small monitors.
- Added copyable diagnostic logs and full tracebacks in QGIS Log Messages.
- Added top-level error guards around refresh and cleanup execution.
- Avoided up-front featureCount() calls across all target layers.
- Added prepared geometry-engine intersection checks and frequent UI/progress updates.
- Batched deletions by 1,000 features with UI yields between batches.
- Preserved existing cleanup semantics and conservative handling of geometry-check errors.

## 1.0.2
- Existing FDA boundary cleanup logic and confirmation behavior.
