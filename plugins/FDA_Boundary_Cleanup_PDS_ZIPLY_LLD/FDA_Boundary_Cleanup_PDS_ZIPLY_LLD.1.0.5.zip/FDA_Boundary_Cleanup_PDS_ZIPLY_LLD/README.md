# FDA Boundary Cleanup PDS_ZIPLY_LLD — v1.0.5

**Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere**

A QGIS plugin for cleaning selected vector layers against one or more FDA Boundary `infinium_id` values.

## What's improved in v1.0.5

- **Resizable and scrollable interface:** the content pane scrolls vertically on smaller monitors; the Execute and Close buttons stay visible at the bottom.
- **Easier troubleshooting:** unexpected errors include their exception type and context. Detailed Python tracebacks are sent to QGIS Log Messages and retained in the plugin's diagnostic history.
- **Copy diagnostic log:** copies the visible processing log and captured tracebacks for sharing when reporting an issue.
- **Better performance during large scans:** uses a prepared geometry engine for repeated spatial intersection tests, avoids a pre-run `featureCount()` over every layer, and refreshes progress/UI events regularly.
- **Batched feature deletion:** queues deletions in blocks of 250 and yields to the UI between batches.
- **Safe cancellation checkpoints:** you can request cancellation while the plugin is preparing data, scanning layers, or applying delete batches. The plugin stops at the next checkpoint rather than abruptly terminating QGIS.
- **Undo-safe delete batches:** plugin-generated deletions are grouped into an edit command. A cancellation or batch error attempts to undo only that command; edit sessions started by the plugin are rolled back where possible.
- **Smaller batches:** deletion batches are reduced from 1,000 to 250 IDs to make progress updates more frequent and keep each edit-buffer operation smaller.
- **Improved preparation progress:** source reading, large boundary dissolves, buffer creation and CRS preparation now report their current stage. Large boundary dissolve inputs are processed in chunks.
- **QGIS 3 / QGIS 4 compatibility:** Qt5/Qt6 enum and dialog execution fallbacks are used, QAction is imported from the correct Qt module, and scoped PyQGIS enums are resolved for QGIS 3 and QGIS 4.
- The cleanup rules, selected-ID behavior, tolerance conversion, conservative handling of geometry-check failures, and confirmation prompt are retained.

> QGIS vector layer and provider APIs remain on the main thread for data safety. Cancellation is cooperative and works at checkpoints; it cannot interrupt a single blocked provider read, one complex geometry operation, or a provider commit already in progress. A slow network/database provider can therefore still pause the interface during that individual call. Do not force-close QGIS during a commit.

## Install

1. Save the plugin ZIP locally.
2. In QGIS, open **Plugins → Manage and Install Plugins… → Install from ZIP**.
3. Select `FDA_Boundary_Cleanup_PDS_ZIPLY_LLD.1.0.5.zip` and install it. If upgrading, remove or overwrite the older version first to avoid loading duplicate plugin folders.
4. Open it from the Plugins menu or toolbar icon.

## Compatibility

- Declares a QGIS metadata range of **3.28–4.99**, intended to cover QGIS 3.28+ and QGIS 4.x.
- Uses QGIS-provided `qgis.PyQt` imports, Qt5/Qt6 scoped-enum fallbacks, and QGIS 3/QGIS 4 scoped-PyQGIS-enum fallbacks.
- The compatibility target includes your QGIS 3.44.14 and QGIS 4.2.3 installations. Static checks have passed, but this package has not yet been run inside those QGIS applications; runtime validation is still required before treating both environments as verified.
- It cannot guarantee compatibility with every historical PyQt minor release, unsupported Python/QGIS combinations, or future QGIS major versions.

## Use

1. Ensure the project contains a valid vector layer named **FDA Boundaries** with an **infinium_id** field.
2. Check one or more boundary ID values.
3. Review **Select layers to clean**. Eligible vector geometry layers other than the FDA Boundaries source are checked by default. Uncheck any layer you do not want modified.
4. Set tolerance in feet. The default is **20 ft**.
5. Leave **Delete other FDA Boundaries records (keep selected ID(s))** checked to remove source records whose `infinium_id` is not selected; uncheck it to keep all FDA Boundaries records.
6. Review the destructive-action confirmation, then click **Execute cleanup**.
7. Monitor the processing log and progress bar. To report an issue, click **Copy diagnostic log** and share the copied text. You can also inspect **View → Panels → Log Messages** (or the QGIS Log Messages panel) for detailed diagnostics.

## Retained cleanup logic

- Dissolves geometries belonging to the selected `infinium_id` value(s).
- Optionally removes FDA Boundaries records whose IDs were not selected. All records matching selected IDs are retained.
- Creates a buffer around the dissolved geometry.
- If the boundary CRS uses feet, the entered feet value is used as map units.
- If the boundary CRS uses metres, feet are converted using `0.3048`.
- If the boundary CRS uses another unit, the legacy fixed fallback of **6.096 map units** is retained regardless of the entered feet value. **If the CRS uses degrees, 6.096 means 6.096 degrees and can cover a very large area; verify the CRS before proceeding.**
- Transforms the buffered geometry into each selected target layer's CRS before intersection tests.
- Deletes target features that do **not** intersect the buffered boundary. Empty geometries and features whose intersection check fails are preserved.
- Commits deletions per layer. If a target layer or the source boundary layer was already in edit mode, pending edits in that session may be committed along with cleanup deletions; the confirmation prompt warns about this.

## Important

**Deleted features cannot be recovered. Take a backup to avoid data loss.** Review selected IDs and layers before confirming. Do not force-close QGIS while the provider is committing changes.

Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere
