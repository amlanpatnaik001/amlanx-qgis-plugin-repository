# -*- coding: utf-8 -*-
"""QGIS plugin controller for FDA Boundary Cleanup.

Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere
"""

import os

from qgis.PyQt.QtGui import QIcon
try:  # QAction moved from QtWidgets to QtGui in Qt6.
    from qgis.PyQt.QtGui import QAction
except ImportError:  # PyQt5 / older QGIS builds
    from qgis.PyQt.QtWidgets import QAction

from .dialog import FDABoundaryCleanupDialog


class FDABoundaryCleanupPlugin:
    """Register the cleanup dialog in QGIS."""

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.svg")
        self.action = QAction(
            QIcon(icon_path),
            "FDA Boundary Cleanup",
            self.iface.mainWindow(),
        )
        self.action.setToolTip(
            "FDA Boundary Cleanup PDS_ZIPLY_LLD — Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere"
        )
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&FDA Boundary Cleanup", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action is not None:
            self.iface.removePluginMenu("&FDA Boundary Cleanup", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None
        if self.dialog is not None:
            self.dialog.close()
            self.dialog = None

    def run(self):
        if self.dialog is None:
            self.dialog = FDABoundaryCleanupDialog(self.iface, self.iface.mainWindow())
        self.dialog.refresh_lists(show_log_message=False)
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
