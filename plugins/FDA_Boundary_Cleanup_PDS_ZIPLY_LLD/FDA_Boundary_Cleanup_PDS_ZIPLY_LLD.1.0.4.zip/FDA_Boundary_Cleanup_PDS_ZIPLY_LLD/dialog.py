# -*- coding: utf-8 -*-
"""FDA Boundary Cleanup dialog and processing logic.

Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QFont, QTextCursor
import traceback

from qgis.PyQt.QtWidgets import (
    QApplication,
    QDialog,
    QScrollArea,
    QWidget,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QDoubleSpinBox,
    QCheckBox,
    QSizePolicy,
    QTextEdit,
    QVBoxLayout,
)
from qgis.core import (
    QgsCoordinateTransform,
    QgsFeatureRequest,
    QgsGeometry,
    QgsMapLayer,
    QgsMessageLog,
    QgsProject,
    QgsUnitTypes,
    QgsWkbTypes,
    Qgis,
)


COPYRIGHT = "Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere"
BOUNDARY_LAYER_NAME = "FDA Boundaries"
BOUNDARY_ID_FIELD = "infinium_id"
DEFAULT_BUFFER_FEET = 20.0
LEGACY_FALLBACK_MAP_UNITS = 6.096
PLUGIN_TAG = "FDA Boundary Cleanup PDS_ZIPLY_LLD"


class _CleanupCancelled(Exception):
    """Internal sentinel used to stop at a safe processing checkpoint."""


def _enum_value(owner, group_name, member_name, legacy_name=None):
    """Resolve Qt5/Qt6 scoped enums while retaining Qt5 aliases."""
    group = getattr(owner, group_name, None) if group_name else None
    if group is not None and hasattr(group, member_name):
        return getattr(group, member_name)
    return getattr(owner, legacy_name or member_name)


# PyQt5 exposes many enum values directly on their class; PyQt6 scopes them.
QT_CHECKED = _enum_value(Qt, "CheckState", "Checked")
QT_UNCHECKED = _enum_value(Qt, "CheckState", "Unchecked")
QT_ITEM_CHECKABLE = _enum_value(Qt, "ItemFlag", "ItemIsUserCheckable")
QT_ITEM_ENABLED = _enum_value(Qt, "ItemFlag", "ItemIsEnabled")
QT_ITEM_SELECTABLE = _enum_value(Qt, "ItemFlag", "ItemIsSelectable")
QT_USER_ROLE = _enum_value(Qt, "ItemDataRole", "UserRole")
QT_SCROLLBAR_OFF = _enum_value(Qt, "ScrollBarPolicy", "ScrollBarAlwaysOff")
QT_SCROLLBAR_AS_NEEDED = _enum_value(Qt, "ScrollBarPolicy", "ScrollBarAsNeeded")
QT_PLAIN_TEXT = _enum_value(Qt, "TextFormat", "PlainText")
QSIZE_EXPANDING = _enum_value(QSizePolicy, "Policy", "Expanding")
QTEXTCURSOR_END = _enum_value(QTextCursor, "MoveOperation", "End")
MB_ICON_WARNING = _enum_value(QMessageBox, "Icon", "Warning")
MB_ICON_CRITICAL = _enum_value(QMessageBox, "Icon", "Critical")
MB_ICON_INFORMATION = _enum_value(QMessageBox, "Icon", "Information")
MB_BUTTON_OK = _enum_value(QMessageBox, "StandardButton", "Ok")
MB_BUTTON_YES = _enum_value(QMessageBox, "StandardButton", "Yes")
MB_BUTTON_NO = _enum_value(QMessageBox, "StandardButton", "No")
_QGIS_LOG_LEVEL = getattr(Qgis, "MessageLevel", Qgis)
QGIS_LOG_INFO = getattr(_QGIS_LOG_LEVEL, "Info", getattr(Qgis, "Info", 0))
QGIS_LOG_WARNING = getattr(_QGIS_LOG_LEVEL, "Warning", getattr(Qgis, "Warning", 1))
QGIS_LOG_CRITICAL = getattr(_QGIS_LOG_LEVEL, "Critical", getattr(Qgis, "Critical", 2))


def _exec_dialog(dialog):
    """Execute a modal Qt dialog under both PyQt5 and PyQt6."""
    execute = getattr(dialog, "exec", None) or getattr(dialog, "exec_", None)
    if execute is None:
        raise RuntimeError("This Qt binding does not expose QDialog.exec()/exec_().")
    return execute()


class FDABoundaryCleanupDialog(QDialog):
    """A polished dialog for selecting boundary IDs and target layers."""

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self._is_processing = False
        self._is_preparing = False
        self._cancel_requested = False
        self._boundary_field_index = -1
        self.setObjectName("FDABoundaryCleanupDialog")
        self.setWindowTitle(f"{PLUGIN_TAG} | {COPYRIGHT}")
        self.setWindowIcon(self._load_icon())
        # Small-monitor friendly: the content scrolls, and the footer stays visible.
        self.setMinimumSize(400, 420)
        self.resize(680, 600)
        self.setSizeGripEnabled(True)
        self._diagnostic_errors = []
        self._build_ui()
        self.refresh_lists(show_log_message=False)

    def _load_icon(self):
        from qgis.PyQt.QtGui import QIcon
        import os
        return QIcon(os.path.join(os.path.dirname(__file__), "icon.svg"))

    def _build_ui(self):
        """Build a compact interface using the host application's native style."""
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(8, 8, 8, 8)
        outer_layout.setSpacing(6)

        self.scroll_area = QScrollArea(self)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(QT_SCROLLBAR_OFF)
        self.scroll_area.setVerticalScrollBarPolicy(QT_SCROLLBAR_AS_NEEDED)
        content_widget = QWidget(self.scroll_area)
        root = QVBoxLayout(content_widget)
        root.setContentsMargins(4, 4, 10, 4)
        root.setSpacing(7)
        self.scroll_area.setWidget(content_widget)
        outer_layout.addWidget(self.scroll_area, 1)

        # Plain heading: let QGIS/Qt supply the colors and widget appearance.
        title = QLabel("FDA Boundary Cleanup")
        title_font = QFont(title.font())
        title_font.setBold(True)
        title_font.setPointSize(title_font.pointSize() + 2)
        title.setFont(title_font)
        root.addWidget(title)

        subtitle = QLabel(
            f"PDS_ZIPLY_LLD  |  {COPYRIGHT}\n"
            "Keep features within the selected FDA boundary and its tolerance buffer."
        )
        subtitle.setWordWrap(True)
        root.addWidget(subtitle)

        # FDA boundary IDs
        boundary_group = QGroupBox("1. Choose FDA boundary IDs")
        boundary_layout = QVBoxLayout(boundary_group)
        source_row = QHBoxLayout()
        self.boundary_source_label = QLabel("Source: FDA Boundaries  |  Field: infinium_id")
        self.boundary_source_label.setWordWrap(True)
        self.boundary_count_label = QLabel("0 selected")
        count_font = QFont(self.boundary_count_label.font())
        count_font.setBold(True)
        self.boundary_count_label.setFont(count_font)
        self.select_all_ids_button = QPushButton("All IDs")
        self.select_all_ids_button.clicked.connect(lambda: self._set_all_boundary_checks(QT_CHECKED))
        self.clear_ids_button = QPushButton("Clear IDs")
        self.clear_ids_button.clicked.connect(lambda: self._set_all_boundary_checks(QT_UNCHECKED))
        self.refresh_button = QPushButton("Refresh")
        self.refresh_button.clicked.connect(lambda: self.refresh_lists(show_log_message=True))
        source_row.addWidget(self.boundary_source_label, 1)
        source_row.addWidget(self.boundary_count_label)
        source_row.addWidget(self.select_all_ids_button)
        source_row.addWidget(self.clear_ids_button)
        source_row.addWidget(self.refresh_button)
        boundary_layout.addLayout(source_row)

        self.boundary_list = QListWidget()
        self.boundary_list.setMinimumHeight(75)
        self.boundary_list.setSizePolicy(QSIZE_EXPANDING, QSIZE_EXPANDING)
        self.boundary_list.setAlternatingRowColors(True)
        self.boundary_list.itemChanged.connect(self._update_counts)
        boundary_layout.addWidget(self.boundary_list, 1)

        boundary_help = QLabel(
            "Select one or more infinium_id values. Matching FDA features are dissolved "
            "into one cleanup footprint."
        )
        boundary_help.setWordWrap(True)
        boundary_layout.addWidget(boundary_help)

        self.delete_other_boundaries_checkbox = QCheckBox(
            "Delete other FDA Boundaries records (keep selected ID(s))"
        )
        self.delete_other_boundaries_checkbox.setChecked(True)
        self.delete_other_boundaries_checkbox.setToolTip(
            "When checked, all FDA Boundaries features whose infinium_id is not among the selected IDs "
            "will be deleted after the target-layer cleanup. All records matching a selected ID are kept."
        )
        boundary_layout.addWidget(self.delete_other_boundaries_checkbox)
        root.addWidget(boundary_group, 3)

        # Target layers
        target_group = QGroupBox("2. Select layers to clean")
        target_layout = QVBoxLayout(target_group)
        target_top = QHBoxLayout()
        target_note = QLabel("Eligible geometry layers only; FDA Boundaries is excluded.")
        target_note.setWordWrap(True)
        target_top.addWidget(target_note, 1)
        self.select_all_button = QPushButton("Select all")
        self.select_all_button.clicked.connect(lambda: self._set_all_target_checks(QT_CHECKED))
        self.select_none_button = QPushButton("Clear")
        self.select_none_button.clicked.connect(lambda: self._set_all_target_checks(QT_UNCHECKED))
        target_top.addWidget(self.select_all_button)
        target_top.addWidget(self.select_none_button)
        target_layout.addLayout(target_top)

        self.target_list = QListWidget()
        self.target_list.setMinimumHeight(75)
        self.target_list.setSizePolicy(QSIZE_EXPANDING, QSIZE_EXPANDING)
        self.target_list.setAlternatingRowColors(True)
        self.target_list.itemChanged.connect(self._update_counts)
        target_layout.addWidget(self.target_list, 1)

        target_foot = QLabel(
            "Eligible vector layers are checked by default. Clear any layer you do not want to modify."
        )
        target_foot.setWordWrap(True)
        target_layout.addWidget(target_foot)
        root.addWidget(target_group, 3)

        # Tolerance
        tolerance_group = QGroupBox("3. Tolerance")
        tolerance_layout = QHBoxLayout(tolerance_group)
        tolerance_label = QLabel("Buffer distance:")
        self.buffer_spin = QDoubleSpinBox()
        self.buffer_spin.setRange(0.0, 1000000.0)
        self.buffer_spin.setDecimals(2)
        self.buffer_spin.setSingleStep(1.0)
        self.buffer_spin.setValue(DEFAULT_BUFFER_FEET)
        self.buffer_spin.setSuffix(" ft")
        self.buffer_spin.setToolTip(
            "Buffer distance in feet. The legacy 6.096-map-unit fallback remains fixed "
            "for CRS units other than feet or metres."
        )
        default_label = QLabel("Default: 20 ft")
        tolerance_layout.addWidget(tolerance_label)
        tolerance_layout.addWidget(self.buffer_spin)
        tolerance_layout.addWidget(default_label)
        tolerance_layout.addStretch(1)
        root.addWidget(tolerance_group)

        crs_hint = QLabel(
            "CRS: feet use the entered value; metres convert feet × 0.3048; other units use "
            "the legacy 6.096-map-unit fallback. A degree-based boundary CRS can create an "
            "extremely large buffer—verify the CRS before proceeding."
        )
        crs_hint.setWordWrap(True)
        root.addWidget(crs_hint)

        # Processing log and progress bar
        log_group = QGroupBox("Processing log")
        log_layout = QVBoxLayout(log_group)
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMinimumHeight(55)
        self.log_box.setSizePolicy(QSIZE_EXPANDING, QSIZE_EXPANDING)
        self.log_box.setPlaceholderText("Processing messages will appear here...")
        self.log_box.document().setMaximumBlockCount(5000)
        self.log_box.setUndoRedoEnabled(False)
        mono_font = QFont("Consolas")
        mono_font.setPointSize(9)
        self.log_box.setFont(mono_font)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setTextVisible(True)
        self.progress.setFormat("Ready")
        log_actions = QHBoxLayout()
        self.copy_log_button = QPushButton("Copy diagnostic log")
        self.copy_log_button.setToolTip(
            "Copy the visible log and detailed Python tracebacks for sharing when troubleshooting."
        )
        self.copy_log_button.clicked.connect(self._copy_diagnostic_log)
        self.clear_log_button = QPushButton("Clear log")
        self.clear_log_button.clicked.connect(self._clear_log)
        log_actions.addWidget(self.copy_log_button)
        log_actions.addWidget(self.clear_log_button)
        log_actions.addStretch(1)
        log_layout.addLayout(log_actions)
        log_layout.addWidget(self.log_box, 1)
        log_layout.addWidget(self.progress)
        root.addWidget(log_group, 2)

        self.warning_label = QLabel(
            "Warning: Deleted features cannot be recovered. Take a backup to avoid data loss."
        )
        self.warning_label.setWordWrap(True)
        root.addWidget(self.warning_label)

        footer_row = QHBoxLayout()
        self.support_label = QLabel(
            "For support, contact Amlan Patnaik.  |  Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere"
        )
        self.support_label.setWordWrap(True)
        footer_row.addWidget(self.support_label, 1)
        self.execute_button = QPushButton("Execute cleanup")
        self.execute_button.clicked.connect(self.execute_cleanup)
        self.cancel_button = QPushButton("Close")
        self.cancel_button.clicked.connect(self._cancel_or_close)
        footer_row.addWidget(self.execute_button)
        footer_row.addWidget(self.cancel_button)
        outer_layout.addLayout(footer_row)

    # ------------------------------------------------------------------
    # User interface helpers
    # ------------------------------------------------------------------
    def _popup_title(self, title):
        return f"{title} | {COPYRIGHT}"

    def _popup_message(self, message):
        text = str(message).strip()
        if COPYRIGHT not in text:
            text += f"\n\n{COPYRIGHT}"
        return text

    def _show_message(self, icon, title, message):
        box = QMessageBox(self)
        box.setIcon(icon)
        box.setWindowTitle(self._popup_title(title))
        box.setTextFormat(QT_PLAIN_TEXT)
        box.setText(self._popup_message(message))
        box.setStandardButtons(MB_BUTTON_OK)
        _exec_dialog(box)

    def _confirm(self, title, message):
        box = QMessageBox(self)
        box.setIcon(MB_ICON_WARNING)
        box.setWindowTitle(self._popup_title(title))
        box.setTextFormat(QT_PLAIN_TEXT)
        box.setText(self._popup_message(message))
        box.setStandardButtons(MB_BUTTON_YES | MB_BUTTON_NO)
        box.setDefaultButton(MB_BUTTON_NO)
        return _exec_dialog(box) == MB_BUTTON_YES

    def _cancel_or_close(self):
        """Request cancellation at the next safe checkpoint, or close while idle."""
        if self._is_processing or self._is_preparing:
            if not self._cancel_requested:
                self._cancel_requested = True
                self.cancel_button.setEnabled(False)
                self.progress.setFormat("Cancellation requested — stopping safely at the next checkpoint...")
                self._append_log("Cancellation requested. The current provider/geometry call will be allowed to finish first.")
            return
        self.close()

    def _ui_checkpoint(self, stage):
        """Pump GUI events at controlled checkpoints and raise on cancellation."""
        QApplication.processEvents()
        if self._cancel_requested:
            raise _CleanupCancelled(f"Cancelled during {stage}.")

    def _set_busy_controls(self, busy, cancel_text=None):
        """Enable/disable controls consistently when preparing or processing."""
        names = (
            "execute_button", "refresh_button", "select_all_button", "select_none_button",
            "select_all_ids_button", "clear_ids_button", "delete_other_boundaries_checkbox",
            "boundary_list", "target_list", "clear_log_button",
        )
        for name in names:
            widget = getattr(self, name, None)
            if widget is not None:
                widget.setEnabled(not busy)
        self.cancel_button.setText(cancel_text or "Close")
        self.cancel_button.setEnabled(True)

    def _append_log(self, message):
        """Append a bounded log entry without pumping the event loop on every line."""
        line = str(message)
        try:
            self.log_box.moveCursor(QTEXTCURSOR_END)
            self.log_box.insertPlainText(line + "\n")
            self.log_box.moveCursor(QTEXTCURSOR_END)
        except Exception:
            # Logging must never cause the cleanup operation itself to fail.
            pass
        try:
            QgsMessageLog.logMessage(line, PLUGIN_TAG, QGIS_LOG_INFO)
        except Exception:
            pass

    def _log_exception(self, context, exc):
        """Write a readable error to the dialog and a full traceback to QGIS Log Messages."""
        summary = f"{context}: {type(exc).__name__}: {exc}"
        trace = traceback.format_exc()
        if not trace or trace.strip() == "NoneType: None":
            trace = "No active traceback was available."
        details = f"{summary}\n\n{trace}"
        try:
            self._diagnostic_errors.append(details)
            # Keep troubleshooting history bounded if an operation encounters many failures.
            self._diagnostic_errors = self._diagnostic_errors[-100:]
        except Exception:
            pass
        self._append_log("ERROR: " + summary)
        try:
            QgsMessageLog.logMessage(details, PLUGIN_TAG, QGIS_LOG_CRITICAL)
        except Exception:
            try:
                QgsMessageLog.logMessage(details, PLUGIN_TAG, QGIS_LOG_WARNING)
            except Exception:
                pass
        return summary

    def _copy_diagnostic_log(self):
        """Copy the visible run log plus detailed exception tracebacks."""
        try:
            parts = [self.log_box.toPlainText()]
            if self._diagnostic_errors:
                parts.append("\n\n========== DETAILED ERROR TRACEBACKS ==========\n")
                parts.extend(self._diagnostic_errors)
            QApplication.clipboard().setText("\n\n".join(parts).strip())
            self._append_log("Diagnostic log copied to clipboard.")
        except Exception as exc:
            self._log_exception("Could not copy diagnostic log", exc)
            self._show_message(
                MB_ICON_WARNING,
                "Could not copy log",
                "The diagnostic log could not be copied automatically. You can still select and copy text from the log panel."
            )

    def _clear_log(self):
        try:
            self.log_box.clear()
            self._diagnostic_errors = []
            self.progress.setFormat("Ready")
            self.progress.setValue(0)
        except Exception as exc:
            self._log_exception("Could not clear log", exc)

    @staticmethod
    def _value_key(value):
        if value is None:
            return ("NULL", "")
        try:
            if hasattr(value, "isNull") and callable(value.isNull) and value.isNull():
                return ("NULL", "")
        except Exception:
            pass
        return (type(value).__name__, str(value))

    @staticmethod
    def _display_id(value):
        if value is None:
            return "(NULL)"
        value_text = str(value)
        if not value_text.strip():
            return "(blank)"
        return value_text

    @staticmethod
    def _geometry_label(layer):
        try:
            geom_type = layer.geometryType()
            if geom_type == QgsWkbTypes.PointGeometry:
                return "Point"
            if geom_type == QgsWkbTypes.LineGeometry:
                return "Line"
            if geom_type == QgsWkbTypes.PolygonGeometry:
                return "Polygon"
            return "Geometry"
        except Exception:
            return "Geometry"

    def _find_boundary_layer(self):
        matches = QgsProject.instance().mapLayersByName(BOUNDARY_LAYER_NAME)
        for layer in matches:
            if layer and layer.isValid() and layer.type() == QgsMapLayer.VectorLayer:
                return layer
        return None

    def _set_all_boundary_checks(self, state):
        self.boundary_list.blockSignals(True)
        for index in range(self.boundary_list.count()):
            self.boundary_list.item(index).setCheckState(state)
        self.boundary_list.blockSignals(False)
        self._update_counts()

    def _set_all_target_checks(self, state):
        self.target_list.blockSignals(True)
        for index in range(self.target_list.count()):
            self.target_list.item(index).setCheckState(state)
        self.target_list.blockSignals(False)
        self._update_counts()

    def _update_counts(self, _item=None):
        boundary_checked = sum(
            1 for i in range(self.boundary_list.count())
            if self.boundary_list.item(i).checkState() == QT_CHECKED
        )
        target_checked = sum(
            1 for i in range(self.target_list.count())
            if self.target_list.item(i).checkState() == QT_CHECKED
        )
        self.boundary_count_label.setText(f"{boundary_checked} selected")
        self.select_all_button.setEnabled(self.target_list.count() > 0 and not self._is_processing and not self._is_preparing)
        self.select_none_button.setEnabled(self.target_list.count() > 0 and not self._is_processing and not self._is_preparing)
        self.select_all_ids_button.setEnabled(self.boundary_list.count() > 0 and not self._is_processing and not self._is_preparing)
        self.clear_ids_button.setEnabled(self.boundary_list.count() > 0 and not self._is_processing and not self._is_preparing)
        self.delete_other_boundaries_checkbox.setEnabled(
            self.boundary_list.count() > 0 and not self._is_processing
        )
        self.execute_button.setEnabled(
            not self._is_processing and not self._is_preparing and self.boundary_list.count() > 0 and self.target_list.count() > 0
        )
        self.execute_button.setToolTip(f"{boundary_checked} boundary ID(s), {target_checked} target layer(s) checked")

    def refresh_lists(self, show_log_message=False):
        """Refresh UI choices while containing provider/layer errors."""
        try:
            self._refresh_lists_impl(show_log_message=show_log_message)
        except Exception as exc:
            self._log_exception("Refreshing boundary/layer lists failed", exc)
            try:
                self.boundary_list.blockSignals(False)
                self.target_list.blockSignals(False)
                self._update_counts()
            except Exception:
                pass
            if show_log_message:
                self._show_message(
                    MB_ICON_WARNING,
                    "Refresh completed with an error",
                    "QGIS could not read one or more layers. Check the Processing log and use Copy diagnostic log to share the detailed error.\n\n"
                    f"Details: {type(exc).__name__}: {exc}"
                )

    def _refresh_lists_impl(self, show_log_message=False):
        if not hasattr(self, "boundary_list"):
            return
        self.boundary_list.blockSignals(True)
        self.target_list.blockSignals(True)
        self.boundary_list.clear()
        self.target_list.clear()
        project = QgsProject.instance()
        boundary_layer = self._find_boundary_layer()
        self._boundary_field_index = -1

        if boundary_layer is None:
            self.boundary_source_label.setText("Source unavailable: add a valid 'FDA Boundaries' vector layer")
        else:
            field_names = [field.name() for field in boundary_layer.fields()]
            for idx, name in enumerate(field_names):
                if name.lower() == BOUNDARY_ID_FIELD.lower():
                    self._boundary_field_index = idx
                    break
            self.boundary_source_label.setText(
                f"Source: {boundary_layer.name()}  |  Field: {BOUNDARY_ID_FIELD}"
            )
            if self._boundary_field_index >= 0:
                try:
                    # Provider-backed uniqueValues can use a database DISTINCT query and
                    # avoids fetching every geometry just to populate the ID checklist.
                    values = list(boundary_layer.uniqueValues(self._boundary_field_index))
                    self._append_log(
                        f"Loaded {len(values):,} distinct '{BOUNDARY_ID_FIELD}' value(s) using the provider."
                    )
                except Exception as unique_exc:
                    self._append_log(
                        f"Provider unique-value query unavailable; scanning the boundary layer instead "
                        f"({type(unique_exc).__name__}: {unique_exc})."
                    )
                    unique_values = {}
                    for feature in boundary_layer.getFeatures():
                        value = feature.attribute(self._boundary_field_index)
                        unique_values.setdefault(self._value_key(value), value)
                    values = list(unique_values.values())
                values.sort(key=lambda value: (self._display_id(value).casefold(), self._value_key(value)))
                for value in values:
                    item = QListWidgetItem(self._display_id(value))
                    item.setFlags(item.flags() | QT_ITEM_CHECKABLE | QT_ITEM_ENABLED | QT_ITEM_SELECTABLE)
                    item.setCheckState(QT_UNCHECKED)
                    item.setData(QT_USER_ROLE, value)
                    self.boundary_list.addItem(item)
            else:
                self._append_log(
                    f"ERROR: '{BOUNDARY_LAYER_NAME}' does not contain the required '{BOUNDARY_ID_FIELD}' field."
                )

        target_layers = []
        for layer in project.mapLayers().values():
            if not layer or not layer.isValid() or layer.type() != QgsMapLayer.VectorLayer:
                continue
            if boundary_layer is not None and layer.id() == boundary_layer.id():
                continue
            if layer.geometryType() == QgsWkbTypes.NullGeometry:
                continue
            target_layers.append(layer)
        target_layers.sort(key=lambda lyr: (lyr.name().casefold(), lyr.id()))
        for layer in target_layers:
            display = f"{layer.name()}   ·   {self._geometry_label(layer)}"
            item = QListWidgetItem(display)
            item.setFlags(item.flags() | QT_ITEM_CHECKABLE | QT_ITEM_ENABLED | QT_ITEM_SELECTABLE)
            # Match the original script's default behavior: all eligible vector layers are selected.
            item.setCheckState(QT_CHECKED)
            item.setData(QT_USER_ROLE, layer.id())
            self.target_list.addItem(item)

        self.boundary_list.blockSignals(False)
        self.target_list.blockSignals(False)
        self._update_counts()

        if show_log_message:
            self._append_log(
                f"Refreshed lists: {self.boundary_list.count()} boundary ID value(s), "
                f"{self.target_list.count()} target layer(s)."
            )

    def closeEvent(self, event):
        """Prevent the dialog from being destroyed while a cleanup is running."""
        if self._is_processing or self._is_preparing:
            self._show_message(
                MB_ICON_WARNING,
                "Cleanup is running",
                "Use the Cancel button to request a safe stop. The dialog cannot close during provider operations or commits.",
            )
            event.ignore()
            return
        event.accept()

    # ------------------------------------------------------------------
    # Processing
    # ------------------------------------------------------------------
    def execute_cleanup(self):
        """Top-level safety net with a preparation guard and safe cancellation handling."""
        if self._is_processing or self._is_preparing:
            return
        self._is_preparing = True
        self._cancel_requested = False
        self._set_busy_controls(True, "Cancel preparation")
        try:
            self._execute_cleanup_impl()
        except _CleanupCancelled as exc:
            self._append_log(str(exc))
            self._append_log("No uncommitted changes from this preparation phase were made.")
            self._show_message(
                MB_ICON_INFORMATION,
                "Cleanup cancelled",
                f"{exc} No layer edits were made during preparation.",
            )
        except Exception as exc:
            summary = self._log_exception("Unexpected cleanup preparation/runtime error", exc)
            self._show_message(
                MB_ICON_CRITICAL,
                "Cleanup stopped safely",
                "An unexpected error stopped the operation. Review the log and use Copy diagnostic log.\n\n"
                + summary,
            )
        finally:
            self._is_preparing = False
            self._is_processing = False
            self._cancel_requested = False
            self._set_busy_controls(False, "Close")
            self._update_counts()

    def _execute_cleanup_impl(self):
        if self._is_processing:
            return

        boundary_layer = self._find_boundary_layer()
        if boundary_layer is None:
            self._show_message(
                MB_ICON_CRITICAL,
                "Boundary layer not found",
                f"A valid vector layer named '{BOUNDARY_LAYER_NAME}' is required. Add it to the project and click Refresh.",
            )
            return

        field_index = -1
        for idx, field in enumerate(boundary_layer.fields()):
            if field.name().lower() == BOUNDARY_ID_FIELD.lower():
                field_index = idx
                break
        if field_index < 0:
            self._show_message(
                MB_ICON_CRITICAL,
                "Required field missing",
                f"The '{BOUNDARY_LAYER_NAME}' layer must contain an '{BOUNDARY_ID_FIELD}' field.",
            )
            return

        selected_ids = []
        for index in range(self.boundary_list.count()):
            item = self.boundary_list.item(index)
            if item.checkState() == QT_CHECKED:
                selected_ids.append(item.data(QT_USER_ROLE))
        if not selected_ids:
            self._show_message(
                MB_ICON_WARNING,
                "Choose a boundary",
                "Select at least one FDA boundary infinium_id before executing cleanup.",
            )
            return

        selected_layers = []
        project = QgsProject.instance()
        for index in range(self.target_list.count()):
            item = self.target_list.item(index)
            if item.checkState() != QT_CHECKED:
                continue
            layer_id = item.data(QT_USER_ROLE)
            layer = project.mapLayer(layer_id)
            if layer is not None and layer.isValid():
                selected_layers.append(layer)
        if not selected_layers:
            self._show_message(
                MB_ICON_WARNING,
                "Choose target layers",
                "Select at least one target layer to clean. Use the layer checkboxes to choose which layers are modified.",
            )
            return

        selected_keys = {self._value_key(value) for value in selected_ids}
        delete_other_boundaries = self.delete_other_boundaries_checkbox.isChecked()
        boundary_geometries = []
        other_boundary_feature_ids = []
        self.progress.setRange(0, 0)
        self.progress.setFormat("Reading selected FDA boundary features...")
        self._append_log("Reading FDA Boundaries source features...")
        QApplication.processEvents()
        boundary_scan_count = 0
        boundary_request = QgsFeatureRequest()
        try:
            boundary_request.setSubsetOfAttributes([field_index], boundary_layer.fields())
        except Exception as request_exc:
            self._append_log(
                f"Attribute-subset optimization unavailable; using default boundary request "
                f"({type(request_exc).__name__}: {request_exc})."
            )
        for feature in boundary_layer.getFeatures(boundary_request):
            boundary_scan_count += 1
            feature_key = self._value_key(feature.attribute(field_index))
            if feature_key not in selected_keys:
                if delete_other_boundaries:
                    other_boundary_feature_ids.append(feature.id())
                continue
            geom = feature.geometry()
            if geom and not geom.isEmpty():
                boundary_geometries.append(QgsGeometry(geom))
            if boundary_scan_count % 250 == 0:
                self.progress.setFormat(
                    f"Reading FDA Boundaries: {boundary_scan_count:,} feature(s)..."
                )
                self._ui_checkpoint("FDA boundary scan")
        self._ui_checkpoint("FDA boundary scan completion")
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setFormat("Preparing boundary geometry...")
        if not boundary_geometries:
            self._show_message(
                MB_ICON_WARNING,
                "No usable boundary geometry",
                "The selected infinium_id value(s) did not produce any non-empty boundary geometries. Check the FDA Boundaries data.",
            )
            return

        # Dissolve only the chosen boundary IDs, as requested.
        try:
            self._append_log(
                f"Dissolving {len(boundary_geometries):,} selected boundary geometry(ies)..."
            )
            self.progress.setFormat("Dissolving selected boundary geometries...")
            QApplication.processEvents()
            union_chunk_size = 200
            if len(boundary_geometries) > union_chunk_size:
                partial_unions = []
                total_chunks = (len(boundary_geometries) + union_chunk_size - 1) // union_chunk_size
                for chunk_index, offset in enumerate(range(0, len(boundary_geometries), union_chunk_size), start=1):
                    chunk = boundary_geometries[offset:offset + union_chunk_size]
                    partial = QgsGeometry.unaryUnion(chunk)
                    if not partial or partial.isEmpty():
                        raise RuntimeError(
                            f"Boundary dissolve chunk {chunk_index}/{total_chunks} produced an empty geometry."
                        )
                    partial_unions.append(partial)
                    self.progress.setFormat(f"Dissolving boundaries: chunk {chunk_index}/{total_chunks}")
                    self._ui_checkpoint("boundary dissolve")
                boundary_geometries.clear()
                boundary_geom = QgsGeometry.unaryUnion(partial_unions)
                partial_unions.clear()
            else:
                boundary_geom = QgsGeometry.unaryUnion(boundary_geometries)
            self._ui_checkpoint("boundary dissolve completion")
            if not boundary_geom or boundary_geom.isEmpty():
                raise RuntimeError("The dissolved boundary geometry is empty.")
        except Exception as exc:
            self._log_exception("Selected FDA boundary dissolve failed", exc)
            self._show_message(
                MB_ICON_CRITICAL,
                "Boundary dissolve failed",
                f"Could not dissolve the selected FDA boundary geometries.\nDetails: {exc}",
            )
            return

        if not boundary_layer.crs().isValid():
            self._show_message(
                MB_ICON_CRITICAL,
                "Invalid boundary CRS",
                "The FDA Boundaries layer has an invalid CRS. Assign the correct CRS before running cleanup.",
            )
            return

        if not boundary_layer.crs().isValid():
            self._show_message(
                MB_ICON_CRITICAL,
                "Invalid boundary CRS",
                "The FDA Boundaries layer has an invalid CRS. Assign the correct CRS before running cleanup.",
            )
            return

        buffer_feet = float(self.buffer_spin.value())
        map_units = boundary_layer.crs().mapUnits()
        if map_units == QgsUnitTypes.DistanceFeet:
            buffer_distance = buffer_feet
            conversion_note = f"Boundary CRS units are feet; using {buffer_distance:g} map units."
        elif map_units == QgsUnitTypes.DistanceMeters:
            buffer_distance = buffer_feet * 0.3048
            conversion_note = f"Boundary CRS units are metres; using {buffer_distance:g} map units ({buffer_feet:g} ft × 0.3048)."
        else:
            # Preserve the exact legacy behavior requested by the user.
            buffer_distance = LEGACY_FALLBACK_MAP_UNITS
            conversion_note = (
                f"WARNING: Boundary CRS units are not feet or metres; using the legacy fixed fallback "
                f"of {LEGACY_FALLBACK_MAP_UNITS} map units, regardless of the entered feet value. "
                "If the CRS uses degrees, this is 6.096 degrees and may cover a very large area; "
                "verify the boundary CRS before continuing."
            )

        try:
            self._append_log(f"Creating {buffer_distance:g}-unit tolerance buffer...")
            self.progress.setFormat("Creating tolerance buffer...")
            QApplication.processEvents()
            boundary_buffer = boundary_geom.buffer(buffer_distance, 16)
            if not boundary_buffer or boundary_buffer.isEmpty():
                raise RuntimeError("The buffered boundary geometry is empty.")
        except Exception as exc:
            self._log_exception("Tolerance buffer creation failed", exc)
            self._show_message(
                MB_ICON_CRITICAL,
                "Buffer creation failed",
                f"Could not create the boundary tolerance buffer.\nDetails: {exc}",
            )
            return

        # Pre-compute all CRS transforms before editing any target layer. This prevents a
        # transform error from being discovered only after some layers have been modified.
        buffers_by_layer = {}
        try:
            for transform_index, layer in enumerate(selected_layers, start=1):
                self.progress.setFormat(
                    f"Preparing CRS {transform_index}/{len(selected_layers)}: {layer.name()}"
                )
                self._ui_checkpoint("coordinate-system preparation")
                if not layer.crs().isValid():
                    raise RuntimeError(f"Target layer '{layer.name()}' has an invalid CRS.")
                if layer.crs() == boundary_layer.crs():
                    buffers_by_layer[layer.id()] = QgsGeometry(boundary_buffer)
                    continue
                if not boundary_layer.crs().isValid() or not layer.crs().isValid():
                    raise RuntimeError(
                        f"Cannot transform buffer for layer '{layer.name()}': source or target CRS is invalid."
                    )
                transform = QgsCoordinateTransform(
                    boundary_layer.crs(), layer.crs(), project.transformContext()
                )
                layer_buffer = QgsGeometry(boundary_buffer)
                result = layer_buffer.transform(transform)
                if result is not None:
                    try:
                        result_code = int(result)
                    except Exception:
                        result_code = 0
                    if result_code != 0:
                        raise RuntimeError(
                            f"Coordinate transformation failed for layer '{layer.name()}' (result {result_code})."
                        )
                if layer_buffer.isEmpty():
                    raise RuntimeError(f"Transformed buffer is empty for layer '{layer.name()}'.")
                buffers_by_layer[layer.id()] = layer_buffer
        except Exception as exc:
            self._log_exception("CRS pre-check failed", exc)
            self._show_message(
                MB_ICON_CRITICAL,
                "CRS pre-check failed",
                f"No target layer has been edited. Fix the CRS issue and try again.\nDetails: {exc}",
            )
            return

        checked_id_names = [self._display_id(value) for value in selected_ids]
        editable_layers = [layer.name() for layer in selected_layers if layer.isEditable()]
        if delete_other_boundaries and boundary_layer.isEditable():
            editable_layers.append(f"{boundary_layer.name()} (FDA boundary layer)")
        detail_message = (
            "This operation will delete target-layer features that do not intersect the selected FDA boundary footprint "
            "or its tolerance buffer.\n\n"
            f"Boundary infinium_id value(s) to keep: {', '.join(checked_id_names)}\n"
            f"Target layers to clean: {len(selected_layers)}\n"
            f"Tolerance entered: {buffer_feet:g} ft\n"
            f"Buffer behavior: {conversion_note}\n"
        )
        if delete_other_boundaries:
            detail_message += (
                f"\nFDA Boundaries records to delete: {len(other_boundary_feature_ids)}\n"
                "All FDA Boundaries records matching the selected ID(s) will be kept; records with other IDs "
                "will be deleted."
            )
        else:
            detail_message += "\nFDA Boundaries source records: unchanged."
        detail_message += "\n\nDeleted features cannot be recovered. Take a backup to avoid data loss."
        if editable_layers:
            preview = ", ".join(editable_layers[:5])
            if len(editable_layers) > 5:
                preview += f", and {len(editable_layers) - 5} more"
            detail_message += (
                "\n\nWARNING: These layers are already in edit mode: " + preview + ". "
                "If cleanup deletes features in those layers, their existing pending edits may also be committed."
            )
        detail_message += "\n\nProceed with cleanup?"
        if not self._confirm("Confirm destructive cleanup", detail_message):
            self._append_log("Cleanup cancelled by user; no changes made.")
            return

        self._is_processing = True
        self._is_preparing = False
        self.cancel_button.setText("Cancel cleanup")
        self.cancel_button.setEnabled(True)
        self.log_box.clear()
        self._diagnostic_errors = []
        self.clear_log_button.setEnabled(False)
        self.progress.setValue(0)
        self._append_log("FDA Boundary Cleanup started.")
        self._append_log(f"Selected boundary ID(s) to keep: {', '.join(checked_id_names)}")
        self._append_log(f"Target layers selected: {len(selected_layers)}")
        if delete_other_boundaries:
            self._append_log(
                f"Other FDA Boundaries records queued for deletion: {len(other_boundary_feature_ids)}"
            )
        else:
            self._append_log("Other FDA Boundaries records will be left unchanged.")
        self._append_log(conversion_note)

        deleted_total = 0
        boundary_deleted_total = 0
        committed_layers = 0
        failed_layers = []
        cancelled = False
        # Avoid querying featureCount() for every source up front: remote/database providers
        # may need a costly full count, which used to make QGIS appear frozen before scanning.
        # Progress therefore advances by layer; per-layer scan counts are shown in the bar text.
        self.progress.setRange(0, len(selected_layers))
        self.progress.setValue(0)
        self.progress.setTextVisible(True)
        self.progress.setFormat(f"0 / {len(selected_layers)} layers")
        processed_features = 0

        try:
            for layer_index, layer in enumerate(selected_layers, start=1):
                self.progress.setValue(layer_index - 1)
                self.progress.setFormat(f"Layer {layer_index}/{len(selected_layers)}: preparing {layer.name()}")
                self._append_log(f"[{layer_index}/{len(selected_layers)}] Cleaning layer: {layer.name()}")
                self._ui_checkpoint("layer preparation")
                target_buffer = buffers_by_layer[layer.id()]

                # Prepared geometry engines can greatly speed up repeated intersection checks.
                # Geometry is only read in this scan; edits/commits remain on the main thread.
                geometry_engine = None
                try:
                    geometry_engine = QgsGeometry.createGeometryEngine(target_buffer.constGet())
                    if geometry_engine is not None:
                        geometry_engine.prepareGeometry()
                except Exception as engine_exc:
                    geometry_engine = None
                    self._append_log(
                        f"  Note: prepared spatial test unavailable for '{layer.name()}'; "
                        f"using standard intersects checks ({type(engine_exc).__name__}: {engine_exc})."
                    )

                was_editable = layer.isEditable()
                if not was_editable:
                    if not layer.startEditing():
                        failed_layers.append(f"{layer.name()}: could not start editing (provider may be read-only).")
                        self._append_log(f"  ERROR: Could not start editing '{layer.name()}'.")
                        continue

                delete_ids = []
                geometry_check_errors = 0
                scanned_in_layer = 0
                try:
                    # No attribute columns are required for this geometry-only test. Limiting
                    # the request can reduce database/network transfer on large PostGIS layers.
                    feature_request = QgsFeatureRequest()
                    try:
                        feature_request.setNoAttributes()
                    except Exception:
                        try:
                            feature_request.setSubsetOfAttributes([])
                        except Exception:
                            pass
                    for feature in layer.getFeatures(feature_request):
                        processed_features += 1
                        scanned_in_layer += 1
                        geom = feature.geometry()
                        # Preserve empty/missing geometries, matching the original script.
                        if not geom or geom.isEmpty():
                            pass
                        else:
                            try:
                                # target_buffer and feature geometry are now in the same CRS.
                                if geometry_engine is not None:
                                    try:
                                        intersects = geometry_engine.intersects(geom.constGet())
                                    except Exception:
                                        # Compatibility fallback for QGIS/provider edge cases.
                                        intersects = geom.intersects(target_buffer)
                                else:
                                    intersects = geom.intersects(target_buffer)
                                if not intersects:
                                    delete_ids.append(feature.id())
                            except Exception as exc:
                                # Be conservative: if an intersection test fails, keep that feature.
                                geometry_check_errors += 1
                                if geometry_check_errors <= 3:
                                    self._append_log(
                                        f"  WARNING: Could not test feature {feature.id()} "
                                        f"({type(exc).__name__}: {exc}); keeping it."
                                    )

                        # Yield regularly so the dialog can repaint and QGIS can process UI events.
                        # More frequent updates also make long scans visibly active on slower PCs.
                        if scanned_in_layer % 25 == 0:
                            self.progress.setFormat(
                                f"Layer {layer_index}/{len(selected_layers)} | {scanned_in_layer:,} scanned"
                            )
                            self._ui_checkpoint(f"scanning layer '{layer.name()}'")
                        if scanned_in_layer % 1000 == 0:
                            self._append_log(
                                f"  Progress: {scanned_in_layer:,} feature(s) scanned; "
                                f"{len(delete_ids):,} queued for deletion so far."
                            )
                except _CleanupCancelled:
                    if not was_editable and layer.isEditable():
                        layer.rollBack()
                    raise
                except Exception as exc:
                    failed_layers.append(f"{layer.name()}: feature scan failed ({type(exc).__name__}: {exc}).")
                    self._log_exception(f"Feature scan failed for layer '{layer.name()}'", exc)
                    if not was_editable and layer.isEditable():
                        layer.rollBack()
                    continue

                if geometry_check_errors:
                    self._append_log(
                        f"  Warning: {geometry_check_errors} geometry intersection test(s) failed; those features were preserved."
                    )

                if not delete_ids:
                    self._append_log("  Nothing outside the buffered boundary; no features deleted.")
                    if not was_editable and layer.isEditable():
                        layer.rollBack()
                    continue

                edit_command_open = False
                try:
                    # Group the plugin's edits into one undo command. This lets cancellation
                    # undo only this cleanup operation without discarding a user's prior edits.
                    layer.beginEditCommand("FDA Boundary Cleanup — delete outside features")
                    edit_command_open = True
                    delete_batch_size = 250
                    for offset in range(0, len(delete_ids), delete_batch_size):
                        batch = delete_ids[offset:offset + delete_batch_size]
                        delete_result = layer.deleteFeatures(batch)
                        if delete_result is False:
                            raise RuntimeError(
                                f"QGIS reported a deletion failure in batch starting at feature {offset + 1}."
                            )
                        self.progress.setFormat(
                            f"Layer {layer_index}/{len(selected_layers)} | queued "
                            f"{min(offset + len(batch), len(delete_ids)):,}/{len(delete_ids):,} deletes"
                        )
                        self._ui_checkpoint(f"deleting features from '{layer.name()}'")
                    layer.endEditCommand()
                    edit_command_open = False
                except _CleanupCancelled:
                    if edit_command_open:
                        try:
                            layer.destroyEditCommand()
                        except Exception as rollback_exc:
                            self._log_exception(
                                f"Could not undo the interrupted delete command on '{layer.name()}'", rollback_exc
                            )
                    if not was_editable and layer.isEditable():
                        layer.rollBack()
                    raise
                except Exception as exc:
                    if edit_command_open:
                        try:
                            layer.destroyEditCommand()
                        except Exception as rollback_exc:
                            self._log_exception(
                                f"Could not undo the failed delete command on '{layer.name()}'", rollback_exc
                            )
                    failed_layers.append(f"{layer.name()}: delete operation failed ({type(exc).__name__}: {exc}).")
                    self._log_exception(f"Feature deletion failed for layer '{layer.name()}'", exc)
                    if not was_editable and layer.isEditable():
                        layer.rollBack()
                    continue

                try:
                    self.progress.setFormat(f"Committing edits to '{layer.name()}' (provider may take time)...")
                    self._append_log(
                        f"  Committing {len(delete_ids):,} deletion(s) for '{layer.name()}'. "
                        "The provider commit itself cannot be cancelled once started."
                    )
                    commit_result = layer.commitChanges()
                except Exception as exc:
                    commit_result = False
                    commit_exception = str(exc)
                else:
                    commit_exception = ""

                if not commit_result:
                    errors = []
                    try:
                        errors = layer.commitErrors()
                    except Exception:
                        pass
                    error_text = "; ".join(str(error) for error in errors if str(error).strip())
                    if commit_exception:
                        error_text = (error_text + "; " + commit_exception).strip("; ")
                    if not error_text:
                        error_text = "provider rejected the commit"
                    failed_layers.append(f"{layer.name()}: commit failed ({error_text}).")
                    self._append_log(f"  ERROR: Commit failed: {error_text}")
                    # Only roll back edit buffers created by this plugin. Never roll back
                    # a user's pre-existing edit buffer, which could discard unrelated edits.
                    if not was_editable and layer.isEditable():
                        layer.rollBack()
                    else:
                        self._append_log("  Pending edits were left in the existing edit session for review.")
                    continue

                deleted_total += len(delete_ids)
                committed_layers += 1
                layer.triggerRepaint()
                self._append_log(f"  Deleted and committed: {len(delete_ids)} feature(s).")
                self._ui_checkpoint(f"post-commit checkpoint for '{layer.name()}'")

            # Delete all source boundary records whose infinium_id was not selected.
            # This is kept as a separate, explicitly confirmed operation because it
            # modifies the FDA Boundaries source layer as well as the target layers.
            if delete_other_boundaries:
                if not other_boundary_feature_ids:
                    self._append_log(
                        "No other FDA Boundaries records found; all source records already match selected ID(s)."
                    )
                else:
                    self._append_log(
                        f"Deleting {len(other_boundary_feature_ids)} other FDA Boundaries record(s)..."
                    )
                    was_editable = boundary_layer.isEditable()
                    boundary_edit_command_open = False
                    try:
                        if not was_editable and not boundary_layer.startEditing():
                            raise RuntimeError(
                                "could not start editing the FDA Boundaries layer (provider may be read-only)."
                            )

                        boundary_layer.beginEditCommand("FDA Boundary Cleanup — delete unselected boundary records")
                        boundary_edit_command_open = True
                        delete_batch_size = 250
                        for offset in range(0, len(other_boundary_feature_ids), delete_batch_size):
                            batch = other_boundary_feature_ids[offset:offset + delete_batch_size]
                            delete_result = boundary_layer.deleteFeatures(batch)
                            if delete_result is False:
                                raise RuntimeError(
                                    f"QGIS reported a boundary deletion failure in batch starting at feature {offset + 1}."
                                )
                            self.progress.setFormat(
                                "FDA Boundaries | queued "
                                f"{min(offset + len(batch), len(other_boundary_feature_ids)):,}/"
                                f"{len(other_boundary_feature_ids):,} deletes"
                            )
                            self._ui_checkpoint("deleting unselected FDA boundary records")

                        boundary_layer.endEditCommand()
                        boundary_edit_command_open = False
                        try:
                            self.progress.setFormat("Committing FDA Boundaries edits (provider may take time)...")
                            self._append_log(
                                "  Committing deletions in FDA Boundaries. The provider commit itself cannot be cancelled once started."
                            )
                            commit_result = boundary_layer.commitChanges()
                        except Exception as exc:
                            commit_result = False
                            commit_exception = str(exc)
                        else:
                            commit_exception = ""

                        if not commit_result:
                            errors = []
                            try:
                                errors = boundary_layer.commitErrors()
                            except Exception:
                                pass
                            error_text = "; ".join(str(error) for error in errors if str(error).strip())
                            if commit_exception:
                                error_text = (error_text + "; " + commit_exception).strip("; ")
                            if not error_text:
                                error_text = "provider rejected the commit"
                            raise RuntimeError(f"commit failed ({error_text}).")

                        boundary_deleted_total = len(other_boundary_feature_ids)
                        boundary_layer.triggerRepaint()
                        self._append_log(
                            f"  Deleted and committed: {boundary_deleted_total} other FDA Boundaries record(s)."
                        )
                        self._ui_checkpoint("post-commit checkpoint for FDA Boundaries")
                    except _CleanupCancelled:
                        if boundary_edit_command_open:
                            try:
                                boundary_layer.destroyEditCommand()
                            except Exception as rollback_exc:
                                self._log_exception("Could not undo interrupted FDA Boundaries delete command", rollback_exc)
                        if not was_editable and boundary_layer.isEditable():
                            boundary_layer.rollBack()
                        raise
                    except Exception as exc:
                        if boundary_edit_command_open:
                            try:
                                boundary_layer.destroyEditCommand()
                            except Exception as rollback_exc:
                                self._log_exception("Could not undo failed FDA Boundaries delete command", rollback_exc)
                        failed_layers.append(f"{boundary_layer.name()}: other-boundary deletion failed ({type(exc).__name__}: {exc}).")
                        self._log_exception("Other FDA Boundaries deletion failed", exc)
                        # Only roll back an edit session created by this plugin.
                        if not was_editable and boundary_layer.isEditable():
                            boundary_layer.rollBack()
                        elif was_editable:
                            self._append_log(
                                "  The FDA Boundaries layer was already in edit mode; pending edits were left for review."
                            )

            self.progress.setRange(0, len(selected_layers))
            self.progress.setValue(len(selected_layers))
            self.progress.setFormat(f"Finished: {len(selected_layers)} layer(s) checked")
            self._append_log("Cleanup processing finished.")
        except _CleanupCancelled as exc:
            cancelled = True
            self._append_log(str(exc))
            self._append_log(
                "Cleanup stopped at a safe checkpoint. Layers already committed before cancellation remain changed; "
                "the current uncommitted layer was rolled back where possible."
            )
        except Exception as exc:
            failed_layers.append(f"Unexpected processing error: {type(exc).__name__}: {exc}")
            self._log_exception("Fatal processing error", exc)
        finally:
            self._is_processing = False
            self.progress.setTextVisible(True)
            self.cancel_button.setText("Close")
            self._set_busy_controls(False, "Close")
            self._update_counts()

        summary = (
            ("Cleanup run was cancelled at a safe checkpoint.\n\n" if cancelled else "Cleanup run finished.\n\n")
            + f"Target-layer features deleted and committed: {deleted_total}\n"
            f"Other FDA Boundaries records deleted and committed: {boundary_deleted_total}\n"
            f"Target layers with committed deletions: {committed_layers}\n"
            f"Boundary IDs kept: {len(selected_ids)}\n"
            f"Tolerance entered: {buffer_feet:g} ft\n"
            f"Effective buffer distance: {buffer_distance:g} map units in the boundary CRS\n\n"
            "Empty geometries and features whose intersection check failed were preserved."
        )
        if cancelled:
            summary += "\n\nPreviously committed layers remain changed. The active uncommitted layer was rolled back where possible."
        if failed_layers:
            summary += "\n\nSome layers were not fully processed:\n• " + "\n• ".join(failed_layers[:8])
            if len(failed_layers) > 8:
                summary += f"\n• And {len(failed_layers) - 8} more issue(s); see the log box."
            self._show_message(MB_ICON_WARNING, "Cleanup completed with warnings", summary)
        elif cancelled:
            self._show_message(MB_ICON_WARNING, "Cleanup cancelled", summary)
        elif deleted_total == 0 and boundary_deleted_total == 0:
            self._show_message(MB_ICON_INFORMATION, "Cleanup finished — nothing deleted", summary)
        else:
            self._show_message(MB_ICON_INFORMATION, "Cleanup completed", summary)
