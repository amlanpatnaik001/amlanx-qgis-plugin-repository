# -*- coding: utf-8 -*-
"""High-Res Map Exporter for QGIS.

Exports the current map canvas view with resolution-aware DPI scaling so
labels, symbols and millimetre-based line widths remain visually balanced.

Copyright © 2077 Amlan Patnaik. All rights reserved.
"""

import os
import re
from datetime import datetime

from qgis.PyQt.QtCore import QSize, Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QProgressDialog
from qgis.core import QgsMapRendererSequentialJob, QgsRectangle, QgsSettings

from .map_exporter_dialog import MapExporterDialog


class MapExporter:
    """QGIS plugin controller."""

    SETTINGS_GROUP = "HighResMapExporter"
    SETTINGS_DIRECTORY = "lastOutputDirectory"
    DEFAULT_PREFIX = "map_export"

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.export_action = None
        self.render_job = None
        self.progress_dialog = None
        self._cancel_requested = False
        self._active_path = None
        self._active_config = None

    def tr(self, message):
        from qgis.PyQt.QtCore import QCoreApplication
        return QCoreApplication.translate("MapExporter", message)

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        action = QAction(
            QIcon(icon_path),
            self.tr("High-Res Map Exporter…"),
            self.iface.mainWindow(),
        )
        action.setStatusTip(
            self.tr("Export the current QGIS map view as a high-resolution image")
        )
        action.triggered.connect(self.run)
        self.iface.addToolBarIcon(action)
        self.iface.addPluginToMenu(self.tr("&High-Res Map Exporter"), action)
        self.actions.append(action)
        self.export_action = action

    def unload(self):
        if self.render_job is not None:
            try:
                self._cancel_requested = True
                if hasattr(self.render_job, "cancelWithoutBlocking"):
                    self.render_job.cancelWithoutBlocking()
                else:
                    self.render_job.cancel()
            except Exception:
                pass

        for action in self.actions:
            try:
                action.triggered.disconnect(self.run)
            except (TypeError, RuntimeError):
                pass
            self.iface.removePluginMenu(self.tr("&High-Res Map Exporter"), action)
            self.iface.removeToolBarIcon(action)

        self.actions.clear()
        self.export_action = None

    def _last_directory(self):
        settings = QgsSettings()
        home = os.path.expanduser("~")
        pictures = os.path.join(home, "Pictures")
        default_directory = pictures if os.path.isdir(pictures) else home
        remembered = settings.value(
            f"{self.SETTINGS_GROUP}/{self.SETTINGS_DIRECTORY}",
            default_directory,
            type=str,
        )
        return remembered if os.path.isdir(remembered) else default_directory

    def run(self):
        """Open the export configuration and start rendering."""
        if self.render_job is not None:
            self._message(
                "Export already running",
                "Wait for the current render to finish or cancel it before starting another export.",
                level=1,
                duration=5,
            )
            return

        dialog = MapExporterDialog(
            self.iface.mainWindow(),
            last_directory=self._last_directory(),
        )
        if not dialog.exec_():
            return

        config = dialog.values()
        QgsSettings().setValue(
            f"{self.SETTINGS_GROUP}/{self.SETTINGS_DIRECTORY}",
            config["directory"],
        )
        self._start_export(config)

    def _start_export(self, config):
        try:
            canvas = self.iface.mapCanvas()
            settings = canvas.mapSettings()
            # Use physical canvas pixels when Qt high-DPI scaling is active.
            # Standalone exports are then forced to DPR 1 so the requested
            # width/height correspond to the actual saved image dimensions.
            if hasattr(settings, "deviceOutputSize"):
                source_size = settings.deviceOutputSize()
            else:
                source_size = settings.outputSize()
            source_dpi = float(settings.outputDpi())

            if source_size.width() <= 0 or source_size.height() <= 0:
                raise RuntimeError("QGIS returned an invalid map-canvas size.")
            if source_dpi <= 0:
                raise RuntimeError("QGIS returned an invalid map-rendering DPI.")

            target_width = int(config["width"])
            target_height = int(config["height"])

            # Keep the geographic view and expand, never crop, if aspect ratios differ.
            if config["fit_extent"]:
                self._expand_extent_to_aspect(settings, target_width, target_height)

            # The key fix: scale output DPI with output pixel dimensions. This keeps
            # millimetre-based labels, symbols and line widths proportionate at 4K/8K.
            render_dpi = source_dpi
            if config["scale_symbols"]:
                dpi_scale = target_width / float(source_size.width())
                render_dpi = source_dpi * dpi_scale
                settings.setOutputDpi(render_dpi)

            if hasattr(settings, "setDevicePixelRatio"):
                settings.setDevicePixelRatio(1.0)
            settings.setOutputSize(QSize(target_width, target_height))
            # Do not replace the map background with white. Retain the canvas setting.

            path = self._build_output_path(config)
            self.render_job = QgsMapRendererSequentialJob(settings)
            self._cancel_requested = False
            self._active_path = path
            self._active_config = dict(config, render_dpi=render_dpi)

            progress = QProgressDialog(
                "Preparing high-resolution map render…",
                "Cancel",
                0,
                100,
                self.iface.mainWindow(),
            )
            progress.setWindowTitle("High-Res Map Exporter")
            progress.setWindowModality(Qt.WindowModal)
            progress.setMinimumDuration(0)
            progress.setValue(0)
            progress.canceled.connect(self._cancel_export)
            self.progress_dialog = progress

            self._total_layers = max(1, len(settings.layers()))
            self._rendered_layers = 0
            job = self.render_job
            layer_signal = getattr(job, "layerRendered", None)
            if layer_signal is not None:
                layer_signal.connect(self._update_layer_progress)
            layers_finished_signal = getattr(job, "renderingLayersFinished", None)
            if layers_finished_signal is not None:
                layers_finished_signal.connect(self._layers_finished)
            job.finished.connect(
                lambda current_job=job, output_path=path:
                    self._save_rendered_map(current_job, output_path)
            )

            if self.export_action is not None:
                self.export_action.setEnabled(False)
            progress.show()
            job.start()

            self._message(
                "Map export started",
                f"Rendering {target_width:,} × {target_height:,} pixels at {render_dpi:.1f} DPI.",
                level=0,
                duration=6,
            )

        except Exception as error:
            self._cleanup_render_state()
            self._message("Export could not start", str(error), level=2, duration=10)

    @staticmethod
    def _expand_extent_to_aspect(settings, target_width, target_height):
        """Expand the current map extent to fit target aspect without cropping."""
        extent = settings.extent()
        current_width = extent.width()
        current_height = extent.height()
        if current_width <= 0 or current_height <= 0:
            raise RuntimeError("The current map extent is empty or invalid.")

        target_ratio = float(target_width) / float(target_height)
        current_ratio = current_width / current_height
        center_x = extent.center().x()
        center_y = extent.center().y()

        if current_ratio < target_ratio:
            new_width = current_height * target_ratio
            new_height = current_height
        else:
            new_width = current_width
            new_height = current_width / target_ratio

        settings.setExtent(
            QgsRectangle(
                center_x - new_width / 2.0,
                center_y - new_height / 2.0,
                center_x + new_width / 2.0,
                center_y + new_height / 2.0,
            )
        )

    def _build_output_path(self, config):
        prefix = re.sub(r"[^A-Za-z0-9._-]+", "_", config["prefix"]).strip("._-")
        prefix = prefix or self.DEFAULT_PREFIX
        extension = config["format"]
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        filename = f"{prefix}_{stamp}.{extension}"
        path = os.path.join(config["directory"], filename)

        # Avoid overwriting an existing file even if the system clock repeats.
        counter = 1
        while os.path.exists(path):
            filename = f"{prefix}_{stamp}_{counter:02d}.{extension}"
            path = os.path.join(config["directory"], filename)
            counter += 1
        return path

    def _update_layer_progress(self, _layer_id):
        if self.progress_dialog is None:
            return
        self._rendered_layers = min(
            self._total_layers,
            self._rendered_layers + 1,
        )
        percent = int(90 * self._rendered_layers / self._total_layers)
        self.progress_dialog.setLabelText(
            f"Rendering map layers… {self._rendered_layers}/{self._total_layers}"
        )
        self.progress_dialog.setValue(percent)

    def _layers_finished(self):
        if self.progress_dialog is not None:
            self.progress_dialog.setLabelText("Finishing labels and map composition…")
            self.progress_dialog.setValue(95)

    def _cancel_export(self):
        if self.render_job is None:
            return
        self._cancel_requested = True
        self.progress_dialog.setLabelText("Cancelling map render…")
        try:
            if hasattr(self.render_job, "cancelWithoutBlocking"):
                self.render_job.cancelWithoutBlocking()
            else:
                self.render_job.cancel()
        except Exception as error:
            self._message("Cancellation warning", str(error), level=1, duration=6)

    def _save_rendered_map(self, job, full_path):
        try:
            if self._cancel_requested:
                self._message(
                    "Export cancelled",
                    "The map render was cancelled. No output image was saved.",
                    level=1,
                    duration=5,
                )
                return

            image = job.renderedImage()
            if image.isNull():
                raise RuntimeError("QGIS returned an empty rendered image.")

            expected_width = int(self._active_config["width"])
            expected_height = int(self._active_config["height"])
            actual_width = image.width()
            actual_height = image.height()
            if actual_width != expected_width or actual_height != expected_height:
                raise RuntimeError(
                    "QGIS did not produce the requested image dimensions. "
                    f"Requested {expected_width:,} × {expected_height:,}; "
                    f"received {actual_width:,} × {actual_height:,}. "
                    "The image was not saved to avoid a misleading export."
                )

            render_dpi = float(self._active_config["render_dpi"])
            dots_per_meter = int(round(render_dpi / 0.0254))
            image.setDotsPerMeterX(dots_per_meter)
            image.setDotsPerMeterY(dots_per_meter)

            format_key = self._active_config["format"].lower()
            image_format = {"jpg": "JPG", "png": "PNG", "tif": "TIFF"}[format_key]
            quality = (
                int(self._active_config["quality"])
                if format_key == "jpg"
                else -1
            )
            if not image.save(full_path, image_format, quality):
                raise RuntimeError(
                    "Qt could not save the rendered image. Check the output "
                    "folder permissions, available disk space and image format support."
                )

            file_size_mb = os.path.getsize(full_path) / (1024.0 * 1024.0)
            self._message(
                "Map export completed",
                f"{actual_width:,} × {actual_height:,} px | "
                f"{render_dpi:.1f} DPI | {file_size_mb:.2f} MB | {full_path}",
                level=0,
                duration=12,
            )

        except Exception as error:
            self._message("Export failed", str(error), level=2, duration=12)
        finally:
            self._cleanup_render_state()

    def _cleanup_render_state(self):
        if self.progress_dialog is not None:
            try:
                self.progress_dialog.close()
                self.progress_dialog.deleteLater()
            except RuntimeError:
                pass
        self.progress_dialog = None
        self.render_job = None
        self._active_path = None
        self._active_config = None
        self._cancel_requested = False
        if self.export_action is not None:
            self.export_action.setEnabled(True)

    def _message(self, title, message, level=0, duration=6):
        self.iface.messageBar().pushMessage(
            title,
            message,
            level=level,
            duration=duration,
        )
