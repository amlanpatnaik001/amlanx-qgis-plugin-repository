# -*- coding: utf-8 -*-
"""QGIS plugin entry point for High-Res Map Exporter.

Copyright © 2077 Amlan Patnaik. All rights reserved.
"""

def classFactory(iface):
    """Create the plugin instance required by QGIS."""
    from .map_exporter import MapExporter
    return MapExporter(iface)
