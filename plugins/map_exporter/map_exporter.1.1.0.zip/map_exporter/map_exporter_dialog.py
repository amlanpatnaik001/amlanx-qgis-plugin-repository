# -*- coding: utf-8 -*-
"""Configuration dialog for High-Res Map Exporter.

Copyright © 2077 Amlan Patnaik. All rights reserved.
"""

import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QSpinBox,
    QVBoxLayout,
    QWidget,
    QPushButton,
)


class MapExporterDialog(QDialog):
    """Collect export dimensions, format, rendering and destination settings."""

    PRESETS = (
        ("Full HD (1920 × 1080)", 1920, 1080),
        ("4K UHD (3840 × 2160)", 3840, 2160),
        ("8K UHD (7680 × 4320)", 7680, 4320),
        ("Custom dimensions", None, None),
    )

    def __init__(self, parent=None, last_directory=None):
        super().__init__(parent)
        self.setWindowTitle("High-Res Map Exporter")
        self.setMinimumWidth(540)
        self.resize(590, 490)
        self.setWindowModality(Qt.WindowModal)

        root = QVBoxLayout(self)
        intro = QLabel(
            "Export the current QGIS map view while preserving its layers, "
            "styling and geographic content. High-resolution rendering can "
            "scale labels, symbols and line widths to retain their on-screen "
            "visual proportions."
        )
        intro.setWordWrap(True)
        root.addWidget(intro)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        root.addLayout(form)

        self.preset_combo = QComboBox()
        for label, width, height in self.PRESETS:
            self.preset_combo.addItem(label, (width, height))
        self.preset_combo.setCurrentIndex(2)
        form.addRow("Resolution:", self.preset_combo)

        dimensions = QWidget(self)
        dimensions_layout = QHBoxLayout(dimensions)
        dimensions_layout.setContentsMargins(0, 0, 0, 0)
        self.width_spin = QSpinBox()
        self.width_spin.setRange(320, 20000)
        self.width_spin.setSingleStep(100)
        self.width_spin.setSuffix(" px")
        self.height_spin = QSpinBox()
        self.height_spin.setRange(320, 20000)
        self.height_spin.setSingleStep(100)
        self.height_spin.setSuffix(" px")
        dimensions_layout.addWidget(QLabel("Width"))
        dimensions_layout.addWidget(self.width_spin)
        dimensions_layout.addSpacing(10)
        dimensions_layout.addWidget(QLabel("Height"))
        dimensions_layout.addWidget(self.height_spin)
        form.addRow("Custom size:", dimensions)

        self.format_combo = QComboBox()
        self.format_combo.addItem("JPEG (.jpg)", "jpg")
        self.format_combo.addItem("PNG (.png)", "png")
        self.format_combo.addItem("TIFF (.tif)", "tif")
        form.addRow("Image format:", self.format_combo)

        self.quality_spin = QSpinBox()
        self.quality_spin.setRange(50, 100)
        self.quality_spin.setValue(100)
        self.quality_spin.setSuffix(" / 100")
        form.addRow("JPEG quality:", self.quality_spin)

        folder_widget = QWidget(self)
        folder_layout = QHBoxLayout(folder_widget)
        folder_layout.setContentsMargins(0, 0, 0, 0)
        self.folder_edit = QLineEdit(last_directory or "")
        self.folder_edit.setPlaceholderText("Choose an output folder")
        self.folder_edit.setClearButtonEnabled(True)
        browse_button = QPushButton("Browse…", folder_widget)
        browse_button.clicked.connect(self._browse_folder)
        folder_layout.addWidget(self.folder_edit, 1)
        folder_layout.addWidget(browse_button)
        form.addRow("Save to:", folder_widget)

        self.prefix_edit = QLineEdit("map_export")
        self.prefix_edit.setMaxLength(80)
        form.addRow("Filename prefix:", self.prefix_edit)

        root.addSpacing(6)
        self.scale_symbols_check = QCheckBox(
            "Scale labels, symbols and line widths with export resolution"
        )
        self.scale_symbols_check.setChecked(True)
        self.scale_symbols_check.setToolTip(
            "Recommended. Scales QGIS output DPI in proportion to the pixel "
            "dimensions so millimetre-based text and symbols do not look tiny "
            "in 4K/8K exports."
        )
        root.addWidget(self.scale_symbols_check)

        self.fit_extent_check = QCheckBox(
            "Expand the map extent to fit the output aspect ratio (never crop)"
        )
        self.fit_extent_check.setChecked(True)
        self.fit_extent_check.setToolTip(
            "When the export aspect ratio differs from the QGIS canvas, "
            "expand the shorter map dimension rather than cutting off the view."
        )
        root.addWidget(self.fit_extent_check)

        note = QLabel(
            "The current visible map area and layer styling are used. "
            "The map background is preserved from QGIS. 8K rendering may "
            "require substantial memory."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: palette(mid); font-size: 9pt;")
        root.addWidget(note)

        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel,
            parent=self,
        )
        buttons.accepted.connect(self._validate_and_accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

        copyright_label = QLabel("Copyright © 2077 Amlan Patnaik. All rights reserved.")
        copyright_label.setAlignment(Qt.AlignCenter)
        copyright_label.setStyleSheet("color: palette(mid); font-size: 8pt;")
        root.addWidget(copyright_label)

        self.preset_combo.currentIndexChanged.connect(self._preset_changed)
        self.format_combo.currentIndexChanged.connect(self._format_changed)
        self._preset_changed(self.preset_combo.currentIndex())
        self._format_changed(self.format_combo.currentIndex())

    def _preset_changed(self, index):
        width, height = self.preset_combo.itemData(index)
        is_custom = width is None or height is None
        self.width_spin.setEnabled(is_custom)
        self.height_spin.setEnabled(is_custom)
        if not is_custom:
            self.width_spin.setValue(width)
            self.height_spin.setValue(height)

    def _format_changed(self, _index):
        is_jpeg = self.format_combo.currentData() == "jpg"
        self.quality_spin.setEnabled(is_jpeg)

    def _browse_folder(self):
        current = self.folder_edit.text().strip()
        selected = QFileDialog.getExistingDirectory(
            self,
            "Select map export folder",
            current if os.path.isdir(current) else os.path.expanduser("~"),
        )
        if selected:
            self.folder_edit.setText(os.path.normpath(selected))

    def _validate_and_accept(self):
        folder = self.folder_edit.text().strip()
        if not folder or not os.path.isdir(folder):
            QMessageBox.warning(
                self,
                "Output folder required",
                "Choose an existing folder where the exported map can be saved.",
            )
            return
        if self.width_spin.value() * self.height_spin.value() > 100_000_000:
            QMessageBox.warning(
                self,
                "Resolution too large",
                "The selected image exceeds 100 million pixels. "
                "Choose a smaller output size to reduce memory usage.",
            )
            return
        self.accept()

    def values(self):
        """Return the validated export configuration."""
        return {
            "width": self.width_spin.value(),
            "height": self.height_spin.value(),
            "format": self.format_combo.currentData(),
            "quality": self.quality_spin.value(),
            "directory": os.path.normpath(self.folder_edit.text().strip()),
            "prefix": self.prefix_edit.text().strip() or "map_export",
            "scale_symbols": self.scale_symbols_check.isChecked(),
            "fit_extent": self.fit_extent_check.isChecked(),
        }

