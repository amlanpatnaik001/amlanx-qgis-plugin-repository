# -*- coding: utf-8 -*-
"""QGIS plugin entry controller for the standalone CRS Guardian window."""
# Copyright © 2077 Amlan Patnaik. All rights reserved.
# Author: Amlan Patnaik <amlanpatnaikx@gmail.com>
# Licence: GPL-2.0-or-later.
import os

from qgis.PyQt.QtGui import QIcon

try:
    # QAction moved from QtWidgets to QtGui in Qt 6.
    from qgis.PyQt.QtGui import QAction
except ImportError:  # QGIS / PyQt5
    from qgis.PyQt.QtWidgets import QAction

from . import errors


class CrsGuardian(object):
    """Registers one toolbar/menu action and owns one independent window."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.window = None

    def initGui(self):
        """Create the toolbar/menu action. The UI itself is lazy-loaded."""
        try:
            icon_path = os.path.join(self.plugin_dir, "icon.png")
            icon = QIcon(icon_path) if os.path.isfile(icon_path) else QIcon()
            self.action = QAction(icon, "CRS Guardian", self.iface.mainWindow())
            self.action.setToolTip("Open CRS Guardian in a separate window")
            self.action.triggered.connect(self.open_window)
            self.iface.addToolBarIcon(self.action)
            self.iface.addPluginToMenu("&CRS Guardian", self.action)
        except Exception as exc:
            errors.log_exception("Unable to initialise CRS Guardian GUI", exc)
            raise

    def open_window(self, checked=False):
        """Show, raise and activate the standalone non-dockable window."""
        try:
            if self.window is None:
                from .main_window import CrsGuardianWindow
                self.window = CrsGuardianWindow(self.iface, self.iface.mainWindow())
            self.window.show()
            self.window.raise_()
            self.window.activateWindow()
        except Exception as exc:
            errors.show_error(
                self.iface.mainWindow(), "CRS Guardian could not open",
                "The standalone CRS Guardian window could not be opened.", exc
            )

    def unload(self):
        """Release actions and close the standalone window safely."""
        if self.window is not None:
            try:
                self.window.shutdown()
                self.window.close()
                self.window.deleteLater()
            except Exception as exc:
                errors.log_exception("Unable to close CRS Guardian window", exc)
            self.window = None

        if self.action is not None:
            try:
                self.iface.removePluginMenu("&CRS Guardian", self.action)
                self.iface.removeToolBarIcon(self.action)
                self.action.deleteLater()
            except Exception as exc:
                errors.log_exception("Unable to remove CRS Guardian action", exc)
            self.action = None
