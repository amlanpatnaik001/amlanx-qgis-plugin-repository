# -*- coding: utf-8 -*-
"""Standalone CRS Guardian window with safe, cancellable processing tasks."""
# Copyright © 2077 Amlan Patnaik. All rights reserved.
# Author: Amlan Patnaik <amlanpatnaikx@gmail.com>
# Licence: GPL-2.0-or-later.
import atexit
import csv
import json
import math
import os
import shutil
import sys
import tempfile
from datetime import datetime

from qgis.PyQt.QtCore import Qt, QTimer, QSettings, pyqtSignal
from qgis.PyQt.QtGui import QColor, QFont, QIcon
from qgis.PyQt.QtWidgets import (
    QApplication,
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)
from qgis.core import (
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsPointXY,
    QgsProcessingAlgRunnerTask,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer,
)
from qgis.gui import QgsProjectionSelectionDialog

from . import checker, errors, harmonizer
from .compat import dialog_exec, enum_value, layer_type_value, message_box_button


TARGET_AUTO = 0
TARGET_PROJECT = 1
TARGET_CUSTOM = 2


COLORS = {
    "navy": "#07111F",
    "navy_2": "#0B1930",
    "accent": "#F6C945",
    "accent_hover": "#FFD85C",
    "yellow": "#F6C945",
    "bg": "#091423",
    "surface": "#122139",
    "surface_2": "#172943",
    "border": "#293D5B",
    "text": "#EEF3FC",
    "muted": "#9EADC2",
    "critical": "#FF5364",
    "critical_bg": "#351B2A",
    "warning": "#FF5364",
    "warning_bg": "#351B2A",
    "ok": "#F6C945",
    "ok_bg": "#2B2A25",
}


STYLE = """
/* CRS Guardian dark technical theme: navy surfaces, yellow actions, red warnings. */
QDialog#crsGuardianWindow, QDialog { background: #091423; color: #EEF3FC; }
QWidget { background-color: transparent; font-family: 'Segoe UI', 'Noto Sans', sans-serif; font-size: 10pt; color: #EEF3FC; }
QLabel { background: transparent; color: #EEF3FC; }
QFrame#sidebar { background: #07111F; border: none; }
QLabel#brandName { color: #FFFFFF; font-size: 14pt; font-weight: 800; }
QLabel#brandCaption { color: #9EADC2; font-size: 8pt; letter-spacing: 1px; font-weight: 700; }
QLabel#sidebarSection { color: #8295B0; font-size: 8pt; font-weight: 800; letter-spacing: 1px; padding: 12px 8px 5px 8px; }
QPushButton#navButton { background: transparent; color: #C5D0E0; border: 1px solid transparent; border-radius: 9px; text-align: left; padding: 11px 13px; font-weight: 650; }
QPushButton#navButton:hover { background: #142641; color: #FFFFFF; }
QPushButton#navButton:checked { background: #1B2F4D; color: #F6C945; border: 1px solid #F6C945; }
QLabel#sidebarVersion { color: #8295B0; font-size: 8pt; padding: 10px; }
QFrame#topbar { background: #111F35; border: 1px solid #293D5B; border-radius: 13px; }
QLabel#pageTitle { color: #F4F7FC; font-size: 19pt; font-weight: 800; }
QLabel#pageSubtitle { color: #9EADC2; font-size: 9pt; }
QLabel#eyebrow { color: #AEBBD0; font-size: 8pt; font-weight: 800; letter-spacing: 1px; }
QLabel#sectionTitle { color: #F1F5FC; font-size: 11pt; font-weight: 800; }
QLabel#muted { color: #9EADC2; font-size: 9pt; }
QLabel#pill { background: #2A2A24; color: #F6D96F; border: 1px solid #8B742D; border-radius: 10px; padding: 7px 11px; font-size: 8pt; font-weight: 800; }
QFrame#hero { background: #10213C; border: 1px solid #243A5C; border-radius: 14px; }
QLabel#heroTitle { color: #FFFFFF; font-size: 20pt; font-weight: 800; }
QLabel#heroSubtitle { color: #C4D0E1; font-size: 9pt; }
QFrame#metricCard, QFrame#panelCard, QFrame#infoCard { background: #111F35; border: 1px solid #293D5B; border-radius: 12px; }
QLabel#metricValue { color: #F6C945; font-size: 21pt; font-weight: 800; }
QLabel#metricCaption { color: #9EADC2; font-size: 8pt; font-weight: 800; letter-spacing: .5px; }
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox { background: #0A1729; color: #EEF3FC; border: 1px solid #344A6B; border-radius: 8px; padding: 9px 11px; min-height: 20px; selection-background-color: #66551D; selection-color: #FFFFFF; }
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus { border: 1px solid #F6C945; }
QLineEdit:disabled, QComboBox:disabled { background: #101B2C; color: #687B96; border-color: #263750; }
QComboBox::drop-down { border: none; width: 25px; }
QComboBox QAbstractItemView { background: #101E33; color: #EEF3FC; border: 1px solid #344A6B; selection-background-color: #293D5B; selection-color: #F6D96F; outline: 0; }
QPushButton { background: #172943; color: #DCE6F4; border: 1px solid #344A6B; border-radius: 8px; padding: 9px 13px; font-weight: 650; }
QPushButton:hover { border-color: #F6C945; color: #F6D96F; background: #213452; }
QPushButton:pressed { background: #2B3D56; }
QPushButton:disabled { background: #101B2C; color: #687B96; border-color: #263750; }
QPushButton#primaryButton { background: #F6C945; color: #081321; border: 1px solid #F6C945; padding: 10px 16px; font-weight: 850; }
QPushButton#primaryButton:hover { background: #FFD85C; color: #07111F; border-color: #FFD85C; }
QPushButton#dangerButton { background: #351B2A; color: #FF7A86; border: 1px solid #A93649; }
QPushButton#dangerButton:hover { background: #4A1F31; color: #FFFFFF; border-color: #FF5364; }
QPushButton#softButton { background: #292A25; color: #F6D96F; border: 1px solid #8B742D; }
QPushButton#softButton:hover { background: #383423; color: #FFE58A; border-color: #F6C945; }
QTableWidget { background: #0C192B; alternate-background-color: #122139; color: #E6EDF8; border: 1px solid #293D5B; border-radius: 9px; gridline-color: transparent; selection-background-color: #293D5B; selection-color: #FFFFFF; outline: 0; }
QTableWidget::item { padding: 8px; border-bottom: 1px solid #1C304B; }
QTableWidget::item:selected { background: #263B5A; color: #FFFFFF; }
QHeaderView { background: #14243C; }
QHeaderView::section { background: #192B45; color: #AEBBD0; border: none; border-bottom: 1px solid #344A6B; padding: 11px 8px; font-size: 8pt; font-weight: 800; }
QProgressBar { background: #1C2D46; border: 1px solid #304562; border-radius: 5px; min-height: 9px; max-height: 9px; text-align: center; }
QProgressBar::chunk { background: #F6C945; border-radius: 5px; }
QCheckBox { color: #DCE6F4; spacing: 8px; padding: 4px 0; }
QCheckBox::indicator { width: 16px; height: 16px; border: 1px solid #506581; border-radius: 4px; background: #0A1729; }
QCheckBox::indicator:checked { background: #F6C945; border-color: #F6C945; }
QCheckBox::indicator:disabled { background: #17243A; border-color: #34445C; }
QPlainTextEdit, QTextEdit { background: #081321; color: #DCE6F4; border: 1px solid #293D5B; border-radius: 10px; padding: 12px; selection-background-color: #66551D; font-family: 'Consolas', 'Cascadia Mono', monospace; font-size: 9pt; }
QAbstractScrollArea { background: #0C192B; border: none; }
QAbstractScrollArea::viewport { background: #0C192B; }
QSplitter::handle { background: #293D5B; }
QScrollBar:vertical { background: #0B1728; width: 11px; margin: 2px; }
QScrollBar::handle:vertical { background: #344A6B; border-radius: 5px; min-height: 24px; }
QScrollBar::handle:vertical:hover { background: #516784; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
QScrollBar:horizontal { background: #0B1728; height: 11px; margin: 2px; }
QScrollBar::handle:horizontal { background: #344A6B; border-radius: 5px; min-width: 24px; }
QMenu { background: #111F35; color: #EEF3FC; border: 1px solid #344A6B; padding: 5px; }
QMenu::item { padding: 7px 24px; border-radius: 4px; }
QMenu::item:selected { background: #263B5A; color: #F6D96F; }
QToolTip { background: #172943; color: #FFFFFF; border: 1px solid #F6C945; padding: 5px; }
QDialogButtonBox QPushButton { min-width: 82px; }
QTreeView, QListView, QTableView { background: #0C192B; alternate-background-color: #122139; color: #E6EDF8; border: 1px solid #293D5B; selection-background-color: #293D5B; selection-color: #FFFFFF; }
QTreeView::item, QListView::item { padding: 5px; }
QTreeView::item:selected, QListView::item:selected { background: #293D5B; color: #F6D96F; }
"""


def _qt(name, group=None):
    return enum_value(Qt, name, group)


def _button_box(parent, title, message, buttons, default_button=None):
    box = QMessageBox(parent)
    box.setWindowTitle(title)
    box.setText(message)
    box.setStandardButtons(buttons)
    if default_button is not None:
        box.setDefaultButton(default_button)
    box.setStyleSheet(STYLE)
    return box


class CrsGuardianWindow(QDialog):
    """A native, non-dockable, resizable CRS Guardian desktop window."""

    # Bridge task-thread signals back to the GUI thread before touching widgets
    # or the QGIS project. The lambdas connected to workers only emit signals.
    task_executed_signal = pyqtSignal(object, bool, object)
    task_terminated_signal = pyqtSignal(object)
    task_progress_signal = pyqtSignal(float)

    def __init__(self, iface, parent=None):
        super(CrsGuardianWindow, self).__init__(
            parent, _qt("Window", "WindowType")
        )
        self.iface = iface
        # Store simple workflow preferences outside the project so they persist between sessions.
        self._settings = QSettings("AMLAN-X", "CRS Guardian")
        self.setObjectName("crsGuardianWindow")
        self.setWindowTitle("CRS Guardian | Coordinate Systems Workspace")
        self.setMinimumSize(1080, 700)
        self.resize(1440, 900)
        try:
            self.setWindowIcon(QIcon(os.path.join(os.path.dirname(__file__), "icon.png")))
        except Exception:
            errors.get_logger().exception("Unable to set CRS Guardian window icon")
        self.setModal(False)
        self.setStyleSheet(STYLE)

        self._custom_crs = None
        self._chosen_output_dir = None
        self._reports = []
        self._qa_results = []
        self._preflight_report = ""
        self._projection_recommendation = None
        self._projection_analysis = None
        self._live_sentinel_enabled = False
        self._live_scan_pending = False
        self._result = harmonizer.HarmonizeResult()
        self._queue = []
        self._active_task = None
        self._active_feedback = None
        self._active_context = None
        self._active_output = None
        self._active_layer = None
        self._active_algorithm = None
        self._active_executed_slot = None
        self._active_terminated_slot = None
        self._active_progress_slot = None
        self._task_completion_handled = False
        self._batch_target = None
        self._batch_output_dir = None
        self._batch_total = 0
        self._done_count = 0
        self._update_project_crs = False
        self._current_mode = "batch"
        self._cancel_requested = False
        self._shutting_down = False
        self._temp_output_dirs = []
        self._temp_cleanup_pending = False
        self._project_generation = 0
        self._job_project_generation = 0

        queued = _qt("QueuedConnection", "ConnectionType")
        self.task_executed_signal.connect(self._on_task_executed, queued)
        self.task_terminated_signal.connect(self._on_task_terminated, queued)
        self.task_progress_signal.connect(self._on_task_progress, queued)
        try:
            QgsProject.instance().cleared.connect(self._on_project_cleared)
        except Exception as exc:
            errors.log_exception("Unable to connect temporary-output cleanup to project lifecycle", exc)
        atexit.register(self._cleanup_temporary_outputs)

        self._build_ui()
        QTimer.singleShot(0, self._apply_native_dark_titlebar)
        auto_scan = self._settings.value("CRSGuardian/autoScanOnOpen", True)
        if isinstance(auto_scan, str):
            auto_scan = auto_scan.strip().lower() not in ("0", "false", "no", "off")
        if auto_scan:
            self.run_scan()
        else:
            self._set_status("Ready. Automatic scan on open is disabled; use Scan project when needed.")
            self._add_activity("CRS Guardian opened with automatic scan disabled.")

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        """Create the standalone application shell and its focused workspaces."""
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Left navigation rail
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(242)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(16, 22, 16, 16)
        side.setSpacing(7)

        brand_row = QHBoxLayout()
        brand_icon = QLabel()
        brand_icon.setFixedSize(43, 43)
        brand_icon.setAlignment(_qt("AlignCenter", "AlignmentFlag"))
        brand_icon.setPixmap(QIcon(os.path.join(os.path.dirname(__file__), "icon.png")).pixmap(39, 39))
        brand_icon.setStyleSheet(
            "background: #1B2F4D; border: 1px solid #3A5070; border-radius: 10px;"
        )
        brand_text = QVBoxLayout()
        brand_name = QLabel("CRS GUARDIAN")
        brand_name.setObjectName("brandName")
        brand_name.setMinimumWidth(154)
        brand_caption = QLabel("GIS QUALITY TOOLS")
        brand_caption.setObjectName("brandCaption")
        brand_text.addWidget(brand_name)
        brand_text.addWidget(brand_caption)
        brand_row.addWidget(brand_icon)
        brand_row.addLayout(brand_text, 1)
        side.addLayout(brand_row)
        side.addSpacing(28)

        section = QLabel("WORKSPACE")
        section.setObjectName("sidebarSection")
        side.addWidget(section)
        self._nav_buttons = []
        # Navigation labels follow the workspace order. Existing core pages retain
        # their original widgets; new workspaces are appended as focused modules.
        nav_items = [
            ("◫   Overview", 0),
            ("✦   CRS Intelligence", 4),
            ("▤   Diagnostics", 5),
            ("⌖   Measurement Guard", 6),
            ("⇄   Transformation", 7),
            ("⇆   Harmonize", 1),
            ("✓   Quality Assurance", 8),
            ("⚙   Automation", 9),
            ("◷   Reports & History", 2),
            ("☷   Settings", 3),
        ]
        for label, page_index in nav_items:
            button = QPushButton(label)
            button.setObjectName("navButton")
            button.setCheckable(True)
            button.setAutoExclusive(True)
            button.setMinimumHeight(34)
            button.setMaximumHeight(38)
            button.page_index = page_index
            button.setStyleSheet("QPushButton#navButton { padding: 8px 10px; font-size: 9pt; }")
            button.clicked.connect(lambda checked=False, idx=page_index: self._navigate_to(idx))
            side.addWidget(button)
            self._nav_buttons.append(button)
        self._nav_buttons[0].setChecked(True)
        side.addStretch(1)

        side_status = QFrame()
        side_status.setStyleSheet("background: #10213A; border: 1px solid #293D5B; border-radius: 10px;")
        side_status_layout = QVBoxLayout(side_status)
        side_status_layout.setContentsMargins(12, 11, 12, 11)
        side_status_layout.setSpacing(3)
        health_title = QLabel("ENGINE STATUS")
        health_title.setStyleSheet("color: #9EADC2; font-size: 8pt; font-weight: 800; letter-spacing: 1px;")
        health_value = QLabel("●   Ready for project scan")
        health_value.setStyleSheet("color: #F6C945; font-size: 9pt; font-weight: 700;")
        health_hint = QLabel("Standalone workspace")
        health_hint.setStyleSheet("color: #AEBBD0; font-size: 8pt;")
        side_status_layout.addWidget(health_title)
        side_status_layout.addWidget(health_value)
        side_status_layout.addWidget(health_hint)
        side.addWidget(side_status)
        version_label = QLabel("CRS GUARDIAN  ·  VERSION 2.5.1")
        version_label.setObjectName("sidebarVersion")
        version_label.setAlignment(_qt("AlignCenter", "AlignmentFlag"))
        side.addWidget(version_label)
        copyright_label = QLabel("© 2077 Amlan Patnaik")
        copyright_label.setAlignment(_qt("AlignCenter", "AlignmentFlag"))
        copyright_label.setStyleSheet("color: #8295B0; font-size: 7pt; padding-bottom: 2px;")
        side.addWidget(copyright_label)
        root.addWidget(sidebar)

        # Main workspace
        main = QWidget()
        main_layout = QVBoxLayout(main)
        main_layout.setContentsMargins(22, 18, 22, 14)
        main_layout.setSpacing(14)

        topbar = QFrame()
        topbar.setObjectName("topbar")
        top_layout = QHBoxLayout(topbar)
        top_layout.setContentsMargins(18, 13, 16, 13)
        page_copy = QVBoxLayout()
        self.page_title = QLabel("Project overview")
        self.page_title.setObjectName("pageTitle")
        self.page_subtitle = QLabel("Inspect coordinate reference systems and review project health.")
        self.page_subtitle.setObjectName("pageSubtitle")
        page_copy.addWidget(self.page_title)
        page_copy.addWidget(self.page_subtitle)
        top_layout.addLayout(page_copy, 1)
        self.project_crs_badge = QLabel("PROJECT CRS · —")
        self.project_crs_badge.setObjectName("pill")
        top_layout.addWidget(self.project_crs_badge)
        self.scan_btn = QPushButton("↻   Scan project")
        self.scan_btn.setObjectName("primaryButton")
        self.scan_btn.clicked.connect(self.run_scan)
        top_layout.addWidget(self.scan_btn)
        main_layout.addWidget(topbar)

        self.pages = QStackedWidget()
        main_layout.addWidget(self.pages, 1)

        # Page 0: overview and diagnostics
        overview_page = QWidget()
        overview = QVBoxLayout(overview_page)
        overview.setContentsMargins(0, 0, 0, 0)
        overview.setSpacing(13)

        hero = QFrame()
        hero.setObjectName("hero")
        hero_layout = QHBoxLayout(hero)
        hero_layout.setContentsMargins(21, 17, 21, 17)
        hero_layout.setSpacing(15)
        hero_mark = QLabel()
        hero_mark.setFixedSize(48, 48)
        hero_mark.setAlignment(_qt("AlignCenter", "AlignmentFlag"))
        hero_mark.setPixmap(QIcon(os.path.join(os.path.dirname(__file__), "icon.png")).pixmap(44, 44))
        hero_mark.setStyleSheet("background: #1B2F4D; border: 1px solid #3A5070; border-radius: 12px;")
        hero_layout.addWidget(hero_mark)
        hero_text = QVBoxLayout()
        hero_eyebrow = QLabel("COORDINATE SYSTEM INTELLIGENCE")
        hero_eyebrow.setObjectName("eyebrow")
        hero_eyebrow.setStyleSheet("color: #B7C5D8;")
        hero_title = QLabel("Know your project. Trust your coordinates.")
        hero_title.setObjectName("heroTitle")
        hero_subtitle = QLabel("Find CRS inconsistencies early and correct them without overwriting source data.")
        hero_subtitle.setObjectName("heroSubtitle")
        hero_text.addWidget(hero_eyebrow)
        hero_text.addWidget(hero_title)
        hero_text.addWidget(hero_subtitle)
        hero_layout.addLayout(hero_text, 1)
        overview.addWidget(hero)

        metrics = QHBoxLayout()
        metrics.setSpacing(10)
        self.metric_layers = self._metric_card("—", "LAYERS IN PROJECT", COLORS["yellow"])
        self.metric_critical = self._metric_card("—", "CRITICAL ISSUES", COLORS["critical"])
        self.metric_warning = self._metric_card("—", "WARNINGS", COLORS["warning"])
        self.metric_ok = self._metric_card("—", "HEALTHY LAYERS", COLORS["ok"])
        self.metric_health = self._metric_card("—", "PROJECT HEALTH", COLORS["yellow"])
        for card in (self.metric_layers, self.metric_critical, self.metric_warning, self.metric_ok, self.metric_health):
            metrics.addWidget(card, 1)
        overview.addLayout(metrics)

        report_panel = QFrame()
        report_panel.setObjectName("panelCard")
        report_layout = QVBoxLayout(report_panel)
        report_layout.setContentsMargins(15, 14, 15, 13)
        report_layout.setSpacing(10)
        report_header = QHBoxLayout()
        report_copy = QVBoxLayout()
        report_title = QLabel("Layer diagnostics")
        report_title.setObjectName("sectionTitle")
        report_subtitle = QLabel("One consolidated result per supported layer · Select an action to resolve an issue")
        report_subtitle.setObjectName("muted")
        report_copy.addWidget(report_title)
        report_copy.addWidget(report_subtitle)
        report_header.addLayout(report_copy, 1)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Search layers or findings…")
        self.search_edit.setClearButtonEnabled(True)
        self.search_edit.setMinimumWidth(205)
        self.search_edit.setMaximumWidth(270)
        self.search_edit.textChanged.connect(self._filter_rows)
        report_header.addWidget(self.search_edit)
        self.severity_filter = QComboBox()
        self.severity_filter.addItem("All statuses", "all")
        self.severity_filter.addItem("Critical", checker.CRITICAL)
        self.severity_filter.addItem("Warnings", checker.WARNING)
        self.severity_filter.addItem("Healthy", checker.OK)
        self.severity_filter.setMinimumWidth(125)
        self.severity_filter.currentIndexChanged.connect(lambda unused: self._filter_rows(self.search_edit.text()))
        report_header.addWidget(self.severity_filter)
        self.export_btn = QPushButton("⇩   Export CSV")
        self.export_btn.setObjectName("softButton")
        self.export_btn.setToolTip("Export the complete scan report, including layers hidden by current filters.")
        self.export_btn.clicked.connect(self._export_report)
        report_header.addWidget(self.export_btn)
        report_layout.addLayout(report_header)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["STATUS", "LAYER", "SOURCE CRS", "FINDINGS", "ACTION"])
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(45)
        self.table.setEditTriggers(enum_value(QAbstractItemView, "NoEditTriggers", "EditTrigger"))
        self.table.setSelectionBehavior(enum_value(QAbstractItemView, "SelectRows", "SelectionBehavior"))
        self.table.setSelectionMode(enum_value(QAbstractItemView, "SingleSelection", "SelectionMode"))
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.setWordWrap(False)
        self.table.setSortingEnabled(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, enum_value(QHeaderView, "ResizeToContents", "ResizeMode"))
        header.setSectionResizeMode(1, enum_value(QHeaderView, "Interactive", "ResizeMode"))
        header.setSectionResizeMode(2, enum_value(QHeaderView, "ResizeToContents", "ResizeMode"))
        header.setSectionResizeMode(3, enum_value(QHeaderView, "Stretch", "ResizeMode"))
        header.setSectionResizeMode(4, enum_value(QHeaderView, "Fixed", "ResizeMode"))
        self.table.setColumnWidth(1, 200)
        self.table.setColumnWidth(4, 132)
        self.table.setMinimumHeight(260)
        self.table.setToolTip("Double-click a layer row to view full diagnostic details.")
        self.table.cellDoubleClicked.connect(self._show_layer_details)
        report_layout.addWidget(self.table, 1)
        self.table_empty = QLabel("No matching layers. Change the filters or run a new scan.")
        self.table_empty.setObjectName("muted")
        self.table_empty.setAlignment(_qt("AlignCenter", "AlignmentFlag"))
        self.table_empty.setMinimumHeight(42)
        self.table_empty.hide()
        report_layout.addWidget(self.table_empty)
        report_foot = QLabel("Assign CRS only when the existing coordinate values already match the selected CRS. Reproject transforms coordinates into a new output copy.")
        report_foot.setObjectName("muted")
        report_foot.setWordWrap(True)
        report_layout.addWidget(report_foot)
        overview.addWidget(report_panel, 1)
        self.pages.addWidget(overview_page)

        # Page 1: harmonization workspace
        harmonize_page = QWidget()
        harmonize_layout = QVBoxLayout(harmonize_page)
        harmonize_layout.setContentsMargins(0, 0, 0, 0)
        harmonize_layout.setSpacing(14)
        h_hero = QFrame()
        h_hero.setObjectName("hero")
        h_hero_layout = QVBoxLayout(h_hero)
        h_hero_layout.setContentsMargins(22, 19, 22, 19)
        h_eyebrow = QLabel("COORDINATE TRANSFORMATION WORKSPACE")
        h_eyebrow.setObjectName("eyebrow")
        h_eyebrow.setStyleSheet("color: #B7C5D8;")
        h_title = QLabel("Harmonize your layers")
        h_title.setObjectName("heroTitle")
        h_subtitle = QLabel("Create consistent, analysis-ready copies while keeping every original data source untouched.")
        h_subtitle.setObjectName("heroSubtitle")
        h_hero_layout.addWidget(h_eyebrow)
        h_hero_layout.addWidget(h_title)
        h_hero_layout.addWidget(h_subtitle)
        harmonize_layout.addWidget(h_hero)

        h_columns = QHBoxLayout()
        h_columns.setSpacing(13)
        target_panel = QFrame()
        target_panel.setObjectName("panelCard")
        target_layout = QVBoxLayout(target_panel)
        target_layout.setContentsMargins(19, 18, 19, 18)
        target_layout.setSpacing(12)
        target_title = QLabel("01  ·  Target coordinate system")
        target_title.setObjectName("sectionTitle")
        target_desc = QLabel("Choose the CRS that all supported vector and raster output layers should use.")
        target_desc.setObjectName("muted")
        target_desc.setWordWrap(True)
        target_layout.addWidget(target_title)
        target_layout.addWidget(target_desc)
        target_label = QLabel("TARGET CRS")
        target_label.setObjectName("eyebrow")
        target_layout.addWidget(target_label)
        self.target_combo = QComboBox()
        self.target_combo.addItem("Auto-suggest UTM", TARGET_AUTO)
        self.target_combo.addItem("Use project CRS", TARGET_PROJECT)
        self.target_combo.addItem("Choose custom CRS…", TARGET_CUSTOM)
        self.target_combo.currentIndexChanged.connect(self._on_target_changed)
        target_layout.addWidget(self.target_combo)
        self.target_hint = QLabel("Automatic UTM is a best-effort suggestion for geographically compact projects.")
        self.target_hint.setObjectName("muted")
        self.target_hint.setWordWrap(True)
        target_layout.addWidget(self.target_hint)
        target_layout.addSpacing(8)
        target_rule = QLabel("OUTPUT BEHAVIOUR")
        target_rule.setObjectName("eyebrow")
        target_layout.addWidget(target_rule)
        self.chk_set_project = QCheckBox("Update project CRS after successful batch")
        self.chk_set_project.setChecked(True)
        target_layout.addWidget(self.chk_set_project)
        target_layout.addStretch(1)
        h_columns.addWidget(target_panel, 3)

        output_panel = QFrame()
        output_panel.setObjectName("panelCard")
        output_layout = QVBoxLayout(output_panel)
        output_layout.setContentsMargins(19, 18, 19, 18)
        output_layout.setSpacing(12)
        output_title = QLabel("02  ·  Output destination")
        output_title.setObjectName("sectionTitle")
        output_desc = QLabel("Choose a permanent folder or use a temporary session workspace.")
        output_desc.setObjectName("muted")
        output_desc.setWordWrap(True)
        output_layout.addWidget(output_title)
        output_layout.addWidget(output_desc)
        self.chk_save = QCheckBox("Save outputs to a permanent folder")
        self.chk_save.setChecked(False)
        output_layout.addWidget(self.chk_save)
        self.output_folder_btn = QPushButton("Choose output folder…")
        self.output_folder_btn.clicked.connect(self._choose_output_folder)
        self.output_folder_btn.setEnabled(False)
        self.chk_save.toggled.connect(self.output_folder_btn.setEnabled)
        output_layout.addWidget(self.output_folder_btn)
        self.output_folder_label = QLabel("Temporary session output")
        self.output_folder_label.setObjectName("muted")
        self.output_folder_label.setWordWrap(True)
        self.output_layout_spacer = QLabel(" ")
        output_layout.addWidget(self.output_folder_label)
        output_layout.addSpacing(10)
        safety = QLabel("SAFE PROCESSING\n\n• Original data sources are never overwritten\n• Every output receives a unique filename\n• Failed partial outputs are cleaned up\n• Jobs run through QGIS background processing\n• Cancellation stops queued operations")
        safety.setWordWrap(True)
        safety.setStyleSheet("background: #172943; color: #F6D96F; border: 1px solid #8B742D; border-radius: 9px; padding: 12px; font-size: 9pt;")
        output_layout.addWidget(safety)
        output_layout.addStretch(1)
        h_columns.addWidget(output_panel, 2)
        harmonize_layout.addLayout(h_columns, 1)

        action_panel = QFrame()
        action_panel.setObjectName("panelCard")
        action_row = QHBoxLayout(action_panel)
        action_row.setContentsMargins(18, 14, 18, 14)
        action_copy = QVBoxLayout()
        action_title = QLabel("Ready to harmonize?")
        action_title.setObjectName("sectionTitle")
        action_hint = QLabel("Review the target CRS and output location before starting the batch.")
        action_hint.setObjectName("muted")
        action_copy.addWidget(action_title)
        action_copy.addWidget(action_hint)
        action_row.addLayout(action_copy, 1)
        self.harmonize_btn = QPushButton("Run harmonization   →")
        self.harmonize_btn.setObjectName("primaryButton")
        self.harmonize_btn.setMinimumWidth(205)
        self.harmonize_btn.clicked.connect(self.run_harmonize)
        action_row.addWidget(self.harmonize_btn)
        harmonize_layout.addWidget(action_panel)
        self.pages.addWidget(harmonize_page)

        # Page 2: operation history
        activity_page = QWidget()
        activity_layout = QVBoxLayout(activity_page)
        activity_layout.setContentsMargins(0, 0, 0, 0)
        activity_layout.setSpacing(13)
        activity_header = QFrame()
        activity_header.setObjectName("panelCard")
        activity_header_layout = QHBoxLayout(activity_header)
        activity_header_layout.setContentsMargins(18, 15, 18, 15)
        activity_copy = QVBoxLayout()
        activity_title = QLabel("Reports & history")
        activity_title.setObjectName("sectionTitle")
        activity_subtitle = QLabel("Persistent timestamped history of scans, fixes, processing and QA events.")
        activity_subtitle.setObjectName("muted")
        activity_copy.addWidget(activity_title)
        activity_copy.addWidget(activity_subtitle)
        activity_header_layout.addLayout(activity_copy, 1)
        copy_activity_btn = QPushButton("Copy activity")
        copy_activity_btn.clicked.connect(self._copy_activity)
        export_activity_btn = QPushButton("Export history")
        export_activity_btn.clicked.connect(self._export_activity_history)
        export_scan_btn = QPushButton("Export scan CSV")
        export_scan_btn.clicked.connect(self._export_report)
        clear_activity_btn = QPushButton("Clear")
        clear_activity_btn.clicked.connect(self._clear_activity)
        activity_header_layout.addWidget(copy_activity_btn)
        activity_header_layout.addWidget(export_activity_btn)
        activity_header_layout.addWidget(export_scan_btn)
        activity_header_layout.addWidget(clear_activity_btn)
        activity_layout.addWidget(activity_header)
        self.activity_view = QPlainTextEdit()
        self.activity_view.setReadOnly(True)
        self.activity_view.setPlaceholderText("CRS Guardian activity will appear here…")
        activity_layout.addWidget(self.activity_view, 1)
        self._activity_lines = []
        self.pages.addWidget(activity_page)
        self._load_persistent_history()

        # Page 3: guide and about
        guide_page = QWidget()
        guide_layout = QVBoxLayout(guide_page)
        guide_layout.setContentsMargins(0, 0, 0, 0)
        guide_layout.setSpacing(13)
        guide_hero = QFrame()
        guide_hero.setObjectName("hero")
        guide_hero_layout = QVBoxLayout(guide_hero)
        guide_hero_layout.setContentsMargins(22, 20, 22, 20)
        guide_kicker = QLabel("CRS GUARDIAN  ·  VERSION 2.5.1")
        guide_kicker.setObjectName("eyebrow")
        guide_kicker.setStyleSheet("color: #B7C5D8;")
        guide_heading = QLabel("Coordinate confidence, built into your workflow.")
        guide_heading.setObjectName("heroTitle")
        guide_body = QLabel("Audit. Understand. Correct. CRS Guardian helps identify common coordinate reference system risks and safely creates reprojected copies for GIS analysis.")
        guide_body.setObjectName("heroSubtitle")
        guide_body.setWordWrap(True)
        guide_hero_layout.addWidget(guide_kicker)
        guide_hero_layout.addWidget(guide_heading)
        guide_hero_layout.addWidget(guide_body)
        guide_layout.addWidget(guide_hero)

        guide_columns = QHBoxLayout()
        guide_columns.setSpacing(13)
        guide_steps = [
            ("01  ·  Scan", "Review missing CRS, suspicious coordinate extents, geographic measurement units and project CRS differences."),
            ("02  ·  Assign or reproject", "Assign CRS only when coordinate values are already correct. Reproject when coordinates must be transformed."),
            ("03  ·  Harmonize", "Choose a target CRS and create new vector or raster outputs. Keep permanent outputs in a folder you control."),
        ]
        for heading, body in guide_steps:
            card = QFrame()
            card.setObjectName("infoCard")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(17, 16, 17, 16)
            title = QLabel(heading)
            title.setObjectName("sectionTitle")
            text = QLabel(body)
            text.setObjectName("muted")
            text.setWordWrap(True)
            card_layout.addWidget(title)
            card_layout.addWidget(text)
            card_layout.addStretch(1)
            guide_columns.addWidget(card, 1)
        guide_layout.addLayout(guide_columns)
        note = QLabel("Important: Automatic UTM is only a suggestion for compact geographic areas. Verify the source CRS before assigning it. Availability of raster reprojection depends on the installed GDAL Processing provider.")
        note.setWordWrap(True)
        note.setStyleSheet("background: #172943; color: #F6D96F; border: 1px solid #8B742D; border-radius: 10px; padding: 13px;")
        guide_layout.addWidget(note)
        prefs_card, prefs_layout = self._workspace_card(
            "Workspace preferences",
            "Configure how CRS Guardian starts. The navy/gold technical theme remains the default release appearance."
        )
        self.auto_scan_checkbox = QCheckBox("Run a project scan automatically whenever CRS Guardian opens")
        auto_scan_setting = self._settings.value("CRSGuardian/autoScanOnOpen", True)
        if isinstance(auto_scan_setting, str):
            auto_scan_setting = auto_scan_setting.strip().lower() not in ("0", "false", "no", "off")
        self.auto_scan_checkbox.setChecked(bool(auto_scan_setting))
        self.auto_scan_checkbox.toggled.connect(self._save_auto_scan_preference)
        prefs_layout.addWidget(self.auto_scan_checkbox)
        guide_layout.addWidget(prefs_card)
        guide_layout.addStretch(1)
        self.pages.addWidget(guide_page)

        # New focused workspaces introduced in 2.5.0.
        self._build_advanced_workspaces()

        # Persistent task/status strip
        activity = QFrame()
        activity.setObjectName("panelCard")
        activity_layout = QVBoxLayout(activity)
        activity_layout.setContentsMargins(14, 10, 14, 10)
        activity_layout.setSpacing(7)
        status_row = QHBoxLayout()
        self.status_label = QLabel("Ready. Run a scan to inspect the current QGIS project.")
        self.status_label.setObjectName("muted")
        status_row.addWidget(self.status_label, 1)
        self.cancel_btn = QPushButton("Cancel task")
        self.cancel_btn.setObjectName("dangerButton")
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setVisible(False)
        self.cancel_btn.clicked.connect(self.cancel_processing)
        status_row.addWidget(self.cancel_btn)
        activity_layout.addLayout(status_row)
        progress_row = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setTextVisible(False)
        self.progress.setVisible(False)
        progress_row.addWidget(self.progress, 1)
        self.progress_caption = QLabel("")
        self.progress_caption.setObjectName("muted")
        progress_row.addWidget(self.progress_caption)
        activity_layout.addLayout(progress_row)
        main_layout.addWidget(activity)
        root.addWidget(main, 1)
        self._sync_project_info()

    # ------------------------------------------------------ 2.5.0 workspaces
    def _workspace_hero(self, eyebrow, title, subtitle):
        """Build a consistent dark-navy hero for an advanced workspace."""
        frame = QFrame()
        frame.setObjectName("hero")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(20, 17, 20, 17)
        layout.setSpacing(5)
        top = QLabel(eyebrow.upper())
        top.setObjectName("eyebrow")
        heading = QLabel(title)
        heading.setObjectName("heroTitle")
        heading.setWordWrap(True)
        detail = QLabel(subtitle)
        detail.setObjectName("heroSubtitle")
        detail.setWordWrap(True)
        layout.addWidget(top)
        layout.addWidget(heading)
        layout.addWidget(detail)
        return frame

    def _workspace_card(self, heading, description=None):
        """Return a styled card and its vertical content layout."""
        card = QFrame()
        card.setObjectName("panelCard")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(9)
        title = QLabel(heading)
        title.setObjectName("sectionTitle")
        layout.addWidget(title)
        if description:
            subtitle = QLabel(description)
            subtitle.setObjectName("muted")
            subtitle.setWordWrap(True)
            layout.addWidget(subtitle)
        return card, layout

    def _build_advanced_workspaces(self):
        """Append CRS Intelligence, Diagnostics, Measurement, Transformation, QA and Automation pages."""
        # Page 4 — CRS Intelligence
        intelligence_page = QWidget()
        intelligence_layout = QVBoxLayout(intelligence_page)
        intelligence_layout.setContentsMargins(0, 0, 0, 0)
        intelligence_layout.setSpacing(13)
        intelligence_layout.addWidget(self._workspace_hero(
            "Spatial decision support",
            "Understand the footprint before choosing a projection",
            "CRS Guardian samples project layer extents in WGS 84, identifies UTM zone spread and explains the confidence behind a recommendation."
        ))
        intel_card, intel_layout = self._workspace_card(
            "Project footprint analysis",
            "Recommendations are advisory only. They do not reassign source CRS values or change project settings."
        )
        self.intelligence_view = QPlainTextEdit()
        self.intelligence_view.setReadOnly(True)
        self.intelligence_view.setMinimumHeight(220)
        self.intelligence_view.setPlaceholderText("Run a project footprint analysis to see the geographic extent and projection guidance.")
        intel_layout.addWidget(self.intelligence_view, 1)
        intel_actions = QHBoxLayout()
        analyze_btn = QPushButton("↻   Analyze project footprint")
        analyze_btn.setObjectName("primaryButton")
        analyze_btn.clicked.connect(self._refresh_projection_intelligence)
        self.use_projection_btn = QPushButton("Use recommendation in Harmonize →")
        self.use_projection_btn.setEnabled(False)
        self.use_projection_btn.clicked.connect(self._use_projection_recommendation)
        intel_actions.addWidget(analyze_btn)
        intel_actions.addWidget(self.use_projection_btn)
        intel_layout.addLayout(intel_actions)
        intelligence_layout.addWidget(intel_card, 1)
        note = QLabel("Safety rule: a footprint-based projection suggestion is not evidence that the source CRS is correct. Verify source coordinate metadata before assigning or transforming data.")
        note.setWordWrap(True)
        note.setStyleSheet("background: #172943; color: #F6D96F; border: 1px solid #8B742D; border-radius: 9px; padding: 11px;")
        intelligence_layout.addWidget(note)
        self.pages.addWidget(intelligence_page)

        # Page 5 — Diagnostics
        diagnostics_page = QWidget()
        diagnostics_layout = QVBoxLayout(diagnostics_page)
        diagnostics_layout.setContentsMargins(0, 0, 0, 0)
        diagnostics_layout.setSpacing(12)
        diagnostics_layout.addWidget(self._workspace_hero(
            "Layer-level quality inspection",
            "Diagnostics explorer",
            "The same scan findings used by Overview are shown here in a dedicated full-size workspace. Double-click any row for the complete explanation."
        ))
        diag_card, diag_layout = self._workspace_card(
            "Project layer findings",
            "Use the search field and severity selector in Overview to filter this shared diagnostics view."
        )
        self.diagnostics_table = QTableWidget(0, 4)
        self.diagnostics_table.setHorizontalHeaderLabels(["SEVERITY", "LAYER", "SOURCE CRS", "FINDINGS"])
        self.diagnostics_table.verticalHeader().setVisible(False)
        self.diagnostics_table.setAlternatingRowColors(True)
        self.diagnostics_table.setShowGrid(False)
        self.diagnostics_table.setEditTriggers(enum_value(QAbstractItemView, "NoEditTriggers", "EditTrigger"))
        self.diagnostics_table.setSelectionBehavior(enum_value(QAbstractItemView, "SelectRows", "SelectionBehavior"))
        self.diagnostics_table.setSelectionMode(enum_value(QAbstractItemView, "SingleSelection", "SelectionMode"))
        diag_header = self.diagnostics_table.horizontalHeader()
        diag_header.setSectionResizeMode(0, enum_value(QHeaderView, "ResizeToContents", "ResizeMode"))
        diag_header.setSectionResizeMode(1, enum_value(QHeaderView, "Interactive", "ResizeMode"))
        diag_header.setSectionResizeMode(2, enum_value(QHeaderView, "ResizeToContents", "ResizeMode"))
        diag_header.setSectionResizeMode(3, enum_value(QHeaderView, "Stretch", "ResizeMode"))
        self.diagnostics_table.setColumnWidth(1, 210)
        self.diagnostics_table.cellDoubleClicked.connect(self._show_diagnostic_details)
        diag_layout.addWidget(self.diagnostics_table, 1)
        diag_actions = QHBoxLayout()
        diag_refresh = QPushButton("↻   Refresh diagnostics")
        diag_refresh.clicked.connect(self.run_scan)
        diag_export = QPushButton("⇩   Export CSV")
        diag_export.setObjectName("softButton")
        diag_export.clicked.connect(self._export_report)
        diag_actions.addWidget(diag_refresh)
        diag_actions.addWidget(diag_export)
        diag_actions.addStretch(1)
        diag_layout.addLayout(diag_actions)
        diagnostics_layout.addWidget(diag_card, 1)
        self.pages.addWidget(diagnostics_page)

        # Page 6 — Measurement & Unit Guardian
        measurement_page = QWidget()
        measurement_layout = QVBoxLayout(measurement_page)
        measurement_layout.setContentsMargins(0, 0, 0, 0)
        measurement_layout.setSpacing(13)
        measurement_layout.addWidget(self._workspace_hero(
            "Engineering measurement safeguards",
            "Measurement & Unit Guardian",
            "Compare project measurement defaults with each layer's native map units. Check geographic-degree risks and review the project ellipsoid before measuring, buffering or offsetting."
        ))
        unit_card, unit_layout = self._workspace_card(
            "Project measurement configuration",
            "Changing the project distance unit does not reproject layer coordinates. Layer coordinate units remain defined by each layer CRS."
        )
        self.measurement_view = QPlainTextEdit()
        self.measurement_view.setReadOnly(True)
        self.measurement_view.setMinimumHeight(210)
        unit_layout.addWidget(self.measurement_view, 1)
        unit_controls = QHBoxLayout()
        self.measurement_unit_combo = QComboBox()
        self.measurement_unit_combo.addItem("Keep current project units", "keep")
        self.measurement_unit_combo.addItem("Metres", "meters")
        self.measurement_unit_combo.addItem("Feet (international)", "feet")
        self.measurement_unit_combo.addItem("US survey feet", "us_survey_feet")
        unit_controls.addWidget(self.measurement_unit_combo, 1)
        refresh_units = QPushButton("Refresh checks")
        refresh_units.clicked.connect(self._refresh_measurement_guard)
        apply_units = QPushButton("Apply project unit")
        apply_units.setObjectName("primaryButton")
        apply_units.clicked.connect(self._apply_measurement_unit)
        unit_controls.addWidget(refresh_units)
        unit_controls.addWidget(apply_units)
        unit_layout.addLayout(unit_controls)
        measurement_layout.addWidget(unit_card, 1)
        self.pages.addWidget(measurement_page)

        # Page 7 — Transformation inspector
        transform_page = QWidget()
        transform_layout = QVBoxLayout(transform_page)
        transform_layout.setContentsMargins(0, 0, 0, 0)
        transform_layout.setSpacing(13)
        transform_layout.addWidget(self._workspace_hero(
            "Datum and coordinate operation inspector",
            "Inspect the transformation QGIS will use",
            "Review the source and destination CRS, selected PROJ operation, reported accuracy and fallback status. Actual details depend on the installed PROJ database and transformation grids."
        ))
        transform_card, transform_content = self._workspace_card(
            "Transformation configuration",
            "Choose a valid project layer and destination CRS, then inspect the operation using the current QGIS project transform context."
        )
        controls = QHBoxLayout()
        self.transform_layer_combo = QComboBox()
        self.transform_target_combo = QComboBox()
        self.transform_target_combo.addItem("Project CRS", "project")
        self.transform_target_combo.addItem("WGS 84 · EPSG:4326", "EPSG:4326")
        controls.addWidget(self.transform_layer_combo, 2)
        controls.addWidget(self.transform_target_combo, 1)
        transform_content.addLayout(controls)
        action_row = QHBoxLayout()
        refresh_layers = QPushButton("Refresh layer list")
        refresh_layers.clicked.connect(self._refresh_transformation_layers)
        custom_target = QPushButton("Choose custom target CRS…")
        custom_target.clicked.connect(self._choose_transformation_target)
        inspect_btn = QPushButton("Inspect coordinate operation")
        inspect_btn.setObjectName("primaryButton")
        inspect_btn.clicked.connect(self._inspect_transformation)
        action_row.addWidget(refresh_layers)
        action_row.addWidget(custom_target)
        action_row.addWidget(inspect_btn)
        transform_content.addLayout(action_row)
        self.transformation_view = QPlainTextEdit()
        self.transformation_view.setReadOnly(True)
        self.transformation_view.setMinimumHeight(245)
        self.transformation_view.setPlaceholderText("Transformation details will appear here.")
        transform_content.addWidget(self.transformation_view, 1)
        transform_layout.addWidget(transform_card, 1)
        self._transform_custom_crs = None
        self.pages.addWidget(transform_page)

        # Page 8 — Quality Assurance
        qa_page = QWidget()
        qa_layout = QVBoxLayout(qa_page)
        qa_layout.setContentsMargins(0, 0, 0, 0)
        qa_layout.setSpacing(13)
        qa_layout.addWidget(self._workspace_hero(
            "Before and after validation",
            "Preflight & Postflight QA",
            "Run a readiness review before harmonization and inspect output validation after reprojection. QA does not silently change data or CRS assignments."
        ))
        qa_card, qa_content = self._workspace_card(
            "Quality assurance results",
            "Preflight checks layer availability, valid source CRS, non-empty extents and transformation feasibility. Postflight checks generated output validity, CRS and basic data integrity."
        )
        qa_actions = QHBoxLayout()
        preflight_btn = QPushButton("Run preflight checks")
        preflight_btn.setObjectName("primaryButton")
        preflight_btn.clicked.connect(self._run_preflight)
        qa_refresh_btn = QPushButton("Refresh QA history")
        qa_refresh_btn.clicked.connect(self._refresh_qa_view)
        qa_actions.addWidget(preflight_btn)
        qa_actions.addWidget(qa_refresh_btn)
        qa_actions.addStretch(1)
        qa_content.addLayout(qa_actions)
        self.qa_view = QPlainTextEdit()
        self.qa_view.setReadOnly(True)
        self.qa_view.setMinimumHeight(265)
        self.qa_view.setPlaceholderText("Preflight and postflight QA results will appear here.")
        qa_content.addWidget(self.qa_view, 1)
        qa_layout.addWidget(qa_card, 1)
        self.pages.addWidget(qa_page)

        # Page 9 — Automation and profiles
        automation_page = QWidget()
        automation_layout = QVBoxLayout(automation_page)
        automation_layout.setContentsMargins(0, 0, 0, 0)
        automation_layout.setSpacing(13)
        automation_layout.addWidget(self._workspace_hero(
            "Reusable standards and proactive monitoring",
            "Automation workspace",
            "Save named project CRS profiles and optionally monitor layer additions, removals and project CRS changes. Live monitoring triggers a fresh diagnostic scan; it never auto-assigns or reprojects data."
        ))
        monitor_card, monitor_layout = self._workspace_card(
            "Live CRS Sentinel",
            "When enabled, CRS Guardian re-runs diagnostics after project layer or project CRS changes."
        )
        self.live_sentinel_checkbox = QCheckBox("Enable live project monitoring")
        self.live_sentinel_checkbox.toggled.connect(self._toggle_live_sentinel)
        monitor_layout.addWidget(self.live_sentinel_checkbox)
        self.live_sentinel_status = QLabel("Monitoring is off. No automatic changes will be made to project data.")
        self.live_sentinel_status.setObjectName("muted")
        self.live_sentinel_status.setWordWrap(True)
        monitor_layout.addWidget(self.live_sentinel_status)
        automation_layout.addWidget(monitor_card)

        profile_card, profile_layout = self._workspace_card(
            "CRS profiles",
            "Save the current target CRS and measurement-unit preference for repeatable project setup. Profiles are stored locally in the active QGIS user profile."
        )
        profile_row = QHBoxLayout()
        self.profile_name_edit = QLineEdit()
        self.profile_name_edit.setPlaceholderText("Profile name, e.g. Engineering Feet")
        self.profile_combo = QComboBox()
        self.profile_combo.setMinimumWidth(190)
        profile_row.addWidget(self.profile_name_edit, 2)
        profile_row.addWidget(self.profile_combo, 1)
        profile_layout.addLayout(profile_row)
        profile_actions = QHBoxLayout()
        save_profile_btn = QPushButton("Save current profile")
        save_profile_btn.setObjectName("primaryButton")
        save_profile_btn.clicked.connect(self._save_profile)
        load_profile_btn = QPushButton("Load selected profile")
        load_profile_btn.clicked.connect(self._load_selected_profile)
        refresh_profiles_btn = QPushButton("Refresh profiles")
        refresh_profiles_btn.clicked.connect(self._refresh_profile_list)
        profile_actions.addWidget(save_profile_btn)
        profile_actions.addWidget(load_profile_btn)
        profile_actions.addWidget(refresh_profiles_btn)
        profile_layout.addLayout(profile_actions)
        automation_layout.addWidget(profile_card)
        profile_note = QLabel("Profiles only store CRS Guardian preferences. They do not modify source layers and are not embedded into external datasets.")
        profile_note.setObjectName("muted")
        profile_note.setWordWrap(True)
        automation_layout.addWidget(profile_note)
        automation_layout.addStretch(1)
        self.pages.addWidget(automation_page)
        self._refresh_profile_list()
        self._refresh_transformation_layers()

    # ------------------------------------------------------ projection advisor
    @staticmethod
    def _utm_zone(longitude, latitude=None):
        """Return the UTM zone, including Norway and Svalbard special zones."""
        lon = float(longitude)
        lat = float(latitude) if latitude is not None else 0.0
        if 56.0 <= lat < 64.0 and 3.0 <= lon < 12.0:
            return 32
        if 72.0 <= lat < 84.0:
            if 0.0 <= lon < 9.0:
                return 31
            if 9.0 <= lon < 21.0:
                return 33
            if 21.0 <= lon < 33.0:
                return 35
            if 33.0 <= lon < 42.0:
                return 37
        return max(1, min(60, int(math.floor((lon + 180.0) / 6.0)) + 1))

    def _refresh_projection_intelligence(self):
        """Analyze sampled project layer footprints and only recommend defensible UTM cases."""
        if not hasattr(self, "intelligence_view"):
            return
        project = QgsProject.instance()
        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        sample_points = []
        layer_rows = []
        skipped = []
        layers = list(project.mapLayers().values())
        supported = (layer_type_value("VectorLayer"), layer_type_value("RasterLayer"), layer_type_value("MeshLayer"))
        for layer in layers:
            try:
                if layer.type() not in supported:
                    continue
                valid, reason = errors.validate_layer(layer)
                crs = layer.crs()
                if not valid or crs is None or not crs.isValid():
                    skipped.append("{} — invalid layer or missing CRS".format(self._safe_layer_name(layer)))
                    continue
                extent = layer.extent()
                if extent is None or extent.isNull() or extent.isEmpty():
                    skipped.append("{} — empty extent".format(self._safe_layer_name(layer)))
                    continue
                transform = QgsCoordinateTransform(crs, wgs84, project)
                xmin, xmax = extent.xMinimum(), extent.xMaximum()
                ymin, ymax = extent.yMinimum(), extent.yMaximum()
                # Nine samples reduce the risk of relying only on a layer centroid.
                coords = [
                    (xmin, ymin), ((xmin + xmax) / 2.0, ymin), (xmax, ymin),
                    (xmax, (ymin + ymax) / 2.0), (xmax, ymax),
                    ((xmin + xmax) / 2.0, ymax), (xmin, ymax),
                    (xmin, (ymin + ymax) / 2.0), ((xmin + xmax) / 2.0, (ymin + ymax) / 2.0),
                ]
                transformed = []
                for x, y in coords:
                    try:
                        point = transform.transform(QgsPointXY(float(x), float(y)))
                        lon, lat = float(point.x()), float(point.y())
                        if math.isfinite(lon) and math.isfinite(lat) and -180 <= lon <= 180 and -90 <= lat <= 90:
                            transformed.append((lon, lat))
                    except Exception as point_exc:
                        errors.log_exception("Unable to transform a sampled project footprint coordinate", point_exc)
                if not transformed:
                    skipped.append("{} — extent could not be transformed to WGS 84".format(self._safe_layer_name(layer)))
                    continue
                sample_points.extend(transformed)
                layer_rows.append((self._safe_layer_name(layer), crs.authid() or crs.description(), len(transformed)))
            except Exception as exc:
                skipped.append("{} — {}".format(self._safe_layer_name(layer), exc))
                errors.log_exception("Projection intelligence failed for layer", exc)

        if not sample_points:
            self._projection_recommendation = None
            self._projection_analysis = None
            self.use_projection_btn.setEnabled(False)
            lines = ["No valid georeferenced layer extents were available for analysis.", "Run Diagnostics and verify source CRS definitions before requesting a projection recommendation."]
            if skipped:
                lines.append("\nSkipped layers:\n" + "\n".join("• " + item for item in skipped[:15]))
            self.intelligence_view.setPlainText("\n".join(lines))
            return

        # Circular longitude mean handles projects close to the antimeridian more safely.
        sin_sum = sum(math.sin(math.radians(p[0])) for p in sample_points)
        cos_sum = sum(math.cos(math.radians(p[0])) for p in sample_points)
        center_lon = math.degrees(math.atan2(sin_sum, cos_sum))
        center_lat = sum(p[1] for p in sample_points) / float(len(sample_points))
        lons = [p[0] for p in sample_points]
        lats = [p[1] for p in sample_points]
        lon_span = max(lons) - min(lons)
        lat_span = max(lats) - min(lats)
        zones = sorted(set(self._utm_zone(lon, lat) for lon, lat in sample_points))
        crosses_equator = min(lats) < 0 < max(lats)
        inside_utm_latitudes = min(lats) >= -80.0 and max(lats) <= 84.0
        recommendation = None
        confidence = "LOW"
        reasons = []
        if not inside_utm_latitudes:
            reasons.append("Part of the project footprint lies outside the usual UTM latitude band (-80° to 84°). Consider a suitable polar or regional CRS.")
        elif crosses_equator:
            reasons.append("The project footprint crosses the equator. A single northern or southern UTM zone is not a safe automatic recommendation.")
        elif len(zones) > 1:
            reasons.append("The footprint intersects {} UTM zones ({}). A single UTM CRS may distort or complicate edge coverage; choose a regional/project-specific CRS deliberately.".format(len(zones), ", ".join(str(z) for z in zones)))
        else:
            zone = zones[0]
            epsg = (32600 if center_lat >= 0 else 32700) + zone
            candidate = QgsCoordinateReferenceSystem("EPSG:{}".format(epsg))
            if candidate.isValid():
                recommendation = candidate
                if lon_span <= 5.0 and lat_span <= 8.0:
                    confidence = "HIGH"
                    reasons.append("The sampled footprint stays inside one UTM zone and is geographically compact.")
                else:
                    confidence = "MEDIUM"
                    reasons.append("The sampled footprint stays inside one UTM zone, but its geographic span is broad. Check scale distortion and project purpose before adopting the suggestion.")
        self._projection_recommendation = recommendation
        self._projection_analysis = {
            "layers": len(layer_rows), "points": len(sample_points), "zones": zones,
            "center": (center_lon, center_lat), "lon_span": lon_span, "lat_span": lat_span,
            "confidence": confidence,
        }
        lines = [
            "ANALYSIS SUMMARY",
            "Supported layers analyzed: {} of {} project layers".format(len(layer_rows), len(layers)),
            "Sampled WGS 84 coordinates: {}".format(len(sample_points)),
            "Approximate center: {:.6f}° longitude, {:.6f}° latitude".format(center_lon, center_lat),
            "Longitude / latitude span: {:.4f}° / {:.4f}°".format(lon_span, lat_span),
            "UTM zones touched by samples: {}".format(", ".join(str(z) for z in zones) or "Not determined"),
            "",
            "PROJECTION GUIDANCE",
        ]
        if recommendation is not None and skipped:
            # Unresolved layers are excluded from the footprint; avoid overstating coverage confidence.
            confidence = "LOW"
            reasons.append("Some project layers could not be included in the footprint analysis; verify their CRS and extent before applying this candidate.")
        if recommendation is not None:
            lines.extend([
                "Recommended candidate: {} — {}".format(recommendation.authid(), recommendation.description()),
                "Confidence: {}".format(confidence),
            ])
            self.use_projection_btn.setEnabled(True)
        else:
            lines.append("No automatic UTM candidate was issued.")
            self.use_projection_btn.setEnabled(False)
        lines.extend("• " + reason for reason in reasons)
        if layer_rows:
            lines.extend(["", "LAYER FOOTPRINTS"])
            lines.extend("• {} | {} | {} samples".format(name, crs, count) for name, crs, count in layer_rows[:30])
        if skipped:
            lines.extend(["", "SKIPPED / UNRESOLVED"])
            lines.extend("• " + item for item in skipped[:15])
        lines.extend(["", "This analysis is advisory. It does not verify the source CRS or estimate all local scale distortions."])
        self.intelligence_view.setPlainText("\n".join(lines))

    def _use_projection_recommendation(self):
        crs = self._projection_recommendation
        if crs is None or not crs.isValid():
            return
        index = self.target_combo.findData(TARGET_CUSTOM)
        if index < 0:
            return
        self._custom_crs = crs
        self.target_combo.blockSignals(True)
        self.target_combo.setItemText(index, "Suggested · {}".format(crs.authid()))
        self.target_combo.setCurrentIndex(index)
        self.target_combo.blockSignals(False)
        self.target_hint.setText("Footprint-based suggestion · {} · Verify suitability for your project purpose.".format(crs.authid()))
        self._add_activity("Loaded footprint-based projection suggestion {} into Harmonize target selection.".format(crs.authid()))
        self._navigate_to(1)

    # ------------------------------------------------------ measurement guard
    @staticmethod
    def _unit_text(unit):
        try:
            from qgis.core import QgsUnitTypes
            return QgsUnitTypes.toString(unit)
        except Exception:
            try:
                return str(unit)
            except Exception:
                return "Unknown"

    def _refresh_measurement_guard(self):
        if not hasattr(self, "measurement_view"):
            return
        project = QgsProject.instance()
        try:
            distance = self._unit_text(project.distanceUnits())
        except Exception:
            distance = "Unavailable"
        try:
            area = self._unit_text(project.areaUnits())
        except Exception:
            area = "Unavailable"
        try:
            ellipsoid = project.ellipsoid() or "None / planimetric"
        except Exception:
            ellipsoid = "Unavailable"
        try:
            project_crs = project.crs()
            project_map_units = self._unit_text(project_crs.mapUnits()) if project_crs and project_crs.isValid() else "Project CRS not set"
        except Exception:
            project_map_units = "Unavailable"
        def unit_family(value):
            text = (value or "").strip().lower().replace("_", " ")
            if "degree" in text or "radian" in text:
                return "angular"
            if "ftus" in text or "us survey" in text or ("survey" in text and ("foot" in text or "feet" in text or "ft" in text)):
                return "us_survey_feet"
            if "foot" in text or "feet" in text or text in ("ft", "feet"):
                return "international_feet"
            if "metre" in text or "meter" in text:
                return "metres"
            return "unknown"

        project_distance_family = unit_family(distance)
        project_map_family = unit_family(project_map_units)
        lines = [
            "PROJECT MEASUREMENT SETTINGS",
            "Distance measurement unit: {}".format(distance),
            "Area measurement unit: {}".format(area),
            "Ellipsoid: {}".format(ellipsoid),
            "Project CRS map units: {}".format(project_map_units),
        ]
        if project_map_family == "angular" and project_distance_family in ("metres", "international_feet", "us_survey_feet"):
            lines.append("REVIEW: The project CRS uses angular coordinates while the distance preference is linear. Confirm that the intended measurement workflow uses ellipsoidal/geodesic measurements.")
        elif project_map_family not in ("unknown", "angular") and project_distance_family not in ("unknown", project_map_family):
            lines.append("UNIT DIFFERENCE: Project distance preference differs from the project CRS map units. QGIS measurement APIs can convert units, but confirm downstream tools honour the project measurement settings.")
        lines.extend(["", "LAYER MAP UNIT REVIEW"])
        warnings = 0
        unit_differences = 0
        for layer in project.mapLayers().values():
            try:
                crs = layer.crs()
                if crs is None or not crs.isValid():
                    lines.append("• {} — CRS missing / invalid".format(self._safe_layer_name(layer)))
                    warnings += 1
                    continue
                map_units = self._unit_text(crs.mapUnits())
                is_geographic = crs.isGeographic()
                family = unit_family(map_units)
                if is_geographic:
                    label = "WARNING: angular map units; use geodesic measurement or reproject for planar engineering operations"
                    warnings += 1
                elif family not in ("unknown", project_distance_family):
                    label = "REVIEW: layer map units differ from the project distance preference; check tool-specific unit handling"
                    unit_differences += 1
                else:
                    label = "Linear map units"
                lines.append("• {} | {} | {} | {}".format(self._safe_layer_name(layer), crs.authid() or crs.description(), map_units, label))
            except Exception as exc:
                warnings += 1
                lines.append("• {} — could not inspect units ({})".format(self._safe_layer_name(layer), exc))
        lines.extend(["", "UNIT GUARD SUMMARY", "{} potential unit / CRS warnings".format(warnings), "{} project/layer unit differences requiring review".format(unit_differences)])
        if warnings or unit_differences:
            lines.append("A project measurement preference does not change native source coordinate values. Confirm downstream tool behaviour, ellipsoid settings and required accuracy before measurement-intensive work.")
        else:
            lines.append("No missing CRS or geographic layer-unit risks were identified. Confirm unit conventions before engineering production work.")
        self.measurement_view.setPlainText("\n".join(lines))

    @staticmethod
    def _qgis_unit_enum(kind, key):
        """Resolve unit enums across the QGIS 3 legacy and QGIS 4 scoped API styles."""
        from qgis.core import QgsUnitTypes
        legacy_names = {
            ("distance", "meters"): "DistanceMeters",
            ("distance", "feet"): "DistanceFeet",
            ("distance", "us_survey_feet"): "DistanceFeetUSSurvey",
            ("area", "meters"): "AreaSquareMeters",
            ("area", "feet"): "AreaSquareFeet",
            ("area", "us_survey_feet"): None,
        }
        legacy_name = legacy_names[(kind, key)]
        if legacy_name is not None:
            legacy = getattr(QgsUnitTypes, legacy_name, None)
            if legacy is not None:
                return legacy
        elif kind == "area" and key == "us_survey_feet":
            # QGIS has no distinct US-survey-square-foot project area enum.
            return None
        try:
            from qgis.core import Qgis
            group = getattr(Qgis, "DistanceUnit" if kind == "distance" else "AreaUnit")
            scoped_names = {
                ("distance", "meters"): "Meters",
                ("distance", "feet"): "Feet",
                ("distance", "us_survey_feet"): "FeetUSSurvey",
                ("area", "meters"): "SquareMeters",
                ("area", "feet"): "SquareFeet",
                ("area", "us_survey_feet"): None,
            }
            scoped_name = scoped_names[(kind, key)]
            return getattr(group, scoped_name) if scoped_name else None
        except Exception:
            return None

    def _apply_measurement_unit(self):
        key = self.measurement_unit_combo.currentData()
        if key == "keep":
            self._set_status("No unit change requested.")
            return
        project = QgsProject.instance()
        distance_enum = self._qgis_unit_enum("distance", key)
        if distance_enum is None:
            self._show_message("Warning", "Unit is not available", "This QGIS build does not expose the requested measurement unit.")
            return
        unit_note = "This changes project measurement preferences only. It does not reproject or modify any layer coordinates."
        if key == "us_survey_feet":
            unit_note += "\n\nQGIS does not expose a separate square US-survey-foot area unit; the current project area preference will remain unchanged."
        choice = self._show_message(
            "Question", "Apply project measurement unit?",
            "Set the project distance measurement unit to {}?".format(self.measurement_unit_combo.currentText()),
            unit_note,
            message_box_button("Yes") | message_box_button("No")
        )
        if choice != message_box_button("Yes"):
            return
        try:
            project.setDistanceUnits(distance_enum)
            area_enum = self._qgis_unit_enum("area", key)
            if area_enum is not None:
                project.setAreaUnits(area_enum)
            project.setDirty(True)
            self._add_activity("Updated project measurement preference to {}.".format(self.measurement_unit_combo.currentText()), "SUCCESS")
            self._refresh_measurement_guard()
            self._set_status("Project measurement preference updated. Layer coordinate values were not changed.")
        except Exception as exc:
            errors.show_error(self, "Unable to update measurement settings", "QGIS could not apply the selected measurement unit.", exc)

    # ------------------------------------------------------ transformation inspector
    def _refresh_transformation_layers(self):
        if not hasattr(self, "transform_layer_combo"):
            return
        current = self.transform_layer_combo.currentData()
        self.transform_layer_combo.clear()
        for layer in QgsProject.instance().mapLayers().values():
            try:
                crs = layer.crs()
                crs_text = crs.authid() if crs and crs.isValid() else "CRS missing"
                self.transform_layer_combo.addItem("{}  ·  {}".format(self._safe_layer_name(layer), crs_text), layer.id())
            except Exception:
                continue
        index = self.transform_layer_combo.findData(current)
        if index >= 0:
            self.transform_layer_combo.setCurrentIndex(index)

    def _choose_transformation_target(self):
        try:
            dialog = QgsProjectionSelectionDialog(self)
            dialog.setWindowTitle("Choose transformation destination CRS")
            dialog.setStyleSheet(STYLE)
            QTimer.singleShot(0, lambda target=dialog: self._apply_native_dark_titlebar(target))
            if self._transform_custom_crs is not None and self._transform_custom_crs.isValid():
                dialog.setCrs(self._transform_custom_crs)
            if dialog_exec(dialog):
                crs = dialog.crs()
                if crs is not None and crs.isValid():
                    self._transform_custom_crs = crs
                    for existing_index in range(self.transform_target_combo.count() - 1, -1, -1):
                        if self.transform_target_combo.itemData(existing_index) == "custom":
                            self.transform_target_combo.removeItem(existing_index)
                    self.transform_target_combo.addItem("Custom · {}".format(crs.authid() or crs.description()), "custom")
                    self.transform_target_combo.setCurrentIndex(self.transform_target_combo.count() - 1)
        except Exception as exc:
            errors.show_error(self, "CRS selector failed", "The custom target CRS selector could not be opened.", exc)

    def _inspect_transformation(self):
        layer_id = self.transform_layer_combo.currentData()
        layer = QgsProject.instance().mapLayer(layer_id) if layer_id else None
        if layer is None:
            self.transformation_view.setPlainText("Choose a project layer first.")
            return
        try:
            source = layer.crs()
            if source is None or not source.isValid():
                raise ValueError("The selected layer has no valid source CRS. Assign the correct source CRS before inspecting a transformation.")
            target_key = self.transform_target_combo.currentData()
            if target_key == "project":
                target = QgsProject.instance().crs()
            elif target_key == "custom":
                target = self._transform_custom_crs
            else:
                target = QgsCoordinateReferenceSystem(str(target_key))
            if target is None or not target.isValid():
                raise ValueError("The selected destination CRS is invalid or the project CRS is not set.")

            transform = QgsCoordinateTransform(source, target, QgsProject.instance())
            lines = [
                "SOURCE LAYER: {}".format(self._safe_layer_name(layer)),
                "SOURCE CRS: {} — {}".format(source.authid() or "Custom CRS", source.description()),
                "DESTINATION CRS: {} — {}".format(target.authid() or "Custom CRS", target.description()),
                "",
                "SAMPLE TRANSFORM CHECK",
            ]
            sample_succeeded = False
            extent = layer.extent()
            if extent is not None and not extent.isNull() and not extent.isEmpty():
                try:
                    transform.transform(extent.center())
                    sample_succeeded = True
                    lines.append("Coordinate test: succeeded at the source extent centre.")
                    try:
                        if transform.fallbackOperationOccurred():
                            lines.append("WARNING: QGIS reported a fallback transformation for the sample coordinate.")
                        else:
                            lines.append("Fallback status: no fallback reported for the sample coordinate.")
                    except Exception:
                        lines.append("Fallback status: this QGIS/PROJ build does not expose fallback reporting.")
                except Exception as test_exc:
                    lines.append("WARNING: Sample coordinate transform failed: {}".format(test_exc))
            else:
                lines.append("No non-empty layer extent was available for a sample coordinate test.")

            lines.extend(["", "COORDINATE OPERATION"])
            try:
                operation = transform.coordinateOperation()
                lines.append(operation or "No explicit PROJ operation string was exposed by this QGIS/PROJ build.")
            except Exception as operation_exc:
                lines.append("Requested operation string unavailable: {}".format(operation_exc))
            try:
                details = transform.instantiatedCoordinateOperationDetails()
                for attr, label in (("name", "Instantiated operation name"), ("accuracy", "Reported accuracy (metres)"), ("proj", "Instantiated PROJ pipeline"), ("scope", "Scope"), ("remarks", "Remarks")):
                    value = getattr(details, attr, None)
                    if callable(value):
                        try:
                            value = value()
                        except Exception:
                            value = None
                    if value not in (None, "", 0):
                        lines.append("{}: {}".format(label, value))
                grids = getattr(details, "grids", None)
                if callable(grids):
                    grids = grids()
                if grids:
                    lines.append("Required grids: {}".format(", ".join(str(g) for g in grids)))
            except Exception as detail_exc:
                lines.append("Instantiated operation details unavailable: {}".format(detail_exc))
            try:
                lines.append("Fallback transformations allowed: {}".format(transform.allowFallbackTransforms()))
            except Exception:
                pass
            try:
                lines.append("Vertical component: {}".format(transform.hasVerticalComponent()))
            except Exception:
                pass
            try:
                lines.append("Transform object valid: {}".format(transform.isValid()))
            except Exception:
                pass
            lines.extend([
                "",
                "Interpretation: the operation metadata describes the current project transform context. A successful test at one coordinate does not guarantee that every coordinate in the layer can be transformed.",
                "Accuracy and availability depend on the installed PROJ database and required grid resources.",
            ])
            self.transformation_view.setPlainText("\n".join(lines))
            level = "SUCCESS" if sample_succeeded else "WARNING"
            self._add_activity("Inspected transformation {} → {} for layer '{}' (sample test {}).".format(source.authid(), target.authid(), self._safe_layer_name(layer), "passed" if sample_succeeded else "not passed"), level)
        except Exception as exc:
            self.transformation_view.setPlainText("Transformation inspection could not be completed.\n\n{}".format(exc))
            self._add_activity("Transformation inspection warning: {}".format(exc), "WARNING")

    # ------------------------------------------------------ preflight / postflight
    def _run_preflight(self, checked=False, target_override=None):
        """Check source layers and test a representative transform before processing."""
        project = QgsProject.instance()
        target = target_override if target_override is not None else project.crs()
        supported = (layer_type_value("VectorLayer"), layer_type_value("RasterLayer"))
        lines = ["PREFLIGHT REPORT · {}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S")), ""]
        passed = warnings = failed = 0
        layers = [layer for layer in project.mapLayers().values() if layer.type() in supported]
        if not layers:
            lines.append("FAIL — No supported vector or raster layers are available.")
            failed += 1
        for layer in layers:
            checks = []
            status = "PASS"
            try:
                valid, reason = errors.validate_layer(layer)
                if not valid:
                    status = "FAIL"
                    checks.append("Layer/provider unavailable: {}".format(reason))
                else:
                    checks.append("Layer/provider is valid")

                source = layer.crs()
                if source is None or not source.isValid():
                    status = "FAIL"
                    checks.append("Source CRS missing or invalid")
                else:
                    checks.append("Source CRS: {}".format(source.authid() or source.description()))

                extent = layer.extent()
                has_extent = extent is not None and not extent.isNull() and not extent.isEmpty()
                if not has_extent:
                    if status != "FAIL":
                        status = "WARNING"
                    checks.append("Layer extent is empty")
                else:
                    checks.append("Layer extent is non-empty")

                if source is not None and source.isValid():
                    if target is None or not target.isValid():
                        if status != "FAIL":
                            status = "WARNING"
                        checks.append("Target CRS is not valid or not set")
                    else:
                        possible_fn = getattr(QgsCoordinateTransform, "isTransformationPossible", None)
                        if callable(possible_fn):
                            try:
                                if not possible_fn(source, target):
                                    status = "FAIL"
                                    checks.append("QGIS reports that this source-to-target CRS pair is not theoretically transformable")
                                else:
                                    checks.append("CRS pair is theoretically transformable")
                            except Exception as possible_exc:
                                if status != "FAIL":
                                    status = "WARNING"
                                checks.append("Theoretical feasibility check unavailable: {}".format(possible_exc))
                        else:
                            checks.append("This QGIS version does not expose a separate theoretical feasibility check")

                        if status != "FAIL":
                            try:
                                probe = QgsCoordinateTransform(source, target, project)
                                if not probe.isValid():
                                    status = "FAIL"
                                    checks.append("QGIS could not construct the coordinate transform")
                                elif has_extent:
                                    probe.transform(extent.center())
                                    checks.append("Sample coordinate transformed successfully using the project transform context")
                                    try:
                                        if probe.fallbackOperationOccurred():
                                            if status != "FAIL":
                                                status = "WARNING"
                                            checks.append("QGIS reported a fallback transformation for the sample coordinate")
                                    except Exception:
                                        checks.append("Fallback reporting is unavailable in this QGIS/PROJ build")
                                else:
                                    if status != "FAIL":
                                        status = "WARNING"
                                    checks.append("No sample coordinate was available to test the transform")
                            except Exception as transform_exc:
                                status = "FAIL"
                                checks.append("Sample coordinate transform failed; inspect datum operation and grid resources: {}".format(transform_exc))
            except Exception as exc:
                status = "FAIL"
                checks.append("Inspection failed: {}".format(exc))

            if status == "PASS":
                passed += 1
            elif status == "WARNING":
                warnings += 1
            else:
                failed += 1
            lines.append("{} — {}".format(status, self._safe_layer_name(layer)))
            lines.extend("   • " + item for item in checks)
            lines.append("")

        lines.extend(["SUMMARY", "PASS: {}   WARNING: {}   FAIL: {}".format(passed, warnings, failed)])
        if failed:
            lines.append("Resolve failed checks before starting a production harmonization batch.")
        elif warnings:
            lines.append("Review warnings and confirm the intended target CRS and transformation accuracy before processing.")
        else:
            lines.append("Preflight checks passed for all supported layers. Review target suitability and measurement conventions before production use.")
        lines.extend([
            "",
            "Limit: the sample transformation tests one representative coordinate per layer. It cannot guarantee every feature coordinate will transform or that the selected operation meets a project-specific accuracy requirement.",
        ])
        self._preflight_report = "\n".join(lines)
        self._refresh_qa_view()
        self._add_activity("Preflight QA completed: {} pass, {} warning, {} fail.".format(passed, warnings, failed), "ERROR" if failed else ("WARNING" if warnings else "SUCCESS"))
        return passed, warnings, failed

    def _validate_output_layer(self, source_layer, output_layer, target_crs):
        """Postflight-check an output before it is registered in the project."""
        checks = []
        status = "PASS"
        if output_layer is None or not output_layer.isValid():
            return {"status": "FAIL", "layer": self._safe_layer_name(source_layer), "checks": ["Output provider could not open the generated file"]}
        checks.append("Output provider opened successfully")
        try:
            output_crs = output_layer.crs()
            if output_crs is None or not output_crs.isValid():
                status = "FAIL"
                checks.append("Output CRS is missing or invalid")
            elif output_crs != target_crs and output_crs.authid() != target_crs.authid():
                status = "FAIL"
                checks.append("Output CRS does not match the requested target CRS ({})".format(target_crs.authid()))
            else:
                checks.append("Output CRS matches requested target ({})".format(target_crs.authid() or target_crs.description()))
            extent = output_layer.extent()
            if extent is None or extent.isNull() or extent.isEmpty():
                status = "FAIL"
                checks.append("Output extent is empty")
            else:
                checks.append("Output extent is non-empty")
            if output_layer.type() == layer_type_value("VectorLayer"):
                source_count = int(source_layer.featureCount())
                output_count = int(output_layer.featureCount())
                if source_count < 0 or output_count < 0:
                    if status != "FAIL":
                        status = "WARNING"
                    checks.append("Feature count could not be confirmed by the provider")
                elif source_count != output_count:
                    status = "FAIL"
                    checks.append("Feature-count mismatch: source {} / output {}".format(source_count, output_count))
                else:
                    checks.append("Feature count preserved: {}".format(output_count))
            elif output_layer.type() == layer_type_value("RasterLayer"):
                width = int(output_layer.width())
                height = int(output_layer.height())
                if width <= 0 or height <= 0 or int(output_layer.bandCount()) <= 0:
                    status = "FAIL"
                    checks.append("Raster dimensions or band count are invalid")
                else:
                    checks.append("Raster dimensions and band count are valid: {} × {}, {} band(s)".format(width, height, output_layer.bandCount()))
        except Exception as exc:
            status = "FAIL"
            checks.append("Postflight check raised an error: {}".format(exc))
        return {"status": status, "layer": self._safe_layer_name(source_layer), "checks": checks, "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

    def _refresh_qa_view(self):
        if not hasattr(self, "qa_view"):
            return
        lines = []
        if self._preflight_report:
            lines.extend(["LATEST PREFLIGHT REPORT", self._preflight_report, "", "LATEST POSTFLIGHT RESULTS"])
        else:
            lines.append("LATEST POSTFLIGHT RESULTS")
        if not self._qa_results:
            lines.append("No postflight output results are recorded in this session.")
        else:
            for result in self._qa_results[-50:]:
                lines.append("{} — {} — {}".format(result.get("status", "UNKNOWN"), result.get("layer", "Layer"), result.get("time", "")))
                lines.extend("   • " + check for check in result.get("checks", []))
        lines.extend(["", "Run preflight before harmonization to inspect source layers and transformation feasibility."])
        self.qa_view.setPlainText("\n".join(lines))

    # ------------------------------------------------------ automation profiles
    def _profiles_file_path(self):
        try:
            root = QgsApplication.qgisSettingsDirPath()
        except Exception:
            root = ""
        if not root:
            root = os.path.join(os.path.expanduser("~"), ".qgis")
        folder = os.path.join(root, "crs_guardian")
        if not os.path.isdir(folder):
            os.makedirs(folder)
        return os.path.join(folder, "profiles.json")

    def _read_profiles(self):
        try:
            with open(self._profiles_file_path(), "r", encoding="utf-8") as stream:
                data = json.load(stream)
            return data if isinstance(data, dict) else {}
        except IOError:
            return {}
        except Exception as exc:
            errors.log_exception("Unable to read CRS Guardian profiles", exc)
            return {}

    def _refresh_profile_list(self):
        if not hasattr(self, "profile_combo"):
            return
        current = self.profile_combo.currentText()
        profiles = self._read_profiles()
        self.profile_combo.clear()
        for name in sorted(profiles.keys(), key=lambda value: value.lower()):
            self.profile_combo.addItem(name)
        index = self.profile_combo.findText(current)
        if index >= 0:
            self.profile_combo.setCurrentIndex(index)

    def _save_profile(self):
        name = self.profile_name_edit.text().strip()
        if not name:
            self._show_message("Information", "Profile name required", "Enter a name for this CRS profile.")
            return
        try:
            profiles = self._read_profiles()
            target_mode = self.target_combo.currentData()
            target_crs = ""
            target_wkt = ""
            if target_mode == TARGET_PROJECT:
                current = QgsProject.instance().crs()
                target_crs = current.authid() if current and current.isValid() else ""
                target_wkt = current.toWkt() if current and current.isValid() else ""
            elif target_mode == TARGET_CUSTOM and self._custom_crs is not None and self._custom_crs.isValid():
                target_crs = self._custom_crs.authid()
                target_wkt = self._custom_crs.toWkt()
            profiles[name] = {
                "measurement_unit": self.measurement_unit_combo.currentData(),
                "target_mode": target_mode,
                "target_crs": target_crs,
                "target_wkt": target_wkt,
                "saved_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            with open(self._profiles_file_path(), "w", encoding="utf-8") as stream:
                json.dump(profiles, stream, indent=2, sort_keys=True)
            self._refresh_profile_list()
            self.profile_combo.setCurrentIndex(self.profile_combo.findText(name))
            self._add_activity("Saved CRS Guardian profile '{}'.".format(name), "SUCCESS")
            self._set_status("Profile '{}' saved locally.".format(name))
        except Exception as exc:
            errors.show_error(self, "Profile save failed", "The CRS profile could not be saved.", exc)

    def _load_selected_profile(self):
        name = self.profile_combo.currentText()
        profile = self._read_profiles().get(name)
        if not profile:
            self._show_message("Information", "No profile selected", "Choose a saved CRS profile first.")
            return
        unit_index = self.measurement_unit_combo.findData(profile.get("measurement_unit", "keep"))
        if unit_index >= 0:
            self.measurement_unit_combo.setCurrentIndex(unit_index)
        target_mode = profile.get("target_mode")
        if target_mode == TARGET_AUTO:
            index = self.target_combo.findData(TARGET_AUTO)
            if index >= 0:
                self.target_combo.setCurrentIndex(index)
        elif target_mode == TARGET_PROJECT:
            index = self.target_combo.findData(TARGET_PROJECT)
            if index >= 0:
                self.target_combo.setCurrentIndex(index)
        elif target_mode == TARGET_CUSTOM:
            crs = QgsCoordinateReferenceSystem(profile.get("target_crs", "")) if profile.get("target_crs") else QgsCoordinateReferenceSystem()
            if not crs.isValid() and profile.get("target_wkt"):
                crs.createFromWkt(profile.get("target_wkt"))
            if crs.isValid():
                self._custom_crs = crs
                index = self.target_combo.findData(TARGET_CUSTOM)
                if index >= 0:
                    self.target_combo.blockSignals(True)
                    self.target_combo.setItemText(index, "Custom · {}".format(crs.authid() or crs.description()))
                    self.target_combo.setCurrentIndex(index)
                    self.target_combo.blockSignals(False)
        self._add_activity("Loaded CRS Guardian profile '{}'.".format(name), "SUCCESS")
        self._set_status("Profile loaded. Review project settings before applying any changes.")

    def _toggle_live_sentinel(self, enabled):
        project = QgsProject.instance()
        if enabled == self._live_sentinel_enabled:
            return
        try:
            if enabled:
                project.layersAdded.connect(self._on_live_project_change)
                project.layersRemoved.connect(self._on_live_project_change)
                project.crsChanged.connect(self._on_live_project_change)
                self._live_sentinel_enabled = True
                self.live_sentinel_status.setText("Live monitoring is ON. A new diagnostics scan will run after layer or project CRS changes; no automatic data edits are performed.")
                self._add_activity("Live CRS Sentinel enabled.", "SUCCESS")
            else:
                for signal in (project.layersAdded, project.layersRemoved, project.crsChanged):
                    try:
                        signal.disconnect(self._on_live_project_change)
                    except Exception:
                        pass
                self._live_sentinel_enabled = False
                self.live_sentinel_status.setText("Monitoring is off. No automatic changes will be made to project data.")
                self._add_activity("Live CRS Sentinel disabled.")
        except Exception as exc:
            self._live_sentinel_enabled = False
            self.live_sentinel_checkbox.blockSignals(True)
            self.live_sentinel_checkbox.setChecked(False)
            self.live_sentinel_checkbox.blockSignals(False)
            self.live_sentinel_status.setText("Live monitoring could not be enabled: {}".format(exc))
            errors.log_exception("Unable to configure Live CRS Sentinel", exc)

    def _on_live_project_change(self, *args):
        if not self._live_sentinel_enabled:
            return
        self._refresh_transformation_layers()
        self._refresh_measurement_guard()
        if self._live_scan_pending:
            return
        self._live_scan_pending = True
        self.live_sentinel_status.setText("Project change detected. Diagnostics scan queued…")
        QTimer.singleShot(800, self._run_live_scan)

    def _run_live_scan(self):
        self._live_scan_pending = False
        if not self._live_sentinel_enabled or self._shutting_down:
            return
        if self._active_task is not None:
            self.live_sentinel_status.setText("Project change detected; scan will be retried after processing completes.")
            QTimer.singleShot(1500, self._run_live_scan)
            return
        self.run_scan()
        if self._live_sentinel_enabled:
            self.live_sentinel_status.setText("Live monitoring is ON. Latest CRS diagnostics are up to date.")

    def _export_activity_history(self):
        default_name = "crs_guardian_history_{}.txt".format(datetime.now().strftime("%Y%m%d_%H%M%S"))
        path, unused_filter = QFileDialog.getSaveFileName(self, "Export CRS Guardian history", default_name, "Text files (*.txt)")
        if not path:
            return
        if not path.lower().endswith(".txt"):
            path += ".txt"
        try:
            with open(path, "w", encoding="utf-8") as stream:
                stream.write("\n".join(self._activity_lines))
            self._set_status("History exported: {}".format(path))
            self._add_activity("Exported history to {}.".format(path), "SUCCESS")
        except Exception as exc:
            errors.show_error(self, "History export failed", "The activity history could not be exported.", exc)

    def _save_auto_scan_preference(self, checked):
        try:
            self._settings.setValue("CRSGuardian/autoScanOnOpen", bool(checked))
            self._settings.sync()
            self._add_activity("Automatic project scan on open {}.".format("enabled" if checked else "disabled"))
            self._set_status("Workspace preference saved.")
        except Exception as exc:
            errors.log_exception("Unable to save workspace preference", exc)

    def _apply_native_dark_titlebar(self, widget=None):
        """Request a dark native caption on Windows; safe no-op elsewhere."""
        if sys.platform != "win32":
            return
        try:
            import ctypes
            target = widget or self
            hwnd = ctypes.c_void_p(int(target.winId()))
            dwmapi = ctypes.WinDLL("dwmapi")
            setter = dwmapi.DwmSetWindowAttribute
            setter.restype = ctypes.c_long
            value = ctypes.c_int(1)
            # Attribute 20 is used by current Windows builds; 19 is a fallback.
            for attribute in (20, 19):
                result = setter(
                    hwnd, ctypes.c_uint(attribute),
                    ctypes.byref(value), ctypes.sizeof(value)
                )
                if result == 0:
                    break
        except Exception as exc:
            errors.log_exception("Unable to request Windows dark title bar", exc)

    def _show_message(self, icon_name, title, message, informative=None, buttons=None):
        """Show a consistently dark, non-native Qt message dialog."""
        box = QMessageBox(self)
        box.setWindowTitle(title)
        box.setText(message)
        if informative:
            box.setInformativeText(informative)
        try:
            box.setIcon(enum_value(QMessageBox, icon_name, "Icon"))
        except Exception:
            pass
        box.setStandardButtons(buttons if buttons is not None else message_box_button("Ok"))
        box.setStyleSheet(STYLE)
        QTimer.singleShot(0, lambda target=box: self._apply_native_dark_titlebar(target))
        return dialog_exec(box)

    def _navigate_to(self, page_index):
        """Switch workspace page and update the shared page heading."""
        titles = {
            0: ("Overview", "Project health, key statistics and immediate CRS alerts."),
            1: ("Harmonize", "Safely transform vector and raster layers into a consistent target CRS."),
            2: ("Reports & History", "Review persistent audit events and export project diagnostics."),
            3: ("Settings", "Plugin guidance, safety preferences and release information."),
            4: ("CRS Intelligence", "Analyze the project footprint and receive evidence-based projection guidance."),
            5: ("Diagnostics", "Inspect layer-by-layer CRS findings and open detailed explanations."),
            6: ("Measurement Guard", "Verify project distance units, area units, ellipsoid and layer map units."),
            7: ("Transformation", "Inspect the coordinate operation QGIS will use between source and destination CRSs."),
            8: ("Quality Assurance", "Run preflight checks and review postflight output validation results."),
            9: ("Automation", "Save reusable CRS profiles and enable live project monitoring."),
        }
        if page_index < 0 or page_index >= self.pages.count():
            return
        self.pages.setCurrentIndex(page_index)
        title, subtitle = titles.get(page_index, ("CRS Guardian", "Coordinate Systems Workspace"))
        self.page_title.setText(title)
        self.page_subtitle.setText(subtitle)
        # Button order is not stack order; select by the page index stored on each button.
        for button in self._nav_buttons:
            if getattr(button, "page_index", None) == page_index:
                button.setChecked(True)
                break
        if page_index == 4:
            self._refresh_projection_intelligence()
        elif page_index == 6:
            self._refresh_measurement_guard()
        elif page_index == 7:
            self._refresh_transformation_layers()
        elif page_index == 8:
            self._refresh_qa_view()

    def _sync_project_info(self):
        try:
            crs = QgsProject.instance().crs()
            value = crs.authid() if crs and crs.isValid() else "Not set"
        except Exception:
            value = "Unavailable"
        self.project_crs_badge.setText("PROJECT CRS  ·  {}".format(value))

    def _history_file_path(self):
        """Return a per-user QGIS profile path for persistent CRS Guardian history."""
        try:
            root = QgsApplication.qgisSettingsDirPath()
        except Exception:
            root = ""
        if not root:
            root = os.path.join(os.path.expanduser("~"), ".qgis")
        folder = os.path.join(root, "crs_guardian", "history")
        if not os.path.isdir(folder):
            os.makedirs(folder)
        return os.path.join(folder, "activity.log")

    def _load_persistent_history(self):
        """Load the most recent saved events so history survives QGIS restarts."""
        try:
            path = self._history_file_path()
            if os.path.isfile(path):
                with open(path, "r", encoding="utf-8") as stream:
                    self._activity_lines = stream.read().splitlines()[-500:]
            if hasattr(self, "activity_view"):
                self.activity_view.setPlainText("\n".join(self._activity_lines))
        except Exception as exc:
            errors.log_exception("Unable to load persistent activity history", exc)

    def _add_activity(self, message, level="INFO"):
        """Add and persist a timestamped event in the CRS Guardian history."""
        try:
            line = "{}  {:<7}  {}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), level.upper(), message)
            self._activity_lines.append(line)
            if len(self._activity_lines) > 500:
                self._activity_lines = self._activity_lines[-500:]
            if hasattr(self, "activity_view"):
                self.activity_view.appendPlainText(line)
            try:
                with open(self._history_file_path(), "a", encoding="utf-8") as stream:
                    stream.write(line + "\n")
            except Exception as exc:
                errors.log_exception("Unable to persist activity history", exc)
        except Exception:
            errors.get_logger().exception("Unable to append activity event")

    def _copy_activity(self):
        QApplication.clipboard().setText("\n".join(self._activity_lines))
        self._set_status("Activity log copied to clipboard.")

    def _clear_activity(self):
        self._activity_lines = []
        self.activity_view.clear()
        try:
            path = self._history_file_path()
            with open(path, "w", encoding="utf-8") as stream:
                stream.write("")
            self._add_activity("Persistent activity history cleared by user.", "WARNING")
        except Exception as exc:
            errors.log_exception("Unable to clear persistent activity history", exc)

    def _export_report(self):
        """Export the current scan results to a UTF-8 CSV report."""
        if not self._reports:
            self._show_message("Information", "No report available", "Run a project scan before exporting a report.")
            return
        default_name = "crs_guardian_report_{}.csv".format(datetime.now().strftime("%Y%m%d_%H%M%S"))
        dialog = QFileDialog(self, "Export CRS Guardian report")
        dialog.setOption(enum_value(QFileDialog, "DontUseNativeDialog", "Option"), True)
        dialog.setAcceptMode(enum_value(QFileDialog, "AcceptSave", "AcceptMode"))
        dialog.setFileMode(enum_value(QFileDialog, "AnyFile", "FileMode"))
        dialog.setNameFilter("CSV files (*.csv)")
        dialog.setDefaultSuffix("csv")
        dialog.selectFile(default_name)
        dialog.setStyleSheet(STYLE)
        QTimer.singleShot(0, lambda target=dialog: self._apply_native_dark_titlebar(target))
        if not dialog_exec(dialog):
            return
        selected_files = dialog.selectedFiles()
        path = selected_files[0] if selected_files else ""
        if not path:
            return
        if not path.lower().endswith(".csv"):
            path += ".csv"
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as stream:
                writer = csv.writer(stream)
                writer.writerow(["Layer", "Status", "Source CRS", "Findings", "Details"])
                for report in self._reports:
                    try:
                        crs = report.layer.crs()
                        crs_text = crs.authid() if crs and crs.isValid() else "Not assigned"
                    except Exception:
                        crs_text = "Unavailable"
                    writer.writerow([
                        self._safe_layer_name(report.layer),
                        report.severity,
                        crs_text,
                        report.issues,
                        report.hints,
                    ])
            self._add_activity("Exported {} layer reports to {}".format(len(self._reports), path), "SUCCESS")
            self._set_status("Report exported: {}".format(path))
            self._notify("success", "CRS report exported successfully.")
        except Exception as exc:
            errors.show_error(self, "Report export failed", "The CSV report could not be written.", exc)

    def _metric_card(self, value, caption, accent):
        card = QFrame()
        card.setObjectName("metricCard")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(15, 10, 15, 10)
        layout.setSpacing(1)
        value_label = QLabel(value)
        value_label.setObjectName("metricValue")
        value_label.setStyleSheet("color: {};".format(accent))
        caption_label = QLabel(caption)
        caption_label.setObjectName("metricCaption")
        layout.addWidget(value_label)
        layout.addWidget(caption_label)
        card.value_label = value_label
        return card

    # --------------------------------------------------------------- status
    def _set_status(self, message):
        try:
            self.status_label.setText(message)
        except Exception:
            errors.get_logger().exception("Unable to update status text")

    def _notify(self, level, message):
        try:
            bar = self.iface.messageBar()
            if level == "success":
                bar.pushInfo("CRS Guardian", message)
            elif level == "warning":
                bar.pushWarning("CRS Guardian", message)
            else:
                bar.pushInfo("CRS Guardian", message)
        except Exception:
            errors.get_logger().info(message)

    # ------------------------------------------------------------------ scan
    def run_scan(self):
        if self._active_task is not None:
            self._set_status("A processing task is running. Wait or cancel it before scanning.")
            return
        self.scan_btn.setEnabled(False)
        self._set_status("Scanning project layers…")
        self._add_activity("Project scan started.")
        try:
            findings, layer_count = checker.scan_project()
            self._reports = checker.aggregate_by_layer(findings)
            self._populate_table()
            self._update_metrics(layer_count)
            self._refresh_qa_view()
            self._refresh_projection_intelligence()
            self._refresh_measurement_guard()
            self._sync_project_info()
            self._set_status(
                "Scan complete · {} supported layer reports".format(len(self._reports))
            )
            critical = sum(1 for report in self._reports if report.severity == checker.CRITICAL)
            warnings = sum(1 for report in self._reports if report.severity == checker.WARNING)
            self._add_activity(
                "Scan complete: {} project layers, {} reports, {} critical, {} warnings.".format(
                    layer_count, len(self._reports), critical, warnings
                ), "SUCCESS" if not critical and not warnings else "WARNING"
            )
        except Exception as exc:
            errors.show_error(self, "CRS Guardian scan failed", "The project scan could not be completed.", exc)
            self._set_status("Scan failed. See the CRS Guardian log for details.")
            self._add_activity("Project scan failed: {}".format(exc), "ERROR")
        finally:
            self.scan_btn.setEnabled(True)

    def _update_metrics(self, layer_count):
        critical = sum(1 for report in self._reports if report.severity == checker.CRITICAL)
        warning = sum(1 for report in self._reports if report.severity == checker.WARNING)
        healthy = sum(1 for report in self._reports if report.severity == checker.OK)
        self.metric_layers.value_label.setText(str(layer_count))
        self.metric_critical.value_label.setText(str(critical))
        self.metric_warning.value_label.setText(str(warning))
        self.metric_ok.value_label.setText(str(healthy))
        if self._reports:
            score = max(0, 100 - (critical * 25) - (warning * 10))
            self.metric_health.value_label.setText("{}%".format(score))
        else:
            self.metric_health.value_label.setText("N/A")
        self._sync_project_info()

    def _populate_table(self):
        self.table.setRowCount(0)
        for report in self._reports:
            row = self.table.rowCount()
            self.table.insertRow(row)
            tooltip = report.hints or report.issues
            color = {
                checker.CRITICAL: COLORS["critical"],
                checker.WARNING: COLORS["warning"],
                checker.OK: COLORS["ok"],
            }.get(report.severity, COLORS["muted"])
            status_text = {
                checker.CRITICAL: "●  CRITICAL",
                checker.WARNING: "●  WARNING",
                checker.OK: "●  HEALTHY",
            }.get(report.severity, "●  UNKNOWN")
            dot = QTableWidgetItem(status_text)
            dot.setForeground(QColor(color))
            dot.setTextAlignment(_qt("AlignLeft", "AlignmentFlag") | _qt("AlignVCenter", "AlignmentFlag"))
            dot.setToolTip(tooltip)
            dot.setData(_qt("UserRole", "ItemDataRole"), report.severity)
            self.table.setItem(row, 0, dot)

            name = QTableWidgetItem(self._safe_layer_name(report.layer))
            name.setToolTip(tooltip)
            font = QFont()
            font.setBold(report.severity == checker.CRITICAL)
            name.setFont(font)
            try:
                name.setData(_qt("UserRole", "ItemDataRole"), report.layer.id())
            except Exception:
                pass
            self.table.setItem(row, 1, name)

            try:
                crs = report.layer.crs()
                crs_text = crs.authid() if crs and crs.isValid() else "Not assigned"
                crs_tip = crs.description() if crs and crs.isValid() else "No valid CRS"
            except Exception:
                crs_text, crs_tip = "Unavailable", "Layer could not be inspected"
            crs_item = QTableWidgetItem(crs_text)
            crs_item.setToolTip(crs_tip)
            self.table.setItem(row, 2, crs_item)

            issue = QTableWidgetItem(report.issues)
            issue.setToolTip(tooltip)
            self.table.setItem(row, 3, issue)

            if report.fix == "assign":
                action = self._action_button("Assign CRS", lambda unused=False, lyr=report.layer: self.fix_assign(lyr))
            elif report.fix == "reproject":
                action = self._action_button("Reproject", lambda unused=False, lyr=report.layer: self.fix_reproject(lyr))
            else:
                action = QLabel("✓")
                action.setAlignment(_qt("AlignCenter", "AlignmentFlag"))
                action.setStyleSheet("color: {}; font-size: 12pt; font-weight: 800;".format(COLORS["ok"]))
            action.setMinimumWidth(108) if isinstance(action, QPushButton) else None
            self.table.setCellWidget(row, 4, action)
        self._populate_diagnostics_table()
        self._filter_rows(self.search_edit.text())

    def _populate_diagnostics_table(self):
        """Populate the dedicated full-size diagnostics workspace."""
        if not hasattr(self, "diagnostics_table"):
            return
        table = self.diagnostics_table
        table.setRowCount(0)
        for report in self._reports:
            row = table.rowCount()
            table.insertRow(row)
            color = {
                checker.CRITICAL: COLORS["critical"],
                checker.WARNING: COLORS["warning"],
                checker.OK: COLORS["ok"],
            }.get(report.severity, COLORS["muted"])
            status = QTableWidgetItem(report.severity.upper())
            status.setForeground(QColor(color))
            status.setData(_qt("UserRole", "ItemDataRole"), report.severity)
            table.setItem(row, 0, status)
            name = QTableWidgetItem(self._safe_layer_name(report.layer))
            try:
                name.setData(_qt("UserRole", "ItemDataRole"), report.layer.id())
            except Exception:
                pass
            name.setToolTip(report.hints or report.issues)
            table.setItem(row, 1, name)
            try:
                crs = report.layer.crs()
                crs_text = crs.authid() if crs and crs.isValid() else "Not assigned"
            except Exception:
                crs_text = "Unavailable"
            table.setItem(row, 2, QTableWidgetItem(crs_text))
            issue = QTableWidgetItem(report.issues)
            issue.setToolTip(report.hints or report.issues)
            table.setItem(row, 3, issue)
        self._filter_diagnostics_table(self.search_edit.text() if hasattr(self, "search_edit") else "")

    def _filter_diagnostics_table(self, text):
        if not hasattr(self, "diagnostics_table"):
            return
        needle = (text or "").strip().lower()
        severity = self.severity_filter.currentData() if hasattr(self, "severity_filter") else "all"
        for row in range(self.diagnostics_table.rowCount()):
            parts = []
            for column in (1, 2, 3):
                item = self.diagnostics_table.item(row, column)
                if item is not None:
                    parts.append(item.text().lower())
            status_item = self.diagnostics_table.item(row, 0)
            row_severity = status_item.data(_qt("UserRole", "ItemDataRole")) if status_item else None
            visible = (not needle or needle in " ".join(parts)) and (severity == "all" or row_severity == severity)
            self.diagnostics_table.setRowHidden(row, not visible)

    def _show_diagnostic_details(self, row, column):
        try:
            item = self.diagnostics_table.item(row, 1)
            layer_id = item.data(_qt("UserRole", "ItemDataRole")) if item else None
            for report in self._reports:
                if report.layer.id() == layer_id:
                    self._show_layer_details_for_report(report)
                    return
        except Exception as exc:
            errors.log_exception("Unable to open diagnostics detail", exc)

    def _show_layer_details_for_report(self, report):
        try:
            crs = report.layer.crs()
            crs_text = crs.authid() if crs and crs.isValid() else "Not assigned / invalid"
        except Exception:
            crs_text = "Unavailable"
        details = ["• {} — {}".format(f.issue, f.hint or "No additional guidance.") for f in report.findings]
        message = "Layer: {}\nStatus: {}\nSource CRS: {}\n\n{}".format(
            self._safe_layer_name(report.layer), report.severity.upper(), crs_text,
            "\n\n".join(details) if details else "No diagnostic details available."
        )
        self._show_message("Information", "Layer diagnostics", message)

    def _show_layer_details(self, row, column):
        """Show the full diagnostic explanations for a double-clicked layer."""
        try:
            name_item = self.table.item(row, 1)
            layer_id = name_item.data(_qt("UserRole", "ItemDataRole")) if name_item else None
            report = None
            for candidate in self._reports:
                try:
                    if candidate.layer.id() == layer_id:
                        report = candidate
                        break
                except Exception:
                    continue
            if report is None:
                return
            try:
                crs = report.layer.crs()
                crs_text = crs.authid() if crs and crs.isValid() else "Not assigned / invalid"
            except Exception:
                crs_text = "Unavailable"
            details = []
            for finding in report.findings:
                text = "• {} — {}".format(finding.issue, finding.hint or "No additional guidance.")
                details.append(text)
            message = "Layer: {}\nStatus: {}\nSource CRS: {}\n\n{}".format(
                self._safe_layer_name(report.layer), report.severity.upper(), crs_text,
                "\n\n".join(details) if details else "No diagnostic details available."
            )
            self._show_message("Information", "Layer diagnostics", message)
        except Exception as exc:
            errors.log_exception("Unable to display layer diagnostic details", exc)

    @staticmethod
    def _safe_layer_name(layer):
        try:
            return layer.name()
        except Exception:
            return "Unavailable layer"

    def _action_button(self, text, callback):
        button = QPushButton(text)
        button.setCursor(_qt("PointingHandCursor", "CursorShape"))
        button.setMinimumWidth(108)
        button.setMinimumHeight(30)
        button.setStyleSheet(
            "QPushButton {padding: 6px 9px; color: #F6D96F; background: #292A25; "
            "border: 1px solid #8B742D; border-radius: 7px; font-weight: 750;}"
            "QPushButton:hover {background: #383423; border-color: #F6C945; color: #FFE58A;}"
        )
        button.clicked.connect(callback)
        return button

    def _filter_rows(self, text):
        needle = (text or "").strip().lower()
        severity = self.severity_filter.currentData() if hasattr(self, "severity_filter") else "all"
        visible_count = 0
        for row in range(self.table.rowCount()):
            parts = []
            for column in (1, 2, 3):
                item = self.table.item(row, column)
                if item is not None:
                    parts.append(item.text().lower())
            status_item = self.table.item(row, 0)
            row_severity = status_item.data(_qt("UserRole", "ItemDataRole")) if status_item else None
            text_match = not needle or needle in " ".join(parts)
            severity_match = severity == "all" or row_severity == severity
            visible = text_match and severity_match
            self.table.setRowHidden(row, not visible)
            if visible:
                visible_count += 1
        if hasattr(self, "table_empty"):
            self.table_empty.setVisible(visible_count == 0)
        self._filter_diagnostics_table(text)

    # --------------------------------------------------------- assign / CRS
    def fix_assign(self, layer):
        valid, reason = errors.validate_layer(layer)
        if not valid:
            self._show_message("Warning", "Layer unavailable", reason)
            self.run_scan()
            return
        try:
            dialog = QgsProjectionSelectionDialog(self)
            dialog.setWindowTitle("Assign source CRS · {}".format(layer.name()))
            dialog.setStyleSheet(STYLE)
            QTimer.singleShot(0, lambda target=dialog: self._apply_native_dark_titlebar(target))
            if layer.crs().isValid():
                dialog.setCrs(layer.crs())
            if dialog_exec(dialog):
                selected_crs = dialog.crs()
                if selected_crs is None or not selected_crs.isValid():
                    self._show_message("Warning", "Invalid CRS", "Choose a valid coordinate reference system.")
                    return
                # Assigning CRS deliberately relabels coordinates; it does not transform them.
                layer.setCrs(selected_crs)
                if not layer.crs().isValid():
                    raise RuntimeError("QGIS did not retain the selected CRS.")
                layer.triggerRepaint()
                self._notify("success", "Assigned {} to '{}' (coordinates unchanged).".format(
                    selected_crs.authid(), layer.name()
                ))
                self._add_activity("Assigned {} to layer '{}' (coordinate values unchanged).".format(
                    selected_crs.authid(), layer.name()
                ), "SUCCESS")
                self.run_scan()
        except Exception as exc:
            errors.show_error(self, "CRS assignment failed", "The CRS could not be assigned.", exc)

    def fix_reproject(self, layer):
        target = self._resolve_target_crs()
        if target is None:
            return
        valid, reason = errors.validate_layer(layer)
        if not valid:
            self._show_message("Warning", "Layer unavailable", reason)
            self.run_scan()
            return
        try:
            if not layer.crs().isValid():
                self._show_message("Warning", "Source CRS required", "Assign the correct source CRS before reprojection.")
                return
            output_dir = self._get_operation_output_dir()
            if output_dir is None:
                return
            self._begin_jobs([layer], target, output_dir, mode="single", update_project=False)
        except Exception as exc:
            errors.show_error(self, "Unable to start reprojection", "The reprojection task could not be started.", exc)

    def _on_target_changed(self, index):
        if self.target_combo.itemData(index) != TARGET_CUSTOM:
            return
        try:
            dialog = QgsProjectionSelectionDialog(self)
            dialog.setWindowTitle("Choose target CRS")
            dialog.setStyleSheet(STYLE)
            QTimer.singleShot(0, lambda target=dialog: self._apply_native_dark_titlebar(target))
            if self._custom_crs is not None and self._custom_crs.isValid():
                dialog.setCrs(self._custom_crs)
            if dialog_exec(dialog):
                selected = dialog.crs()
                if selected is not None and selected.isValid():
                    self._custom_crs = selected
                    self.target_combo.setItemText(index, "Custom · {}".format(selected.authid()))
                    self.target_hint.setText(selected.description() or selected.authid())
                else:
                    self.target_combo.setCurrentIndex(TARGET_AUTO)
            else:
                self.target_combo.setCurrentIndex(TARGET_AUTO)
        except Exception as exc:
            errors.show_error(self, "CRS selection failed", "The target CRS selector could not be opened.", exc)
            self.target_combo.setCurrentIndex(TARGET_AUTO)

    def _resolve_target_crs(self):
        selection = self.target_combo.currentData()
        project = QgsProject.instance()
        if selection == TARGET_AUTO:
            self._refresh_projection_intelligence()
            # Do not fall back to the older centroid-only UTM heuristic when footprint
            # analysis rejects a recommendation (e.g. multiple zones or equator crossing).
            target = self._projection_recommendation
            if target is None:
                self._show_message("Information", "UTM suggestion unavailable", "A suitable UTM CRS could not be suggested. Choose a custom CRS.")
                return None
            self.target_hint.setText(
                "Suggested {} · Check suitability if the project spans multiple UTM zones.".format(
                    target.authid()
                )
            )
            return target
        if selection == TARGET_PROJECT:
            target = project.crs()
            if target is None or not target.isValid():
                self._show_message("Information", "Project CRS is not set", "Set the project CRS or choose a custom CRS.")
                return None
            return target
        if self._custom_crs is None or not self._custom_crs.isValid():
            self._on_target_changed(self.target_combo.currentIndex())
        return self._custom_crs if self._custom_crs and self._custom_crs.isValid() else None

    # ------------------------------------------------------------- outputs
    def _choose_output_folder(self):
        dialog = QFileDialog(self, "Choose CRS Guardian output folder")
        dialog.setOption(enum_value(QFileDialog, "DontUseNativeDialog", "Option"), True)
        dialog.setOption(enum_value(QFileDialog, "ShowDirsOnly", "Option"), True)
        dialog.setFileMode(enum_value(QFileDialog, "Directory", "FileMode"))
        dialog.setStyleSheet(STYLE)
        QTimer.singleShot(0, lambda target=dialog: self._apply_native_dark_titlebar(target))
        if dialog_exec(dialog):
            selected = dialog.selectedFiles()
            folder = selected[0] if selected else ""
            if folder:
                self._chosen_output_dir = folder
                self.output_folder_label.setText(folder)

    def _get_operation_output_dir(self):
        if self.chk_save.isChecked():
            if not self._chosen_output_dir:
                self._choose_output_folder()
            if not self._chosen_output_dir:
                return None
            return self._chosen_output_dir
        folder = tempfile.mkdtemp(prefix="crs_guardian_outputs_")
        self._temp_output_dirs.append(folder)
        self.output_folder_label.setText("Temporary output: {}".format(folder))
        return folder

    # -------------------------------------------------------- batch process
    def run_harmonize(self):
        if self._active_task is not None:
            return
        target = self._resolve_target_crs()
        if target is None:
            return
        layers = list(QgsProject.instance().mapLayers().values())
        eligible = []
        supported_types = (
            layer_type_value("VectorLayer"), layer_type_value("RasterLayer")
        )
        for layer in layers:
            try:
                if layer.type() in supported_types:
                    eligible.append(layer)
            except Exception as exc:
                errors.log_exception("Unable to inspect layer type during harmonization", exc)
        if not eligible:
            self._show_message("Information", "Nothing to harmonize", "No vector or raster layers were found in this project.")
            return

        preflight = self._run_preflight(target_override=target)
        preflight_pass, preflight_warnings, preflight_failed = preflight
        if preflight_failed:
            self._show_message(
                "Warning", "Preflight checks failed",
                "{} preflight check(s) failed. Harmonization has been stopped to avoid processing layers with invalid or unavailable source data.".format(preflight_failed),
                "Open Quality Assurance and Diagnostics, resolve the failed checks, then run harmonization again."
            )
            return
        if preflight_warnings:
            preflight_choice = self._show_message(
                "Question", "Preflight warnings found",
                "{} warning(s) were found. Continue with harmonization?".format(preflight_warnings),
                "Review the Preflight QA report before proceeding.",
                message_box_button("Yes") | message_box_button("No")
            )
            if preflight_choice != message_box_button("Yes"):
                return

        buttons = message_box_button("Yes") | message_box_button("No")
        box = _button_box(
            self, "Confirm harmonization",
            "Reproject supported layers to {}?\n\n"
            "Original layers will remain untouched. Unique output copies will be added to a new group.".format(
                target.authid()
            ),
            buttons, message_box_button("Yes")
        )
        QTimer.singleShot(0, lambda target=box: self._apply_native_dark_titlebar(target))
        if dialog_exec(box) != message_box_button("Yes"):
            return
        output_dir = self._get_operation_output_dir()
        if output_dir is None:
            return
        self._begin_jobs(
            eligible, target, output_dir, mode="batch",
            update_project=self.chk_set_project.isChecked()
        )

    def _begin_jobs(self, layers, target_crs, output_dir, mode="batch", update_project=False):
        if self._active_task is not None:
            self._show_message("Information", "Task already running", "Finish or cancel the current task first.")
            return
        if target_crs is None or not target_crs.isValid():
            raise ValueError("The target CRS is invalid.")
        if not os.path.isdir(output_dir):
            os.makedirs(output_dir)

        self._result = harmonizer.HarmonizeResult()
        self._queue = []
        self._batch_target = target_crs
        self._batch_output_dir = output_dir
        self._job_project_generation = self._project_generation
        self._update_project_crs = update_project
        self._current_mode = mode
        self._cancel_requested = False
        self._done_count = 0

        for layer in layers:
            valid, reason = errors.validate_layer(layer)
            if not valid:
                self._result.failed.append(self._safe_layer_name(layer))
                self._result.error_details.append(reason)
                continue
            try:
                layer_type = layer.type()
                if layer_type not in (
                    layer_type_value("VectorLayer"), layer_type_value("RasterLayer")
                ):
                    self._result.skipped_unsupported.append(layer.name())
                    continue
                source_crs = layer.crs()
                if source_crs is None or not source_crs.isValid():
                    self._result.skipped_invalid.append(layer.name())
                    continue
                if source_crs.authid() == target_crs.authid():
                    self._result.skipped_ok.append(layer.name())
                    continue
                algorithm_id, extension = harmonizer.algorithm_id_for_layer(layer)
                if not algorithm_id:
                    self._result.skipped_unsupported.append(layer.name())
                    continue
                output_path = harmonizer.unique_output_path(output_dir, layer.name(), extension)
                algorithm = QgsApplication.processingRegistry().algorithmById(algorithm_id)
                if algorithm is None:
                    raise RuntimeError(
                        "Processing algorithm '{}' is unavailable. Check the QGIS Processing and GDAL providers.".format(
                            algorithm_id
                        )
                    )
                unused_id, parameters = harmonizer.processing_parameters(
                    layer, target_crs, output_path
                )
                self._queue.append({
                    "layer": layer,
                    "algorithm": algorithm,
                    "parameters": parameters,
                    "output": output_path,
                    "algorithm_id": algorithm_id,
                })
            except Exception as exc:
                errors.log_exception("Unable to prepare reprojection for {}".format(self._safe_layer_name(layer)), exc)
                self._result.failed.append(self._safe_layer_name(layer))
                self._result.error_details.append("{}: {}".format(self._safe_layer_name(layer), exc))

        self._batch_total = len(self._queue) + len(self._result.skipped_ok) + len(self._result.skipped_invalid) + len(self._result.skipped_unsupported) + len(self._result.failed)
        self._done_count = self._batch_total - len(self._queue)
        if not self._queue:
            self._finish_jobs()
            return

        self.scan_btn.setEnabled(False)
        self.harmonize_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.cancel_btn.setVisible(True)
        self.progress.setVisible(True)
        self.progress.setValue(int(self._done_count * 100 / max(1, self._batch_total)))
        self.progress_caption.setText("0 / {} completed".format(len(self._queue)))
        self._set_status("Preparing background processing tasks…")
        self._add_activity(
            "{} reprojection job(s) queued for target CRS {}.".format(len(self._queue), target_crs.authid()),
            "INFO"
        )
        self._navigate_to(1)
        self._start_next_task()

    def _start_next_task(self):
        if self._shutting_down:
            return
        if self._cancel_requested:
            self._result.cancelled = True
            self._finish_jobs()
            return
        if not self._queue:
            self._finish_jobs()
            return

        job = self._queue.pop(0)
        layer = job["layer"]
        valid, reason = errors.validate_layer(layer)
        if not valid:
            self._result.failed.append(self._safe_layer_name(layer))
            self._result.error_details.append(reason)
            harmonizer.cleanup_output(job["output"])
            self._done_count += 1
            QTimer.singleShot(0, self._start_next_task)
            return

        try:
            context = QgsProcessingContext()
            project = QgsProject.instance()
            context.setProject(project)
            context.setTransformContext(project.transformContext())
            feedback = QgsProcessingFeedback()
            task = QgsProcessingAlgRunnerTask(
                job["algorithm"], job["parameters"], context, feedback,
            )
            try:
                task.setDescription("CRS Guardian · {}".format(layer.name()))
            except Exception:
                pass
            self._active_terminated_slot = (
                lambda task_ref=task: self.task_terminated_signal.emit(task_ref)
            )
            self._active_progress_slot = (
                lambda value: self.task_progress_signal.emit(float(value))
            )
            self._active_executed_slot = (
                lambda successful, results, task_ref=task:
                self.task_executed_signal.emit(task_ref, bool(successful), results)
            )
            task.executed.connect(self._active_executed_slot)
            task.taskTerminated.connect(self._active_terminated_slot)
            feedback.progressChanged.connect(self._active_progress_slot)
            try:
                task.setDependentLayers([layer])
            except Exception:
                # Not all QGIS builds/providers support dependency tracking here.
                pass
            self._active_task = task
            self._active_context = context
            self._active_feedback = feedback
            self._active_output = job["output"]
            self._active_layer = layer
            self._active_algorithm = job["algorithm_id"]
            self._set_status("Reprojecting {}…".format(layer.name()))
            accepted = QgsApplication.taskManager().addTask(task)
            if accepted is False:
                raise RuntimeError("QGIS task manager rejected the processing task.")
        except Exception as exc:
            errors.log_exception("Unable to start Processing task", exc)
            harmonizer.cleanup_output(job["output"])
            self._result.failed.append(layer.name())
            self._result.error_details.append("{}: {}".format(layer.name(), exc))
            self._clear_active_task()
            self._done_count += 1
            QTimer.singleShot(0, self._start_next_task)

    def _on_task_progress(self, value):
        if self._shutting_down:
            return
        try:
            total = max(1, self._batch_total)
            current_fraction = max(0.0, min(100.0, float(value))) / 100.0
            percentage = int(((self._done_count + current_fraction) / total) * 100)
            self.progress.setValue(max(0, min(100, percentage)))
            self.progress_caption.setText(
                "{} / {} completed".format(self._done_count, total)
            )
        except Exception:
            errors.get_logger().exception("Unable to update task progress display")

    def _on_task_executed(self, task, successful, results):
        if self._shutting_down or task is not self._active_task:
            return
        if self._task_completion_handled:
            return
        self._task_completion_handled = True
        layer = self._active_layer
        output_path = self._active_output
        if self._job_project_generation != self._project_generation:
            self._result.cancelled = True
            self._result.error_details.append(
                "The QGIS project changed during processing; the result was not added to the new project."
            )
            if any(output_path.startswith(folder + os.sep) for folder in self._temp_output_dirs):
                harmonizer.cleanup_output(output_path)
            else:
                self._result.output_paths.append(output_path)
        elif successful:
            registered_layer_id = None
            project = QgsProject.instance()
            try:
                if self._active_algorithm == "native:reprojectlayer":
                    output_layer = QgsVectorLayer(output_path, "", "ogr")
                else:
                    output_layer = QgsRasterLayer(output_path, "", "gdal")
                if output_layer is None or not output_layer.isValid():
                    raise RuntimeError("Processing completed but the output layer could not be opened.")
                output_layer.setName("{} ({})".format(layer.name(), self._batch_target.authid()))
                if not output_layer.crs().isValid():
                    raise RuntimeError("The output was created without a valid CRS.")
                qa = self._validate_output_layer(layer, output_layer, self._batch_target)
                self._qa_results.append(qa)
                qa_level = "SUCCESS" if qa.get("status") == "PASS" else ("ERROR" if qa.get("status") == "FAIL" else "WARNING")
                self._add_activity("Postflight QA {} for '{}': {}".format(qa.get("status"), self._safe_layer_name(layer), "; ".join(qa.get("checks", []))), qa_level)
                if qa.get("status") == "FAIL":
                    raise RuntimeError("Postflight QA failed: {}".format("; ".join(qa.get("checks", []))))
                if self._current_mode == "batch":
                    group_name = "Harmonized ({})".format(self._batch_target.authid())
                    root = project.layerTreeRoot()
                    group = root.findGroup(group_name)
                    if group is None:
                        group = root.insertGroup(0, group_name)
                    added_layer = project.addMapLayer(output_layer, False)
                    if added_layer is None or not added_layer.isValid():
                        raise RuntimeError("QGIS could not register the reprojected layer.")
                    registered_layer_id = added_layer.id()
                    group.addLayer(added_layer)
                else:
                    added_layer = project.addMapLayer(output_layer)
                    if added_layer is None or not added_layer.isValid():
                        raise RuntimeError("QGIS could not register the reprojected layer.")
                    registered_layer_id = added_layer.id()
                if project.mapLayer(output_layer.id()) is None:
                    raise RuntimeError("The output layer was not retained in the current project.")
                self._result.reprojected.append(layer.name())
                self._result.output_paths.append(output_path)
                self._add_activity("Reprojected '{}' to {} → {}".format(
                    self._safe_layer_name(layer), self._batch_target.authid(), output_path
                ), "SUCCESS")
            except Exception as exc:
                errors.log_exception("Unable to register completed output layer", exc)
                if registered_layer_id:
                    try:
                        project.removeMapLayer(registered_layer_id)
                    except Exception as rollback_exc:
                        errors.log_exception("Unable to roll back a failed layer registration", rollback_exc)
                harmonizer.cleanup_output(output_path)
                self._result.failed.append(self._safe_layer_name(layer))
                self._result.error_details.append("{}: {}".format(self._safe_layer_name(layer), exc))
                self._add_activity("Could not register output for '{}': {}".format(
                    self._safe_layer_name(layer), exc
                ), "ERROR")
        else:
            harmonizer.cleanup_output(output_path)
            self._result.failed.append(self._safe_layer_name(layer))
            self._add_activity("Reprojection failed for '{}' ({}).".format(
                self._safe_layer_name(layer), self._active_algorithm
            ), "ERROR")
            self._result.error_details.append(
                "{} failed in {}. Review the Processing log for details.".format(
                    self._safe_layer_name(layer), self._active_algorithm
                )
            )

        self._clear_active_task()
        self._done_count += 1
        self.progress.setValue(int(self._done_count * 100 / max(1, self._batch_total)))
        QTimer.singleShot(0, self._start_next_task)

    def _on_task_terminated(self, task):
        # Some QGIS builds signal termination separately when a task is cancelled.
        if self._shutting_down or task is not self._active_task:
            return
        if self._task_completion_handled:
            return
        self._task_completion_handled = True
        output_path = self._active_output
        layer_name = self._safe_layer_name(self._active_layer)
        harmonizer.cleanup_output(output_path)
        if layer_name not in self._result.failed and layer_name not in self._result.reprojected:
            self._result.failed.append(layer_name)
            self._result.error_details.append("{} task was terminated before completion.".format(layer_name))
        self._clear_active_task()
        self._done_count += 1
        QTimer.singleShot(0, self._start_next_task)

    def _clear_active_task(self):
        active = self._active_task
        if active is not None:
            try:
                if self._active_executed_slot is not None:
                    active.executed.disconnect(self._active_executed_slot)
            except Exception:
                pass
            try:
                if self._active_terminated_slot is not None:
                    active.taskTerminated.disconnect(self._active_terminated_slot)
            except Exception:
                pass
            try:
                if self._active_feedback is not None and self._active_progress_slot is not None:
                    self._active_feedback.progressChanged.disconnect(self._active_progress_slot)
            except Exception:
                pass
        self._active_task = None
        self._active_executed_slot = None
        self._active_terminated_slot = None
        self._active_progress_slot = None
        self._active_context = None
        self._active_feedback = None
        self._active_output = None
        self._active_layer = None
        self._active_algorithm = None
        self._task_completion_handled = False

    def cancel_processing(self):
        if self._active_task is None and not self._queue:
            return
        self._cancel_requested = True
        self._result.cancelled = True
        self._add_activity("Cancellation requested by user.", "WARNING")
        self._queue = []
        self.cancel_btn.setEnabled(False)
        self._set_status("Cancellation requested. Waiting for the active QGIS processing task to stop…")
        try:
            if self._active_task is not None:
                self._active_task.cancel()
            else:
                self._finish_jobs()
        except Exception as exc:
            errors.log_exception("Unable to cancel active processing task", exc)
            self._finish_jobs()

    def _finish_jobs(self):
        if self._shutting_down:
            return
        if self._update_project_crs and self._result.reprojected and not self._result.cancelled:
            try:
                QgsProject.instance().setCrs(self._batch_target)
            except Exception as exc:
                errors.log_exception("Unable to update project CRS", exc)
                self._result.failed.append("Project CRS update")
                self._result.error_details.append(str(exc))

        self._clear_active_task()
        if self._temp_cleanup_pending:
            self._cleanup_temporary_outputs()
        self._queue = []
        self.scan_btn.setEnabled(True)
        self.harmonize_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setVisible(False)
        self.progress.setVisible(False)
        self.progress.setValue(0)
        self.progress_caption.setText("")

        summary = self._result.summary()
        details = "\n".join(self._result.error_details[:8])
        if self._result.failed or self._result.skipped_invalid or self._result.cancelled:
            self._notify("warning", summary)
            status = "Completed with warnings · " + summary
        else:
            self._notify("success", summary)
            status = "Completed · " + summary
        self._set_status(status)
        self._sync_project_info()
        self._add_activity("Processing finished: {}".format(summary), "WARNING" if self._result.failed or self._result.cancelled else "SUCCESS")
        self._refresh_qa_view()
        if self._result.error_details:
            errors.get_logger().warning("Processing summary: %s\n%s", summary, details)
        if self._current_mode == "single" and self._result.reprojected:
            self._show_message(
                "Information", "Reprojection complete",
                "The reprojected copy has been added to the QGIS project.\n\n{}".format(
                    self._result.summary()
                )
            )
        self.run_scan()

    # ------------------------------------------------------ temporary cleanup
    def _on_project_cleared(self):
        # Do not let a task started for the previous project add layers to a
        # newly opened project. Request cancellation and remove queued work.
        self._project_generation += 1
        self._add_activity("QGIS project cleared; pending operations are being cancelled and temporary outputs scheduled for cleanup.", "WARNING")
        self._sync_project_info()
        if self._active_task is not None:
            self._temp_cleanup_pending = True
            self._cancel_requested = True
            self._result.cancelled = True
            self._queue = []
            try:
                self._active_task.cancel()
            except Exception as exc:
                errors.log_exception("Unable to cancel task after the project changed", exc)
            return
        self._cleanup_temporary_outputs()

    def _cleanup_temporary_outputs(self):
        if self._active_task is not None:
            self._temp_cleanup_pending = True
            return
        pending = list(self._temp_output_dirs)
        self._temp_output_dirs = []
        self._temp_cleanup_pending = False
        for folder in pending:
            try:
                if folder and os.path.isdir(folder):
                    shutil.rmtree(folder)
            except Exception as exc:
                errors.log_exception("Unable to clean temporary output folder {}".format(folder), exc)

    # ---------------------------------------------------------------- close
    def shutdown(self):
        """Cancel active work and disconnect callbacks before plugin unload."""
        self._shutting_down = True
        try:
            project = QgsProject.instance()
            for signal in (project.layersAdded, project.layersRemoved, project.crsChanged):
                try:
                    signal.disconnect(self._on_live_project_change)
                except Exception:
                    pass
            try:
                project.cleared.disconnect(self._on_project_cleared)
            except Exception:
                pass
            self._live_sentinel_enabled = False
        except Exception as exc:
            errors.log_exception("Unable to disconnect CRS Guardian project listeners", exc)
        try:
            self._queue = []
            if self._active_task is not None:
                try:
                    if self._active_executed_slot is not None:
                        self._active_task.executed.disconnect(self._active_executed_slot)
                except Exception:
                    pass
                try:
                    if self._active_terminated_slot is not None:
                        self._active_task.taskTerminated.disconnect(self._active_terminated_slot)
                except Exception:
                    pass
                try:
                    if self._active_feedback is not None and self._active_progress_slot is not None:
                        self._active_feedback.progressChanged.disconnect(self._active_progress_slot)
                except Exception:
                    pass
                self._active_task.cancel()
        except Exception as exc:
            errors.log_exception("Error while shutting down CRS Guardian", exc)

    def closeEvent(self, event):
        if self._shutting_down:
            event.accept()
            return
        # Keep the top-level window instance alive so the toolbar action reopens it.
        event.ignore()
        self.hide()
