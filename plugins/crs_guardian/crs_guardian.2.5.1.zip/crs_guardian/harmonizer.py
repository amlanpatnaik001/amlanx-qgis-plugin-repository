# -*- coding: utf-8 -*-
"""Safe output planning and processing parameter builders for reprojection."""
# Copyright © 2077 Amlan Patnaik. All rights reserved.
# Author: Amlan Patnaik <amlanpatnaikx@gmail.com>
# Licence: GPL-2.0-or-later.
import os
import re
import uuid

from . import errors
from .compat import layer_type_value


class HarmonizeResult(object):
    """Structured batch result used for summaries and audit details."""
    def __init__(self):
        self.reprojected = []
        self.skipped_ok = []
        self.skipped_invalid = []
        self.skipped_unsupported = []
        self.failed = []
        self.cancelled = False
        self.output_paths = []
        self.error_details = []

    def summary(self):
        parts = []
        if self.reprojected:
            parts.append("{} reprojected".format(len(self.reprojected)))
        if self.skipped_ok:
            parts.append("{} already in target CRS".format(len(self.skipped_ok)))
        if self.skipped_invalid:
            parts.append("{} skipped (invalid CRS)".format(len(self.skipped_invalid)))
        if self.skipped_unsupported:
            parts.append("{} unsupported layer types skipped".format(len(self.skipped_unsupported)))
        if self.failed:
            parts.append("{} failed".format(len(self.failed)))
        if self.cancelled:
            parts.append("cancelled by user")
        return ", ".join(parts) if parts else "Nothing to do"


def safe_name(name):
    """Return a portable, non-empty base filename."""
    text = re.sub(r"[^A-Za-z0-9_-]+", "_", str(name)).strip("_-")
    return text[:80] or "layer"


def unique_output_path(output_dir, layer_name, extension):
    """Create a collision-resistant output path without overwriting data."""
    if not output_dir:
        raise ValueError("An output directory is required.")
    if not os.path.isdir(output_dir):
        os.makedirs(output_dir)
    extension = extension if extension.startswith(".") else "." + extension
    base = safe_name(layer_name)
    # UUID suffix avoids collisions between identically named project layers.
    for unused in range(10):
        candidate = os.path.join(
            output_dir, "{}_{}_{}".format(base, "reprojected", uuid.uuid4().hex[:8]) + extension
        )
        if not os.path.exists(candidate):
            return candidate
    raise IOError("Could not reserve a unique output filename.")


def cleanup_output(path):
    """Remove a failed partial output and common GDAL/SQLite sidecar files."""
    if not path:
        return
    candidates = [path, path + ".aux.xml", path + ".ovr", path + "-wal", path + "-shm"]
    base, extension = os.path.splitext(path)
    if extension.lower() == ".gpkg":
        candidates.extend([base + "-journal", base + "-wal", base + "-shm"])
    for candidate in candidates:
        try:
            if os.path.isfile(candidate):
                os.remove(candidate)
        except Exception as exc:
            errors.log_exception("Unable to remove partial output {}".format(candidate), exc)


def algorithm_id_for_layer(layer):
    """Map a supported layer type to its QGIS Processing algorithm id."""
    if layer.type() == layer_type_value("VectorLayer"):
        return "native:reprojectlayer", ".gpkg"
    if layer.type() == layer_type_value("RasterLayer"):
        return "gdal:warpreproject", ".tif"
    return None, None


def processing_parameters(layer, target_crs, output_path):
    """Build safe, explicit parameters for vector or raster reprojection."""
    valid, reason = errors.validate_layer(layer)
    if not valid:
        raise ValueError(reason)
    source_crs = layer.crs()
    if source_crs is None or not source_crs.isValid():
        raise ValueError("Layer '{}' has no valid source CRS.".format(layer.name()))
    if target_crs is None or not target_crs.isValid():
        raise ValueError("The target CRS is invalid.")

    if layer.type() == layer_type_value("VectorLayer"):
        return "native:reprojectlayer", {
            "INPUT": layer,
            "TARGET_CRS": target_crs,
            "OUTPUT": output_path,
        }
    if layer.type() == layer_type_value("RasterLayer"):
        # GDAL Warp parameter names changed in newer QGIS Processing builds.
        # Inspect the installed algorithm definition instead of hard-coding a
        # version check, so vendor/backported builds are handled as well.
        creation_options_key = "OPTIONS"  # legacy QGIS fallback
        try:
            from qgis.core import QgsApplication
            algorithm = QgsApplication.processingRegistry().algorithmById("gdal:warpreproject")
            if algorithm is not None:
                parameter_names = set(
                    parameter.name() for parameter in algorithm.parameterDefinitions()
                )
                if "CREATION_OPTIONS" in parameter_names:
                    creation_options_key = "CREATION_OPTIONS"
                elif "OPTIONS" in parameter_names:
                    creation_options_key = "OPTIONS"
        except Exception:
            pass
        parameters = {
            "INPUT": layer,
            "SOURCE_CRS": source_crs,
            "TARGET_CRS": target_crs,
            "RESAMPLING": 0,
            "NODATA": None,
            "TARGET_RESOLUTION": None,
            "DATA_TYPE": 0,
            "MULTITHREADING": True,
            "OUTPUT": output_path,
        }
        parameters[creation_options_key] = ""
        return "gdal:warpreproject", parameters
    raise ValueError("This layer type cannot be reprojected by CRS Guardian.")
