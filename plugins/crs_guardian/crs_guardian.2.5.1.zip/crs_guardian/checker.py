# -*- coding: utf-8 -*-
"""CRS validation logic. UI-independent apart from QGIS layer/CRS objects."""
# Copyright © 2077 Amlan Patnaik. All rights reserved.
# Author: Amlan Patnaik <amlanpatnaikx@gmail.com>
# Licence: GPL-2.0-or-later.
import math

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
)

from . import errors
from .compat import layer_type_value

OK = "ok"
WARNING = "warning"
CRITICAL = "critical"
SEVERITY_ORDER = {CRITICAL: 0, WARNING: 1, OK: 2}


class Finding(object):
    """One check result for one layer."""
    def __init__(self, layer, severity, issue, hint="", fix=None):
        self.layer = layer
        self.severity = severity
        self.issue = issue
        self.hint = hint
        self.fix = fix


def _extent_looks_geographic(extent):
    """True if an extent fits inside plausible longitude/latitude bounds."""
    try:
        return (
            -180.5 <= extent.xMinimum() <= 180.5
            and -180.5 <= extent.xMaximum() <= 180.5
            and -90.5 <= extent.yMinimum() <= 90.5
            and -90.5 <= extent.yMaximum() <= 90.5
        )
    except Exception:
        return False


def check_layer(layer, project_crs):
    """Check one layer. A broken provider becomes a finding, not a crash."""
    valid, reason = errors.validate_layer(layer)
    if not valid:
        return [Finding(
            layer, CRITICAL, "Layer is invalid or unavailable",
            reason + " Repair the data source before changing its CRS."
        )]

    findings = []
    try:
        crs = layer.crs()
        if crs is None or not crs.isValid():
            return [Finding(
                layer, CRITICAL, "CRS missing or invalid",
                "Assign the correct source CRS first. Reprojecting without a "
                "known source CRS can create unusable output.",
                fix="assign"
            )]

        extent = layer.extent()
        try:
            extent_valid = extent is not None and not extent.isNull() and not extent.isEmpty()
        except Exception:
            extent_valid = False

        if extent_valid:
            if crs.isGeographic() and not _extent_looks_geographic(extent):
                findings.append(Finding(
                    layer, CRITICAL, "Extent outside valid longitude/latitude range",
                    "Coordinates look projected, but the layer claims a geographic "
                    "CRS. Verify the true source CRS before assigning anything.",
                    fix="assign"
                ))
            elif (not crs.isGeographic()) and _extent_looks_geographic(extent):
                findings.append(Finding(
                    layer, WARNING, "Extent looks like degrees but CRS is projected",
                    "Coordinates fit within longitude/latitude bounds. The source "
                    "data may have a geographic CRS that was incorrectly assigned.",
                    fix="assign"
                ))

        if crs.isGeographic():
            findings.append(Finding(
                layer, WARNING, "Geographic CRS (units = degrees)",
                "Distance, buffer and area measurements may be expressed in "
                "angular units. Use a suitable projected CRS for measurement.",
                fix="reproject"
            ))

        try:
            if project_crs is not None and project_crs.isValid():
                if crs.authid() != project_crs.authid():
                    findings.append(Finding(
                        layer, WARNING,
                        "Does not match project CRS ({})".format(project_crs.authid()),
                        "QGIS can display mixed CRS layers through on-the-fly "
                        "transformation. Some analysis workflows still require "
                        "consistent input CRSs.",
                        fix="reproject"
                    ))
        except Exception as exc:
            errors.log_exception("Unable to compare layer and project CRS", exc)

        if not findings:
            findings.append(Finding(layer, OK, "No CRS issues detected"))
    except Exception as exc:
        errors.log_exception("CRS check failed for layer", exc)
        findings.append(Finding(
            layer, CRITICAL, "CRS check could not be completed",
            "The layer could not be inspected safely. Review the CRS Guardian log."
        ))
    return findings


class LayerReport(object):
    """All findings for one layer, aggregated into one table row."""
    def __init__(self, layer, findings):
        self.layer = layer
        self.findings = findings
        self.severity = min(
            (f.severity for f in findings),
            key=lambda severity: SEVERITY_ORDER.get(severity, 9)
        )
        real = [f for f in findings if f.severity != OK]
        self.issues = "; ".join(f.issue for f in real) if real else "No issues"
        self.hints = "\n\n".join(
            "• {}: {}".format(f.issue, f.hint) for f in real if f.hint
        )
        self.fix = None
        for finding in sorted(
            findings, key=lambda item: SEVERITY_ORDER.get(item.severity, 9)
        ):
            if finding.fix:
                self.fix = finding.fix
                break


def aggregate_by_layer(findings):
    """Group findings by stable layer id and preserve project order."""
    by_layer = {}
    order = []
    for finding in findings:
        try:
            key = finding.layer.id()
        except Exception:
            key = "unavailable-{}".format(id(finding.layer))
        if key not in by_layer:
            by_layer[key] = []
            order.append(key)
        by_layer[key].append(finding)
    reports = [LayerReport(by_layer[key][0].layer, by_layer[key]) for key in order]
    reports.sort(key=lambda report: SEVERITY_ORDER.get(report.severity, 9))
    return reports


def scan_project(project=None):
    """Scan the project defensively. Returns (findings, total_layer_count)."""
    project = project or QgsProject.instance()
    try:
        project_crs = project.crs()
        layers = list(project.mapLayers().values())
    except Exception as exc:
        errors.log_exception("Unable to read the current QGIS project", exc)
        raise

    all_findings = []
    supported = (
        layer_type_value("VectorLayer"),
        layer_type_value("RasterLayer"),
        layer_type_value("MeshLayer"),
    )
    for layer in layers:
        try:
            if layer.type() not in supported:
                continue
            all_findings.extend(check_layer(layer, project_crs))
        except Exception as exc:
            errors.log_exception("Unexpected error while scanning a project layer", exc)
            all_findings.append(Finding(
                layer, CRITICAL, "Layer scan failed",
                "This layer could not be inspected. See the CRS Guardian log."
            ))
    all_findings.sort(key=lambda finding: SEVERITY_ORDER.get(finding.severity, 9))
    return all_findings, len(layers)


def layer_centroid_wgs84(layer):
    """Return (longitude, latitude) for the layer extent centre, or None."""
    valid, unused_reason = errors.validate_layer(layer)
    if not valid:
        return None
    try:
        crs = layer.crs()
        extent = layer.extent()
        if not crs.isValid() or extent is None or extent.isNull() or extent.isEmpty():
            return None
        center = extent.center()
        if crs.authid().upper() == "EPSG:4326":
            lon, lat = center.x(), center.y()
        else:
            transform = QgsCoordinateTransform(
                crs, QgsCoordinateReferenceSystem("EPSG:4326"), QgsProject.instance()
            )
            point = transform.transform(center)
            lon, lat = point.x(), point.y()
        if not (math.isfinite(lon) and math.isfinite(lat)):
            return None
        if lon < -180.0 or lon > 180.0 or lat < -90.0 or lat > 90.0:
            return None
        return lon, lat
    except Exception as exc:
        errors.log_exception("Unable to calculate layer centroid in WGS84", exc)
        return None


def suggest_utm_crs(layers):
    """Suggest a UTM CRS using the circular mean longitude and mean latitude.

    UTM is defined approximately between 80°S and 84°N. The returned CRS is
    only a best-effort suggestion; projects spanning multiple zones need a
    deliberate project-specific choice.
    """
    points = []
    for layer in layers:
        point = layer_centroid_wgs84(layer)
        if point is not None:
            points.append(point)
    if not points:
        return None

    sin_sum = sum(math.sin(math.radians(point[0])) for point in points)
    cos_sum = sum(math.cos(math.radians(point[0])) for point in points)
    if abs(sin_sum) < 1e-12 and abs(cos_sum) < 1e-12:
        return None
    lon = math.degrees(math.atan2(sin_sum, cos_sum))
    lat = sum(point[1] for point in points) / float(len(points))
    if lat < -80.0 or lat > 84.0:
        return None
    zone = int(math.floor((lon + 180.0) / 6.0)) + 1
    zone = max(1, min(60, zone))
    epsg = (32600 if lat >= 0 else 32700) + zone
    crs = QgsCoordinateReferenceSystem("EPSG:{}".format(epsg))
    return crs if crs.isValid() else None
