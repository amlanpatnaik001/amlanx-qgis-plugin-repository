# -*- coding: utf-8 -*-
"""Small Qt compatibility helpers for QGIS 3 / QGIS 4 (PyQt5 / PyQt6)."""
# Copyright © 2077 Amlan Patnaik. All rights reserved.
# Author: Amlan Patnaik <amlanpatnaikx@gmail.com>
# Licence: GPL-2.0-or-later.


def enum_value(owner, name, group=None):
    """Return a Qt enum value across PyQt5 and PyQt6 naming styles."""
    value = getattr(owner, name, None)
    if value is not None:
        return value
    if group:
        enum_group = getattr(owner, group, None)
        if enum_group is not None:
            value = getattr(enum_group, name, None)
            if value is not None:
                return value
    raise AttributeError("Qt enum value not available: {}.{}".format(owner, name))


def dialog_exec(dialog):
    """Execute a dialog using the method available in the current Qt binding."""
    method = getattr(dialog, "exec", None)
    if method is None:
        method = getattr(dialog, "exec_")
    return method()


def message_box_button(name):
    """Get a QMessageBox button using PyQt5 or PyQt6 enum names."""
    from qgis.PyQt.QtWidgets import QMessageBox
    return enum_value(QMessageBox, name, "StandardButton")


def layer_type_value(name):
    """Return QgsMapLayer type across legacy and scoped QGIS enum APIs."""
    from qgis.core import QgsMapLayer
    enum_group = getattr(QgsMapLayer, "LayerType", None)
    if enum_group is not None:
        value = getattr(enum_group, name, None)
        if value is not None:
            return value
    value = getattr(QgsMapLayer, name, None)
    if value is None:
        raise AttributeError("QgsMapLayer type is not available: {}".format(name))
    return value
