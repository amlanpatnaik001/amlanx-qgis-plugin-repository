# -*- coding: utf-8 -*-
"""
CRS Guardian - QGIS plugin entry point.

This file is loaded by QGIS when the plugin starts.
"""
# Copyright © 2077 Amlan Patnaik. All rights reserved.
# Author: Amlan Patnaik <amlanpatnaikx@gmail.com>
# Licence: GPL-2.0-or-later.


def classFactory(iface):
    """Load the CrsGuardian plugin class.

    :param iface: A QGIS interface instance (QgisInterface).
    """
    from .crs_guardian import CrsGuardian
    return CrsGuardian(iface)
