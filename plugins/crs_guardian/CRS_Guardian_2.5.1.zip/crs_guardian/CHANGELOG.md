# Changelog — CRS Guardian

## 2.5.1 — Author and metadata correction

- Set the sole plugin author to Amlan Patnaik and metadata contact email to amlanpatnaikx@gmail.com.
- Removed stale third-party account links from Plugin Manager metadata.
- Aligned package documentation, copyright notice and Python source headers with the author/contact metadata.

**Copyright © 2077 Amlan Patnaik. All rights reserved.**  
**Author and owner:** Amlan Patnaik  
**Contact:** amlanpatnaikx@gmail.com  
**Licence:** GPL-2.0-or-later.

## 2.5.0 — Precision & Quality Assurance Edition

- Added a dedicated **CRS Intelligence** workspace with sampled geographic footprint analysis, UTM-zone spread detection, conservative candidate recommendations and confidence guidance. Removed the unsafe centroid-only fallback when footprint analysis rejects Auto UTM.
- Added **Measurement & Unit Guardian** to inspect project distance/area units, ellipsoid settings and per-layer map units, with guarded project distance-unit changes.
- Added **Transformation Inspector** using the active QGIS project transform context to expose the selected PROJ operation, available instantiated details and fallback status after a sample coordinate test.
- Added a dedicated **Diagnostics** workspace with layer-by-layer findings and detailed explanations.
- Added **Preflight QA** for provider, CRS, extent, theoretical CRS-pair feasibility where available, and a representative sample-coordinate transform using the project transform context.
- Added **Postflight QA** before registering outputs, including output provider, CRS, extent, vector feature-count and raster-dimension checks.
- Added reusable local CRS profiles and optional **Live CRS Sentinel** monitoring for layer/project CRS changes. Monitoring only triggers diagnostics; it never edits data.
- Made activity history persistent across QGIS restarts and added history export.
- Updated GDAL Warp creation-options parameter selection by inspecting the installed Processing algorithm definition, supporting legacy and newer QGIS parameter naming.
- Preserved the AMLAN-X navy/gold identity, original data protection, background processing and existing assign/reproject workflows.

## 2.4.0 — AMLAN-X branding refresh

- Added a new professional CRS Guardian emblem in a navy, blue and gold technical identity.
- Replaced the placeholder sidebar and overview symbols with the new logo.
- Updated the QGIS toolbar/plugin icon and standalone window icon.
- Added the release copyright notice to first-party source headers and documentation while retaining the original author attribution and licence.
- Updated in-app version labels, metadata, README and release documentation to 2.4.0.
- Preserved the existing CRS diagnostics, assign/reproject/harmonize workflows, background tasks, cancellation, logging, output safety and project update behavior.

## 2.3.0
- Full dark mode across all plugin workspaces and child dialogs.
- Dark navy technical surfaces with yellow highlights and red-only warning/error accents.
- Corrected branding and action-button clipping; idle cancel control hidden.
- Applied a dark Windows title-bar hint where supported.

## 2.2.0
- Rebranded the plugin as CRS Guardian.
- Applied a technical dark-navy and yellow visual identity.
- Preserved the 2.1.0 layout, workspace navigation and CRS processing workflows.

## 2.1.0
- Rebuilt the standalone window into Overview, Harmonize, Activity and Guide workspaces.
- Added severity filtering, CSV report export, timestamped activity and project CRS badge.

## 2.0.0
- Replaced dock interface with standalone resizable window.
- Added safer processing, logging, task cancellation and output cleanup.
