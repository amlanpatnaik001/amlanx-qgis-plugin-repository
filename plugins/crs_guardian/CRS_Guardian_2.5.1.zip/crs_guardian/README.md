# CRS Guardian 2.5.1 — QGIS Plugin

![CRS Guardian emblem](brand_logo.png)

**CRS Guardian · Coordinate Systems Workspace**  
**AMLAN-X release · Version 2.5.1**

**Copyright © 2077 Amlan Patnaik. All rights reserved.**  
**Author and owner:** Amlan Patnaik  
**Contact:** amlanpatnaikx@gmail.com  
Distributed under the **GPL-2.0-or-later** licence; see `LICENSE`.

## Overview

CRS Guardian is a project-wide CRS health checker and non-destructive reprojection assistant for QGIS. It audits vector, raster and mesh layer CRS health, flags missing or suspicious CRS assignments, geographic measurement risks and project CRS mismatches, and provides tools for assigning a known CRS or creating reprojected copies.

Version 2.5.0 expands the plugin from CRS diagnostics and safe reprojection into a coordinated precision and QA workspace. The existing navy, blue and gold AMLAN-X identity and non-destructive processing behavior are retained.

## Workspaces and features

- **Overview:** project scan, CRS badge, issue counts and an indicative weighted project health score.
- **CRS Intelligence:** samples nine points around each valid layer extent in WGS 84, checks UTM zone spread and provides an advisory UTM candidate with confidence guidance only when the sampled footprint is contained in one suitable zone and hemisphere. Unresolved layers lower recommendation confidence; unsuitable multi-zone/equator-crossing/polar footprints do not receive an automatic UTM candidate. It does not verify source CRS correctness or model all projection distortion.
- **Diagnostics:** dedicated full-size layer findings table with severity, source CRS and detailed explanations; the Overview search and severity filters are shared.
- **Measurement Guard:** compares project distance/area preferences, ellipsoid and each project layer's native map units; flags geographic-degree risks and project/layer unit differences. It can change the project distance preference to metres, international feet or US survey feet where supported by the QGIS build. For US survey feet, the current area preference is retained because QGIS exposes no distinct square-US-survey-foot project area unit. It does not change layer coordinates.
- **Transformation Inspector:** displays the requested and instantiated coordinate operation plus available PROJ metadata using the current project transform context; tests a sample coordinate at the layer extent centre and reports fallback use where exposed.
- **Harmonize:** batch reproject supported vector and raster layers to Auto UTM, project CRS or a custom CRS while preserving original sources.
- **Quality Assurance:** preflight checks provider validity, source CRS, extent, theoretical CRS-pair feasibility where available, and a real sample transform using the project transform context; postflight validates generated output provider, target CRS, extent, vector feature count or raster dimensions before registration.
- **Automation:** local named profiles and optional Live CRS Sentinel monitoring for layer additions/removals and project CRS changes. The sentinel only queues diagnostics and never automatically edits project data.
- **Reports & History:** persistent activity log across QGIS restarts, CSV scan report and text history export.
- **Settings:** workflow guide, CRS safety notes and automatic-scan-on-open preference.
- **Safety:** collision-resistant output names, per-layer validation, partial-output cleanup, background task cancellation, centralised logging and user-facing errors.

## Install from ZIP

1. Open QGIS.
2. Go to **Plugins → Manage and Install Plugins → Install from ZIP**.
3. Select `CRS_Guardian_2.5.0.zip`.
4. Enable **CRS Guardian** in the Installed tab if needed.
5. Open **Plugins → CRS Guardian** or click its toolbar icon. The plugin opens in a standalone window.

For manual installation, extract the `crs_guardian` folder into the active QGIS profile's `python/plugins` directory, then enable it in Plugin Manager.

## Usage

1. Open CRS Guardian. An initial project scan runs automatically by default; this can be disabled in Settings.
2. In **CRS Intelligence**, inspect the sampled project footprint and advisory projection guidance.
3. In **Measurement Guard**, confirm distance/area preferences, ellipsoid and layer map units before measurement-intensive work.
4. In **Transformation**, inspect the selected source-to-target coordinate operation and any reported fallback.
5. Run **Preflight QA** before a reprojection batch.
6. In **Harmonize**, choose Auto UTM, project CRS or a custom CRS, then choose temporary or permanent output storage.
7. Review postflight validation results in **Quality Assurance**.
8. Save reusable settings in **Automation** and optionally enable Live CRS Sentinel monitoring.
9. Review persistent events and export audit data in **Reports & History**.

## Safety notes

- A CRS suggestion is not proof that the source CRS is correct. Verify the source CRS before assigning anything.
- CRS Intelligence samples nine points from each layer extent. It is not a geometry-level distortion analysis; review the area of use and intended measurement/analysis before accepting any candidate.
- Auto UTM remains a best-effort suggestion. Projects spanning UTM zones, hemispheres or broad regions should use a deliberate regional/project-specific CRS.
- Measurement unit changes modify QGIS project measurement preferences only. They do not change source coordinate units, reproject data or guarantee that all third-party tools use the same unit preferences.
- A successful sample transform does not prove that every coordinate in a layer can be transformed without issue. Review QGIS warnings and installed grid-shift resources for precision workflows.
- Postflight vector QA compares feature counts and raster QA checks dimensions/bands; it does not replace geometry validation, pixel-value checks, topology checks or domain-specific QC.
- Profiles and history are stored locally in the active QGIS user profile; custom profile CRSs are stored as WKT where available. They are not embedded into project files or shared automatically.
- Mesh layers are included in the audit but are not currently batch-reprojected.
- Reprojection tasks run through QGIS Processing. Provider-level operations may not be interruptible immediately; cancellation stops queued work and requests cancellation of the active task.
- QGIS layer and project updates are performed on the main thread after each task completes.
- Temporary output folders are cleaned when the project is cleared or QGIS exits where cleanup can run. Use a permanent output folder for data that must remain after the session.
- CSV export uses the current in-memory scan report and does not modify project data.

## Compatibility

Metadata declares **QGIS 3.16 through 4.99**. The plugin uses the `qgis.PyQt` abstraction and includes PyQt5/PyQt6 enum, QAction and dialog-execution compatibility helpers. Runtime compatibility still depends on the QGIS build and installed Processing providers, particularly GDAL. Test in each target QGIS installation before production use. QGIS 2.x is not supported.

## Development checks

Run from the directory containing `crs_guardian`:

```bash
python -m compileall -q crs_guardian
python -m unittest discover -s crs_guardian/tests -v
```

The test suite covers CRS detection and pure output-planning helpers. Full Processing/provider integration tests require a configured QGIS Python environment.

## Author, ownership, contact and licence

**Author and owner:** Amlan Patnaik

**Contact:** amlanpatnaikx@gmail.com

**Copyright © 2077 Amlan Patnaik. All rights reserved.**

CRS Guardian is distributed under the **GPL-2.0-or-later** licence. The accompanying `LICENSE` file contains the full licence text.
