# -*- coding: utf-8 -*-
"""Standalone CRS Guardian window with safe, cancellable processing tasks."""
# AMLAN-X release branding/adaptation © 2077 Amlan Patnaik. Original CRS Guardian software by Lokesh Sahu; GPL-2.0-or-later.
import atexit
import csv
import os
import shutil
import sys
import tempfile
from datetime import datetime

from qgis.PyQt.QtCore import Qt, QTimer, pyqtSignal
from qgis.PyQt.QtGui import QColor, QFont, QIcon
from qgis.PyQt.QtWidgets import (
    QApplication,
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)
from qgis.core import (
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsProcessingAlgRunnerTask,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer,
)
from qgis.gui import QgsProjectionSelectionDialog

from . import checker, errors, harmonizer
from .compat import dialog_exec, enum_value, layer_type_value, message_box_button


TARGET_AUTO = 0
TARGET_PROJECT = 1
TARGET_CUSTOM = 2


COLORS = {
    "navy": "#07111F",
    "navy_2": "#0B1930",
    "accent": "#F6C945",
    "accent_hover": "#FFD85C",
    "yellow": "#F6C945",
    "bg": "#091423",
    "surface": "#122139",
    "surface_2": "#172943",
    "border": "#293D5B",
    "text": "#EEF3FC",
    "muted": "#9EADC2",
    "critical": "#FF5364",
    "critical_bg": "#351B2A",
    "warning": "#FF5364",
    "warning_bg": "#351B2A",
    "ok": "#F6C945",
    "ok_bg": "#2B2A25",
}


STYLE = """
/* CRS Guardian dark technical theme: navy surfaces, yellow actions, red warnings. */
QDialog#crsGuardianWindow, QDialog { background: #091423; color: #EEF3FC; }
QWidget { background-color: transparent; font-family: 'Segoe UI', 'Noto Sans', sans-serif; font-size: 10pt; color: #EEF3FC; }
QLabel { background: transparent; color: #EEF3FC; }
QFrame#sidebar { background: #07111F; border: none; }
QLabel#brandName { color: #FFFFFF; font-size: 14pt; font-weight: 800; }
QLabel#brandCaption { color: #9EADC2; font-size: 8pt; letter-spacing: 1px; font-weight: 700; }
QLabel#sidebarSection { color: #8295B0; font-size: 8pt; font-weight: 800; letter-spacing: 1px; padding: 12px 8px 5px 8px; }
QPushButton#navButton { background: transparent; color: #C5D0E0; border: 1px solid transparent; border-radius: 9px; text-align: left; padding: 11px 13px; font-weight: 650; }
QPushButton#navButton:hover { background: #142641; color: #FFFFFF; }
QPushButton#navButton:checked { background: #1B2F4D; color: #F6C945; border: 1px solid #F6C945; }
QLabel#sidebarVersion { color: #8295B0; font-size: 8pt; padding: 10px; }
QFrame#topbar { background: #111F35; border: 1px solid #293D5B; border-radius: 13px; }
QLabel#pageTitle { color: #F4F7FC; font-size: 19pt; font-weight: 800; }
QLabel#pageSubtitle { color: #9EADC2; font-size: 9pt; }
QLabel#eyebrow { color: #AEBBD0; font-size: 8pt; font-weight: 800; letter-spacing: 1px; }
QLabel#sectionTitle { color: #F1F5FC; font-size: 11pt; font-weight: 800; }
QLabel#muted { color: #9EADC2; font-size: 9pt; }
QLabel#pill { background: #2A2A24; color: #F6D96F; border: 1px solid #8B742D; border-radius: 10px; padding: 7px 11px; font-size: 8pt; font-weight: 800; }
QFrame#hero { background: #10213C; border: 1px solid #243A5C; border-radius: 14px; }
QLabel#heroTitle { color: #FFFFFF; font-size: 20pt; font-weight: 800; }
QLabel#heroSubtitle { color: #C4D0E1; font-size: 9pt; }
QFrame#metricCard, QFrame#panelCard, QFrame#infoCard { background: #111F35; border: 1px solid #293D5B; border-radius: 12px; }
QLabel#metricValue { color: #F6C945; font-size: 21pt; font-weight: 800; }
QLabel#metricCaption { color: #9EADC2; font-size: 8pt; font-weight: 800; letter-spacing: .5px; }
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox { background: #0A1729; color: #EEF3FC; border: 1px solid #344A6B; border-radius: 8px; padding: 9px 11px; min-height: 20px; selection-background-color: #66551D; selection-color: #FFFFFF; }
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus { border: 1px solid #F6C945; }
QLineEdit:disabled, QComboBox:disabled { background: #101B2C; color: #687B96; border-color: #263750; }
QComboBox::drop-down { border: none; width: 25px; }
QComboBox QAbstractItemView { background: #101E33; color: #EEF3FC; border: 1px solid #344A6B; selection-background-color: #293D5B; selection-color: #F6D96F; outline: 0; }
QPushButton { background: #172943; color: #DCE6F4; border: 1px solid #344A6B; border-radius: 8px; padding: 9px 13px; font-weight: 650; }
QPushButton:hover { border-color: #F6C945; color: #F6D96F; background: #213452; }
QPushButton:pressed { background: #2B3D56; }
QPushButton:disabled { background: #101B2C; color: #687B96; border-color: #263750; }
QPushButton#primaryButton { background: #F6C945; color: #081321; border: 1px solid #F6C945; padding: 10px 16px; font-weight: 850; }
QPushButton#primaryButton:hover { background: #FFD85C; color: #07111F; border-color: #FFD85C; }
QPushButton#dangerButton { background: #351B2A; color: #FF7A86; border: 1px solid #A93649; }
QPushButton#dangerButton:hover { background: #4A1F31; color: #FFFFFF; border-color: #FF5364; }
QPushButton#softButton { background: #292A25; color: #F6D96F; border: 1px solid #8B742D; }
QPushButton#softButton:hover { background: #383423; color: #FFE58A; border-color: #F6C945; }
QTableWidget { background: #0C192B; alternate-background-color: #122139; color: #E6EDF8; border: 1px solid #293D5B; border-radius: 9px; gridline-color: transparent; selection-background-color: #293D5B; selection-color: #FFFFFF; outline: 0; }
QTableWidget::item { padding: 8px; border-bottom: 1px solid #1C304B; }
QTableWidget::item:selected { background: #263B5A; color: #FFFFFF; }
QHeaderView { background: #14243C; }
QHeaderView::section { background: #192B45; color: #AEBBD0; border: none; border-bottom: 1px solid #344A6B; padding: 11px 8px; font-size: 8pt; font-weight: 800; }
QProgressBar { background: #1C2D46; border: 1px solid #304562; border-radius: 5px; min-height: 9px; max-height: 9px; text-align: center; }
QProgressBar::chunk { background: #F6C945; border-radius: 5px; }
QCheckBox { color: #DCE6F4; spacing: 8px; padding: 4px 0; }
QCheckBox::indicator { width: 16px; height: 16px; border: 1px solid #506581; border-radius: 4px; background: #0A1729; }
QCheckBox::indicator:checked { background: #F6C945; border-color: #F6C945; }
QCheckBox::indicator:disabled { background: #17243A; border-color: #34445C; }
QPlainTextEdit, QTextEdit { background: #081321; color: #DCE6F4; border: 1px solid #293D5B; border-radius: 10px; padding: 12px; selection-background-color: #66551D; font-family: 'Consolas', 'Cascadia Mono', monospace; font-size: 9pt; }
QAbstractScrollArea { background: #0C192B; border: none; }
QAbstractScrollArea::viewport { background: #0C192B; }
QSplitter::handle { background: #293D5B; }
QScrollBar:vertical { background: #0B1728; width: 11px; margin: 2px; }
QScrollBar::handle:vertical { background: #344A6B; border-radius: 5px; min-height: 24px; }
QScrollBar::handle:vertical:hover { background: #516784; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
QScrollBar:horizontal { background: #0B1728; height: 11px; margin: 2px; }
QScrollBar::handle:horizontal { background: #344A6B; border-radius: 5px; min-width: 24px; }
QMenu { background: #111F35; color: #EEF3FC; border: 1px solid #344A6B; padding: 5px; }
QMenu::item { padding: 7px 24px; border-radius: 4px; }
QMenu::item:selected { background: #263B5A; color: #F6D96F; }
QToolTip { background: #172943; color: #FFFFFF; border: 1px solid #F6C945; padding: 5px; }
QDialogButtonBox QPushButton { min-width: 82px; }
QTreeView, QListView, QTableView { background: #0C192B; alternate-background-color: #122139; color: #E6EDF8; border: 1px solid #293D5B; selection-background-color: #293D5B; selection-color: #FFFFFF; }
QTreeView::item, QListView::item { padding: 5px; }
QTreeView::item:selected, QListView::item:selected { background: #293D5B; color: #F6D96F; }
"""


def _qt(name, group=None):
    return enum_value(Qt, name, group)


def _button_box(parent, title, message, buttons, default_button=None):
    box = QMessageBox(parent)
    box.setWindowTitle(title)
    box.setText(message)
    box.setStandardButtons(buttons)
    if default_button is not None:
        box.setDefaultButton(default_button)
    box.setStyleSheet(STYLE)
    return box


class CrsGuardianWindow(QDialog):
    """A native, non-dockable, resizable CRS Guardian desktop window."""

    # Bridge task-thread signals back to the GUI thread before touching widgets
    # or the QGIS project. The lambdas connected to workers only emit signals.
    task_executed_signal = pyqtSignal(object, bool, object)
    task_terminated_signal = pyqtSignal(object)
    task_progress_signal = pyqtSignal(float)

    def __init__(self, iface, parent=None):
        super(CrsGuardianWindow, self).__init__(
            parent, _qt("Window", "WindowType")
        )
        self.iface = iface
        self.setObjectName("crsGuardianWindow")
        self.setWindowTitle("CRS Guardian | Coordinate Systems Workspace")
        self.setMinimumSize(1080, 700)
        self.resize(1440, 900)
        try:
            self.setWindowIcon(QIcon(os.path.join(os.path.dirname(__file__), "icon.png")))
        except Exception:
            errors.get_logger().exception("Unable to set CRS Guardian window icon")
        self.setModal(False)
        self.setStyleSheet(STYLE)

        self._custom_crs = None
        self._chosen_output_dir = None
        self._reports = []
        self._result = harmonizer.HarmonizeResult()
        self._queue = []
        self._active_task = None
        self._active_feedback = None
        self._active_context = None
        self._active_output = None
        self._active_layer = None
        self._active_algorithm = None
        self._active_executed_slot = None
        self._active_terminated_slot = None
        self._active_progress_slot = None
        self._task_completion_handled = False
        self._batch_target = None
        self._batch_output_dir = None
        self._batch_total = 0
        self._done_count = 0
        self._update_project_crs = False
        self._current_mode = "batch"
        self._cancel_requested = False
        self._shutting_down = False
        self._temp_output_dirs = []
        self._temp_cleanup_pending = False
        self._project_generation = 0
        self._job_project_generation = 0

        queued = _qt("QueuedConnection", "ConnectionType")
        self.task_executed_signal.connect(self._on_task_executed, queued)
        self.task_terminated_signal.connect(self._on_task_terminated, queued)
        self.task_progress_signal.connect(self._on_task_progress, queued)
        try:
            QgsProject.instance().cleared.connect(self._on_project_cleared)
        except Exception as exc:
            errors.log_exception("Unable to connect temporary-output cleanup to project lifecycle", exc)
        atexit.register(self._cleanup_temporary_outputs)

        self._build_ui()
        QTimer.singleShot(0, self._apply_native_dark_titlebar)
        self.run_scan()

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        """Create the standalone application shell and its focused workspaces."""
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Left navigation rail
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(242)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(16, 22, 16, 16)
        side.setSpacing(7)

        brand_row = QHBoxLayout()
        brand_icon = QLabel()
        brand_icon.setFixedSize(43, 43)
        brand_icon.setAlignment(_qt("AlignCenter", "AlignmentFlag"))
        brand_icon.setPixmap(QIcon(os.path.join(os.path.dirname(__file__), "icon.png")).pixmap(39, 39))
        brand_icon.setStyleSheet(
            "background: #1B2F4D; border: 1px solid #3A5070; border-radius: 10px;"
        )
        brand_text = QVBoxLayout()
        brand_name = QLabel("CRS GUARDIAN")
        brand_name.setObjectName("brandName")
        brand_name.setMinimumWidth(154)
        brand_caption = QLabel("GIS QUALITY TOOLS")
        brand_caption.setObjectName("brandCaption")
        brand_text.addWidget(brand_name)
        brand_text.addWidget(brand_caption)
        brand_row.addWidget(brand_icon)
        brand_row.addLayout(brand_text, 1)
        side.addLayout(brand_row)
        side.addSpacing(28)

        section = QLabel("WORKSPACE")
        section.setObjectName("sidebarSection")
        side.addWidget(section)
        self._nav_buttons = []
        nav_items = [
            ("◫   Overview", 0),
            ("⇄   Harmonize", 1),
            ("◷   Activity log", 2),
            ("ⓘ   Guide and About", 3),
        ]
        for label, page_index in nav_items:
            button = QPushButton(label)
            button.setObjectName("navButton")
            button.setCheckable(True)
            button.setAutoExclusive(True)
            button.clicked.connect(lambda checked=False, idx=page_index: self._navigate_to(idx))
            side.addWidget(button)
            self._nav_buttons.append(button)
        self._nav_buttons[0].setChecked(True)
        side.addStretch(1)

        side_status = QFrame()
        side_status.setStyleSheet("background: #10213A; border: 1px solid #293D5B; border-radius: 10px;")
        side_status_layout = QVBoxLayout(side_status)
        side_status_layout.setContentsMargins(12, 11, 12, 11)
        side_status_layout.setSpacing(3)
        health_title = QLabel("ENGINE STATUS")
        health_title.setStyleSheet("color: #9EADC2; font-size: 8pt; font-weight: 800; letter-spacing: 1px;")
        health_value = QLabel("●   Ready for project scan")
        health_value.setStyleSheet("color: #F6C945; font-size: 9pt; font-weight: 700;")
        health_hint = QLabel("Standalone workspace")
        health_hint.setStyleSheet("color: #AEBBD0; font-size: 8pt;")
        side_status_layout.addWidget(health_title)
        side_status_layout.addWidget(health_value)
        side_status_layout.addWidget(health_hint)
        side.addWidget(side_status)
        version_label = QLabel("CRS GUARDIAN  ·  VERSION 2.4.0")
        version_label.setObjectName("sidebarVersion")
        version_label.setAlignment(_qt("AlignCenter", "AlignmentFlag"))
        side.addWidget(version_label)
        copyright_label = QLabel("© 2077 Amlan Patnaik")
        copyright_label.setAlignment(_qt("AlignCenter", "AlignmentFlag"))
        copyright_label.setStyleSheet("color: #8295B0; font-size: 7pt; padding-bottom: 2px;")
        side.addWidget(copyright_label)
        root.addWidget(sidebar)

        # Main workspace
        main = QWidget()
        main_layout = QVBoxLayout(main)
        main_layout.setContentsMargins(22, 18, 22, 14)
        main_layout.setSpacing(14)

        topbar = QFrame()
        topbar.setObjectName("topbar")
        top_layout = QHBoxLayout(topbar)
        top_layout.setContentsMargins(18, 13, 16, 13)
        page_copy = QVBoxLayout()
        self.page_title = QLabel("Project overview")
        self.page_title.setObjectName("pageTitle")
        self.page_subtitle = QLabel("Inspect coordinate reference systems and review project health.")
        self.page_subtitle.setObjectName("pageSubtitle")
        page_copy.addWidget(self.page_title)
        page_copy.addWidget(self.page_subtitle)
        top_layout.addLayout(page_copy, 1)
        self.project_crs_badge = QLabel("PROJECT CRS · —")
        self.project_crs_badge.setObjectName("pill")
        top_layout.addWidget(self.project_crs_badge)
        self.scan_btn = QPushButton("↻   Scan project")
        self.scan_btn.setObjectName("primaryButton")
        self.scan_btn.clicked.connect(self.run_scan)
        top_layout.addWidget(self.scan_btn)
        main_layout.addWidget(topbar)

        self.pages = QStackedWidget()
        main_layout.addWidget(self.pages, 1)

        # Page 0: overview and diagnostics
        overview_page = QWidget()
        overview = QVBoxLayout(overview_page)
        overview.setContentsMargins(0, 0, 0, 0)
        overview.setSpacing(13)

        hero = QFrame()
        hero.setObjectName("hero")
        hero_layout = QHBoxLayout(hero)
        hero_layout.setContentsMargins(21, 17, 21, 17)
        hero_layout.setSpacing(15)
        hero_mark = QLabel()
        hero_mark.setFixedSize(48, 48)
        hero_mark.setAlignment(_qt("AlignCenter", "AlignmentFlag"))
        hero_mark.setPixmap(QIcon(os.path.join(os.path.dirname(__file__), "icon.png")).pixmap(44, 44))
        hero_mark.setStyleSheet("background: #1B2F4D; border: 1px solid #3A5070; border-radius: 12px;")
        hero_layout.addWidget(hero_mark)
        hero_text = QVBoxLayout()
        hero_eyebrow = QLabel("COORDINATE SYSTEM INTELLIGENCE")
        hero_eyebrow.setObjectName("eyebrow")
        hero_eyebrow.setStyleSheet("color: #B7C5D8;")
        hero_title = QLabel("Know your project. Trust your coordinates.")
        hero_title.setObjectName("heroTitle")
        hero_subtitle = QLabel("Find CRS inconsistencies early and correct them without overwriting source data.")
        hero_subtitle.setObjectName("heroSubtitle")
        hero_text.addWidget(hero_eyebrow)
        hero_text.addWidget(hero_title)
        hero_text.addWidget(hero_subtitle)
        hero_layout.addLayout(hero_text, 1)
        overview.addWidget(hero)

        metrics = QHBoxLayout()
        metrics.setSpacing(10)
        self.metric_layers = self._metric_card("—", "LAYERS IN PROJECT", COLORS["yellow"])
        self.metric_critical = self._metric_card("—", "CRITICAL ISSUES", COLORS["critical"])
        self.metric_warning = self._metric_card("—", "WARNINGS", COLORS["warning"])
        self.metric_ok = self._metric_card("—", "HEALTHY LAYERS", COLORS["ok"])
        for card in (self.metric_layers, self.metric_critical, self.metric_warning, self.metric_ok):
            metrics.addWidget(card, 1)
        overview.addLayout(metrics)

        report_panel = QFrame()
        report_panel.setObjectName("panelCard")
        report_layout = QVBoxLayout(report_panel)
        report_layout.setContentsMargins(15, 14, 15, 13)
        report_layout.setSpacing(10)
        report_header = QHBoxLayout()
        report_copy = QVBoxLayout()
        report_title = QLabel("Layer diagnostics")
        report_title.setObjectName("sectionTitle")
        report_subtitle = QLabel("One consolidated result per supported layer · Select an action to resolve an issue")
        report_subtitle.setObjectName("muted")
        report_copy.addWidget(report_title)
        report_copy.addWidget(report_subtitle)
        report_header.addLayout(report_copy, 1)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Search layers or findings…")
        self.search_edit.setClearButtonEnabled(True)
        self.search_edit.setMinimumWidth(205)
        self.search_edit.setMaximumWidth(270)
        self.search_edit.textChanged.connect(self._filter_rows)
        report_header.addWidget(self.search_edit)
        self.severity_filter = QComboBox()
        self.severity_filter.addItem("All statuses", "all")
        self.severity_filter.addItem("Critical", checker.CRITICAL)
        self.severity_filter.addItem("Warnings", checker.WARNING)
        self.severity_filter.addItem("Healthy", checker.OK)
        self.severity_filter.setMinimumWidth(125)
        self.severity_filter.currentIndexChanged.connect(lambda unused: self._filter_rows(self.search_edit.text()))
        report_header.addWidget(self.severity_filter)
        self.export_btn = QPushButton("⇩   Export CSV")
        self.export_btn.setObjectName("softButton")
        self.export_btn.setToolTip("Export the complete scan report, including layers hidden by current filters.")
        self.export_btn.clicked.connect(self._export_report)
        report_header.addWidget(self.export_btn)
        report_layout.addLayout(report_header)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["STATUS", "LAYER", "SOURCE CRS", "FINDINGS", "ACTION"])
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(45)
        self.table.setEditTriggers(enum_value(QAbstractItemView, "NoEditTriggers", "EditTrigger"))
        self.table.setSelectionBehavior(enum_value(QAbstractItemView, "SelectRows", "SelectionBehavior"))
        self.table.setSelectionMode(enum_value(QAbstractItemView, "SingleSelection", "SelectionMode"))
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.setWordWrap(False)
        self.table.setSortingEnabled(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, enum_value(QHeaderView, "ResizeToContents", "ResizeMode"))
        header.setSectionResizeMode(1, enum_value(QHeaderView, "Interactive", "ResizeMode"))
        header.setSectionResizeMode(2, enum_value(QHeaderView, "ResizeToContents", "ResizeMode"))
        header.setSectionResizeMode(3, enum_value(QHeaderView, "Stretch", "ResizeMode"))
        header.setSectionResizeMode(4, enum_value(QHeaderView, "Fixed", "ResizeMode"))
        self.table.setColumnWidth(1, 200)
        self.table.setColumnWidth(4, 132)
        self.table.setMinimumHeight(260)
        self.table.setToolTip("Double-click a layer row to view full diagnostic details.")
        self.table.cellDoubleClicked.connect(self._show_layer_details)
        report_layout.addWidget(self.table, 1)
        self.table_empty = QLabel("No matching layers. Change the filters or run a new scan.")
        self.table_empty.setObjectName("muted")
        self.table_empty.setAlignment(_qt("AlignCenter", "AlignmentFlag"))
        self.table_empty.setMinimumHeight(42)
        self.table_empty.hide()
        report_layout.addWidget(self.table_empty)
        report_foot = QLabel("Assign CRS only when the existing coordinate values already match the selected CRS. Reproject transforms coordinates into a new output copy.")
        report_foot.setObjectName("muted")
        report_foot.setWordWrap(True)
        report_layout.addWidget(report_foot)
        overview.addWidget(report_panel, 1)
        self.pages.addWidget(overview_page)

        # Page 1: harmonization workspace
        harmonize_page = QWidget()
        harmonize_layout = QVBoxLayout(harmonize_page)
        harmonize_layout.setContentsMargins(0, 0, 0, 0)
        harmonize_layout.setSpacing(14)
        h_hero = QFrame()
        h_hero.setObjectName("hero")
        h_hero_layout = QVBoxLayout(h_hero)
        h_hero_layout.setContentsMargins(22, 19, 22, 19)
        h_eyebrow = QLabel("COORDINATE TRANSFORMATION WORKSPACE")
        h_eyebrow.setObjectName("eyebrow")
        h_eyebrow.setStyleSheet("color: #B7C5D8;")
        h_title = QLabel("Harmonize your layers")
        h_title.setObjectName("heroTitle")
        h_subtitle = QLabel("Create consistent, analysis-ready copies while keeping every original data source untouched.")
        h_subtitle.setObjectName("heroSubtitle")
        h_hero_layout.addWidget(h_eyebrow)
        h_hero_layout.addWidget(h_title)
        h_hero_layout.addWidget(h_subtitle)
        harmonize_layout.addWidget(h_hero)

        h_columns = QHBoxLayout()
        h_columns.setSpacing(13)
        target_panel = QFrame()
        target_panel.setObjectName("panelCard")
        target_layout = QVBoxLayout(target_panel)
        target_layout.setContentsMargins(19, 18, 19, 18)
        target_layout.setSpacing(12)
        target_title = QLabel("01  ·  Target coordinate system")
        target_title.setObjectName("sectionTitle")
        target_desc = QLabel("Choose the CRS that all supported vector and raster output layers should use.")
        target_desc.setObjectName("muted")
        target_desc.setWordWrap(True)
        target_layout.addWidget(target_title)
        target_layout.addWidget(target_desc)
        target_label = QLabel("TARGET CRS")
        target_label.setObjectName("eyebrow")
        target_layout.addWidget(target_label)
        self.target_combo = QComboBox()
        self.target_combo.addItem("Auto-suggest UTM", TARGET_AUTO)
        self.target_combo.addItem("Use project CRS", TARGET_PROJECT)
        self.target_combo.addItem("Choose custom CRS…", TARGET_CUSTOM)
        self.target_combo.currentIndexChanged.connect(self._on_target_changed)
        target_layout.addWidget(self.target_combo)
        self.target_hint = QLabel("Automatic UTM is a best-effort suggestion for geographically compact projects.")
        self.target_hint.setObjectName("muted")
        self.target_hint.setWordWrap(True)
        target_layout.addWidget(self.target_hint)
        target_layout.addSpacing(8)
        target_rule = QLabel("OUTPUT BEHAVIOUR")
        target_rule.setObjectName("eyebrow")
        target_layout.addWidget(target_rule)
        self.chk_set_project = QCheckBox("Update project CRS after successful batch")
        self.chk_set_project.setChecked(True)
        target_layout.addWidget(self.chk_set_project)
        target_layout.addStretch(1)
        h_columns.addWidget(target_panel, 3)

        output_panel = QFrame()
        output_panel.setObjectName("panelCard")
        output_layout = QVBoxLayout(output_panel)
        output_layout.setContentsMargins(19, 18, 19, 18)
        output_layout.setSpacing(12)
        output_title = QLabel("02  ·  Output destination")
        output_title.setObjectName("sectionTitle")
        output_desc = QLabel("Choose a permanent folder or use a temporary session workspace.")
        output_desc.setObjectName("muted")
        output_desc.setWordWrap(True)
        output_layout.addWidget(output_title)
        output_layout.addWidget(output_desc)
        self.chk_save = QCheckBox("Save outputs to a permanent folder")
        self.chk_save.setChecked(False)
        output_layout.addWidget(self.chk_save)
        self.output_folder_btn = QPushButton("Choose output folder…")
        self.output_folder_btn.clicked.connect(self._choose_output_folder)
        self.output_folder_btn.setEnabled(False)
        self.chk_save.toggled.connect(self.output_folder_btn.setEnabled)
        output_layout.addWidget(self.output_folder_btn)
        self.output_folder_label = QLabel("Temporary session output")
        self.output_folder_label.setObjectName("muted")
        self.output_folder_label.setWordWrap(True)
        self.output_layout_spacer = QLabel(" ")
        output_layout.addWidget(self.output_folder_label)
        output_layout.addSpacing(10)
        safety = QLabel("SAFE PROCESSING\n\n• Original data sources are never overwritten\n• Every output receives a unique filename\n• Failed partial outputs are cleaned up\n• Jobs run through QGIS background processing\n• Cancellation stops queued operations")
        safety.setWordWrap(True)
        safety.setStyleSheet("background: #172943; color: #F6D96F; border: 1px solid #8B742D; border-radius: 9px; padding: 12px; font-size: 9pt;")
        output_layout.addWidget(safety)
        output_layout.addStretch(1)
        h_columns.addWidget(output_panel, 2)
        harmonize_layout.addLayout(h_columns, 1)

        action_panel = QFrame()
        action_panel.setObjectName("panelCard")
        action_row = QHBoxLayout(action_panel)
        action_row.setContentsMargins(18, 14, 18, 14)
        action_copy = QVBoxLayout()
        action_title = QLabel("Ready to harmonize?")
        action_title.setObjectName("sectionTitle")
        action_hint = QLabel("Review the target CRS and output location before starting the batch.")
        action_hint.setObjectName("muted")
        action_copy.addWidget(action_title)
        action_copy.addWidget(action_hint)
        action_row.addLayout(action_copy, 1)
        self.harmonize_btn = QPushButton("Run harmonization   →")
        self.harmonize_btn.setObjectName("primaryButton")
        self.harmonize_btn.setMinimumWidth(205)
        self.harmonize_btn.clicked.connect(self.run_harmonize)
        action_row.addWidget(self.harmonize_btn)
        harmonize_layout.addWidget(action_panel)
        self.pages.addWidget(harmonize_page)

        # Page 2: operation history
        activity_page = QWidget()
        activity_layout = QVBoxLayout(activity_page)
        activity_layout.setContentsMargins(0, 0, 0, 0)
        activity_layout.setSpacing(13)
        activity_header = QFrame()
        activity_header.setObjectName("panelCard")
        activity_header_layout = QHBoxLayout(activity_header)
        activity_header_layout.setContentsMargins(18, 15, 18, 15)
        activity_copy = QVBoxLayout()
        activity_title = QLabel("Session activity")
        activity_title.setObjectName("sectionTitle")
        activity_subtitle = QLabel("A readable timeline of scans, fixes and processing events in this window session.")
        activity_subtitle.setObjectName("muted")
        activity_copy.addWidget(activity_title)
        activity_copy.addWidget(activity_subtitle)
        activity_header_layout.addLayout(activity_copy, 1)
        copy_activity_btn = QPushButton("Copy activity")
        copy_activity_btn.clicked.connect(self._copy_activity)
        clear_activity_btn = QPushButton("Clear")
        clear_activity_btn.clicked.connect(self._clear_activity)
        activity_header_layout.addWidget(copy_activity_btn)
        activity_header_layout.addWidget(clear_activity_btn)
        activity_layout.addWidget(activity_header)
        self.activity_view = QPlainTextEdit()
        self.activity_view.setReadOnly(True)
        self.activity_view.setPlaceholderText("CRS Guardian activity will appear here…")
        activity_layout.addWidget(self.activity_view, 1)
        self._activity_lines = []
        self.pages.addWidget(activity_page)

        # Page 3: guide and about
        guide_page = QWidget()
        guide_layout = QVBoxLayout(guide_page)
        guide_layout.setContentsMargins(0, 0, 0, 0)
        guide_layout.setSpacing(13)
        guide_hero = QFrame()
        guide_hero.setObjectName("hero")
        guide_hero_layout = QVBoxLayout(guide_hero)
        guide_hero_layout.setContentsMargins(22, 20, 22, 20)
        guide_kicker = QLabel("CRS GUARDIAN  ·  VERSION 2.4.0")
        guide_kicker.setObjectName("eyebrow")
        guide_kicker.setStyleSheet("color: #B7C5D8;")
        guide_heading = QLabel("Coordinate confidence, built into your workflow.")
        guide_heading.setObjectName("heroTitle")
        guide_body = QLabel("Audit. Understand. Correct. CRS Guardian helps identify common coordinate reference system risks and safely creates reprojected copies for GIS analysis.")
        guide_body.setObjectName("heroSubtitle")
        guide_body.setWordWrap(True)
        guide_hero_layout.addWidget(guide_kicker)
        guide_hero_layout.addWidget(guide_heading)
        guide_hero_layout.addWidget(guide_body)
        guide_layout.addWidget(guide_hero)

        guide_columns = QHBoxLayout()
        guide_columns.setSpacing(13)
        guide_steps = [
            ("01  ·  Scan", "Review missing CRS, suspicious coordinate extents, geographic measurement units and project CRS differences."),
            ("02  ·  Assign or reproject", "Assign CRS only when coordinate values are already correct. Reproject when coordinates must be transformed."),
            ("03  ·  Harmonize", "Choose a target CRS and create new vector or raster outputs. Keep permanent outputs in a folder you control."),
        ]
        for heading, body in guide_steps:
            card = QFrame()
            card.setObjectName("infoCard")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(17, 16, 17, 16)
            title = QLabel(heading)
            title.setObjectName("sectionTitle")
            text = QLabel(body)
            text.setObjectName("muted")
            text.setWordWrap(True)
            card_layout.addWidget(title)
            card_layout.addWidget(text)
            card_layout.addStretch(1)
            guide_columns.addWidget(card, 1)
        guide_layout.addLayout(guide_columns)
        note = QLabel("Important: Automatic UTM is only a suggestion for compact geographic areas. Verify the source CRS before assigning it. Availability of raster reprojection depends on the installed GDAL Processing provider.")
        note.setWordWrap(True)
        note.setStyleSheet("background: #172943; color: #F6D96F; border: 1px solid #8B742D; border-radius: 10px; padding: 13px;")
        guide_layout.addWidget(note)
        guide_layout.addStretch(1)
        self.pages.addWidget(guide_page)

        # Persistent task/status strip
        activity = QFrame()
        activity.setObjectName("panelCard")
        activity_layout = QVBoxLayout(activity)
        activity_layout.setContentsMargins(14, 10, 14, 10)
        activity_layout.setSpacing(7)
        status_row = QHBoxLayout()
        self.status_label = QLabel("Ready. Run a scan to inspect the current QGIS project.")
        self.status_label.setObjectName("muted")
        status_row.addWidget(self.status_label, 1)
        self.cancel_btn = QPushButton("Cancel task")
        self.cancel_btn.setObjectName("dangerButton")
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setVisible(False)
        self.cancel_btn.clicked.connect(self.cancel_processing)
        status_row.addWidget(self.cancel_btn)
        activity_layout.addLayout(status_row)
        progress_row = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setTextVisible(False)
        self.progress.setVisible(False)
        progress_row.addWidget(self.progress, 1)
        self.progress_caption = QLabel("")
        self.progress_caption.setObjectName("muted")
        progress_row.addWidget(self.progress_caption)
        activity_layout.addLayout(progress_row)
        main_layout.addWidget(activity)
        root.addWidget(main, 1)
        self._sync_project_info()

    def _apply_native_dark_titlebar(self, widget=None):
        """Request a dark native caption on Windows; safe no-op elsewhere."""
        if sys.platform != "win32":
            return
        try:
            import ctypes
            target = widget or self
            hwnd = ctypes.c_void_p(int(target.winId()))
            dwmapi = ctypes.WinDLL("dwmapi")
            setter = dwmapi.DwmSetWindowAttribute
            setter.restype = ctypes.c_long
            value = ctypes.c_int(1)
            # Attribute 20 is used by current Windows builds; 19 is a fallback.
            for attribute in (20, 19):
                result = setter(
                    hwnd, ctypes.c_uint(attribute),
                    ctypes.byref(value), ctypes.sizeof(value)
                )
                if result == 0:
                    break
        except Exception as exc:
            errors.log_exception("Unable to request Windows dark title bar", exc)

    def _show_message(self, icon_name, title, message, informative=None, buttons=None):
        """Show a consistently dark, non-native Qt message dialog."""
        box = QMessageBox(self)
        box.setWindowTitle(title)
        box.setText(message)
        if informative:
            box.setInformativeText(informative)
        try:
            box.setIcon(enum_value(QMessageBox, icon_name, "Icon"))
        except Exception:
            pass
        box.setStandardButtons(buttons if buttons is not None else message_box_button("Ok"))
        box.setStyleSheet(STYLE)
        QTimer.singleShot(0, lambda target=box: self._apply_native_dark_titlebar(target))
        return dialog_exec(box)

    def _navigate_to(self, page_index):
        """Switch workspace page and update the shared page heading."""
        titles = [
            ("Project overview", "Inspect coordinate reference systems and review project health."),
            ("Harmonize layers", "Safely transform vector and raster layers into a consistent target CRS."),
            ("Activity log", "Review what happened during this CRS Guardian session."),
            ("Guide and About", "Understand the workflow and important CRS safety rules."),
        ]
        if page_index < 0 or page_index >= self.pages.count():
            return
        self.pages.setCurrentIndex(page_index)
        self.page_title.setText(titles[page_index][0])
        self.page_subtitle.setText(titles[page_index][1])
        if page_index < len(self._nav_buttons):
            self._nav_buttons[page_index].setChecked(True)

    def _sync_project_info(self):
        try:
            crs = QgsProject.instance().crs()
            value = crs.authid() if crs and crs.isValid() else "Not set"
        except Exception:
            value = "Unavailable"
        self.project_crs_badge.setText("PROJECT CRS  ·  {}".format(value))

    def _add_activity(self, message, level="INFO"):
        """Add a timestamped event to the in-session activity timeline."""
        try:
            line = "{}  {:<7}  {}".format(datetime.now().strftime("%H:%M:%S"), level.upper(), message)
            self._activity_lines.append(line)
            if len(self._activity_lines) > 500:
                self._activity_lines = self._activity_lines[-500:]
            if hasattr(self, "activity_view"):
                self.activity_view.appendPlainText(line)
        except Exception:
            errors.get_logger().exception("Unable to append activity event")

    def _copy_activity(self):
        QApplication.clipboard().setText("\n".join(self._activity_lines))
        self._set_status("Activity log copied to clipboard.")

    def _clear_activity(self):
        self._activity_lines = []
        self.activity_view.clear()

    def _export_report(self):
        """Export the current scan results to a UTF-8 CSV report."""
        if not self._reports:
            self._show_message("Information", "No report available", "Run a project scan before exporting a report.")
            return
        default_name = "crs_guardian_report_{}.csv".format(datetime.now().strftime("%Y%m%d_%H%M%S"))
        dialog = QFileDialog(self, "Export CRS Guardian report")
        dialog.setOption(enum_value(QFileDialog, "DontUseNativeDialog", "Option"), True)
        dialog.setAcceptMode(enum_value(QFileDialog, "AcceptSave", "AcceptMode"))
        dialog.setFileMode(enum_value(QFileDialog, "AnyFile", "FileMode"))
        dialog.setNameFilter("CSV files (*.csv)")
        dialog.setDefaultSuffix("csv")
        dialog.selectFile(default_name)
        dialog.setStyleSheet(STYLE)
        QTimer.singleShot(0, lambda target=dialog: self._apply_native_dark_titlebar(target))
        if not dialog_exec(dialog):
            return
        selected_files = dialog.selectedFiles()
        path = selected_files[0] if selected_files else ""
        if not path:
            return
        if not path.lower().endswith(".csv"):
            path += ".csv"
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as stream:
                writer = csv.writer(stream)
                writer.writerow(["Layer", "Status", "Source CRS", "Findings", "Details"])
                for report in self._reports:
                    try:
                        crs = report.layer.crs()
                        crs_text = crs.authid() if crs and crs.isValid() else "Not assigned"
                    except Exception:
                        crs_text = "Unavailable"
                    writer.writerow([
                        self._safe_layer_name(report.layer),
                        report.severity,
                        crs_text,
                        report.issues,
                        report.hints,
                    ])
            self._add_activity("Exported {} layer reports to {}".format(len(self._reports), path), "SUCCESS")
            self._set_status("Report exported: {}".format(path))
            self._notify("success", "CRS report exported successfully.")
        except Exception as exc:
            errors.show_error(self, "Report export failed", "The CSV report could not be written.", exc)

    def _metric_card(self, value, caption, accent):
        card = QFrame()
        card.setObjectName("metricCard")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(15, 10, 15, 10)
        layout.setSpacing(1)
        value_label = QLabel(value)
        value_label.setObjectName("metricValue")
        value_label.setStyleSheet("color: {};".format(accent))
        caption_label = QLabel(caption)
        caption_label.setObjectName("metricCaption")
        layout.addWidget(value_label)
        layout.addWidget(caption_label)
        card.value_label = value_label
        return card

    # --------------------------------------------------------------- status
    def _set_status(self, message):
        try:
            self.status_label.setText(message)
        except Exception:
            errors.get_logger().exception("Unable to update status text")

    def _notify(self, level, message):
        try:
            bar = self.iface.messageBar()
            if level == "success":
                bar.pushInfo("CRS Guardian", message)
            elif level == "warning":
                bar.pushWarning("CRS Guardian", message)
            else:
                bar.pushInfo("CRS Guardian", message)
        except Exception:
            errors.get_logger().info(message)

    # ------------------------------------------------------------------ scan
    def run_scan(self):
        if self._active_task is not None:
            self._set_status("A processing task is running. Wait or cancel it before scanning.")
            return
        self.scan_btn.setEnabled(False)
        self._set_status("Scanning project layers…")
        self._add_activity("Project scan started.")
        try:
            findings, layer_count = checker.scan_project()
            self._reports = checker.aggregate_by_layer(findings)
            self._populate_table()
            self._update_metrics(layer_count)
            self._sync_project_info()
            self._set_status(
                "Scan complete · {} supported layer reports".format(len(self._reports))
            )
            critical = sum(1 for report in self._reports if report.severity == checker.CRITICAL)
            warnings = sum(1 for report in self._reports if report.severity == checker.WARNING)
            self._add_activity(
                "Scan complete: {} project layers, {} reports, {} critical, {} warnings.".format(
                    layer_count, len(self._reports), critical, warnings
                ), "SUCCESS" if not critical and not warnings else "WARNING"
            )
        except Exception as exc:
            errors.show_error(self, "CRS Guardian scan failed", "The project scan could not be completed.", exc)
            self._set_status("Scan failed. See the CRS Guardian log for details.")
            self._add_activity("Project scan failed: {}".format(exc), "ERROR")
        finally:
            self.scan_btn.setEnabled(True)

    def _update_metrics(self, layer_count):
        critical = sum(1 for report in self._reports if report.severity == checker.CRITICAL)
        warning = sum(1 for report in self._reports if report.severity == checker.WARNING)
        healthy = sum(1 for report in self._reports if report.severity == checker.OK)
        self.metric_layers.value_label.setText(str(layer_count))
        self.metric_critical.value_label.setText(str(critical))
        self.metric_warning.value_label.setText(str(warning))
        self.metric_ok.value_label.setText(str(healthy))
        self._sync_project_info()

    def _populate_table(self):
        self.table.setRowCount(0)
        for report in self._reports:
            row = self.table.rowCount()
            self.table.insertRow(row)
            tooltip = report.hints or report.issues
            color = {
                checker.CRITICAL: COLORS["critical"],
                checker.WARNING: COLORS["warning"],
                checker.OK: COLORS["ok"],
            }.get(report.severity, COLORS["muted"])
            status_text = {
                checker.CRITICAL: "●  CRITICAL",
                checker.WARNING: "●  WARNING",
                checker.OK: "●  HEALTHY",
            }.get(report.severity, "●  UNKNOWN")
            dot = QTableWidgetItem(status_text)
            dot.setForeground(QColor(color))
            dot.setTextAlignment(_qt("AlignLeft", "AlignmentFlag") | _qt("AlignVCenter", "AlignmentFlag"))
            dot.setToolTip(tooltip)
            dot.setData(_qt("UserRole", "ItemDataRole"), report.severity)
            self.table.setItem(row, 0, dot)

            name = QTableWidgetItem(self._safe_layer_name(report.layer))
            name.setToolTip(tooltip)
            font = QFont()
            font.setBold(report.severity == checker.CRITICAL)
            name.setFont(font)
            try:
                name.setData(_qt("UserRole", "ItemDataRole"), report.layer.id())
            except Exception:
                pass
            self.table.setItem(row, 1, name)

            try:
                crs = report.layer.crs()
                crs_text = crs.authid() if crs and crs.isValid() else "Not assigned"
                crs_tip = crs.description() if crs and crs.isValid() else "No valid CRS"
            except Exception:
                crs_text, crs_tip = "Unavailable", "Layer could not be inspected"
            crs_item = QTableWidgetItem(crs_text)
            crs_item.setToolTip(crs_tip)
            self.table.setItem(row, 2, crs_item)

            issue = QTableWidgetItem(report.issues)
            issue.setToolTip(tooltip)
            self.table.setItem(row, 3, issue)

            if report.fix == "assign":
                action = self._action_button("Assign CRS", lambda unused=False, lyr=report.layer: self.fix_assign(lyr))
            elif report.fix == "reproject":
                action = self._action_button("Reproject", lambda unused=False, lyr=report.layer: self.fix_reproject(lyr))
            else:
                action = QLabel("✓")
                action.setAlignment(_qt("AlignCenter", "AlignmentFlag"))
                action.setStyleSheet("color: {}; font-size: 12pt; font-weight: 800;".format(COLORS["ok"]))
            action.setMinimumWidth(108) if isinstance(action, QPushButton) else None
            self.table.setCellWidget(row, 4, action)
        self._filter_rows(self.search_edit.text())

    def _show_layer_details(self, row, column):
        """Show the full diagnostic explanations for a double-clicked layer."""
        try:
            name_item = self.table.item(row, 1)
            layer_id = name_item.data(_qt("UserRole", "ItemDataRole")) if name_item else None
            report = None
            for candidate in self._reports:
                try:
                    if candidate.layer.id() == layer_id:
                        report = candidate
                        break
                except Exception:
                    continue
            if report is None:
                return
            try:
                crs = report.layer.crs()
                crs_text = crs.authid() if crs and crs.isValid() else "Not assigned / invalid"
            except Exception:
                crs_text = "Unavailable"
            details = []
            for finding in report.findings:
                text = "• {} — {}".format(finding.issue, finding.hint or "No additional guidance.")
                details.append(text)
            message = "Layer: {}\nStatus: {}\nSource CRS: {}\n\n{}".format(
                self._safe_layer_name(report.layer), report.severity.upper(), crs_text,
                "\n\n".join(details) if details else "No diagnostic details available."
            )
            self._show_message("Information", "Layer diagnostics", message)
        except Exception as exc:
            errors.log_exception("Unable to display layer diagnostic details", exc)

    @staticmethod
    def _safe_layer_name(layer):
        try:
            return layer.name()
        except Exception:
            return "Unavailable layer"

    def _action_button(self, text, callback):
        button = QPushButton(text)
        button.setCursor(_qt("PointingHandCursor", "CursorShape"))
        button.setMinimumWidth(108)
        button.setMinimumHeight(30)
        button.setStyleSheet(
            "QPushButton {padding: 6px 9px; color: #F6D96F; background: #292A25; "
            "border: 1px solid #8B742D; border-radius: 7px; font-weight: 750;}"
            "QPushButton:hover {background: #383423; border-color: #F6C945; color: #FFE58A;}"
        )
        button.clicked.connect(callback)
        return button

    def _filter_rows(self, text):
        needle = (text or "").strip().lower()
        severity = self.severity_filter.currentData() if hasattr(self, "severity_filter") else "all"
        visible_count = 0
        for row in range(self.table.rowCount()):
            parts = []
            for column in (1, 2, 3):
                item = self.table.item(row, column)
                if item is not None:
                    parts.append(item.text().lower())
            status_item = self.table.item(row, 0)
            row_severity = status_item.data(_qt("UserRole", "ItemDataRole")) if status_item else None
            text_match = not needle or needle in " ".join(parts)
            severity_match = severity == "all" or row_severity == severity
            visible = text_match and severity_match
            self.table.setRowHidden(row, not visible)
            if visible:
                visible_count += 1
        if hasattr(self, "table_empty"):
            self.table_empty.setVisible(visible_count == 0)

    # --------------------------------------------------------- assign / CRS
    def fix_assign(self, layer):
        valid, reason = errors.validate_layer(layer)
        if not valid:
            self._show_message("Warning", "Layer unavailable", reason)
            self.run_scan()
            return
        try:
            dialog = QgsProjectionSelectionDialog(self)
            dialog.setWindowTitle("Assign source CRS · {}".format(layer.name()))
            dialog.setStyleSheet(STYLE)
            QTimer.singleShot(0, lambda target=dialog: self._apply_native_dark_titlebar(target))
            if layer.crs().isValid():
                dialog.setCrs(layer.crs())
            if dialog_exec(dialog):
                selected_crs = dialog.crs()
                if selected_crs is None or not selected_crs.isValid():
                    self._show_message("Warning", "Invalid CRS", "Choose a valid coordinate reference system.")
                    return
                # Assigning CRS deliberately relabels coordinates; it does not transform them.
                layer.setCrs(selected_crs)
                if not layer.crs().isValid():
                    raise RuntimeError("QGIS did not retain the selected CRS.")
                layer.triggerRepaint()
                self._notify("success", "Assigned {} to '{}' (coordinates unchanged).".format(
                    selected_crs.authid(), layer.name()
                ))
                self._add_activity("Assigned {} to layer '{}' (coordinate values unchanged).".format(
                    selected_crs.authid(), layer.name()
                ), "SUCCESS")
                self.run_scan()
        except Exception as exc:
            errors.show_error(self, "CRS assignment failed", "The CRS could not be assigned.", exc)

    def fix_reproject(self, layer):
        target = self._resolve_target_crs()
        if target is None:
            return
        valid, reason = errors.validate_layer(layer)
        if not valid:
            self._show_message("Warning", "Layer unavailable", reason)
            self.run_scan()
            return
        try:
            if not layer.crs().isValid():
                self._show_message("Warning", "Source CRS required", "Assign the correct source CRS before reprojection.")
                return
            output_dir = self._get_operation_output_dir()
            if output_dir is None:
                return
            self._begin_jobs([layer], target, output_dir, mode="single", update_project=False)
        except Exception as exc:
            errors.show_error(self, "Unable to start reprojection", "The reprojection task could not be started.", exc)

    def _on_target_changed(self, index):
        if self.target_combo.itemData(index) != TARGET_CUSTOM:
            return
        try:
            dialog = QgsProjectionSelectionDialog(self)
            dialog.setWindowTitle("Choose target CRS")
            dialog.setStyleSheet(STYLE)
            QTimer.singleShot(0, lambda target=dialog: self._apply_native_dark_titlebar(target))
            if self._custom_crs is not None and self._custom_crs.isValid():
                dialog.setCrs(self._custom_crs)
            if dialog_exec(dialog):
                selected = dialog.crs()
                if selected is not None and selected.isValid():
                    self._custom_crs = selected
                    self.target_combo.setItemText(index, "Custom · {}".format(selected.authid()))
                    self.target_hint.setText(selected.description() or selected.authid())
                else:
                    self.target_combo.setCurrentIndex(TARGET_AUTO)
            else:
                self.target_combo.setCurrentIndex(TARGET_AUTO)
        except Exception as exc:
            errors.show_error(self, "CRS selection failed", "The target CRS selector could not be opened.", exc)
            self.target_combo.setCurrentIndex(TARGET_AUTO)

    def _resolve_target_crs(self):
        selection = self.target_combo.currentData()
        project = QgsProject.instance()
        if selection == TARGET_AUTO:
            candidate_layers = [
                layer for layer in project.mapLayers().values()
                if layer.type() in (
                    layer_type_value("VectorLayer"), layer_type_value("RasterLayer")
                )
            ]
            target = checker.suggest_utm_crs(candidate_layers)
            if target is None:
                self._show_message("Information", "UTM suggestion unavailable", "A suitable UTM CRS could not be suggested. Choose a custom CRS.")
                return None
            self.target_hint.setText(
                "Suggested {} · Check suitability if the project spans multiple UTM zones.".format(
                    target.authid()
                )
            )
            return target
        if selection == TARGET_PROJECT:
            target = project.crs()
            if target is None or not target.isValid():
                self._show_message("Information", "Project CRS is not set", "Set the project CRS or choose a custom CRS.")
                return None
            return target
        if self._custom_crs is None or not self._custom_crs.isValid():
            self._on_target_changed(self.target_combo.currentIndex())
        return self._custom_crs if self._custom_crs and self._custom_crs.isValid() else None

    # ------------------------------------------------------------- outputs
    def _choose_output_folder(self):
        dialog = QFileDialog(self, "Choose CRS Guardian output folder")
        dialog.setOption(enum_value(QFileDialog, "DontUseNativeDialog", "Option"), True)
        dialog.setOption(enum_value(QFileDialog, "ShowDirsOnly", "Option"), True)
        dialog.setFileMode(enum_value(QFileDialog, "Directory", "FileMode"))
        dialog.setStyleSheet(STYLE)
        QTimer.singleShot(0, lambda target=dialog: self._apply_native_dark_titlebar(target))
        if dialog_exec(dialog):
            selected = dialog.selectedFiles()
            folder = selected[0] if selected else ""
            if folder:
                self._chosen_output_dir = folder
                self.output_folder_label.setText(folder)

    def _get_operation_output_dir(self):
        if self.chk_save.isChecked():
            if not self._chosen_output_dir:
                self._choose_output_folder()
            if not self._chosen_output_dir:
                return None
            return self._chosen_output_dir
        folder = tempfile.mkdtemp(prefix="crs_guardian_outputs_")
        self._temp_output_dirs.append(folder)
        self.output_folder_label.setText("Temporary output: {}".format(folder))
        return folder

    # -------------------------------------------------------- batch process
    def run_harmonize(self):
        if self._active_task is not None:
            return
        target = self._resolve_target_crs()
        if target is None:
            return
        layers = list(QgsProject.instance().mapLayers().values())
        eligible = []
        supported_types = (
            layer_type_value("VectorLayer"), layer_type_value("RasterLayer")
        )
        for layer in layers:
            try:
                if layer.type() in supported_types:
                    eligible.append(layer)
            except Exception as exc:
                errors.log_exception("Unable to inspect layer type during harmonization", exc)
        if not eligible:
            self._show_message("Information", "Nothing to harmonize", "No vector or raster layers were found in this project.")
            return

        buttons = message_box_button("Yes") | message_box_button("No")
        box = _button_box(
            self, "Confirm harmonization",
            "Reproject supported layers to {}?\n\n"
            "Original layers will remain untouched. Unique output copies will be added to a new group.".format(
                target.authid()
            ),
            buttons, message_box_button("Yes")
        )
        QTimer.singleShot(0, lambda target=box: self._apply_native_dark_titlebar(target))
        if dialog_exec(box) != message_box_button("Yes"):
            return
        output_dir = self._get_operation_output_dir()
        if output_dir is None:
            return
        self._begin_jobs(
            eligible, target, output_dir, mode="batch",
            update_project=self.chk_set_project.isChecked()
        )

    def _begin_jobs(self, layers, target_crs, output_dir, mode="batch", update_project=False):
        if self._active_task is not None:
            self._show_message("Information", "Task already running", "Finish or cancel the current task first.")
            return
        if target_crs is None or not target_crs.isValid():
            raise ValueError("The target CRS is invalid.")
        if not os.path.isdir(output_dir):
            os.makedirs(output_dir)

        self._result = harmonizer.HarmonizeResult()
        self._queue = []
        self._batch_target = target_crs
        self._batch_output_dir = output_dir
        self._job_project_generation = self._project_generation
        self._update_project_crs = update_project
        self._current_mode = mode
        self._cancel_requested = False
        self._done_count = 0

        for layer in layers:
            valid, reason = errors.validate_layer(layer)
            if not valid:
                self._result.failed.append(self._safe_layer_name(layer))
                self._result.error_details.append(reason)
                continue
            try:
                layer_type = layer.type()
                if layer_type not in (
                    layer_type_value("VectorLayer"), layer_type_value("RasterLayer")
                ):
                    self._result.skipped_unsupported.append(layer.name())
                    continue
                source_crs = layer.crs()
                if source_crs is None or not source_crs.isValid():
                    self._result.skipped_invalid.append(layer.name())
                    continue
                if source_crs.authid() == target_crs.authid():
                    self._result.skipped_ok.append(layer.name())
                    continue
                algorithm_id, extension = harmonizer.algorithm_id_for_layer(layer)
                if not algorithm_id:
                    self._result.skipped_unsupported.append(layer.name())
                    continue
                output_path = harmonizer.unique_output_path(output_dir, layer.name(), extension)
                algorithm = QgsApplication.processingRegistry().algorithmById(algorithm_id)
                if algorithm is None:
                    raise RuntimeError(
                        "Processing algorithm '{}' is unavailable. Check the QGIS Processing and GDAL providers.".format(
                            algorithm_id
                        )
                    )
                unused_id, parameters = harmonizer.processing_parameters(
                    layer, target_crs, output_path
                )
                self._queue.append({
                    "layer": layer,
                    "algorithm": algorithm,
                    "parameters": parameters,
                    "output": output_path,
                    "algorithm_id": algorithm_id,
                })
            except Exception as exc:
                errors.log_exception("Unable to prepare reprojection for {}".format(self._safe_layer_name(layer)), exc)
                self._result.failed.append(self._safe_layer_name(layer))
                self._result.error_details.append("{}: {}".format(self._safe_layer_name(layer), exc))

        self._batch_total = len(self._queue) + len(self._result.skipped_ok) + len(self._result.skipped_invalid) + len(self._result.skipped_unsupported) + len(self._result.failed)
        self._done_count = self._batch_total - len(self._queue)
        if not self._queue:
            self._finish_jobs()
            return

        self.scan_btn.setEnabled(False)
        self.harmonize_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.cancel_btn.setVisible(True)
        self.progress.setVisible(True)
        self.progress.setValue(int(self._done_count * 100 / max(1, self._batch_total)))
        self.progress_caption.setText("0 / {} completed".format(len(self._queue)))
        self._set_status("Preparing background processing tasks…")
        self._add_activity(
            "{} reprojection job(s) queued for target CRS {}.".format(len(self._queue), target_crs.authid()),
            "INFO"
        )
        self._navigate_to(1)
        self._start_next_task()

    def _start_next_task(self):
        if self._shutting_down:
            return
        if self._cancel_requested:
            self._result.cancelled = True
            self._finish_jobs()
            return
        if not self._queue:
            self._finish_jobs()
            return

        job = self._queue.pop(0)
        layer = job["layer"]
        valid, reason = errors.validate_layer(layer)
        if not valid:
            self._result.failed.append(self._safe_layer_name(layer))
            self._result.error_details.append(reason)
            harmonizer.cleanup_output(job["output"])
            self._done_count += 1
            QTimer.singleShot(0, self._start_next_task)
            return

        try:
            context = QgsProcessingContext()
            project = QgsProject.instance()
            context.setProject(project)
            context.setTransformContext(project.transformContext())
            feedback = QgsProcessingFeedback()
            task = QgsProcessingAlgRunnerTask(
                job["algorithm"], job["parameters"], context, feedback,
            )
            try:
                task.setDescription("CRS Guardian · {}".format(layer.name()))
            except Exception:
                pass
            self._active_terminated_slot = (
                lambda task_ref=task: self.task_terminated_signal.emit(task_ref)
            )
            self._active_progress_slot = (
                lambda value: self.task_progress_signal.emit(float(value))
            )
            self._active_executed_slot = (
                lambda successful, results, task_ref=task:
                self.task_executed_signal.emit(task_ref, bool(successful), results)
            )
            task.executed.connect(self._active_executed_slot)
            task.taskTerminated.connect(self._active_terminated_slot)
            feedback.progressChanged.connect(self._active_progress_slot)
            try:
                task.setDependentLayers([layer])
            except Exception:
                # Not all QGIS builds/providers support dependency tracking here.
                pass
            self._active_task = task
            self._active_context = context
            self._active_feedback = feedback
            self._active_output = job["output"]
            self._active_layer = layer
            self._active_algorithm = job["algorithm_id"]
            self._set_status("Reprojecting {}…".format(layer.name()))
            accepted = QgsApplication.taskManager().addTask(task)
            if accepted is False:
                raise RuntimeError("QGIS task manager rejected the processing task.")
        except Exception as exc:
            errors.log_exception("Unable to start Processing task", exc)
            harmonizer.cleanup_output(job["output"])
            self._result.failed.append(layer.name())
            self._result.error_details.append("{}: {}".format(layer.name(), exc))
            self._clear_active_task()
            self._done_count += 1
            QTimer.singleShot(0, self._start_next_task)

    def _on_task_progress(self, value):
        if self._shutting_down:
            return
        try:
            total = max(1, self._batch_total)
            current_fraction = max(0.0, min(100.0, float(value))) / 100.0
            percentage = int(((self._done_count + current_fraction) / total) * 100)
            self.progress.setValue(max(0, min(100, percentage)))
            self.progress_caption.setText(
                "{} / {} completed".format(self._done_count, total)
            )
        except Exception:
            errors.get_logger().exception("Unable to update task progress display")

    def _on_task_executed(self, task, successful, results):
        if self._shutting_down or task is not self._active_task:
            return
        if self._task_completion_handled:
            return
        self._task_completion_handled = True
        layer = self._active_layer
        output_path = self._active_output
        if self._job_project_generation != self._project_generation:
            self._result.cancelled = True
            self._result.error_details.append(
                "The QGIS project changed during processing; the result was not added to the new project."
            )
            if any(output_path.startswith(folder + os.sep) for folder in self._temp_output_dirs):
                harmonizer.cleanup_output(output_path)
            else:
                self._result.output_paths.append(output_path)
        elif successful:
            registered_layer_id = None
            project = QgsProject.instance()
            try:
                if self._active_algorithm == "native:reprojectlayer":
                    output_layer = QgsVectorLayer(output_path, "", "ogr")
                else:
                    output_layer = QgsRasterLayer(output_path, "", "gdal")
                if output_layer is None or not output_layer.isValid():
                    raise RuntimeError("Processing completed but the output layer could not be opened.")
                output_layer.setName("{} ({})".format(layer.name(), self._batch_target.authid()))
                if not output_layer.crs().isValid():
                    raise RuntimeError("The output was created without a valid CRS.")
                if self._current_mode == "batch":
                    group_name = "Harmonized ({})".format(self._batch_target.authid())
                    root = project.layerTreeRoot()
                    group = root.findGroup(group_name)
                    if group is None:
                        group = root.insertGroup(0, group_name)
                    added_layer = project.addMapLayer(output_layer, False)
                    if added_layer is None or not added_layer.isValid():
                        raise RuntimeError("QGIS could not register the reprojected layer.")
                    registered_layer_id = added_layer.id()
                    group.addLayer(added_layer)
                else:
                    added_layer = project.addMapLayer(output_layer)
                    if added_layer is None or not added_layer.isValid():
                        raise RuntimeError("QGIS could not register the reprojected layer.")
                    registered_layer_id = added_layer.id()
                if project.mapLayer(output_layer.id()) is None:
                    raise RuntimeError("The output layer was not retained in the current project.")
                self._result.reprojected.append(layer.name())
                self._result.output_paths.append(output_path)
                self._add_activity("Reprojected '{}' to {} → {}".format(
                    self._safe_layer_name(layer), self._batch_target.authid(), output_path
                ), "SUCCESS")
            except Exception as exc:
                errors.log_exception("Unable to register completed output layer", exc)
                if registered_layer_id:
                    try:
                        project.removeMapLayer(registered_layer_id)
                    except Exception as rollback_exc:
                        errors.log_exception("Unable to roll back a failed layer registration", rollback_exc)
                harmonizer.cleanup_output(output_path)
                self._result.failed.append(self._safe_layer_name(layer))
                self._result.error_details.append("{}: {}".format(self._safe_layer_name(layer), exc))
                self._add_activity("Could not register output for '{}': {}".format(
                    self._safe_layer_name(layer), exc
                ), "ERROR")
        else:
            harmonizer.cleanup_output(output_path)
            self._result.failed.append(self._safe_layer_name(layer))
            self._add_activity("Reprojection failed for '{}' ({}).".format(
                self._safe_layer_name(layer), self._active_algorithm
            ), "ERROR")
            self._result.error_details.append(
                "{} failed in {}. Review the Processing log for details.".format(
                    self._safe_layer_name(layer), self._active_algorithm
                )
            )

        self._clear_active_task()
        self._done_count += 1
        self.progress.setValue(int(self._done_count * 100 / max(1, self._batch_total)))
        QTimer.singleShot(0, self._start_next_task)

    def _on_task_terminated(self, task):
        # Some QGIS builds signal termination separately when a task is cancelled.
        if self._shutting_down or task is not self._active_task:
            return
        if self._task_completion_handled:
            return
        self._task_completion_handled = True
        output_path = self._active_output
        layer_name = self._safe_layer_name(self._active_layer)
        harmonizer.cleanup_output(output_path)
        if layer_name not in self._result.failed and layer_name not in self._result.reprojected:
            self._result.failed.append(layer_name)
            self._result.error_details.append("{} task was terminated before completion.".format(layer_name))
        self._clear_active_task()
        self._done_count += 1
        QTimer.singleShot(0, self._start_next_task)

    def _clear_active_task(self):
        active = self._active_task
        if active is not None:
            try:
                if self._active_executed_slot is not None:
                    active.executed.disconnect(self._active_executed_slot)
            except Exception:
                pass
            try:
                if self._active_terminated_slot is not None:
                    active.taskTerminated.disconnect(self._active_terminated_slot)
            except Exception:
                pass
            try:
                if self._active_feedback is not None and self._active_progress_slot is not None:
                    self._active_feedback.progressChanged.disconnect(self._active_progress_slot)
            except Exception:
                pass
        self._active_task = None
        self._active_executed_slot = None
        self._active_terminated_slot = None
        self._active_progress_slot = None
        self._active_context = None
        self._active_feedback = None
        self._active_output = None
        self._active_layer = None
        self._active_algorithm = None
        self._task_completion_handled = False

    def cancel_processing(self):
        if self._active_task is None and not self._queue:
            return
        self._cancel_requested = True
        self._result.cancelled = True
        self._add_activity("Cancellation requested by user.", "WARNING")
        self._queue = []
        self.cancel_btn.setEnabled(False)
        self._set_status("Cancellation requested. Waiting for the active QGIS processing task to stop…")
        try:
            if self._active_task is not None:
                self._active_task.cancel()
            else:
                self._finish_jobs()
        except Exception as exc:
            errors.log_exception("Unable to cancel active processing task", exc)
            self._finish_jobs()

    def _finish_jobs(self):
        if self._shutting_down:
            return
        if self._update_project_crs and self._result.reprojected and not self._result.cancelled:
            try:
                QgsProject.instance().setCrs(self._batch_target)
            except Exception as exc:
                errors.log_exception("Unable to update project CRS", exc)
                self._result.failed.append("Project CRS update")
                self._result.error_details.append(str(exc))

        self._clear_active_task()
        if self._temp_cleanup_pending:
            self._cleanup_temporary_outputs()
        self._queue = []
        self.scan_btn.setEnabled(True)
        self.harmonize_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setVisible(False)
        self.progress.setVisible(False)
        self.progress.setValue(0)
        self.progress_caption.setText("")

        summary = self._result.summary()
        details = "\n".join(self._result.error_details[:8])
        if self._result.failed or self._result.skipped_invalid or self._result.cancelled:
            self._notify("warning", summary)
            status = "Completed with warnings · " + summary
        else:
            self._notify("success", summary)
            status = "Completed · " + summary
        self._set_status(status)
        self._sync_project_info()
        self._add_activity("Processing finished: {}".format(summary), "WARNING" if self._result.failed or self._result.cancelled else "SUCCESS")
        if self._result.error_details:
            errors.get_logger().warning("Processing summary: %s\n%s", summary, details)
        if self._current_mode == "single" and self._result.reprojected:
            self._show_message(
                "Information", "Reprojection complete",
                "The reprojected copy has been added to the QGIS project.\n\n{}".format(
                    self._result.summary()
                )
            )
        self.run_scan()

    # ------------------------------------------------------ temporary cleanup
    def _on_project_cleared(self):
        # Do not let a task started for the previous project add layers to a
        # newly opened project. Request cancellation and remove queued work.
        self._project_generation += 1
        self._add_activity("QGIS project cleared; pending operations are being cancelled and temporary outputs scheduled for cleanup.", "WARNING")
        self._sync_project_info()
        if self._active_task is not None:
            self._temp_cleanup_pending = True
            self._cancel_requested = True
            self._result.cancelled = True
            self._queue = []
            try:
                self._active_task.cancel()
            except Exception as exc:
                errors.log_exception("Unable to cancel task after the project changed", exc)
            return
        self._cleanup_temporary_outputs()

    def _cleanup_temporary_outputs(self):
        if self._active_task is not None:
            self._temp_cleanup_pending = True
            return
        pending = list(self._temp_output_dirs)
        self._temp_output_dirs = []
        self._temp_cleanup_pending = False
        for folder in pending:
            try:
                if folder and os.path.isdir(folder):
                    shutil.rmtree(folder)
            except Exception as exc:
                errors.log_exception("Unable to clean temporary output folder {}".format(folder), exc)

    # ---------------------------------------------------------------- close
    def shutdown(self):
        """Cancel active work and disconnect callbacks before plugin unload."""
        self._shutting_down = True
        try:
            self._queue = []
            if self._active_task is not None:
                try:
                    if self._active_executed_slot is not None:
                        self._active_task.executed.disconnect(self._active_executed_slot)
                except Exception:
                    pass
                try:
                    if self._active_terminated_slot is not None:
                        self._active_task.taskTerminated.disconnect(self._active_terminated_slot)
                except Exception:
                    pass
                try:
                    if self._active_feedback is not None and self._active_progress_slot is not None:
                        self._active_feedback.progressChanged.disconnect(self._active_progress_slot)
                except Exception:
                    pass
                self._active_task.cancel()
        except Exception as exc:
            errors.log_exception("Error while shutting down CRS Guardian", exc)

    def closeEvent(self, event):
        if self._shutting_down:
            event.accept()
            return
        # Keep the top-level window instance alive so the toolbar action reopens it.
        event.ignore()
        self.hide()
