# -*- coding: utf-8 -*-
"""Lightweight tests for CRS logic and safe reprojection planning.

These tests use small QGIS API doubles so they can run without a QGIS install.
Provider/Processing integration still needs a real QGIS runtime.
"""
# AMLAN-X release branding/adaptation © 2077 Amlan Patnaik. Original CRS Guardian software by Lokesh Sahu; GPL-2.0-or-later.
import os
import sys
import tempfile
import types
import unittest


class FakeCRS(object):
    def __init__(self, authid="EPSG:4326", valid=True, geographic=True):
        self._authid = authid
        self._valid = valid
        self._geographic = geographic

    def isValid(self):
        return self._valid

    def isGeographic(self):
        return self._geographic

    def authid(self):
        return self._authid

    def description(self):
        return self._authid


class FakePoint(object):
    def __init__(self, x, y):
        self._x, self._y = x, y

    def x(self):
        return self._x

    def y(self):
        return self._y


class FakeExtent(object):
    def __init__(self, xmin=-1, ymin=-1, xmax=1, ymax=1):
        self.values = (xmin, ymin, xmax, ymax)

    def isNull(self):
        return False

    def isEmpty(self):
        return False

    def xMinimum(self):
        return self.values[0]

    def yMinimum(self):
        return self.values[1]

    def xMaximum(self):
        return self.values[2]

    def yMaximum(self):
        return self.values[3]

    def center(self):
        return FakePoint(
            (self.values[0] + self.values[2]) / 2.0,
            (self.values[1] + self.values[3]) / 2.0,
        )


class FakeLayer(object):
    def __init__(self, name="test", crs=None, layer_type=1, extent=None, valid=True):
        self._name = name
        self._crs = crs or FakeCRS()
        self._type = layer_type
        self._extent = extent or FakeExtent()
        self._valid = valid

    def isValid(self):
        return self._valid

    def id(self):
        return self._name

    def name(self):
        return self._name

    def crs(self):
        return self._crs

    def extent(self):
        return self._extent

    def type(self):
        return self._type


class FakeProject(object):
    @staticmethod
    def instance():
        return FakeProject()


class FakeCoordinateTransform(object):
    def __init__(self, source, target, project):
        pass

    def transform(self, point):
        return point


# Stub the small qgis.core surface imported by the modules under test.
qgis_module = types.ModuleType("qgis")
core_module = types.ModuleType("qgis.core")
core_module.QgsCoordinateReferenceSystem = FakeCRS
core_module.QgsCoordinateTransform = FakeCoordinateTransform
core_module.QgsMapLayer = type("QgsMapLayer", (), {
    "VectorLayer": 1, "RasterLayer": 2, "MeshLayer": 3,
    "LayerType": type("LayerType", (), {
        "VectorLayer": 1, "RasterLayer": 2, "MeshLayer": 3
    })
})
core_module.QgsProject = FakeProject
sys.modules.setdefault("qgis", qgis_module)
sys.modules["qgis.core"] = core_module

from crs_guardian import checker, harmonizer


class CheckerTests(unittest.TestCase):
    def setUp(self):
        self.project_crs = FakeCRS("EPSG:3857", True, False)

    def test_geographic_layer_gets_measurement_warning(self):
        layer = FakeLayer(crs=FakeCRS("EPSG:4326", True, True))
        findings = checker.check_layer(layer, self.project_crs)
        self.assertTrue(any(f.severity == checker.WARNING for f in findings))
        self.assertTrue(any("degrees" in f.issue for f in findings))

    def test_missing_crs_is_critical_and_suggests_assign(self):
        layer = FakeLayer(crs=FakeCRS("", False, False))
        findings = checker.check_layer(layer, self.project_crs)
        self.assertEqual(findings[0].severity, checker.CRITICAL)
        self.assertEqual(findings[0].fix, "assign")

    def test_invalid_provider_does_not_crash(self):
        layer = FakeLayer(valid=False)
        findings = checker.check_layer(layer, self.project_crs)
        self.assertEqual(findings[0].severity, checker.CRITICAL)
        self.assertIn("unavailable", findings[0].issue)

    def test_suspicious_projected_extent_is_detected(self):
        layer = FakeLayer(
            crs=FakeCRS("EPSG:3857", True, False),
            extent=FakeExtent(-10, -5, 10, 5),
        )
        findings = checker.check_layer(layer, self.project_crs)
        self.assertTrue(any("looks like degrees" in f.issue for f in findings))

    def test_utm_suggestion_returns_valid_northern_zone(self):
        layer = FakeLayer(crs=FakeCRS("EPSG:4326", True, True))
        suggested = checker.suggest_utm_crs([layer])
        self.assertIsNotNone(suggested)
        self.assertEqual(suggested.authid(), "EPSG:32631")


class HarmonizerTests(unittest.TestCase):
    def test_safe_name_removes_path_and_special_characters(self):
        self.assertEqual(harmonizer.safe_name("../Fiber Cable #1"), "Fiber_Cable_1")
        self.assertEqual(harmonizer.safe_name("***"), "layer")

    def test_unique_paths_do_not_overwrite_existing_outputs(self):
        with tempfile.TemporaryDirectory() as folder:
            first = harmonizer.unique_output_path(folder, "Fiber Cable", ".gpkg")
            with open(first, "w") as stream:
                stream.write("reserved")
            second = harmonizer.unique_output_path(folder, "Fiber Cable", ".gpkg")
            self.assertNotEqual(first, second)
            self.assertTrue(os.path.basename(second).endswith(".gpkg"))

    def test_vector_parameters_use_native_reproject_algorithm(self):
        layer = FakeLayer(crs=FakeCRS("EPSG:4326", True, True), layer_type=1)
        target = FakeCRS("EPSG:3857", True, False)
        algorithm_id, params = harmonizer.processing_parameters(layer, target, "/tmp/out.gpkg")
        self.assertEqual(algorithm_id, "native:reprojectlayer")
        self.assertIs(params["INPUT"], layer)
        self.assertIs(params["TARGET_CRS"], target)
        self.assertEqual(params["OUTPUT"], "/tmp/out.gpkg")

    def test_invalid_source_crs_blocks_reprojection(self):
        layer = FakeLayer(crs=FakeCRS("", False, False), layer_type=1)
        with self.assertRaises(ValueError):
            harmonizer.processing_parameters(
                layer, FakeCRS("EPSG:3857", True, False), "/tmp/out.gpkg"
            )

    def test_vector_and_raster_algorithm_selection(self):
        vector = FakeLayer(layer_type=1)
        raster = FakeLayer(name="elevation", layer_type=2)
        self.assertEqual(harmonizer.algorithm_id_for_layer(vector), ("native:reprojectlayer", ".gpkg"))
        self.assertEqual(harmonizer.algorithm_id_for_layer(raster), ("gdal:warpreproject", ".tif"))

    def test_failed_output_cleanup_removes_sidecars(self):
        with tempfile.TemporaryDirectory() as folder:
            output = os.path.join(folder, "partial.tif")
            sidecar = output + ".aux.xml"
            with open(output, "w") as stream:
                stream.write("partial")
            with open(sidecar, "w") as stream:
                stream.write("metadata")
            harmonizer.cleanup_output(output)
            self.assertFalse(os.path.exists(output))
            self.assertFalse(os.path.exists(sidecar))


if __name__ == "__main__":
    unittest.main()
