# Changelog — CRS Guardian

**AMLAN-X release branding, logo and release documentation © 2077 Amlan Patnaik. All rights reserved.**  
Original CRS Guardian software by Lokesh Sahu; GPL-2.0-or-later terms retained.

## 2.4.0 — AMLAN-X branding refresh

- Added a new professional CRS Guardian emblem in a navy, blue and gold technical identity.
- Replaced the placeholder sidebar and overview symbols with the new logo.
- Updated the QGIS toolbar/plugin icon and standalone window icon.
- Added the release copyright notice to first-party source headers and documentation while retaining the original author attribution and licence.
- Updated in-app version labels, metadata, README and release documentation to 2.4.0.
- Preserved the existing CRS diagnostics, assign/reproject/harmonize workflows, background tasks, cancellation, logging, output safety and project update behavior.

## 2.3.0
- Full dark mode across all plugin workspaces and child dialogs.
- Dark navy technical surfaces with yellow highlights and red-only warning/error accents.
- Corrected branding and action-button clipping; idle cancel control hidden.
- Applied a dark Windows title-bar hint where supported.

## 2.2.0
- Rebranded the plugin as CRS Guardian.
- Applied a technical dark-navy and yellow visual identity.
- Preserved the 2.1.0 layout, workspace navigation and CRS processing workflows.

## 2.1.0
- Rebuilt the standalone window into Overview, Harmonize, Activity and Guide workspaces.
- Added severity filtering, CSV report export, timestamped activity and project CRS badge.

## 2.0.0
- Replaced dock interface with standalone resizable window.
- Added safer processing, logging, task cancellation and output cleanup.
