# -*- coding: utf-8 -*-
"""Centralised logging, exception reporting and layer safety checks."""
# AMLAN-X release branding/adaptation © 2077 Amlan Patnaik. Original CRS Guardian software by Lokesh Sahu; GPL-2.0-or-later.
import logging
import os
import tempfile
import traceback

LOGGER_NAME = "CRSGuardian"
_LOGGER = None


def get_logger():
    """Return the configured CRS Guardian logger (file + QGIS Python console)."""
    global _LOGGER
    if _LOGGER is not None:
        return _LOGGER

    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    if not logger.handlers:
        log_dir = None
        try:
            from qgis.core import QgsApplication
            profile_dir = QgsApplication.qgisSettingsDirPath()
            if profile_dir:
                log_dir = os.path.join(profile_dir, "crs_guardian", "logs")
        except Exception:
            log_dir = None
        if not log_dir:
            log_dir = os.path.join(tempfile.gettempdir(), "crs_guardian_logs")
        try:
            if not os.path.isdir(log_dir):
                os.makedirs(log_dir)
            file_handler = logging.FileHandler(
                os.path.join(log_dir, "crs_guardian.log"),
                encoding="utf-8"
            )
            file_handler.setLevel(logging.DEBUG)
            file_handler.setFormatter(logging.Formatter(
                "%(asctime)s | %(levelname)s | %(message)s"
            ))
            logger.addHandler(file_handler)
        except Exception:
            # Logging must never prevent QGIS from loading the plugin.
            pass
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.WARNING)
        console_handler.setFormatter(logging.Formatter(
            "CRS Guardian: %(levelname)s: %(message)s"
        ))
        logger.addHandler(console_handler)
    _LOGGER = logger
    return logger


def log_exception(context, exc=None):
    """Log an exception with context and a complete traceback."""
    logger = get_logger()
    if exc is None:
        logger.exception(context)
    else:
        logger.error("%s: %s", context, exc)
        logger.debug("Exception traceback:\n%s", "".join(
            traceback.format_exception(type(exc), exc, exc.__traceback__)
        ))


def exception_message(exc, fallback="An unexpected error occurred."):
    """Create a compact, user-safe message from an exception."""
    try:
        message = str(exc).strip()
    except Exception:
        message = ""
    return message or fallback


def validate_layer(layer):
    """Return (valid, reason), guarding against deleted or broken QGIS objects."""
    if layer is None:
        return False, "The selected layer no longer exists."
    try:
        if not callable(getattr(layer, "isValid", None)):
            return False, "The selected object is not a valid QGIS map layer."
        if not layer.isValid():
            return False, "The layer is invalid or its data source is unavailable."
        layer.id()
        layer.name()
        layer.crs()
        return True, ""
    except RuntimeError as exc:
        return False, "The layer was removed or is no longer available: {}".format(exc)
    except Exception as exc:
        return False, "Could not validate the layer: {}".format(exc)


def show_error(parent, title, context, exc, logger_context=None):
    """Log an error and show a concise dialog without allowing UI failure to escape."""
    log_exception(logger_context or context, exc)
    try:
        from qgis.PyQt.QtWidgets import QMessageBox
        from .compat import enum_value, message_box_button
        details = exception_message(exc)
        box = QMessageBox(parent)
        box.setIcon(enum_value(QMessageBox, "Critical", "Icon"))
        box.setWindowTitle(title)
        box.setText(context)
        box.setInformativeText(details)
        box.setStandardButtons(message_box_button("Ok"))
        box.setStyleSheet("""
            QMessageBox, QDialog { background: #091423; color: #EEF3FC; }
            QLabel { color: #EEF3FC; background: transparent; }
            QPushButton { background: #172943; color: #F6D96F; border: 1px solid #8B742D;
                          border-radius: 7px; padding: 7px 16px; min-width: 82px; }
            QPushButton:hover { background: #293A52; border-color: #F6C945; }
        """)
        if os.name == "nt":
            try:
                import ctypes
                hwnd = ctypes.c_void_p(int(box.winId()))
                dwmapi = ctypes.WinDLL("dwmapi")
                setter = dwmapi.DwmSetWindowAttribute
                setter.restype = ctypes.c_long
                dark = ctypes.c_int(1)
                for attribute in (20, 19):
                    if setter(hwnd, ctypes.c_uint(attribute), ctypes.byref(dark), ctypes.sizeof(dark)) == 0:
                        break
            except Exception:
                get_logger().debug("Native dark message-box caption unavailable", exc_info=True)
        box.exec() if hasattr(box, "exec") else box.exec_()
    except Exception:
        get_logger().exception("Unable to display error dialog")
