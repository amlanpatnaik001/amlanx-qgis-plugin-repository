# CRS Guardian 2.4.0 — QGIS Plugin

![CRS Guardian emblem](brand_logo.png)

**CRS Guardian · Coordinate Systems Workspace**  
**AMLAN-X branded release · Version 2.4.0**

**AMLAN-X release branding, logo and release documentation © 2077 Amlan Patnaik. All rights reserved.**  
Original CRS Guardian plugin by **Lokesh Sahu**. Distributed under the existing **GPL-2.0-or-later** licence; see `LICENSE`.

## Overview

CRS Guardian is a project-wide CRS health checker and non-destructive reprojection assistant for QGIS. It audits vector, raster and mesh layer CRS health, flags missing or suspicious CRS assignments, geographic measurement risks and project CRS mismatches, and provides tools for assigning a known CRS or creating reprojected copies.

Version 2.4.0 introduces a new professional navy, blue and gold CRS emblem and places it consistently in the plugin icon, standalone window, sidebar and overview hero. The existing CRS workflows and processing behavior are retained.

## Workspaces and features

- **Overview:** automatic project scan, project CRS badge, layer diagnostics, and health metrics.
- **Diagnostics:** search by layer/finding and filter by Critical, Warning or Healthy status.
- **CSV reporting:** export current scan findings and explanatory details to UTF-8 CSV.
- **Assign CRS:** assign a known source CRS without changing coordinate values. Use only when the coordinates already match that CRS.
- **Reproject:** transform coordinate values into a new output copy; original layer sources are preserved.
- **Harmonize:** batch reproject supported vector and raster layers to an automatically suggested UTM CRS, project CRS or custom CRS.
- **Background processing:** uses QGIS Processing tasks and the task manager for reprojection.
- **Progress and cancellation:** shows progress, supports cancellation of queued work and requests cancellation of the active task.
- **Activity log:** records timestamped scan, assignment, reprojection, cancellation and completion events.
- **Safety:** collision-resistant output names, per-layer validation, partial-output cleanup, centralised logging and user-facing error reporting.

## Install from ZIP

1. Open QGIS.
2. Go to **Plugins → Manage and Install Plugins → Install from ZIP**.
3. Select `crs_guardian.2.4.0.zip`.
4. Enable **CRS Guardian** in the Installed tab if needed.
5. Open **Plugins → CRS Guardian** or click its toolbar icon. The plugin opens in a standalone window.

For manual installation, extract the `crs_guardian` folder into the active QGIS profile's `python/plugins` directory, then enable it in Plugin Manager.

## Usage

1. Open CRS Guardian. An initial project scan runs automatically.
2. In **Overview**, review health metrics and the diagnostics table.
3. Search by layer/finding or filter by severity.
4. Use **Export CSV** to save the current scan report.
5. Use **Assign CRS** only when the source coordinate values are already in the CRS being assigned.
6. Use **Reproject** when coordinate values must be transformed into a new copy.
7. In **Harmonize**, choose Auto UTM, project CRS or a custom CRS, then choose temporary or permanent output storage.
8. Review operations in **Activity log**.

## Safety notes

- A CRS suggestion is not proof that the source CRS is correct. Verify the source CRS before assigning anything.
- Auto UTM is a best-effort suggestion for geographically compact projects. Projects spanning UTM zones or large regions should use a deliberate custom projected CRS.
- Mesh layers are included in the audit but are not currently batch-reprojected.
- Reprojection tasks run through QGIS Processing. Provider-level operations may not be interruptible immediately; cancellation stops queued work and requests cancellation of the active task.
- QGIS layer and project updates are performed on the main thread after each task completes.
- Temporary output folders are cleaned when the project is cleared or QGIS exits where cleanup can run. Use a permanent output folder for data that must remain after the session.
- CSV export uses the current in-memory scan report and does not modify project data.

## Compatibility

Metadata declares **QGIS 3.16 through 4.99**. The plugin uses the `qgis.PyQt` abstraction and includes PyQt5/PyQt6 enum, QAction and dialog-execution compatibility helpers. Runtime compatibility still depends on the QGIS build and installed Processing providers, particularly GDAL. Test in each target QGIS installation before production use. QGIS 2.x is not supported.

## Development checks

Run from the directory containing `crs_guardian`:

```bash
python -m compileall -q crs_guardian
python -m unittest discover -s crs_guardian/tests -v
```

The test suite covers CRS detection and pure output-planning helpers. Full Processing/provider integration tests require a configured QGIS Python environment.

## Copyright, attribution and licence

**AMLAN-X release branding, logo, release documentation and adaptation contributions © 2077 Amlan Patnaik. All rights reserved.**

The original CRS Guardian software is attributed to **Lokesh Sahu**. The original `LICENSE` file is retained unchanged and continues to govern the original plugin code. These notices do not remove or override rights granted under GPL-2.0-or-later or third-party notices.
