# -*- coding: utf-8 -*-
"""Small Qt compatibility helpers for QGIS/PyQt5 and QGIS/PyQt6.

Always import Qt classes through qgis.PyQt so the plugin uses the Qt binding
shipped with the running QGIS installation.
"""


def enum_value(owner, scope_name, member_name):
    """Resolve a Qt5/Qt6 enum member across scoped and legacy enum APIs."""
    scope = getattr(owner, scope_name, None)
    if scope is not None:
        value = getattr(scope, member_name, None)
        if value is not None:
            return value
    return getattr(owner, member_name)


def exec_dialog(dialog):
    """Execute a modal dialog on Qt5 (exec_) and Qt6 (exec)."""
    execute = getattr(dialog, "exec", None)
    if not callable(execute):
        execute = getattr(dialog, "exec_", None)
    if not callable(execute):
        raise RuntimeError("This QGIS Qt binding does not expose QDialog.exec/exec_.")
    return execute()
