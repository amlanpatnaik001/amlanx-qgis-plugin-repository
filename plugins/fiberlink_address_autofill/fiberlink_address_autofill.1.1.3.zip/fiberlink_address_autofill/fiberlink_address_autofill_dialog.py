# -*- coding: utf-8 -*-
"""FiberLink Address AutoFill dialog. Author: Amlan Patnaik. Copyright (C) 2026 Amlan Patnaik."""

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QComboBox,
    QDoubleSpinBox, QCheckBox, QPushButton, QPlainTextEdit, QMessageBox,
    QGroupBox
)
from .qt_compat import enum_value, exec_dialog

from qgis.core import (
    QgsProject, QgsSpatialIndex, QgsGeometry, QgsPointXY, QgsRectangle,
    QgsFeature, QgsCoordinateTransform
)


class FiberLinkAddressAutoFillDialog(QDialog):
    """Dialog for populating Equipment.location from connected Sites."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("FiberLink Address AutoFill | © 2026 Amlan Patnaik")
        self.setMinimumWidth(610)
        self.setMinimumHeight(540)
        self.project = QgsProject.instance()
        self._build_ui()
        self._populate_layers()

    def _build_ui(self):
        root = QVBoxLayout(self)

        heading = QLabel("<b>FiberLink Address AutoFill</b>")
        heading.setStyleSheet("font-size: 16px;")
        root.addWidget(heading)
        root.addWidget(QLabel(
            "Populate Equipment locations from Sites connected by eligible Fibercable endpoints."
        ))

        layers_box = QGroupBox("Layer selection")
        form = QFormLayout(layers_box)
        self.sites_combo = QComboBox()
        self.fiber_combo = QComboBox()
        self.equipment_combo = QComboBox()
        form.addRow("Sites layer:", self.sites_combo)
        form.addRow("Fibercable layer:", self.fiber_combo)
        form.addRow("Equipment layer:", self.equipment_combo)
        root.addWidget(layers_box)

        options_box = QGroupBox("Processing options")
        options = QFormLayout(options_box)
        self.tolerance_spin = QDoubleSpinBox()
        self.tolerance_spin.setDecimals(3)
        self.tolerance_spin.setRange(0.0, 100000000.0)
        self.tolerance_spin.setValue(5.0)
        self.tolerance_spin.setSingleStep(1.0)
        options.addRow("Endpoint tolerance (Fibercable CRS units):", self.tolerance_spin)
        self.overwrite_check = QCheckBox("Overwrite existing location values")
        self.overwrite_check.setChecked(True)
        options.addRow("", self.overwrite_check)
        self.preview_check = QCheckBox("Preview only (do not modify data)")
        self.preview_check.setChecked(False)
        options.addRow("", self.preview_check)
        root.addWidget(options_box)

        root.addWidget(QLabel("Processing report:"))
        self.report = QPlainTextEdit()
        self.report.setReadOnly(True)
        self.report.setPlaceholderText("Click Run to see matching results and updates.")
        root.addWidget(self.report, 1)

        buttons = QHBoxLayout()
        self.run_button = QPushButton("Run")
        self.close_button = QPushButton("Close")
        buttons.addStretch(1)
        buttons.addWidget(self.run_button)
        buttons.addWidget(self.close_button)
        root.addLayout(buttons)

        author = QLabel("Author: Amlan Patnaik  |  © 2026 Amlan Patnaik. All rights reserved.")
        author.setWordWrap(True)
        author.setStyleSheet("color: #666; font-size: 9pt; padding-top: 3px;")
        root.addWidget(author)

        self.run_button.clicked.connect(self.process)
        self.close_button.clicked.connect(self.close)

    def _populate_layers(self):
        layers = list(self.project.mapLayers().values())
        for combo, preferred in (
            (self.sites_combo, "Sites"),
            (self.fiber_combo, "Fibercable"),
            (self.equipment_combo, "Equipment"),
        ):
            combo.clear()
            for layer in layers:
                if hasattr(layer, "fields"):
                    combo.addItem(layer.name(), layer.id())
            index = combo.findText(preferred)
            if index >= 0:
                combo.setCurrentIndex(index)

    def _log(self, message):
        self.report.appendPlainText(str(message))

    def _show_message(self, icon, title, message):
        """Show a plugin message with a visible author and copyright notice."""
        box = QMessageBox(self)
        box.setIcon(icon)
        box.setWindowTitle("{} | © 2026 Amlan Patnaik".format(title))
        box.setText(
            "{}\n\n© 2026 Amlan Patnaik. All rights reserved.".format(message)
        )
        box.setStandardButtons(enum_value(QMessageBox, "StandardButton", "Ok"))
        exec_dialog(box)

    def _get_layer(self, combo, role):
        layer_id = combo.currentData()
        layer = self.project.mapLayer(layer_id) if layer_id else None
        if layer is None or not layer.isValid():
            raise ValueError("Select a valid {} layer.".format(role))
        if not hasattr(layer, "fields"):
            raise ValueError("The selected {} layer is not a vector layer.".format(role))
        return layer

    @staticmethod
    def _field_index(layer, field_name):
        for i, field in enumerate(layer.fields()):
            if field.name().casefold() == field_name.casefold():
                return i
        available = ", ".join(field.name() for field in layer.fields())
        raise ValueError(
            "Required field {!r} was not found in layer {!r}. Available fields: {}"
            .format(field_name, layer.name(), available)
        )

    @staticmethod
    def _optional_field_index(layer, field_name):
        """Return a field index when present, or None when the field is absent."""
        for i, field in enumerate(layer.fields()):
            if field.name().casefold() == field_name.casefold():
                return i
        return None

    @staticmethod
    def _clean(value):
        if value is None:
            return ""
        value = str(value).strip()
        return "" if value.casefold() in ("null", "none") else value

    def _build_point_index(self, layer, fiber_crs, tolerance):
        spatial_index = QgsSpatialIndex()
        features = {}
        geometries = {}
        transform = None
        if layer.crs() != fiber_crs:
            transform = QgsCoordinateTransform(
                layer.crs(), fiber_crs, self.project.transformContext()
            )

        for feature in layer.getFeatures():
            if not feature.hasGeometry():
                continue
            geometry = QgsGeometry(feature.geometry())
            if geometry.isNull() or geometry.isEmpty():
                continue
            if transform is not None:
                result = geometry.transform(transform)
                result_value = getattr(result, "value", result)
                if result_value != 0:
                    self._log("WARNING: Could not transform {} feature {}."
                              .format(layer.name(), feature.id()))
                    continue
            features[feature.id()] = QgsFeature(feature)
            geometries[feature.id()] = geometry
            indexed_feature = QgsFeature(feature)
            indexed_feature.setGeometry(geometry)
            spatial_index.addFeature(indexed_feature)
        return spatial_index, features, geometries

    @staticmethod
    def _nearby_ids(endpoint, spatial_index, geometry_cache, tolerance):
        point = endpoint.asPoint()
        rect = QgsRectangle(
            point.x() - tolerance, point.y() - tolerance,
            point.x() + tolerance, point.y() + tolerance
        )
        found = []
        for feature_id in spatial_index.intersects(rect):
            geom = geometry_cache.get(feature_id)
            if geom is not None and geom.distance(endpoint) <= tolerance:
                found.append(feature_id)
        return found

    def process(self):
        self.report.clear()
        try:
            sites = self._get_layer(self.sites_combo, "Sites")
            fiber = self._get_layer(self.fiber_combo, "Fibercable")
            equipment = self._get_layer(self.equipment_combo, "Equipment")

            if fiber.crs().isGeographic():
                raise ValueError(
                    "The Fibercable layer uses a geographic CRS in degrees. "
                    "Use a suitable projected CRS before applying a distance tolerance."
                )

            house_idx = self._field_index(sites, "house_number")
            street_idx = self._field_index(sites, "street_name")

            # Client layers may expose either naming convention. Prefer checking
            # both when present so the second field can act as a true fallback.
            category_fields = []
            for field_name in ("cable_category", "category"):
                field_idx = self._optional_field_index(fiber, field_name)
                if field_idx is not None:
                    category_fields.append((field_name, field_idx))
            if not category_fields:
                available = ", ".join(field.name() for field in fiber.fields())
                raise ValueError(
                    "Neither 'cable_category' nor 'category' was found in layer {!r}. "
                    "Available fields: {}".format(fiber.name(), available)
                )

            size_idx = self._field_index(fiber, "size")
            location_idx = self._field_index(equipment, "location")
            tolerance = float(self.tolerance_spin.value())

            self._log("Category field(s) detected: {}".format(
                ", ".join(name for name, _ in category_fields)
            ))
            self._log("Building spatial indexes...")
            site_index, site_features, site_geometries = self._build_point_index(
                sites, fiber.crs(), tolerance
            )
            equipment_index, equipment_features, equipment_geometries = self._build_point_index(
                equipment, fiber.crs(), tolerance
            )
            all_equipment = {
                f.id(): QgsFeature(f) for f in equipment.getFeatures()
            }
            self._log("Sites indexed: {}".format(len(site_features)))
            self._log("Equipment points indexed: {}".format(len(equipment_features)))

            best_match = {}
            eligible_count = 0
            unmatched_count = 0

            for cable in fiber.getFeatures():
                if not cable.hasGeometry():
                    continue
                cable_geom = cable.geometry()
                if cable_geom.isNull() or cable_geom.isEmpty():
                    continue

                # Treat either field as a valid source. If both exist, a Drop
                # value in either one qualifies the cable; blank/null values in
                # one field do not block the other field from being used.
                category_values = [
                    self._clean(cable.attribute(field_idx)).casefold()
                    for _, field_idx in category_fields
                ]
                size_text = self._clean(cable.attribute(size_idx)).replace(",", "")
                try:
                    size_is_one = float(size_text) == 1.0
                except (ValueError, TypeError):
                    size_is_one = False
                if not ("drop" in category_values or size_is_one):
                    continue

                eligible_count += 1
                vertices = list(cable_geom.vertices())
                if len(vertices) < 2:
                    unmatched_count += 1
                    continue

                endpoints = [
                    QgsGeometry.fromPointXY(QgsPointXY(vertices[0])),
                    QgsGeometry.fromPointXY(QgsPointXY(vertices[-1]))
                ]
                sites_at = [
                    self._nearby_ids(ep, site_index, site_geometries, tolerance)
                    for ep in endpoints
                ]
                equipment_at = [
                    self._nearby_ids(ep, equipment_index, equipment_geometries, tolerance)
                    for ep in endpoints
                ]

                found_connection = False
                cable_length = cable_geom.length()
                for equipment_end in (0, 1):
                    site_end = 1 - equipment_end
                    for equipment_id in equipment_at[equipment_end]:
                        for site_id in sites_at[site_end]:
                            site_feature = site_features[site_id]
                            house = self._clean(site_feature.attribute(house_idx))
                            street = self._clean(site_feature.attribute(street_idx))
                            address = " ".join(part for part in (house, street) if part).strip()
                            if not address:
                                continue
                            found_connection = True
                            candidate = (cable_length, cable.id(), site_id, address)
                            previous = best_match.get(equipment_id)
                            if previous is None or candidate[:3] < previous[:3]:
                                best_match[equipment_id] = candidate
                if not found_connection:
                    unmatched_count += 1

            updates = []
            skipped_existing = 0
            for equipment_id, candidate in best_match.items():
                feature = all_equipment.get(equipment_id)
                if feature is None:
                    continue
                current = self._clean(feature.attribute(location_idx))
                if current and not self.overwrite_check.isChecked():
                    skipped_existing += 1
                    continue
                cable_length, cable_id, site_id, address = candidate
                if current == address:
                    continue
                updates.append({
                    "equipment_id": equipment_id,
                    "site_id": site_id,
                    "cable_id": cable_id,
                    "length": cable_length,
                    "old": current,
                    "address": address,
                })

            self._log("")
            self._log("Eligible cables (Drop OR size = 1): {}".format(eligible_count))
            self._log("Equipment matched to Sites: {}".format(len(best_match)))
            self._log("Eligible cables without usable connection: {}".format(unmatched_count))
            self._log("Existing values skipped: {}".format(skipped_existing))
            self._log("Location values to change: {}".format(len(updates)))
            for item in updates:
                self._log(
                    "Equipment {} | Site {} | Cable {} | Old={!r} | New={}".format(
                        item["equipment_id"], item["site_id"], item["cable_id"],
                        item["old"], item["address"]
                    )
                )

            if self.preview_check.isChecked():
                self._log("")
                self._log("PREVIEW ONLY: no data was modified.")
                return
            if not updates:
                self._log("No Equipment location changes are required.")
                return

            already_editable = equipment.isEditable()
            if not already_editable and not equipment.startEditing():
                raise RuntimeError("Could not start editing the Equipment layer.")

            successful = 0
            failed = 0
            for item in updates:
                if equipment.changeAttributeValue(
                    item["equipment_id"], location_idx, item["address"]
                ):
                    successful += 1
                else:
                    failed += 1
                    self._log("FAILED to update Equipment feature {}."
                              .format(item["equipment_id"]))

            self._log("")
            self._log("Successful changes queued: {}".format(successful))
            self._log("Failed changes: {}".format(failed))
            if already_editable:
                self._log(
                    "Equipment was already in edit mode. Review and save edits in QGIS."
                )
            elif equipment.commitChanges():
                self._log("Changes saved successfully.")
            else:
                self._log("COMMIT FAILED. Review the layer's edit state and QGIS messages.")
                for error in equipment.commitErrors():
                    self._log(error)

        except Exception as exc:
            self._log("ERROR: {}".format(exc))
            self._show_message(
                enum_value(QMessageBox, "Icon", "Critical"),
                "FiberLink Address AutoFill",
                "Processing failed:\n{}".format(exc),
            )
