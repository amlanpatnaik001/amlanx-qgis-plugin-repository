FiberLink Address AutoFill
Version: 1.1.3
Author: Amlan Patnaik

Overview
--------
Automatically populates the Equipment layer's location field by matching Sites to eligible Fibercable endpoints.

Layer and field requirements
----------------------------
- Sites: house_number and street_name
- Fibercable: size and at least one of cable_category or category
- Equipment: location

Cable eligibility
-----------------
A cable qualifies when either detected category field contains the Drop value, or its size is 1. If both category fields exist, a Drop value in either one is accepted; a blank value in one field does not block the other field.

Qt / QGIS compatibility
-----------------------
The plugin imports Qt classes through QGIS's qgis.PyQt compatibility layer and includes runtime helpers for Qt5/PyQt5 and Qt6/PyQt6 differences (QAction location, modal dialog execution, and QMessageBox enums). QGIS supplies the matching Qt/PyQt binding; do not install or substitute a separate PyQt package into the QGIS Python environment.

The metadata declares QGIS 3.x through 4.x (qgisMaximumVersion=4.99). Compatibility should still be checked on the specific QGIS builds and operating systems used in production; source-level checks are not a substitute for running QGIS 3 and QGIS 4 tests.

Coordinate reference system
---------------------------
Use a projected coordinate reference system for the Fibercable layer. The plugin rejects a geographic CRS because its distance tolerance is expressed in map units.

Installation
------------
Install the ZIP through QGIS Plugin Manager's Install from ZIP option, or add the AMLAN-X repository URL to QGIS Plugin Manager and install FiberLink Address AutoFill from the available plugins.

Release notes
-------------
1.1.3: Added Qt5/PyQt5 and Qt6/PyQt6 compatibility helpers for QAction, modal dialog execution, and QMessageBox enums; declared QGIS 4.x compatibility in metadata.
1.1.2: Added compatibility with either cable_category or category, including fallback when one field is blank.

Copyright and license
---------------------
Copyright (C) 2026 Amlan Patnaik. Source files contain the applicable GNU General Public License notice.
