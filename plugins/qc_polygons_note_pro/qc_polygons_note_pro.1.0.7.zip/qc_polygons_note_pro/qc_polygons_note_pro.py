import os
import re
from datetime import datetime

# QAction moved from QtWidgets (Qt 5 / PyQt5) to QtGui (Qt 6 / PyQt6).
# Import through QGIS' compatibility layer so the same plugin source can run
# in QGIS 3 and QGIS 4 environments.
try:
    from qgis.PyQt.QtGui import QAction
except ImportError:  # QGIS 3 / PyQt5
    from qgis.PyQt.QtWidgets import QAction

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import (
    QgsCoordinateTransform,
    QgsFeatureRequest,
    QgsGeometry,
    QgsMapLayer,
    QgsProject,
    QgsWkbTypes,
    Qgis,
)

# QGIS 4 uses scoped enum paths. Keep fallbacks for QGIS 3 releases where
# only the older enum aliases are exposed.
try:
    _VECTOR_LAYER_TYPE = QgsMapLayer.LayerType.VectorLayer
except AttributeError:  # Older QGIS 3
    from qgis.core import QgsMapLayerType
    _VECTOR_LAYER_TYPE = QgsMapLayerType.VectorLayer

# GeometryType moved to Qgis in newer PyQGIS APIs. QGIS 3.30+
# exposes the scoped QgsWkbTypes.GeometryType.Polygon alias, while older
# QGIS 3 releases expose QgsWkbTypes.PolygonGeometry.
try:
    _POLYGON_GEOMETRY = Qgis.GeometryType.Polygon
except AttributeError:
    try:
        _POLYGON_GEOMETRY = QgsWkbTypes.GeometryType.Polygon
    except AttributeError:
        _POLYGON_GEOMETRY = QgsWkbTypes.PolygonGeometry

from .address_engine import format_site_records
from .fiber_parser import parse_fiber_range, to_int_or_none
from .note_helpers import build_qc_comment, extract_job_from_comment


# ---------------------------------------------------------------------------
# CONFIGURATION
# Layer names and field names are matched case-insensitively.
# Service addresses come from Sites; the HH address comes from Equipment;
# reserved fiber range comes only from Slack loop.rsv_counts.
# ---------------------------------------------------------------------------
QC_POLYGON_LAYER_NAMES = ("QC Polygons",)
FDA_BOUNDARY_LAYER_NAMES = ("FDA Boundaries",)
SITES_LAYER_NAMES = ("Sites",)
EQUIPMENT_LAYER_NAMES = ("Equipment",)
SLACK_LOOP_LAYER_NAMES = ("Slack loop", "Slackloop", "Slack Loop")
RSV_COUNTS_FIELD = "rsv_counts"
EQUIPMENT_HH_ADDRESS_FIELD_CANDIDATES = (
    "location", "address", "hh_address", "handhole_address",
)

# Generated wording follows the existing QC Polygons comments in the supplied table.
HOUSE_NUMBER_FIELD_CANDIDATES = ("house_number",)
STREET_NAME_FIELD_CANDIDATES = ("street_name",)
JOB_FIELD_CANDIDATES = (
    "job", "job_id", "job_ref", "job_reference", "fiber_ref",
    "fiber_reference", "project_id", "plan_id", "work_order", "infinium_id",
    "cable_name", "cable_id", "cable_ref", "cable_reference", "cable",
    "fiber_cable", "fiber_cable_name", "fiber_cable_id", "rsv_name", "rsv_id",
)
COMMENT_FIELD_CANDIDATES = ("comments", "comment", "notes", "note")
FIBER_COUNT_CANDIDATES = (
    "fiber_count", "fibre_count", "fiber_counts", "fibre_counts",
    "rsv_count", "reserved_fiber_count", "reserved_fibers", "count",
)


COPYRIGHT_NOTICE = "Copyright © Amlan Patnaik @2077 — All copyrights are reserved."

def _copyright_message_box(method, *args, **kwargs):
    """Append the copyright footer to every QMessageBox prompt/dialog."""
    args = list(args)
    if len(args) >= 3 and isinstance(args[2], str):
        if COPYRIGHT_NOTICE not in args[2]:
            args[2] = args[2].rstrip() + "\n\n" + COPYRIGHT_NOTICE
    elif "text" in kwargs and isinstance(kwargs["text"], str):
        if COPYRIGHT_NOTICE not in kwargs["text"]:
            kwargs["text"] = kwargs["text"].rstrip() + "\n\n" + COPYRIGHT_NOTICE
    return method(*args, **kwargs)


class QCPolygonsNotePro:
    """Plugin Builder-style plugin with an action and no custom dialog/form."""

    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        # Load the icon from the plugin folder (no compiled Qt resources needed).
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        self.action = QAction(
            QIcon(icon_path),
            "Generate QC Polygon Notes",
            self.iface.mainWindow(),
        )
        self.action.setToolTip(
            "Generate telecom notes from selected QC Polygons, Sites, and Slack loop data"
        )
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&QC Polygons Note Pro", self.action)

    def unload(self):
        if self.action is not None:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&QC Polygons Note Pro", self.action)
            self.action = None

    def run(self):
        project = QgsProject.instance()
        qc_layer = self._find_layer(QC_POLYGON_LAYER_NAMES)
        fda_layer = self._find_layer(FDA_BOUNDARY_LAYER_NAMES)
        sites_layer = self._find_layer(SITES_LAYER_NAMES)
        equipment_layer = self._find_layer(EQUIPMENT_LAYER_NAMES)
        slack_layer = self._find_layer(SLACK_LOOP_LAYER_NAMES)

        missing = []
        if qc_layer is None:
            missing.append("QC Polygons")
        if fda_layer is None:
            missing.append("FDA Boundaries")
        if sites_layer is None:
            missing.append("Sites")
        if equipment_layer is None:
            missing.append("Equipment")
        if slack_layer is None:
            missing.append("Slack loop")
        if missing:
            _copyright_message_box(QMessageBox.warning, 
                self.iface.mainWindow(),
                "QC Polygons Note Pro",
                "Required layer(s) not found: {}.\n\n"
                "Check the layer names in the Layers panel or update the aliases "
                "at the top of qc_polygons_note_pro.py.".format(", ".join(missing)),
            )
            return

        if qc_layer.type() != _VECTOR_LAYER_TYPE or (
            qc_layer.geometryType() != _POLYGON_GEOMETRY
        ):
            _copyright_message_box(QMessageBox.warning, 
                self.iface.mainWindow(),
                "QC Polygons Note Pro",
                "'QC Polygons' must be a polygon vector layer.",
            )
            return

        selected_polygons = qc_layer.selectedFeatures()
        if not selected_polygons:
            _copyright_message_box(QMessageBox.information, 
                self.iface.mainWindow(),
                "Select QC Polygons",
                "Select one or more features in the 'QC Polygons' layer first, "
                "then run Generate QC Polygon Notes again.\n\n"
                "Only selected QC polygons will be processed.",
            )
            return

        infinium_field = self._detect_field(fda_layer, ("infinium_id",))
        if not infinium_field:
            _copyright_message_box(QMessageBox.warning, 
                self.iface.mainWindow(),
                "Infinium ID field not found",
                "The 'FDA Boundaries' layer must contain an 'infinium_id' field.\n\n"
                "Available fields:\n{}".format(", ".join(f.name() for f in fda_layer.fields())),
            )
            return

        # Address extraction uses only the two authoritative Sites fields.
        # The exact street_name value is the grouping key.
        house_number_field = self._detect_field(sites_layer, HOUSE_NUMBER_FIELD_CANDIDATES)
        street_name_field = self._detect_field(sites_layer, STREET_NAME_FIELD_CANDIDATES)

        if not house_number_field or not street_name_field:
            _copyright_message_box(QMessageBox.warning, 
                self.iface.mainWindow(),
                "Sites address fields not found",
                "The Sites layer must contain both 'house_number' and 'street_name' fields.\\n\\n"
                "Available fields:\\n{}".format(", ".join(f.name() for f in sites_layer.fields())),
            )
            return

        equipment_hh_address_field = self._detect_field(
            equipment_layer, EQUIPMENT_HH_ADDRESS_FIELD_CANDIDATES
        )
        if not equipment_hh_address_field:
            _copyright_message_box(QMessageBox.warning,
                self.iface.mainWindow(),
                "Equipment HH address field not found",
                "The Equipment layer must contain a 'location' or 'address' field.\n\n"
                "Available fields:\n{}".format(
                    ", ".join(f.name() for f in equipment_layer.fields())
                ),
            )
            return

        rsv_field = self._detect_field(slack_layer, (RSV_COUNTS_FIELD,))
        if not rsv_field:
            _copyright_message_box(QMessageBox.warning, 
                self.iface.mainWindow(),
                "rsv_counts field not found",
                "The 'Slack loop' layer must contain the field 'rsv_counts'.\n\n"
                "Available fields:\n{}".format(", ".join(f.name() for f in slack_layer.fields())),
            )
            return

        comments_field = self._detect_field(qc_layer, COMMENT_FIELD_CANDIDATES)
        if not comments_field:
            _copyright_message_box(QMessageBox.warning, 
                self.iface.mainWindow(),
                "Comments field not found",
                "The QC Polygons layer has no comments field. Notes can still be generated "
                "and copied, but they cannot be written back to each polygon until a comments field exists.",
            )

        notes = []
        notes_by_polygon = {}
        warnings = []
        processed_polygons = 0
        matched_sites = 0
        matched_slack = 0

        for polygon_feature in selected_polygons:
            polygon_geometry = polygon_feature.geometry()
            if polygon_geometry is None or polygon_geometry.isNull() or polygon_geometry.isEmpty():
                warnings.append("QC polygon feature {} has empty geometry.".format(polygon_feature.id()))
                continue

            processed_polygons += 1
            boundary_features = self._features_intersecting_polygon(
                fda_layer, polygon_geometry, qc_layer, project
            )
            infinium_ref = ""
            for boundary_feature in boundary_features:
                raw_infinium = self._read_feature_field(boundary_feature, infinium_field)
                # IDs commonly end in H#### (for example, 6012834-H6005).
                match = re.search(r"\b(H\d+)\s*$", raw_infinium, re.IGNORECASE)
                if not match:
                    match = re.search(r"\b(H\d+)\b", raw_infinium, re.IGNORECASE)
                if match:
                    infinium_ref = match.group(1).upper()
                    break
            if not infinium_ref:
                warnings.append(
                    "QC polygon {}: no H-number (such as H6005) could be extracted from "
                    "the intersecting FDA Boundaries feature's infinium_id; skipped.".format(
                        polygon_feature.id()
                    )
                )
                continue

            sites = self._features_intersecting_polygon(
                sites_layer, polygon_geometry, qc_layer, project
            )
            site_address_records = []
            for site in sites:
                house_number = self._read_feature_field(site, house_number_field)
                street_name = self._read_feature_field_raw(site, street_name_field)
                if self._has_field_value(house_number) and self._has_field_value(street_name):
                    site_address_records.append((house_number, street_name))
                elif self._has_field_value(house_number) or self._has_field_value(street_name):
                    warnings.append(
                        "QC polygon {}: Sites feature {} has only one address component "
                        "populated (house_number={!r}, street_name={!r}); skipped.".format(
                            polygon_feature.id(), site.id(), house_number, street_name
                        )
                    )
            # Use the Equipment address only when an Equipment feature intersects
            # this QC polygon. Keep it blank if no populated location/address is found.
            equipment_features = self._features_intersecting_polygon(
                equipment_layer, polygon_geometry, qc_layer, project
            )
            handhole = ""
            for equipment_feature in equipment_features:
                candidate_address = self._read_feature_field(
                    equipment_feature, equipment_hh_address_field
                )
                if candidate_address:
                    handhole = candidate_address
                    break

            matched_sites += len(site_address_records)
            grouped_addresses = format_site_records(site_address_records)
            if not grouped_addresses:
                warnings.append(
                    "QC polygon {}: no valid Sites addresses found inside this polygon.".format(
                        polygon_feature.id()
                    )
                )
                continue

            slack_features = self._features_intersecting_polygon(
                slack_layer, polygon_geometry, qc_layer, project
            )
            if not slack_features:
                warnings.append(
                    "QC polygon {}: no Slack loop features intersect this polygon.".format(
                        polygon_feature.id()
                    )
                )
                continue

            existing_comment = self._read_feature_field(polygon_feature, comments_field)
            job = self._feature_value(polygon_feature, qc_layer, JOB_FIELD_CANDIDATES)
            if not job:
                job = extract_job_from_comment(existing_comment)

            for slack_feature in slack_features:
                rsv_value = slack_feature[rsv_field]
                start, end, range_error = self._resolve_fiber_range(
                    slack_feature, slack_layer, rsv_value
                )
                if start is None or end is None:
                    warnings.append(
                        "QC polygon {}, Slack loop feature {}: {}. rsv_counts={!r}".format(
                            polygon_feature.id(), slack_feature.id(), range_error, rsv_value
                        )
                    )
                    continue

                if self._to_int(start) is not None and self._to_int(end) is not None:
                    if int(start) > int(end):
                        warnings.append(
                            "QC polygon {}, Slack loop feature {}: fiber start {} exceeds fiber end {}; skipped.".format(
                                polygon_feature.id(), slack_feature.id(), start, end
                            )
                        )
                        continue

                note_job = job or self._feature_value(
                    slack_feature, slack_layer, JOB_FIELD_CANDIDATES
                )
                if not note_job:
                    note_job = "QC-{}".format(polygon_feature.id())
                    warnings.append(
                        "QC polygon {}: no job/fiber reference field or existing comment "
                        "reference was found; note uses {}. Update JOB_FIELD_CANDIDATES if needed.".format(
                            polygon_feature.id(), note_job
                        )
                    )

                # `handhole` was resolved from Equipment for this polygon. It remains
                # blank when no Equipment feature with an address was found.

                note = build_qc_comment(
                    addresses=grouped_addresses,
                    infinium_ref=infinium_ref,
                    start=start,
                    end=end,
                    handhole=handhole,
                )
                notes.append({
                    "qc_fid": polygon_feature.id(),
                    "slack_fid": slack_feature.id(),
                    "addresses": grouped_addresses,
                    "job": str(infinium_ref).strip(),
                    "start": str(start).strip(),
                    "end": str(end).strip(),
                    "handhole": str(handhole).strip(),
                    "note": note,
                    "fiber_count": self._fiber_count(slack_feature, slack_layer, start, end),
                })
                notes_by_polygon.setdefault(polygon_feature.id(), []).append(note)
                matched_slack += 1

        if not notes:
            details = "\n".join(warnings[:18]) or "No matching address/slack-loop data was found."
            _copyright_message_box(QMessageBox.warning, 
                self.iface.mainWindow(),
                "No notes generated",
                "No complete telecom notes could be generated.\n\n{}".format(details),
            )
            return

        combined = "\n\n".join(item["note"] for item in notes)
        # QGIS runs under Qt; use QApplication clipboard.
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.clipboard().setText(combined)

        summary = (
            "Generated {} note(s) for {} selected QC polygon(s).\n"
            "Sites address values matched: {}\n"
            "Slack loop features with usable fiber ranges: {}\n"
            "Notes copied to the clipboard."
        ).format(len(notes), processed_polygons, matched_sites, matched_slack)
        # Optional write-back: explicit confirmation before overwriting existing comments.
        if comments_field:
            write_answer = _copyright_message_box(QMessageBox.question, 
                self.iface.mainWindow(),
                "Update QC Polygons comments?",
                "Write the generated note(s) into the 'comments' field of the selected QC Polygons?\n\n"
                "Existing comments for polygons with generated notes will be replaced.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if write_answer == QMessageBox.StandardButton.Yes:
                self._write_polygon_comments(
                    qc_layer, selected_polygons, comments_field, notes_by_polygon
                )

        if warnings:
            summary += "\n\nWarnings: {}\n{}".format(len(warnings), "\n".join(warnings[:10]))
            if len(warnings) > 10:
                summary += "\n...and {} more warning(s).".format(len(warnings) - 10)

        answer = _copyright_message_box(QMessageBox.question, 
            self.iface.mainWindow(),
            "QC Polygons Note Pro",
            summary + "\n\nSave the generated notes to a text file as well?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        if answer == QMessageBox.StandardButton.Yes:
            default_name = "QC_Polygons_Notes_{}.txt".format(
                datetime.now().strftime("%Y%m%d_%H%M%S")
            )
            path, _ = QFileDialog.getSaveFileName(
                self.iface.mainWindow(),
                "Save QC Polygon Notes — Copyright © Amlan Patnaik @2077",
                default_name,
                "Text files (*.txt);;CSV files (*.csv)",
            )
            if path:
                try:
                    if path.lower().endswith(".csv"):
                        import csv
                        with open(path, "w", newline="", encoding="utf-8-sig") as handle:
                            writer = csv.writer(handle)
                            writer.writerow([
                                "qc_polygon_fid", "slack_loop_fid", "job_reference",
                                "fiber_start", "fiber_end", "fiber_count", "handhole",
                                "grouped_addresses", "note",
                            ])
                            for item in notes:
                                writer.writerow([
                                    item["qc_fid"], item["slack_fid"], item["job"],
                                    item["start"], item["end"], item["fiber_count"],
                                    item["handhole"], item["addresses"], item["note"],
                                ])
                    else:
                        with open(path, "w", encoding="utf-8") as handle:
                            handle.write(combined + "\n")
                    _copyright_message_box(QMessageBox.information, 
                        self.iface.mainWindow(),
                        "QC Polygons Note Pro",
                        "Saved {} note(s) to:\n{}".format(len(notes), path),
                    )
                except OSError as exc:
                    _copyright_message_box(QMessageBox.critical, 
                        self.iface.mainWindow(), "Save error", str(exc)
                    )
        else:
            _copyright_message_box(QMessageBox.information, 
                self.iface.mainWindow(),
                "QC Polygons Note Pro",
                "Notes are ready on the clipboard. Paste them where needed.",
            )

    def _write_polygon_comments(self, qc_layer, selected_polygons, comments_field, notes_by_polygon):
        field_index = qc_layer.fields().indexFromName(comments_field)
        if field_index < 0:
            _copyright_message_box(QMessageBox.warning, 
                self.iface.mainWindow(),
                "Comments field unavailable",
                "The comments field could not be found; no attributes were changed.",
            )
            return

        if not qc_layer.isEditable() and not qc_layer.startEditing():
            _copyright_message_box(QMessageBox.critical, 
                self.iface.mainWindow(),
                "Cannot edit QC Polygons",
                "QGIS could not start editing the QC Polygons layer. Check layer permissions and data source.",
            )
            return

        changed = 0
        for polygon_feature in selected_polygons:
            generated = notes_by_polygon.get(polygon_feature.id())
            if not generated:
                continue
            value = "\\n".join(generated)
            if qc_layer.changeAttributeValue(polygon_feature.id(), field_index, value):
                changed += 1

        if changed == 0:
            _copyright_message_box(QMessageBox.warning, 
                self.iface.mainWindow(),
                "No comments changed",
                "No QC Polygons comments were updated.",
            )
            return

        answer = _copyright_message_box(QMessageBox.question, 
            self.iface.mainWindow(),
            "Save QC Polygons edits?",
            "Updated comments for {} polygon(s) in the edit buffer. Save these changes to the data source now?".format(changed),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        if answer == QMessageBox.StandardButton.Yes:
            if qc_layer.commitChanges():
                _copyright_message_box(QMessageBox.information, 
                    self.iface.mainWindow(),
                    "Comments updated",
                    "Successfully saved comments for {} QC polygon(s).".format(changed),
                )
            else:
                errors = "\\n".join(qc_layer.commitErrors()) if hasattr(qc_layer, "commitErrors") else "Unknown commit error"
                _copyright_message_box(QMessageBox.critical, 
                    self.iface.mainWindow(),
                    "Commit failed",
                    "QGIS could not save the comments. The layer may still have pending edits.\\n\\n{}".format(errors),
                )
        else:
            _copyright_message_box(QMessageBox.information, 
                self.iface.mainWindow(),
                "Comments pending",
                "Changes remain in the QGIS edit buffer and have not been saved to the data source.",
            )

    def _find_layer(self, names):
        wanted = {self._norm(name) for name in names}
        for layer in QgsProject.instance().mapLayers().values():
            if layer.name() and self._norm(layer.name()) in wanted:
                return layer
        return None

    @staticmethod
    def _norm(value):
        return re.sub(r"[^a-z0-9]+", "", str(value or "").strip().lower())

    def _detect_field(self, layer, candidates):
        fields = {self._norm(field.name()): field.name() for field in layer.fields()}
        for candidate in candidates:
            if candidate and self._norm(candidate) in fields:
                return fields[self._norm(candidate)]
        # For address fields, fall back to a field containing 'address'.
        if any(self._norm(c) == "address" for c in candidates if c):
            for field in layer.fields():
                name = self._norm(field.name())
                if "address" in name and not name.endswith("type"):
                    return field.name()
        return None

    def _features_intersecting_polygon(self, source_layer, polygon_geometry, qc_layer, project):
        """Return source features spatially intersecting a QC polygon, with CRS transforms."""
        try:
            qc_to_source = QgsCoordinateTransform(
                qc_layer.crs(), source_layer.crs(), project
            )
            source_to_qc = QgsCoordinateTransform(
                source_layer.crs(), qc_layer.crs(), project
            )
            search_geometry = QgsGeometry(polygon_geometry)
            if qc_layer.crs() != source_layer.crs():
                search_geometry.transform(qc_to_source)
            request = QgsFeatureRequest().setFilterRect(search_geometry.boundingBox())
        except Exception:
            # Fallback without a bounding-box request if a transform is unavailable.
            source_to_qc = QgsCoordinateTransform(
                source_layer.crs(), qc_layer.crs(), project
            )
            request = QgsFeatureRequest()

        matched = []
        for feature in source_layer.getFeatures(request):
            geometry = feature.geometry()
            if geometry is None or geometry.isNull() or geometry.isEmpty():
                continue
            try:
                if source_layer.crs() != qc_layer.crs():
                    geometry = QgsGeometry(geometry)
                    geometry.transform(source_to_qc)
                if geometry.intersects(polygon_geometry):
                    matched.append(feature)
            except Exception:
                continue
        return matched

    @staticmethod
    def _has_field_value(value):
        if value is None:
            return False
        text = str(value)
        return bool(text.strip()) and text.strip().lower() not in ("null", "none", "nan")

    @staticmethod
    def _read_feature_field_raw(feature, field_name):
        """Read a field without trimming it; street_name values are literal group keys."""
        if not field_name:
            return None
        try:
            return feature[field_name]
        except Exception:
            return None

    @staticmethod
    def _read_feature_field(feature, field_name):
        if not field_name:
            return ""
        try:
            value = feature[field_name]
        except Exception:
            return ""
        if value is None:
            return ""
        value = str(value).strip()
        if not value or value.lower() in ("null", "none", "nan"):
            return ""
        return value

    def _feature_value(self, feature, layer, candidates):
        # Try candidates in priority order and continue past empty fields.
        field_map = {self._norm(field.name()): field.name() for field in layer.fields()}
        for candidate in candidates:
            field_name = field_map.get(self._norm(candidate)) if candidate else None
            if not field_name:
                continue
            try:
                value = feature[field_name]
            except Exception:
                continue
            if value is None:
                continue
            value = str(value).strip()
            if value and value.lower() not in ("null", "none", "nan"):
                return value
        return ""

    @staticmethod
    def _to_int(value):
        """Convert a value to int, returning None instead of raising on invalid input."""
        return to_int_or_none(value)

    def _resolve_fiber_range(self, feature, layer, rsv_value):
        """Read the reserved fiber interval from Slack loop.rsv_counts only."""
        start, end = self._parse_range(rsv_value)
        if start and end:
            return start, end, ""
        return None, None, (
            "could not parse a fiber range from Slack loop.rsv_counts; store a range "
            "such as '86-87' in rsv_counts"
        )

    @staticmethod
    def _parse_range(value):
        return parse_fiber_range(value)

    def _fiber_count(self, feature, layer, start, end):
        count = self._feature_value(feature, layer, FIBER_COUNT_CANDIDATES)
        if count:
            return count
        try:
            start_i = int(start)
            end_i = int(end)
            if end_i >= start_i:
                return str(end_i - start_i + 1)
        except (ValueError, TypeError):
            pass
        return ""
