QC POLYGONS NOTE PRO v1.0.7
Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.

OVERVIEW
Generate future-reserve notes for selected QC Polygons using authoritative data
from FDA Boundaries, Sites, Equipment, and Slack loop layers.

VERSION 1.0.7
- Updated polygon geometry enum resolution for current QGIS 4 / PyQt6 APIs.
- Retained compatibility fallbacks for QGIS 3.28 and later QGIS 3 releases.
- Added a multiline metadata changelog for display in QGIS Plugin Manager.
- Added release documentation and copyright coverage.
- Preserved all note-generation and data-processing logic.

VERSION 1.0.6
- Added Qt 5 / Qt 6 QAction import compatibility.
- Added QGIS 3 / QGIS 4 layer and geometry enum compatibility.
- Added a technical toolbar icon while keeping the action text.

DATA SOURCES
- QC Polygons: Select one or more polygons to process.
- FDA Boundaries: infinium_id supplies the H-number (for example, H3133).
- Sites: house_number and street_name supply service addresses. Grouping is by
  exact street_name value and each Site record is preserved.
- Equipment: location, address, hh_address, or handhole_address supplies the
  handhole address when an Equipment feature intersects the QC polygon.
- Slack loop: rsv_counts supplies the reserved fiber range.

WORKFLOW
1. Load the required layers into the QGIS project.
2. Select the QC Polygons features to process.
3. Run Plugins > QC Polygons Note Pro > Generate QC Polygon Notes.
4. Review generated notes and warnings.
5. Copy generated notes or confirm optional write-back to the comments field.

REQUIREMENTS
- QGIS 3.28 through QGIS 4.x (maximum declared version 4.99).
- Uses QGIS-provided qgis.PyQt abstraction for Qt compatibility.
- Uses QGIS/PyQGIS APIs bundled with the active QGIS installation.

INSTALLATION
Install through the AMLAN-X QGIS Plugin Repository or use Plugin Manager >
Install from ZIP.

COMPATIBILITY NOTE
The package includes Qt5/Qt6 QAction import handling and QGIS legacy/scoped
enum fallbacks. The release targets QGIS 3.28+ and QGIS 4.x; a successful
package check is not a substitute for testing inside each QGIS installation.

CHANGELOG
See CHANGELOG.md or the changelog in metadata.txt. QGIS Plugin Manager reads
the changelog from the repository XML feed.

COPYRIGHT
Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.
