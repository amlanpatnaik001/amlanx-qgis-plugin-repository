# Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.
import re

# Format matched from the existing QC Polygons comments supplied by the user.
QC_COMMENT_TEMPLATE = (
    "FUTURE RESERVE - PRIVATE PROPERTY. {infinium_ref}, {start}-{end} "
    "RESERVED IN HH AT {handhole} FOR ADDRESSES {addresses}."
)

REFERENCE_RE = re.compile(
    r"\b(?:RESERVED\s+)?FIBERS?\s+([^,\r\n]+?)\s*,\s*\d+\s*(?:-|–|—|to|thru|through)\s*\d+",
    re.IGNORECASE,
)
HANDHOLE_RE = re.compile(r"\bLeft\s+in\s+slack\s+loop\s+at\s+HH\s+(.+?)\s*$", re.IGNORECASE)


def build_qc_comment(addresses, infinium_ref, start, end, handhole):
    """Format one future-reserve note in the required QC Polygons style."""
    values = {
        "addresses": str(addresses or "").strip(),
        "infinium_ref": str(infinium_ref or "").strip().upper(),
        "start": str(start or "").strip(),
        "end": str(end or "").strip(),
        "handhole": str(handhole or "").strip().upper(),
    }
    # The HH address is optional: no matching Equipment feature means the value
    # after "AT" is deliberately left blank.
    missing = [key for key, value in values.items() if not value and key != "handhole"]
    if missing:
        raise ValueError("Missing note values: {}".format(", ".join(missing)))
    return QC_COMMENT_TEMPLATE.format(**values)


def extract_job_from_comment(comment):
    """Reuse the job/fiber reference from an existing QC comment, if present."""
    match = REFERENCE_RE.search(str(comment or ""))
    return match.group(1).strip() if match else ""


def extract_handhole_from_comment(comment):
    """Reuse the HH location from an existing QC comment, if present."""
    match = HANDHOLE_RE.search(str(comment or ""))
    return match.group(1).strip() if match else ""
