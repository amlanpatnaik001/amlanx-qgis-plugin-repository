# Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.
import re

RANGE_RE = re.compile(
    r"(?<!\d)(\d+)\s*(?:-|–|—|to|thru|through)\s*(\d+)(?!\d)",
    re.IGNORECASE,
)
START_LABEL_RE = re.compile(
    r"(?:fiber[\s_-]*)?start\D{0,12}(\d+)", re.IGNORECASE
)
END_LABEL_RE = re.compile(
    r"(?:fiber[\s_-]*)?end\D{0,12}(\d+)", re.IGNORECASE
)


def parse_fiber_range(value):
    """Parse a fiber start/end range from strings such as '78-82' or 'start=78 end=82'.

    A single numeric rsv_counts value is intentionally not treated as a range.
    """
    if value is None:
        return None, None
    text = str(value).strip()
    if not text or text.lower() in ("null", "none", "nan"):
        return None, None

    match = RANGE_RE.search(text)
    if match:
        return match.group(1), match.group(2)

    start_match = START_LABEL_RE.search(text)
    end_match = END_LABEL_RE.search(text)
    if start_match and end_match:
        return start_match.group(1), end_match.group(1)

    return None, None


def to_int_or_none(value):
    """Return an integer for an integer-like value, or None when it is not valid."""
    try:
        text = str(value).strip()
        if not text:
            return None
        return int(text)
    except (TypeError, ValueError):
        return None
