# Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.
import re

STREET_TYPES = {
    "ST", "STREET", "AVE", "AV", "AVENUE", "RD", "ROAD", "DR", "DRIVE",
    "PL", "PLACE", "CT", "COURT", "LN", "LANE", "WAY", "TER", "TERRACE",
    "CIR", "CIRCLE", "BLVD", "BOULEVARD", "PKWY", "PARKWAY", "TRL", "TRAIL",
    "HWY", "HIGHWAY", "PKE", "PIKE", "LOOP", "PASS", "PATH", "PT", "POINT",
    "SQ", "SQUARE", "ALY", "ALLEY", "BND", "BEND", "XING", "CROSSING"
}
DIRECTIONS = {"N", "S", "E", "W", "NE", "NW", "SE", "SW"}
HOUSE_RE = re.compile(r"^\d+[A-Z]?$")


def normalize_address(raw):
    """Return (house number, street) while retaining directional prefix/suffix."""
    raw = str(raw or "").strip().upper()
    raw = re.sub(r"[,]+", " ", raw)
    raw = re.sub(r"\s+", " ", raw)
    tokens = raw.split()
    if not tokens or not HOUSE_RE.fullmatch(tokens[0]):
        raise ValueError("Cannot identify house number: {}".format(raw))

    house = tokens[0]
    remaining = tokens[1:]
    prefix = None
    if remaining and remaining[0] in DIRECTIONS:
        prefix = remaining.pop(0)

    suffix_index = next(
        (i for i, token in enumerate(remaining) if token in STREET_TYPES), None
    )
    if suffix_index is None:
        raise ValueError("Cannot identify street type: {}".format(raw))

    street_tokens = remaining[:suffix_index + 1]
    suffix_direction = None
    if suffix_index + 1 < len(remaining) and remaining[suffix_index + 1] in DIRECTIONS:
        suffix_direction = remaining[suffix_index + 1]

    street_parts = ([prefix] if prefix else []) + street_tokens + (
        [suffix_direction] if suffix_direction else []
    )
    street = " ".join(street_parts)
    if not street:
        raise ValueError("Cannot identify street name: {}".format(raw))
    return house, street


def format_addresses(raw_text, sort_house_numbers=False):
    """Group addresses by first-seen street; deduplicate house numbers."""
    lines = [line.strip() for line in str(raw_text or "").splitlines() if line.strip()]
    if not lines:
        raise ValueError("No valid address text was provided.")

    groups = {}
    street_order = []
    warnings = []
    errors = []

    for line_no, line in enumerate(lines, 1):
        try:
            house, street = normalize_address(line)
        except ValueError as exc:
            errors.append("Line {}: {}".format(line_no, exc))
            continue

        if street not in groups:
            groups[street] = []
            street_order.append(street)

        if house not in groups[street]:
            groups[street].append(house)
        else:
            warnings.append(
                "Duplicate house number {} on {} was ignored.".format(house, street)
            )

    if errors:
        raise ValueError("\n".join(errors))

    result = []
    for street in street_order:
        houses = groups[street]
        if sort_house_numbers:
            def sort_key(value):
                match = re.match(r"(\d+)([A-Z]?)$", value)
                return (int(match.group(1)), match.group(2))
            houses = sorted(houses, key=sort_key)
        result.append("{} {}".format(", ".join(houses), street))

    return ", ".join(result), warnings


def format_site_records(records):
    """Group (house_number, street_name) Site records by exact street_name.

    Street names are used as literal grouping keys: no address parser, uppercasing,
    street suffix inference, house-number sorting, or duplicate removal is performed.
    Duplicate house numbers remain because each Sites feature represents a record.
    """
    groups = {}
    street_order = []

    for record in records:
        if not record or len(record) < 2:
            continue
        house_number, street_name = record[0], record[1]
        if house_number is None or street_name is None:
            continue

        house_text = str(house_number)
        street_text = str(street_name)

        if not house_text.strip() or house_text.strip().lower() in ("null", "none", "nan"):
            continue
        if not street_text.strip() or street_text.strip().lower() in ("null", "none", "nan"):
            continue

        # Exact field value is the key. Values differing by case or whitespace remain separate.
        if street_text not in groups:
            groups[street_text] = []
            street_order.append(street_text)

        # Do not deduplicate: preserve every Site row, including repeated house numbers.
        groups[street_text].append(house_text.strip())

    result = []
    for street_name in street_order:
        result.append("{} {}".format(", ".join(groups[street_name]), street_name))
    return ", ".join(result)
