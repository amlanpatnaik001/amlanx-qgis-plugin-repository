# Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.
def classFactory(iface):
    from .qc_polygons_note_pro import QCPolygonsNotePro
    return QCPolygonsNotePro(iface)
