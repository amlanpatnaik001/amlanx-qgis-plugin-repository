QC POLYGONS NOTE PRO — CHANGELOG
Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.

Version 1.0.7
- Updated polygon geometry enum resolution for current QGIS 4 / PyQt6 APIs.
- Retained fallbacks for QGIS 3.28 and later QGIS 3 releases.
- Added multiline changelog metadata for QGIS Plugin Manager.
- Preserved note generation, exact street grouping, duplicate Site records,
  fiber-range parsing, Equipment HH address lookup, and optional comments write-back.
- Added copyright notice and release documentation.

Version 1.0.6
- Added Qt 5 / Qt 6 QAction import compatibility.
- Added QGIS 3 / QGIS 4 layer and geometry enum compatibility handling.
- Added a technical toolbar icon while keeping the action text.
- Note-generation and data-processing logic unchanged.
