# Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere.
# import qgis libs so that ve set the correct sip api version
import qgis   # pylint: disable=W0611  # NOQA
