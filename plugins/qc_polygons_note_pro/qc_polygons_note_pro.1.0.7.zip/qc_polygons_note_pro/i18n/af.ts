<?xml version="1.0" encoding="utf-8"?>
<!-- Copyright Amlan Patnaik @2077 All copyrights are reserved everywhere. -->
<!DOCTYPE TS><TS version="2.0" language="af" sourcelanguage="en">
<context>
    <name>@default</name>
    <message>
        <location filename="test_translations.py" line="48"/>
        <source>Good morning</source>
        <translation>Goeie more</translation>
    </message>
</context>
</TS>
