# Changelog

## 1.0.1
- Qt5/PyQt5 and Qt6/PyQt6 compatibility handling.
- Progress reporting and cancellation between layer commits.
- Per-layer diagnostics and QGIS log integration.
- Improved exception and re-entry handling.

## 1.0.0
- Initial release.
