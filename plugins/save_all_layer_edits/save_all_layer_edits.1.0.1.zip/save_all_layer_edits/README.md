# Save All Layer Edits — QGIS Plugin

Copyright © Amlan Patnaik @2077. All rights reserved.

## What it does

Adds a toolbar button and a Plugins-menu command called **Save All Layer Edits**. One click checks the project and commits pending edits for every valid vector layer currently in editing mode.

- Saves pending edits across all editable vector layers, not just the active layer.
- Keeps edit mode enabled after each successful commit (`commitChanges(False)`).
- Skips unchanged layers and non-vector layers.
- Shows a progress dialog and supports cancellation **between** layer commits.
- Reports successes, failures, skipped layers, elapsed time, layer IDs and provider names.
- Captures provider `commitErrors()` and logs diagnostics to **View → Panels → Log Messages** (or the QGIS Log Messages panel).
- Does not automatically roll back failed edit buffers or turn editing off.
- Uses the QGIS `qgis.PyQt` abstraction and Qt enum fallbacks for Qt5/PyQt5 and Qt6/PyQt6.

## Compatibility target

- QGIS 3.28+ (including QGIS 3.44.x)
- QGIS 4.x (including QGIS 4.2.x), subject to runtime testing against the installed QGIS build
- Uses the PyQt binding shipped by QGIS through `qgis.PyQt`; do not install or import a separate PyQt package for this plugin.

The declared metadata range is `qgisMinimumVersion=3.28` and `qgisMaximumVersion=4.99`. This does not promise compatibility with every historical standalone PyQt release or every future QGIS version.

## Install

1. Open **Plugins → Manage and Install Plugins…**.
2. Choose **Install from ZIP**.
3. Select `save_all_layer_edits.1.0.1.zip`.
4. Enable **Save All Layer Edits** if it is not enabled automatically.
5. Use the toolbar button or Plugins menu command.

## Safe commit behavior and limitations

The plugin commits layers one at a time on QGIS' main thread. This is intentional: live `QgsVectorLayer` edit buffers and provider commits must not be moved to an arbitrary worker thread. The progress dialog keeps the user informed and processes GUI events between layers. The Cancel button is honored between layer commits; it cannot interrupt a single provider/database commit already in progress. A slow database, network share, provider lock, or large transaction may therefore still block the UI until that one commit returns.

A successful layer commit clears that layer's current edit buffer but leaves the layer in editing mode. Commits are not atomic across all layers: if a later layer fails, earlier successful layer commits remain saved. If `commitChanges(False)` returns `False`, QGIS retains the uncommitted in-memory changes so the user can inspect the error, correct it, and retry. Do not close the project or discard edits when a failed layer is reported.

Always back up important data before bulk commits. Test first on a copy of the project, especially when layers use remote databases or shared storage.

## Release 1.0.1

- Added Qt5/PyQt5 and Qt6/PyQt6 import and enum compatibility.
- Added progress, safe cancellation between layer commits, and re-entry protection.
- Added per-layer provider diagnostics, QGIS Log Messages logging, and summary reporting.
- Improved exception handling during layer inspection and commits.
