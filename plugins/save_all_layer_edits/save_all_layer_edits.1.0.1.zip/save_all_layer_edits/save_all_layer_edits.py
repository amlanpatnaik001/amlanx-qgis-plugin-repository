# -*- coding: utf-8 -*-
# Copyright © Amlan Patnaik @2077. All rights reserved.

"""Save pending edits on all editable vector layers without ending edit sessions.

Layer commits intentionally run on QGIS' main thread. This is required for safe
interaction with live QgsVectorLayer edit buffers. The progress dialog keeps the
user informed and permits cancellation between layer commits; an individual
provider commit cannot be safely interrupted by this plugin.
"""

import os
import time
import traceback

from qgis.PyQt.QtCore import QCoreApplication, Qt
from qgis.PyQt.QtGui import QIcon

# QAction moved from QtWidgets (Qt5) to QtGui (Qt6).
try:
    from qgis.PyQt.QtGui import QAction
except ImportError:  # PyQt5 / older QGIS compatibility
    from qgis.PyQt.QtWidgets import QAction

from qgis.PyQt.QtWidgets import (
    QApplication,
    QMessageBox,
    QProgressDialog,
)
from qgis.core import Qgis, QgsMessageLog, QgsProject, QgsVectorLayer


COPYRIGHT = "Copyright © Amlan Patnaik @2077. All rights reserved."
PLUGIN_NAME = "Save All Layer Edits"
LOG_TAG = "Save All Layer Edits"


def _enum_value(container, enum_group, member, fallback=None):
    """Return a Qt/QGIS enum across scoped (Qt6) and unscoped (Qt5) APIs."""
    group = getattr(container, enum_group, None) if enum_group else None
    if group is not None and hasattr(group, member):
        return getattr(group, member)
    if hasattr(container, member):
        return getattr(container, member)
    return fallback


def _message_level(name):
    """Resolve QGIS message levels across QGIS 3/4 enum layouts."""
    return _enum_value(Qgis, "MessageLevel", name, getattr(Qgis, "Info", 0))


def _message_box_value(group, name):
    """Resolve QMessageBox scoped and legacy enum members."""
    return _enum_value(QMessageBox, group, name, getattr(QMessageBox, name, None))


class SaveAllLayerEditsPlugin:
    """Toolbar/menu tool to commit modified vector layers while retaining edit mode."""

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self._running = False

    def tr(self, message):
        return QCoreApplication.translate(PLUGIN_NAME, message)

    def initGui(self):
        """Create the toolbar button and Plugins-menu entry."""
        if self.action is not None:
            return

        icon_path = os.path.join(os.path.dirname(__file__), "icon.svg")
        self.action = QAction(
            QIcon(icon_path), self.tr("Save All Layer Edits"), self.iface.mainWindow()
        )
        self.action.setObjectName("SaveAllLayerEditsAction")
        self.action.setToolTip(
            self.tr("Save unsaved edits in all editable vector layers without turning editing off.\n")
            + COPYRIGHT
        )
        self.action.setStatusTip(
            self.tr("Commit pending edits for every modified editable vector layer; keep editing enabled. ")
            + COPYRIGHT
        )
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(self.tr("&Save All Layer Edits"), self.action)

    def unload(self):
        """Remove the toolbar button and menu entry."""
        if self.action is not None:
            try:
                self.iface.removeToolBarIcon(self.action)
                self.iface.removePluginMenu(self.tr("&Save All Layer Edits"), self.action)
            finally:
                self.action.deleteLater()
                self.action = None

    def _log(self, message, level_name="Info"):
        try:
            QgsMessageLog.logMessage(
                str(message), LOG_TAG, _message_level(level_name)
            )
        except Exception:
            # Logging must never prevent the remaining layer saves.
            pass

    def _notify(self, message, level_name="Info", duration=6):
        try:
            self.iface.messageBar().pushMessage(
                PLUGIN_NAME,
                str(message) + " " + COPYRIGHT,
                level=_message_level(level_name),
                duration=duration,
            )
        except Exception:
            # The detailed report remains available through the message box/log.
            self._log(message, level_name)

    @staticmethod
    def _layer_label(layer):
        try:
            name = layer.name() or "Unnamed layer"
        except Exception:
            name = "Unknown layer"
        try:
            layer_id = layer.id()
        except Exception:
            layer_id = "ID unavailable"
        try:
            provider = layer.providerType() or "unknown provider"
        except Exception:
            provider = "unknown provider"
        return "{0} [ID: {1}; provider: {2}]".format(name, layer_id, provider)

    @staticmethod
    def _commit_error_text(layer):
        try:
            errors = layer.commitErrors()
        except Exception as exc:
            errors = ["Could not read commitErrors(): {0}".format(exc)]
        cleaned = [str(item).strip() for item in (errors or []) if str(item).strip()]
        if not cleaned:
            cleaned = ["QGIS/provider returned no additional commit error details."]
        return "\n".join(cleaned)

    def _show_report(self, title, heading, details, warning=True):
        box = QMessageBox(self.iface.mainWindow())
        box.setWindowTitle(title)
        icon = _message_box_value("Icon", "Warning" if warning else "Information")
        if icon is not None:
            box.setIcon(icon)
        box.setText(heading)
        box.setInformativeText(
            self.tr("Expand Details for per-layer results and diagnostic information.")
        )
        box.setDetailedText(details + "\n\n" + COPYRIGHT)
        ok_button = _message_box_value("StandardButton", "Ok")
        if ok_button is not None:
            box.setStandardButtons(ok_button)
        # exec() is preferred in Qt6; exec_() remains available on some Qt5 builds.
        execute = getattr(box, "exec", None) or getattr(box, "exec_", None)
        if callable(execute):
            execute()
        else:
            box.open()

    def run(self):
        """Save all pending editable vector layers, keeping editing mode enabled."""
        if self._running:
            return

        self._running = True
        if self.action is not None:
            self.action.setEnabled(False)

        progress = None
        started = time.monotonic()
        saved = []
        failed = []
        skipped = []
        scan_errors = []
        cancelled = False
        pending = []

        try:
            # Snapshot the project layer collection before processing.
            try:
                project_layers = list(QgsProject.instance().mapLayers().values())
            except Exception as exc:
                self._show_report(
                    self.tr("Save All Layer Edits — Project Error"),
                    self.tr("Could not read the current project's layers."),
                    "Project scan error: {0}\n\n{1}".format(exc, traceback.format_exc()),
                    warning=True,
                )
                self._log(traceback.format_exc(), "Critical")
                return

            editable_count = 0
            for layer in project_layers:
                try:
                    if not isinstance(layer, QgsVectorLayer):
                        continue
                    if not layer.isValid():
                        skipped.append("{0}: invalid vector layer; skipped".format(self._layer_label(layer)))
                        continue
                    if not layer.isEditable():
                        continue
                    editable_count += 1
                    if layer.isModified():
                        pending.append(layer)
                except Exception as exc:
                    detail = "Layer inspection failed ({0}): {1}".format(
                        self._layer_label(layer), exc
                    )
                    scan_errors.append(detail)
                    self._log(detail + "\n" + traceback.format_exc(), "Warning")

            if not pending:
                if scan_errors or skipped:
                    details = "Editable vector layers found: {0}\nPending modified layers found: 0\n\n".format(editable_count)
                    details += "Inspection warnings:\n" + "\n".join(scan_errors + skipped)
                    self._show_report(
                        self.tr("Save All Layer Edits — Inspection Report"),
                        self.tr("No pending edits were identified; some layers could not be inspected."),
                        details,
                        warning=bool(scan_errors),
                    )
                elif editable_count == 0:
                    self._notify(
                        self.tr("No valid vector layers are currently in editing mode."),
                        "Info",
                    )
                else:
                    self._notify(
                        self.tr("No unsaved edits were found. All editable layers remain in editing mode."),
                        "Info",
                    )
                return

            progress = QProgressDialog(
                self.tr("Preparing to save edited layers…"),
                self.tr("Cancel after current layer"),
                0,
                len(pending),
                self.iface.mainWindow(),
            )
            progress.setWindowTitle(self.tr("Save All Layer Edits"))
            progress.setMinimumDuration(0)
            progress.setAutoClose(False)
            progress.setAutoReset(False)
            modality = _enum_value(Qt, "WindowModality", "WindowModal")
            if modality is not None:
                progress.setWindowModality(modality)
            progress.show()
            QApplication.processEvents()

            for index, layer in enumerate(pending, start=1):
                if progress.wasCanceled():
                    cancelled = True
                    break

                label = self._layer_label(layer)
                progress.setLabelText(
                    self.tr("Saving layer {0} of {1}:\n{2}").format(index, len(pending), label)
                )
                progress.setValue(index - 1)
                QApplication.processEvents()

                try:
                    # A provider commit can take time. It must remain on QGIS' main
                    # thread; the Cancel button is honoured between commits only.
                    if not layer.isValid():
                        skipped.append("{0}: became invalid before commit; skipped".format(label))
                    elif not layer.isEditable():
                        skipped.append("{0}: is no longer editable; skipped".format(label))
                    elif not layer.isModified():
                        skipped.append("{0}: no longer has pending changes; skipped".format(label))
                    elif layer.commitChanges(False):
                        saved.append(label)
                        self._log("Saved pending edits: {0}".format(label), "Info")
                    else:
                        message = self._commit_error_text(layer)
                        failed.append((label, message))
                        self._log(
                            "Commit failed: {0}\n{1}".format(label, message), "Critical"
                        )
                except Exception as exc:
                    message = "{0}: {1}\n\n{2}".format(
                        type(exc).__name__, exc, traceback.format_exc()
                    )
                    failed.append((label, message))
                    self._log("Unexpected layer save exception: {0}\n{1}".format(label, message), "Critical")

                progress.setValue(index)
                QApplication.processEvents()

            if progress.wasCanceled() and len(saved) + len(failed) + len(skipped) < len(pending):
                cancelled = True

            elapsed = time.monotonic() - started
            lines = [
                "Editable vector layers: {0}".format(editable_count),
                "Layers with pending edits at start: {0}".format(len(pending)),
                "Successfully saved: {0}".format(len(saved)),
                "Failed: {0}".format(len(failed)),
                "Skipped: {0}".format(len(skipped)),
                "Elapsed: {0:.2f} seconds".format(elapsed),
                "Editing mode is intentionally kept enabled for each successfully committed layer.",
            ]
            if cancelled:
                lines.append("Operation cancelled between layer commits. Remaining layers were not processed.")
            if saved:
                lines.extend(["", "SAVED LAYERS:"] + ["- " + name for name in saved])
            if failed:
                lines.append("\nFAILED LAYERS (their edit buffers are retained by QGIS when commitChanges returns False):")
                for name, error in failed:
                    lines.extend(["- " + name, textwrap_indent(error)])
            if skipped:
                lines.extend(["\nSKIPPED LAYERS:"] + ["- " + item for item in skipped])
            if scan_errors:
                lines.extend(["\nINSPECTION WARNINGS:"] + ["- " + item for item in scan_errors])

            if failed or cancelled or scan_errors:
                heading = self.tr("Saving finished with warnings.")
                if cancelled:
                    heading = self.tr("Saving was cancelled after the current layer.")
                self._show_report(
                    self.tr("Save All Layer Edits — Results"), heading,
                    "\n".join(lines), warning=True,
                )
            elif saved:
                self._notify(
                    self.tr("Saved edits for {0} layer(s). Editing mode remains enabled.").format(len(saved)),
                    "Success", duration=8,
                )
            else:
                self._show_report(
                    self.tr("Save All Layer Edits — Results"),
                    self.tr("No layer required saving."),
                    "\n".join(lines), warning=False,
                )

        except Exception as exc:
            detail = "Unexpected plugin error: {0}: {1}\n\n{2}".format(
                type(exc).__name__, exc, traceback.format_exc()
            )
            self._log(detail, "Critical")
            try:
                self._show_report(
                    self.tr("Save All Layer Edits — Unexpected Error"),
                    self.tr("The operation stopped because of an unexpected error."),
                    detail,
                    warning=True,
                )
            except Exception:
                self._notify(self.tr("An unexpected error occurred. See the QGIS Log Messages panel."), "Critical")
        finally:
            if progress is not None:
                try:
                    progress.close()
                    progress.deleteLater()
                except Exception:
                    pass
            self._running = False
            if self.action is not None:
                try:
                    self.action.setEnabled(True)
                except Exception:
                    pass


def textwrap_indent(value):
    """Indent multiline layer diagnostics for the expanded report."""
    return "  " + "\n  ".join(str(value).splitlines())
