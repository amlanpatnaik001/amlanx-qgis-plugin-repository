# Save All Layer Edits — QGIS Plugin

Copyright © Amlan Patnaik @2077. All rights reserved.

## What it does

Adds a toolbar button and a Plugins-menu command called **Save All Layer Edits**. One click checks all project layers and saves pending edits for every valid vector layer that is currently in editing mode and reports unsaved modifications.

- Saves pending edits for all matching layers, not only the active layer.
- Keeps editing mode enabled after saving, matching QGIS **Save Layer Edits** behaviour.
- Skips editable layers with no unsaved changes.
- Reports any layer that fails to save, including QGIS commit error details where available.
- Does not roll back edits or turn editing off.

## Compatibility

- Declared QGIS range: **3.0–4.99**.
- Uses the QGIS-provided `qgis.PyQt` abstraction for the active Qt binding.
- Includes compatibility handling for QAction module relocation, scoped Qt message-box enums, QGIS message-level enums, and dialog execution (`exec()` / `exec_()`).
- QGIS 3 builds using Qt 5 or Qt 6 and QGIS 4 builds using Qt 6 are the intended targets.

Compatibility metadata is a declaration, not a guarantee for every historical/future QGIS build. Test in the specific QGIS versions deployed in your environment. QGIS 2.x is not supported.

## Install

1. In QGIS, open **Plugins → Manage and Install Plugins…**.
2. Choose **Install from ZIP**.
3. Select `save_all_layer_edits.2.0.1.zip`.
4. Enable **Save All Layer Edits** if it is not enabled automatically.
5. Use the toolbar button or Plugins menu entry.

## Important behaviour

The plugin commits layer edits one layer at a time by calling `commitChanges(False)`. A successful commit leaves the layer in editing mode. If a commit fails, QGIS retains the layer's in-memory edit buffer and the plugin reports the commit errors; correct the issue and save again. Non-vector layers are not processed.

## Release integrity

Version 2.0.1 changes only cross-version compatibility imports/API access and release documentation/metadata. The layer discovery, pending-edit detection, commit order, `commitChanges(False)` call, success reporting, and failure reporting behaviour are preserved.

**Copyright © Amlan Patnaik @2077. All rights reserved.**
