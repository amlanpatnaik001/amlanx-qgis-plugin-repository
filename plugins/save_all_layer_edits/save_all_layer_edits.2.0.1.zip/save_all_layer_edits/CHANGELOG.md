# Changelog

Copyright © Amlan Patnaik @2077. All rights reserved.

## 2.0.1 — QGIS / Qt compatibility release

- Added QAction import compatibility for Qt 5 and Qt 6 module locations.
- Added support for scoped and legacy QMessageBox icon/button enums.
- Added support for scoped and legacy QGIS message-level enums.
- Added dialog execution compatibility for `exec()` and `exec_()`.
- Updated QGIS compatibility metadata to declare QGIS 3.0–4.99.
- Preserved the original layer iteration, modified-layer detection, commit order, `commitChanges(False)` behaviour, and user-facing save/failure workflow.

## 2.0.0 / 1.0.1 / 1.0.0

Previous release history retained in the repository's earlier ZIP archives.
