# -*- coding: utf-8 -*-
# Copyright © Amlan Patnaik @2077. All rights reserved.

"""QGIS plugin entry point for Save All Layer Edits."""


def classFactory(iface):
    """Load the Save All Layer Edits plugin."""
    from .save_all_layer_edits import SaveAllLayerEditsPlugin
    return SaveAllLayerEditsPlugin(iface)
