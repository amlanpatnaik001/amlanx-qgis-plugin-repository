# -*- coding: utf-8 -*-
# Copyright © Amlan Patnaik @2077. All rights reserved.

"""Save pending edits across editable vector layers without ending edit sessions."""

from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.core import Qgis, QgsProject, QgsVectorLayer
import os


COPYRIGHT = "Copyright © Amlan Patnaik @2077. All rights reserved."
PLUGIN_NAME = "Save All Layer Edits"


class SaveAllLayerEditsPlugin:
    """Toolbar/menu tool to commit edits on all modified editable vector layers."""

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.toolbar = None

    def tr(self, message):
        return QCoreApplication.translate(PLUGIN_NAME, message)

    def initGui(self):
        """Create the toolbar button and plugin-menu entry."""
        icon_path = os.path.join(os.path.dirname(__file__), "icon.svg")
        self.action = QAction(QIcon(icon_path), self.tr("Save All Layer Edits"), self.iface.mainWindow())
        self.action.setObjectName("SaveAllLayerEditsAction")
        self.action.setToolTip(
            self.tr("Save unsaved edits in all editable vector layers without turning editing off.\n")
            + COPYRIGHT
        )
        self.action.setStatusTip(
            self.tr("Commit pending edits for every modified, editable vector layer; keep editing enabled. ")
            + COPYRIGHT
        )
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(self.tr("&Save All Layer Edits"), self.action)

    def unload(self):
        """Remove the toolbar button and menu entry."""
        if self.action is not None:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu(self.tr("&Save All Layer Edits"), self.action)
            self.action.deleteLater()
            self.action = None

    def run(self):
        """Commit every pending editable vector layer, preserving edit mode."""
        editable_layers = []
        pending_layers = []

        for layer in QgsProject.instance().mapLayers().values():
            try:
                if isinstance(layer, QgsVectorLayer) and layer.isValid() and layer.isEditable():
                    editable_layers.append(layer)
                    if layer.isModified():
                        pending_layers.append(layer)
            except Exception:
                # A problematic layer should not stop other layers from being saved.
                continue

        if not editable_layers:
            self.iface.messageBar().pushMessage(
                PLUGIN_NAME,
                self.tr("No vector layers are currently in editing mode. ") + COPYRIGHT,
                level=Qgis.Info,
                duration=5,
            )
            return

        if not pending_layers:
            self.iface.messageBar().pushMessage(
                PLUGIN_NAME,
                self.tr("No unsaved edits were found. All editable layers remain in editing mode. ") + COPYRIGHT,
                level=Qgis.Info,
                duration=5,
            )
            return

        saved_names = []
        failures = []

        for layer in pending_layers:
            try:
                # stopEditing=False mirrors QGIS' "Save Layer Edits" behavior:
                # commit the buffer but leave the layer in editing mode.
                if layer.commitChanges(False):
                    saved_names.append(layer.name())
                else:
                    errors = layer.commitErrors()
                    detail = "\n".join(str(error) for error in errors if str(error).strip())
                    if not detail:
                        detail = self.tr("QGIS did not provide additional error details.")
                    failures.append((layer.name(), detail))
            except Exception as exc:
                failures.append((layer.name(), str(exc)))

        if failures:
            lines = []
            if saved_names:
                lines.append(self.tr("Successfully saved {0} layer(s): {1}.").format(
                    len(saved_names), ", ".join(saved_names)
                ))
                lines.append("")
            lines.append(self.tr("Could not save the following layer(s):"))
            for layer_name, error_text in failures:
                lines.append("\n• {0}\n  {1}".format(layer_name, error_text))
            lines.append("")
            lines.append(self.tr("Failed layers remain in editing mode; their unsaved changes were not discarded."))
            lines.append(COPYRIGHT)

            box = QMessageBox(self.iface.mainWindow())
            box.setWindowTitle(self.tr("Save All Layer Edits — Some Layers Failed"))
            box.setIcon(QMessageBox.Warning)
            box.setText(self.tr("Some layer edits could not be saved."))
            box.setInformativeText("\n".join(lines))
            box.setStandardButtons(QMessageBox.Ok)
            box.exec_()
            return

        self.iface.messageBar().pushMessage(
            PLUGIN_NAME,
            self.tr("Saved edits for {0} layer(s). Editing mode remains enabled. ").format(len(saved_names))
            + COPYRIGHT,
            level=Qgis.Success,
            duration=6,
        )
