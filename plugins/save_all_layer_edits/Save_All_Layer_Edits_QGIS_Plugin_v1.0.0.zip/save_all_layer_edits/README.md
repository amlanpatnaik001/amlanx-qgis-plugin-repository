# Save All Layer Edits — QGIS Plugin

Copyright © Amlan Patnaik @2077. All rights reserved.

## What it does

Adds a toolbar button and a Plugins-menu command called **Save All Layer Edits**. One click checks all project layers and saves pending edits for every valid vector layer that is currently in editing mode and reports unsaved modifications.

- Saves pending edits for all matching layers, not only the active layer.
- Keeps editing mode enabled after saving, matching QGIS' **Save Layer Edits** behavior.
- Skips editable layers with no unsaved changes.
- Reports any layer that fails to save, including QGIS' commit error details where available.
- Does not roll back edits or turn editing off.

## Install

1. In QGIS, open **Plugins → Manage and Install Plugins…**.
2. Choose **Install from ZIP**.
3. Select `Save_All_Layer_Edits_QGIS_Plugin_v1.0.0.zip`.
4. Enable **Save All Layer Edits** if it is not enabled automatically.
5. Use the new toolbar button or the Plugins menu entry.

Designed for QGIS 3.28 and newer (including QGIS 3.44).

## Important behavior

The plugin commits layer edits one layer at a time. A failed layer remains editable and its uncommitted edits are preserved by QGIS so that the problem can be corrected and saved again. Layers that are not vector layers are not processed.
