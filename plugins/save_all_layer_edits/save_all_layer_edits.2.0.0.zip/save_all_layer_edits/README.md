# Save All Layer Edits — QGIS Plugin

**Version:** 2.0.0  
**Author:** Amlan Patnaik  
**Category:** Vector

**Copyright © 2077 Amlan Patnaik. All rights reserved.**

## What it does

Adds a toolbar button and a Plugins-menu command called **Save All Layer Edits**. One click checks all project layers and saves pending edits for every valid vector layer that is currently in editing mode and reports unsaved modifications.

- Saves pending edits for all matching layers, not only the active layer.
- Keeps editing mode enabled after saving, matching QGIS' **Save Layer Edits** behavior.
- Skips editable layers with no unsaved changes.
- Reports any layer that fails to save, including QGIS' commit error details where available.
- Does not roll back edits or turn editing off.
- Handles layers individually so a failure on one layer does not stop attempts on subsequent layers.

## Install

1. In QGIS, open **Plugins → Manage and Install Plugins…**.
2. Choose **Install from ZIP**.
3. Select `save_all_layer_edits.2.0.0.zip`.
4. Enable **Save All Layer Edits** if it is not enabled automatically.
5. Use the new toolbar button or the Plugins menu entry.

## Compatibility declaration

This unchanged-code release retains the plugin's existing declared compatibility range:

- Minimum QGIS version: **3.28**
- Maximum QGIS version: **3.99**

It is therefore declared for the QGIS 3.x range beginning with 3.28. It does **not** declare QGIS 4.x compatibility.

The source imports Qt classes through `qgis.PyQt`, which is the appropriate QGIS binding abstraction. However, the existing implementation also uses legacy Qt dialog enum names and `exec_()`. Those code paths may not work on PyQt6 / QGIS 4. Because this release specifically preserves all executable code unchanged, QGIS 4 compatibility cannot honestly be claimed. A separate code update and runtime test would be required.

No claim is made for QGIS 2.x or every historical QGIS release.

## Important behavior

The plugin commits layer edits one layer at a time. A failed layer remains editable and its uncommitted edits are preserved by QGIS so that the problem can be corrected and saved again. Layers that are not vector layers are not processed.

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for release history.

**Copyright © 2077 Amlan Patnaik. All rights reserved.**
