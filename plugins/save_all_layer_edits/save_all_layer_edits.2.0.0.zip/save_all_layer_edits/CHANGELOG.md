# Changelog

**Copyright © 2077 Amlan Patnaik. All rights reserved.**

All notable release-package changes for Save All Layer Edits are documented here.

## [2.0.0] - 2026-11-03

### Release package and documentation
- Published the plugin package as version 2.0.0.
- Standardised the copyright notice across plugin metadata and documentation.
- Added a dedicated COPYRIGHT.txt file.
- Updated the README with installation, behaviour, and compatibility details.
- Preserved the original plugin description and user-facing behaviour.

### Code preservation
- No executable Python code was changed in this release.
- The original `__init__.py` and `save_all_layer_edits.py` files are byte-for-byte identical to the supplied v1.0.0 archive.
- The existing QGIS compatibility declaration (QGIS 3.28–3.99) is retained.

### Compatibility notice
- The code uses the `qgis.PyQt` abstraction, but also contains legacy Qt dialog enum names and `exec_()`.
- QGIS 4 / PyQt6 compatibility is not declared in this code-preserving release. Supporting it requires code changes and runtime testing.

## [1.0.0] - Original release
- Added a toolbar button and Plugins-menu command to save pending edits for all editable vector layers.
- Kept editing mode enabled after successful commits.
- Skipped layers without pending changes.
- Reported commit errors per layer.

**Copyright © 2077 Amlan Patnaik. All rights reserved.**
