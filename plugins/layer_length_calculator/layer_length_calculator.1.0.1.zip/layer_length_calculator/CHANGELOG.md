# Changelog

Copyright © 2077 Amlan Patnaik. All rights reserved.

## 1.0.1 — Compatibility release

- Added QGIS Qt binding abstraction using `qgis.PyQt` rather than a hard-coded PyQt5 import.
- Added QAction import fallback for Qt5 (QtWidgets) and Qt6 (QtGui).
- Added vector-layer and line-geometry enum fallbacks for early QGIS 3, later QGIS 3, and QGIS 4 API generations.
- Added QMessageBox scoped/legacy icon enum handling.
- Added dialog execution fallback for `exec()` and `exec_()`.
- Replaced f-strings in runtime code with equivalent `.format()` calls for compatibility with older Python 3 runtimes used by early QGIS 3 builds.
- Updated plugin metadata to declare QGIS 3.0–4.99 compatibility.
- No changes to the length-calculation algorithm, selected-feature behaviour, ellipsoid handling, unit conversions, or result dialog content.

## 0.1 — Original release

- Original Layer Length Calculator plugin.
