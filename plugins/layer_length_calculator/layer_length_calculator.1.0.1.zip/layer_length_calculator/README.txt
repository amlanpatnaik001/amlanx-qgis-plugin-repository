Layer Length Calculator
=======================

Version: 1.0.1
Author: Amlan Patnaik

Copyright © 2077 Amlan Patnaik. All rights reserved.

Overview
--------
Calculates the total length of linear features in the active QGIS vector layer.
If one or more features are selected, only the selected features are measured;
otherwise, the entire layer is measured.

Measurements
------------
The result dialog reports total length in feet, miles, metres, and kilometres.
Measurements use QgsDistanceArea with the active layer CRS and current project
transform context. The project ellipsoid is used when configured; WGS84 is used
when the project ellipsoid is unset or set to NONE.

Install from ZIP
----------------
1. In QGIS, open Plugins > Manage and Install Plugins.
2. Select Install from ZIP.
3. Choose the Layer Length Calculator ZIP archive.
4. Enable the plugin in the Installed tab if it is not enabled automatically.

Compatibility target
--------------------
The plugin metadata targets QGIS 3.0 through QGIS 4.x (maximum declared
version 4.99). It uses the QGIS-provided qgis.PyQt abstraction and Qt5/Qt6
compatibility handling. QGIS 2.x is not supported. Compatibility is declared
for the QGIS 3 and QGIS 4 API generations; runtime testing on each target
installation is still recommended.

Release 1.0.1
------------
- Use qgis.PyQt instead of a hard-coded PyQt5 import.
- Resolve QAction from QtGui on Qt6 and fall back to QtWidgets on Qt5.
- Resolve vector-layer and line-geometry enum names across early QGIS 3, later QGIS 3, and QGIS 4.
- Handle scoped and legacy QMessageBox information icons.
- Use exec() where available and fall back to exec_() for older Qt bindings.
- Replace runtime f-strings with equivalent format strings to retain parsing
  support on older Python 3 runtimes used by early QGIS 3 builds.
- No change to feature selection, geometry measurement, ellipsoid selection,
  unit conversion, or result presentation logic.

Copyright
---------
Copyright © 2077 Amlan Patnaik. All rights reserved.

The plugin's existing GPL licence terms are retained.
