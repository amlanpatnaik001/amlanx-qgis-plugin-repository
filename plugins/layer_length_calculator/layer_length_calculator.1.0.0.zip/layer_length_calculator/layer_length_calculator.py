# -*- coding: utf-8 -*-
"""Layer Length Calculator QGIS plugin.

Measures selected line features, or all line features when nothing is selected,
using QgsDistanceArea and the project's ellipsoid. The result is reported in
feet, miles, metres and kilometres.

Copyright (C) 2026 Amlan Patnaik
SPDX-License-Identifier: GPL-2.0-or-later
"""

from __future__ import annotations

import html
import math
import os
import traceback

from qgis.PyQt.QtCore import QCoreApplication, QLocale, QTranslator, Qt
from qgis.PyQt.QtGui import QIcon
try:  # QAction moved from QtWidgets to QtGui in Qt 6.
    from qgis.PyQt.QtGui import QAction
except ImportError:  # Qt 5 / PyQt5
    from qgis.PyQt.QtWidgets import QAction

from qgis.PyQt.QtWidgets import QApplication, QMessageBox, QProgressDialog
from qgis.core import (
    Qgis,
    QgsDistanceArea,
    QgsMessageLog,
    QgsProject,
    QgsSettings,
    QgsVectorLayer,
)
try:
    from qgis.core import QgsWkbTypes
except ImportError:  # QGIS 4 scoped geometry enums are exposed through Qgis.
    QgsWkbTypes = None


PLUGIN_LOG_TAG = "Layer Length Calculator"
METERS_TO_FEET = 3.280839895013123
FEET_PER_MILE = 5280.0


def _enum_member(owner, group_name, member_names):
    """Return the first available enum member across Qt/QGIS API generations."""
    if owner is None:
        return None
    group = getattr(owner, group_name, None) if group_name else None
    for candidate_owner in (group, owner):
        if candidate_owner is None:
            continue
        for member_name in member_names:
            value = getattr(candidate_owner, member_name, None)
            if value is not None:
                return value
    return None


def _message_icon(name):
    """Resolve QMessageBox icons in both legacy and scoped-enum bindings."""
    return _enum_member(QMessageBox, "Icon", (name,))


def _window_modal_value():
    """Resolve Qt window modality across PyQt5 and PyQt6."""
    return _enum_member(Qt, "WindowModality", ("WindowModal",))


def _rich_text_value():
    """Resolve the rich-text enum across PyQt5 and PyQt6."""
    return _enum_member(Qt, "TextFormat", ("RichText",))


def _is_line_geometry(layer):
    """Check line geometry using QGIS 3 legacy or QGIS 4 scoped enums."""
    try:
        geometry_type = layer.geometryType()
    except Exception:
        return False

    candidates = [
        _enum_member(Qgis, "GeometryType", ("Line",)),
        _enum_member(QgsWkbTypes, "GeometryType", ("Line",)),
        getattr(QgsWkbTypes, "LineGeometry", None),
    ]
    for candidate in candidates:
        if candidate is not None:
            try:
                if geometry_type == candidate:
                    return True
            except Exception:
                pass

    # Last-resort compatibility for bindings which stringify enum values.
    try:
        return "line" in str(geometry_type).lower()
    except Exception:
        return False


def _log_message(message, level_name="Warning"):
    """Write diagnostics to QGIS Log Messages without relying on one enum API."""
    try:
        level = _enum_member(Qgis, "MessageLevel", (level_name,))
        if level is None:
            level = getattr(Qgis, level_name, None)
        if level is None:
            level = 1
        QgsMessageLog.logMessage(str(message), PLUGIN_LOG_TAG, level)
    except Exception:
        # Logging must never cause the plugin itself to fail.
        pass


class LayerLengthCalculator:
    """QGIS plugin implementation."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = self.tr("&Layer Length Calculator")
        self.translator = None

        try:
            locale = QgsSettings().value("locale/userLocale", QLocale().name())
            locale = str(locale or QLocale().name())[:2]
            locale_path = os.path.join(self.plugin_dir, "i18n", "{}.qm".format(locale))
            if os.path.isfile(locale_path):
                translator = QTranslator()
                if translator.load(locale_path):
                    QCoreApplication.installTranslator(translator)
                    self.translator = translator
        except Exception as exc:
            _log_message("Could not load plugin translation: {}".format(exc), "Warning")

    def tr(self, message):
        return QCoreApplication.translate("LayerLengthCalculator", message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None,
    ):
        """Create and register a QGIS menu/toolbar action."""
        action = QAction(QIcon(icon_path), text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)
        if status_tip:
            action.setStatusTip(status_tip)
        if whats_this:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.iface.addToolBarIcon(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)
        self.actions.append(action)
        return action

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        self.add_action(
            icon_path,
            text=self.tr("Calculate Active Layer Length"),
            callback=self.run,
            status_tip=self.tr("Measure selected or all line features in the active layer"),
            parent=self.iface.mainWindow(),
        )

    def unload(self):
        """Remove all registered QGIS actions and translator resources."""
        for action in list(self.actions):
            try:
                self.iface.removePluginMenu(self.menu, action)
            except Exception as exc:
                _log_message("Could not remove plugin menu action: {}".format(exc))
            try:
                self.iface.removeToolBarIcon(action)
            except Exception as exc:
                _log_message("Could not remove plugin toolbar action: {}".format(exc))
        self.actions.clear()
        if self.translator is not None:
            try:
                QCoreApplication.removeTranslator(self.translator)
            except Exception as exc:
                _log_message("Could not remove plugin translator: {}".format(exc))
            self.translator = None

    def _show_message(self, title, message, icon_name="Information"):
        """Display a message using a Qt5/Qt6-compatible QMessageBox."""
        try:
            parent = self.iface.mainWindow() if self.iface else None
        except Exception:
            parent = None
        box = QMessageBox(parent)
        box.setWindowTitle(str(title))
        box.setText(str(message))
        icon = _message_icon(icon_name)
        if icon is not None:
            box.setIcon(icon)
        rich_text = _rich_text_value()
        if rich_text is not None:
            try:
                box.setTextFormat(rich_text)
            except Exception:
                pass
        execute = getattr(box, "exec", None) or getattr(box, "exec_", None)
        if callable(execute):
            execute()

    def _create_progress(self, maximum, parent):
        """Create progress UI with compatible modality enums."""
        maximum = max(0, int(maximum)) if maximum is not None else 0
        progress = QProgressDialog(
            self.tr("Calculating line length..."),
            self.tr("Cancel"),
            0,
            maximum,
            parent,
        )
        progress.setWindowTitle(self.tr("Layer Length Calculator"))
        progress.setMinimumDuration(500)
        progress.setAutoClose(True)
        progress.setAutoReset(False)
        modality = _window_modal_value()
        if modality is not None:
            try:
                progress.setWindowModality(modality)
            except Exception:
                pass
        return progress

    def run(self):
        """Measure the active line layer with progress and defensive error handling."""
        layer = None
        progress = None
        try:
            layer = self.iface.activeLayer()
            if layer is None:
                self._show_message(
                    self.tr("No active layer"),
                    self.tr("Select a line vector layer in the Layers panel and try again."),
                    "Warning",
                )
                return

            if not isinstance(layer, QgsVectorLayer):
                self._show_message(
                    self.tr("Invalid layer"),
                    self.tr("The active layer is not a vector layer."),
                    "Warning",
                )
                return

            if not layer.isValid():
                self._show_message(
                    self.tr("Invalid layer"),
                    self.tr("The active vector layer is invalid or its data source is unavailable."),
                    "Critical",
                )
                return

            if not _is_line_geometry(layer):
                self._show_message(
                    self.tr("Invalid geometry type"),
                    "<b>{}</b> is not a line or multiline layer.".format(
                        html.escape(layer.name())
                    ),
                    "Warning",
                )
                return

            project = QgsProject.instance()
            distance_area = QgsDistanceArea()
            source_crs = layer.crs()
            if not source_crs or not source_crs.isValid():
                self._show_message(
                    self.tr("Invalid coordinate reference system"),
                    self.tr("The active layer has no valid CRS. Assign a valid CRS before measuring."),
                    "Critical",
                )
                return
            distance_area.setSourceCrs(source_crs, project.transformContext())

            ellipsoid = str(project.ellipsoid() or "").strip()
            if not ellipsoid or ellipsoid.upper() == "NONE":
                ellipsoid = "WGS84"
            try:
                ellipsoid_ok = distance_area.setEllipsoid(ellipsoid)
            except Exception:
                ellipsoid_ok = False
            if ellipsoid_ok is False:
                ellipsoid = "WGS84"
                try:
                    distance_area.setEllipsoid(ellipsoid)
                except Exception as exc:
                    raise RuntimeError("Could not configure distance ellipsoid: {}".format(exc))

            try:
                selected_count = int(layer.selectedFeatureCount())
            except Exception:
                selected_count = len(layer.selectedFeatures())
            has_selection = selected_count > 0
            scope_text = self.tr("Selected features only") if has_selection else self.tr("Entire layer")

            if has_selection:
                selected_iterator = getattr(layer, "getSelectedFeatures", None)
                features = selected_iterator() if callable(selected_iterator) else iter(layer.selectedFeatures())
                expected_count = selected_count
            else:
                features = layer.getFeatures()
                try:
                    expected_count = int(layer.featureCount())
                except Exception:
                    expected_count = -1

            progress_maximum = expected_count if expected_count >= 0 else 0
            parent = self.iface.mainWindow() if self.iface else None
            progress = self._create_progress(progress_maximum, parent)
            progress.show()

            total_length_meters = 0.0
            processed_count = 0
            measured_count = 0
            skipped_empty_count = 0
            failed_count = 0
            failure_examples = []
            cancelled = False

            for feature in features:
                if progress.wasCanceled():
                    cancelled = True
                    break

                processed_count += 1
                try:
                    geometry = feature.geometry()
                    if geometry is None or geometry.isNull() or geometry.isEmpty():
                        skipped_empty_count += 1
                    else:
                        length_meters = float(distance_area.measureLength(geometry))
                        if not math.isfinite(length_meters) or length_meters < 0:
                            raise ValueError("Measurement returned an invalid length")
                        total_length_meters += length_meters
                        measured_count += 1
                except Exception as feature_error:
                    failed_count += 1
                    if len(failure_examples) < 5:
                        try:
                            feature_id = feature.id()
                        except Exception:
                            feature_id = "unknown"
                        failure_examples.append("Feature {}: {}".format(feature_id, feature_error))

                # Update every 50 features to keep UI overhead low on large layers.
                if processed_count % 50 == 0:
                    if expected_count > 0:
                        progress.setValue(min(processed_count, expected_count))
                    progress.setLabelText(
                        self.tr("Processed {:,} features; measured {:,}...").format(
                            processed_count, measured_count
                        )
                    )
                    QApplication.processEvents()

            if expected_count > 0:
                progress.setValue(min(processed_count, expected_count))
            QApplication.processEvents()
            cancelled = cancelled or progress.wasCanceled()
            progress.close()
            progress = None

            total_feet = total_length_meters * METERS_TO_FEET
            total_miles = total_feet / FEET_PER_MILE
            total_km = total_length_meters / 1000.0

            status_line = (
                "<b>Result:</b> {}".format(
                    self.tr("Cancelled by user; partial result shown") if cancelled else self.tr("Completed")
                )
            )
            message_parts = [
                status_line,
                "<b>{}</b> {}".format(self.tr("Layer name:"), html.escape(layer.name())),
                "<b>{}</b> {}".format(self.tr("Layer CRS:"), html.escape(source_crs.authid() or self.tr("Unknown"))),
                "<b>{}</b> {}".format(self.tr("Ellipsoid:"), html.escape(ellipsoid)),
                "<b>{}</b> {}".format(self.tr("Calculation scope:"), html.escape(scope_text)),
                "<b>{}</b> {:,}".format(self.tr("Features processed:"), processed_count),
                "<b>{}</b> {:,}".format(self.tr("Features measured:"), measured_count),
                "<b>{}</b> {:,}".format(self.tr("Empty geometries skipped:"), skipped_empty_count),
                "<b>{}</b> {:,}".format(self.tr("Feature measurement errors:"), failed_count),
                "<br><b>{}</b> {:,.2f} ft".format(self.tr("Total length (feet):"), total_feet),
                "<b>{}</b> {:,.4f} mi".format(self.tr("Total length (miles):"), total_miles),
                "<b>{}</b> {:,.2f} m".format(self.tr("Total length (metres):"), total_length_meters),
                "<b>{}</b> {:,.3f} km".format(self.tr("Total length (kilometres):"), total_km),
            ]
            if failure_examples:
                message_parts.append("<br><b>{}</b><br>{}".format(
                    self.tr("First measurement errors:"),
                    "<br>".join(html.escape(item) for item in failure_examples),
                ))
                _log_message("\n".join(failure_examples), "Warning")

            message = "<br>".join(message_parts)
            icon_name = "Warning" if failed_count else "Information"
            if cancelled:
                icon_name = "Warning"
            self._show_message(self.tr("Layer Length Summary"), message, icon_name)

        except Exception as exc:
            details = "{}\n{}".format(exc, traceback.format_exc())
            _log_message(details, "Critical")
            if progress is not None:
                try:
                    progress.close()
                except Exception:
                    pass
            self._show_message(
                self.tr("Length calculation failed"),
                "{}<br><br><b>{}</b><pre>{}</pre>".format(
                    self.tr("The calculation could not be completed. See QGIS Log Messages for details."),
                    self.tr("Error:"),
                    html.escape(str(exc)),
                ),
                "Critical",
            )
