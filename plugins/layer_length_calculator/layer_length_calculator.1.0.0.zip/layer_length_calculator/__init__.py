# -*- coding: utf-8 -*-

"""QGIS plugin entry point for Layer Length Calculator."""


def classFactory(iface):
    """Create the plugin instance (QGIS plugin loading contract)."""
    from .layer_length_calculator import LayerLengthCalculator
    return LayerLengthCalculator(iface)
