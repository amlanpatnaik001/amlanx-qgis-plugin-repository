# Layer Length Calculator

**Version:** 1.0.0  
**Author:** Amlan Patnaik  
**Plugin ID:** `layer_length_calculator`

## Overview

Calculate the total length of line features in the active QGIS vector layer. If one or more features are selected, only the selected features are measured. If no features are selected, the whole layer is measured.

The plugin uses `QgsDistanceArea` with the layer CRS and the current QGIS project ellipsoid, then reports the result in feet, miles, metres and kilometres.

## Features

- Selection-aware measurements.
- Whole-layer measurements when no features are selected.
- Ellipsoidal measurement using the project ellipsoid (WGS84 fallback when the project ellipsoid is unset).
- Progress feedback and cancellation between features.
- Empty geometries are skipped and counted.
- Per-feature measurement errors are reported without abandoning the remaining features.
- Diagnostic details are written to **View → Panels → Log Messages** (Layer Length Calculator tag).
- Qt imports use the QGIS `qgis.PyQt` abstraction with Qt5/Qt6 QAction compatibility.

## Compatibility target

- QGIS 3.28 and later in the QGIS 3 series.
- QGIS 4.x (metadata advertises up to 4.99).
- Qt5/PyQt5 and Qt6/PyQt6 builds bundled with supported QGIS versions.

This is a compatibility target, not a promise for every historical QGIS or standalone PyQt release. Runtime validation is still required on each QGIS build you deploy.

## Installation

Install through the AMLAN-X QGIS Plugin Repository or use **Plugins → Manage and Install Plugins → Install from ZIP**.

## Usage

1. Select a line or multiline vector layer in the Layers panel.
2. Optionally select specific features on the map or in the attribute table.
3. Run **Plugins → Layer Length Calculator → Calculate Active Layer Length** (or use its toolbar button).
4. Review the calculation scope, feature counts, ellipsoid and unit totals.
5. For large layers, use the progress dialog to monitor the scan or cancel between feature measurements.

## Notes and limitations

- The plugin reads features; it does not modify the layer or its attributes.
- Cancellation is checked between features. A single exceptionally complex geometry measurement cannot be interrupted mid-call.
- Lengths are measured through QGIS `QgsDistanceArea`; results depend on the layer CRS and selected ellipsoid.
- QGIS/PyQt must be installed and supported by the host QGIS application. The plugin does not support arbitrary standalone PyQt installations outside QGIS.

## Licence

GPL-2.0-or-later. The source headers in this package carry the same licence notice.
