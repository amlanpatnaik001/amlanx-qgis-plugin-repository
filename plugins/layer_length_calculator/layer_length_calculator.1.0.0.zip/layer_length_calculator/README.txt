Layer Length Calculator
=======================
Version: 1.0.0
Author: Amlan Patnaik

See README.md for installation, usage, compatibility targets and limitations.

This distribution removes the original Plugin Builder machine-specific paths.
Licence: GPL-2.0-or-later.
